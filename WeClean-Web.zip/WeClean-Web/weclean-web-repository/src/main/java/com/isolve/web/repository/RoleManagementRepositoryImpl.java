package com.isolve.web.repository;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.isolve.web.model.MenuUserRights;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RoleActionForSpecificIDReqModel;
import com.isolve.web.model.RoleActionForSpecificIDResModel;
import com.isolve.web.model.RolePermissionReqModel;
import com.isolve.web.model.RoleTargetActionReqModel;
import com.isolve.web.model.RoleTargetsResponseModel;
import com.isolve.web.model.RolesResponseModel;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.MyObject;
import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;
import com.microsoft.sqlserver.jdbc.SQLServerException;

@Repository
public class RoleManagementRepositoryImpl implements IRoleManagementRepository
{

	@Autowired
	EntityManager entityManager;

	Logger log = LoggerFactory.getLogger(RepeatCollectionRepositoryImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getRoleTargets()
	{

		List<RoleTargetsResponseModel> roleManagement = new ArrayList<>();
		ResponseModel responseModel = new ResponseModel();
		try
		{
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_ROLE_TARGETS, RoleTargetsResponseModel.class);
			roleManagement = query.getResultList();
			responseModel.setStatusCode(200);
			responseModel.setRespList(roleManagement);
		}
		finally 
		{
			entityManager.close();
		}
		//log.info("resp----"+responseModel);
		return responseModel;

	}
	
	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getRoles()
	{

		List<RolesResponseModel> rolesResponseModels = new ArrayList<>();
		ResponseModel responseModel = new ResponseModel();
		try
		{
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_ROLE_ROLES, RolesResponseModel.class);
			rolesResponseModels = query.getResultList();
			responseModel.setStatusCode(200);
			responseModel.setRespList(rolesResponseModels);
		}
		finally 
		{
			entityManager.close();
		}
		//log.info("resp----"+responseModel);
		return responseModel;

	}
	
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel saveTargetActionRole(RoleTargetActionReqModel reqModel) throws SQLServerException {

		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			SQLServerDataTable menuUser = new SQLServerDataTable();
			menuUser.addColumnMetadata("ROLEID", java.sql.Types.INTEGER);
			menuUser.addColumnMetadata("TARGETACTIONID", java.sql.Types.INTEGER);
			menuUser.addColumnMetadata("CREATEDBY", java.sql.Types.BIGINT);
			menuUser.addColumnMetadata("MENUTARGET", java.sql.Types.INTEGER);
			menuUser.addColumnMetadata("EXECUTE", java.sql.Types.INTEGER);
			menuUser.addColumnMetadata("LANDING", java.sql.Types.INTEGER);
			
			for (MenuUserRights d : reqModel.getMenuUserRights()) {			
				menuUser.addRow(d.getRoleid(),d.getTargetactionid(),d.getCreatedby(),d.getMenutarget(),d.getExecute(),d.getLanding());
			}
			
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection.prepareCall("{call USP_INSERT_ROLE_SAVETARGETACTIONROLE_NEW(?,?,?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					cs.setStructured(1, "dbo.UTT_MENU_USER_RIGHTS", menuUser);
					cs.setInt(2, reqModel.getActionstatus());
					cs.setString(3, reqModel.getRolename());
					cs.setString(4, reqModel.getRolediscription());
					cs.setInt(5, reqModel.getRolestatus());
//					cs.execute();
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info("set--"+set);
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("Response", l_lstResult);
			}
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}//log.info("responseModel---"+responseModel);
		return responseModel;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel getRoleActionForSpecificId(RoleActionForSpecificIDReqModel reqModel) throws SQLServerException{
		
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection.prepareCall("{call USP_GET_ROLE_ACTIONSFORSPECIFICTARGETID(?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					cs.setInt(1, reqModel.getRoleid());
					cs.setInt(2, reqModel.getTargetid());
					cs.setInt(3, reqModel.getMenutarget());
//					cs.execute();
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info("set--"+set);
			// Create properties
			int count=0;
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				count++;
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				if (count == 1) {
					 properties.put("targetaction", l_lstResult);
				 } else if (count == 2) {
					 properties.put("Roles", l_lstResult);
				 } 
				
			}
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}//log.info("responseModel---"+responseModel);
		return responseModel;
	}
		
		

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getUserRolePermission(RolePermissionReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_ROLE_USERROLE_VIEWPERMISSION_REPORTS(?,?)}");
				callableStatement.setLong(1, reqModel.getUserid());
				callableStatement.setInt(2, reqModel.getLang_id());
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getUserRolePermission", l_lstResult);
			}
			
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}//log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getroleuseroleservicesteps(RolePermissionReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_ROLE_USERROLE_SERVICE_STEPS(?,?)}");
				callableStatement.setLong(1, reqModel.getUserid());
				callableStatement.setInt(2, reqModel.getLang_id());
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getUserRolePermission", l_lstResult);
			}
			
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}//log.info("responseModel--"+responseModel);
		return responseModel;
	}

}
