package com.isolve.common.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.isolve.common.model.RequestModel;
import com.isolve.common.model.ResponseModel;
import com.isolve.common.service.IAppWebTokenService;
import com.isolve.common.utils.CommonConstants;
import com.isolve.common.utils.Utils;

@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
public class AppWebTokenController {

	@Autowired
	private IAppWebTokenService iAppWebTokenService;

	/**
	 * @author
	 * @Name createAuthenticationToken - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: createAuthenticationToken method using to validate the auth Token.
	 */
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/" + CommonConstants.GENERATE_TOKEN, method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iAppWebTokenService.createAuthenticationToken(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name appWebLogin - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: appWebLogin method using to login Web.
	 */
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/" + CommonConstants.LOGIN, method = RequestMethod.POST)
	public ResponseEntity<?> appWebLogin(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iAppWebTokenService.appWebLogin(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name appLogout - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: appLogout method using to logout the WEB page.
	 */
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/" + CommonConstants.APP_LOGOUT, method = RequestMethod.POST)
	public ResponseEntity<?> appLogout(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iAppWebTokenService.logout(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name signUpDetails - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: signUpDetails method using to insert sign up web page.
	 */
	@RequestMapping(value = "/" + CommonConstants.SIGNUP, method = RequestMethod.POST)
	public ResponseEntity<?> signUpDetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iAppWebTokenService.signUpDetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name generateOTP - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: generateOTP method using to generate OTP for mobile.
	 */
	@RequestMapping(value = "/" + CommonConstants.GENERATE_OTP, method = RequestMethod.POST)
	public ResponseEntity<?> generateOTP(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iAppWebTokenService.generateOTP(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name verifyOTP - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: verifyOTP method using to verify generated OTP.
	 */
	@RequestMapping(value = "/" + CommonConstants.VERIFY_OTP, method = RequestMethod.POST)
	public ResponseEntity<?> verifyOTP(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iAppWebTokenService.verifyOTP(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

}
