package com.isolve.web.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class BioBankResponseModel implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7373608550742005618L;
	@Id
	private Long orderid;
	private String crm_id;
	private String kit_box_id;
	private String patient_name;
	private String client_name;
	private String paramedic_name;
	private String pickup_type;
	private Date pickup_time;
	private String client_type;
	private Date received_time;
	private Long total_samples;		
	private Long lc_vd_venid;
	private String lc_or_enrolement_id;
}
