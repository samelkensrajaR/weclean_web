package com.isolve.web.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UpdateUserApproveRejectRequestModel 
{
	private Long userid; 
	private Long approverid;
	private Integer apprejsts;
	private Long roleid;
	private String remarks; 	
}
