package com.isolve.web.repository;

import java.io.IOException;

import com.isolve.web.model.AppUsageStatusReportRequestModel;
import com.isolve.web.model.ReportsReqModel;

import java.util.List;

import com.isolve.web.model.ResponseModel;
import com.microsoft.sqlserver.jdbc.SQLServerException;

public interface IReportRepository{

	ResponseModel getAppUsageStatusReport(AppUsageStatusReportRequestModel requestModel) throws SQLServerException;
  
	ResponseModel getCashCollectionTrackReport(AppUsageStatusReportRequestModel reqModel);

	ResponseModel getCenterwiseSampleCollectionStatusReport(AppUsageStatusReportRequestModel requestModel);

	ResponseModel getParamedicTatReport(AppUsageStatusReportRequestModel reqModel);

	ResponseModel getBeatvsVisitComplianceTrackerReport(AppUsageStatusReportRequestModel requestModel);

	ResponseModel viewReports(ReportsReqModel reqModel);
	

	
	ResponseModel getOrderHandOverType();

	ResponseModel getPendingReports(ReportsReqModel reportsReqModel) throws IOException;
	
	ResponseModel updateReportPath(ReportsReqModel reqModel);
	
		ResponseModel getRepositoryReports(ReportsReqModel reqModel);

		ResponseModel getReportMaster(ReportsReqModel reqModel);

	
}
