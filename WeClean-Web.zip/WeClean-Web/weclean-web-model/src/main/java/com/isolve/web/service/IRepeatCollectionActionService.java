package com.isolve.web.service;

import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;

public interface IRepeatCollectionActionService {

	public ResponseModel getRepeatCollectionAction(RequestModel requestModel);

}
