package com.isolve.web.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.isolve.web.model.BioBankReceiveSampleModel;
import com.isolve.web.model.BioBankResponseModel;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@Transactional
@Repository
public class BioBankRepositoryImpl implements IBioBankRepository{
	
	@Autowired
	private EntityManager entityManager;
	
	Logger log = LoggerFactory.getLogger(BioBankRepositoryImpl.class);

	@SuppressWarnings("unchecked")
	@Override
	public List<BioBankResponseModel> getReceiveBioBankSample(BioBankReceiveSampleModel bioBankReceiveModel) {
		List<BioBankResponseModel> bankResponseModels = new ArrayList<>();
		try {
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_BIO_RECEIVE_DETAILS,BioBankResponseModel.class);
			query.registerStoredProcedureParameter(CommonConstants.PARAMEDICID, Long.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.SCHSTARTDATETIME, Date.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.SCHENDDATETIME, Date.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.RPTTYPE, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.ORDERORIGINATION, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.CLIENTID, Long.class, ParameterMode.IN);
			query.setParameter(CommonConstants.PARAMEDICID, bioBankReceiveModel.getParamedicID());
			query.setParameter(CommonConstants.SCHSTARTDATETIME, Utils.utilDateToSqlDate(bioBankReceiveModel.getSchStartdatetime()));
			query.setParameter(CommonConstants.SCHENDDATETIME, Utils.utilDateToSqlDate(bioBankReceiveModel.getSchEnddatetime()));
			query.setParameter(CommonConstants.RPTTYPE, bioBankReceiveModel.getRptType());
			query.setParameter(CommonConstants.ORDERORIGINATION, bioBankReceiveModel.getOrderOrigination());
			query.setParameter(CommonConstants.CLIENTID, bioBankReceiveModel.getClientID());		
			bankResponseModels = query.getResultList();
		} finally {
			entityManager.close();
		}

		return bankResponseModels;
	}
}
