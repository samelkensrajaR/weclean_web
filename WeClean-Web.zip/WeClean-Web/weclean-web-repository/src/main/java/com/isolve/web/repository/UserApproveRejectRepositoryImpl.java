package com.isolve.web.repository;

import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.UpdateUserApproveRejectRequestModel;
import com.isolve.web.utils.CommonConstants;

@Transactional
@Repository
public class UserApproveRejectRepositoryImpl implements IUserApproveRejectRepository
{

	@Autowired
	private EntityManager entityManager;

	Logger log = LoggerFactory.getLogger(UserApproveRejectRepositoryImpl.class);

	@Override
	public ResponseModel updateUserApproveReject(UpdateUserApproveRejectRequestModel approveRejectRequestModel) throws SQLException
	{
		ResponseModel responseModel = new ResponseModel();
		try {
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_UPDATE_USER_APPROVE);
			query.registerStoredProcedureParameter(CommonConstants.USERID, Long.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.APPROVERID, Long.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.APPREJSTS, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.ROLEID, Long.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.REMARKS, String.class, ParameterMode.IN);
			query.setParameter(CommonConstants.USERID, approveRejectRequestModel.getUserid());
			query.setParameter(CommonConstants.APPROVERID, approveRejectRequestModel.getApproverid());
			query.setParameter(CommonConstants.APPREJSTS, approveRejectRequestModel.getApprejsts());
			query.setParameter(CommonConstants.ROLEID, approveRejectRequestModel.getRoleid());
			query.setParameter(CommonConstants.REMARKS, approveRejectRequestModel.getRemarks());
			Object[] object = (Object[]) query.getSingleResult();
			responseModel.setStatusCode((Integer)object[0]);
			responseModel.setMessage((String)object[1]);
		} finally {
			entityManager.close();
		}
		return responseModel;
	}
}
