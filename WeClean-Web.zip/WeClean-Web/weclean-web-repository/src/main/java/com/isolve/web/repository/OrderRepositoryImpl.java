package com.isolve.web.repository;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.isolve.web.model.GrommingstandardsReqModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.MyObject;
import com.isolve.web.utils.Utils;
import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;
import com.microsoft.sqlserver.jdbc.SQLServerException;

@Repository
public class OrderRepositoryImpl implements IOrderRepository {

	Logger log = LoggerFactory.getLogger(OrderRepositoryImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	

@SuppressWarnings({ "unchecked", "rawtypes" })
@Override
public ResponseModel  getTrainingVideosDetails(GrommingstandardsReqModel reqModel) {
	ResponseModel responseModel = new ResponseModel();
	try {
		List prmtrsList = new ArrayList();
		prmtrsList.add(new SqlParameter(Types.INTEGER));
		prmtrsList.add(new SqlParameter(Types.INTEGER));
		prmtrsList.add(new SqlParameter(Types.VARCHAR));
		prmtrsList.add(new SqlParameter(Types.VARCHAR));
		
		
		

		Map<String, Object> resultData = jdbcTemplate.call(connection -> {
			CallableStatement callableStatement = connection
					.prepareCall("{call USP_GET_TRAINING_VIDEOS_DETAILS(?,?,?,?)}");
	
			callableStatement.setInt(1, reqModel.getStart());
			callableStatement.setInt(2, reqModel.getEnd());
			callableStatement.setString(3, reqModel.getStatus());
			callableStatement.setString(4, reqModel.getSearch());
			
			return callableStatement;
		}, prmtrsList);
		Set<String> set = new HashSet<>();
		set = resultData.keySet();
		log.info(set.toString());
		// Create properties
		HashMap<String, Object> properties = new HashMap<>();
		for (String key : set) {
			List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
					.get(key);
			properties.put("getTrainingVideosDetails", l_lstResult);
		}
		
		MyObject object = new MyObject(properties);
		responseModel.setResponseObject(object);
		responseModel.setStatusCode(200);
	} finally {
		try {
			jdbcTemplate.getDataSource().getConnection().close();
		} catch (SQLException e) {
			e.printStackTrace();
			log.debug(e.getMessage());
		}
	}//log.info("responseModel--"+responseModel);
	return responseModel;
}


@SuppressWarnings({ "unchecked", "rawtypes" })
@Override
public ResponseModel insertupdateTrainingVideos(GrommingstandardsReqModel reqModel)
		 {
	ResponseModel responseModel = new ResponseModel();
	try {
		List prmtrsList = new ArrayList();
		
		Map<String, Object> resultData = jdbcTemplate.call(connection -> {
			CallableStatement callableStatement = connection
					.prepareCall("{call "+CommonConstants.USP_INSERT_UPDATE_TRAINING_VIDEOS+"(?,?,?,?,?,?,?,?,?)}");
			
			if (reqModel.getFlag() != null) {
			callableStatement.setInt(1, reqModel.getFlag());
			} else {
				callableStatement.setString(1, null);
			}
			if (reqModel.getTitle() != null) {
			callableStatement.setString(2, reqModel.getTitle());
			} else {
				callableStatement.setString(2, null);
			}
			
			callableStatement.setString(3, reqModel.getUserid());
			
			if (reqModel.getDiscription() != null) {
			callableStatement.setString(4, reqModel.getDiscription());
			} else {
				callableStatement.setString(4, null);
			}
			
			callableStatement.setString(5, reqModel.getActiveflag());
			
			if (reqModel.getVideoid() != null) {
			callableStatement.setInt(6, reqModel.getVideoid());
			} else {
				callableStatement.setString(6, null);
			}
			if (reqModel.getOrder() != null) {
			callableStatement.setLong(7, reqModel.getOrder());
			} else {
				callableStatement.setString(7, null);
			}
			if (reqModel.getVideourl() != null) {
			callableStatement.setString(8, reqModel.getVideourl());
			} else {
				callableStatement.setString(8, null);
			}
			
				callableStatement.setString(9, reqModel.getDuration());
				
		
			return callableStatement;
		}, prmtrsList);
		Set<String> set = new HashSet<>();
		set = resultData.keySet();
		//log.info(set.toString());
		// Create properties
		HashMap<String, Object> properties = new HashMap<>();
		for (String key : set) {
			List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
					.get(key);				
			properties.put("insertupdateTrainingVideos", l_lstResult);
		}		
		responseModel.setResponseObject(properties);
		responseModel.setStatusCode(200);
	} finally {
		try {
			jdbcTemplate.getDataSource().getConnection().close();
		} catch (SQLException e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
		}
	}
	return responseModel;
}


@SuppressWarnings({ "unchecked", "rawtypes" })
@Override
public ResponseModel  getgrommingstandardsdetailsExports(GrommingstandardsReqModel reqModel) {
	ResponseModel responseModel = new ResponseModel();
	try {
		List prmtrsList = new ArrayList();
	
		prmtrsList.add(new SqlParameter(Types.VARCHAR));
		
		

		Map<String, Object> resultData = jdbcTemplate.call(connection -> {
			CallableStatement callableStatement = connection
					.prepareCall("{call USP_GET_GROOMING_STANDARDS_DETAILS_EXPORTS(?)}");
	
			
			callableStatement.setString(1, reqModel.getStatus());
			
			return callableStatement;
		}, prmtrsList);
		Set<String> set = new HashSet<>();
		set = resultData.keySet();
		log.info(set.toString());
		// Create properties
		HashMap<String, Object> properties = new HashMap<>();
		for (String key : set) {
			List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
					.get(key);
			properties.put("getgrommingstandardsdetailsExports", l_lstResult);
		}
		
		MyObject object = new MyObject(properties);
		responseModel.setResponseObject(object);
		responseModel.setStatusCode(200);
	} finally {
		try {
			jdbcTemplate.getDataSource().getConnection().close();
		} catch (SQLException e) {
			e.printStackTrace();
			log.debug(e.getMessage());
		}
	}//log.info("responseModel--"+responseModel);
	return responseModel;
}



@SuppressWarnings({ "unchecked", "rawtypes" })
@Override
public ResponseModel  getTrainingVideosDetailsExports(GrommingstandardsReqModel reqModel) {
	ResponseModel responseModel = new ResponseModel();
	try {
		List prmtrsList = new ArrayList();
	
		prmtrsList.add(new SqlParameter(Types.VARCHAR));
		
		

		Map<String, Object> resultData = jdbcTemplate.call(connection -> {
			CallableStatement callableStatement = connection
					.prepareCall("{call USP_GET_TRAINING_VIDEOS_DETAILS_EXPORTS(?)}");
	
			
			callableStatement.setString(1, reqModel.getStatus());
			
			return callableStatement;
		}, prmtrsList);
		Set<String> set = new HashSet<>();
		set = resultData.keySet();
		log.info(set.toString());
		// Create properties
		HashMap<String, Object> properties = new HashMap<>();
		for (String key : set) {
			List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
					.get(key);
			properties.put("getTrainingVideosDetailsExports", l_lstResult);
		}
		
		MyObject object = new MyObject(properties);
		responseModel.setResponseObject(object);
		responseModel.setStatusCode(200);
	} finally {
		try {
			jdbcTemplate.getDataSource().getConnection().close();
		} catch (SQLException e) {
			e.printStackTrace();
			log.debug(e.getMessage());
		}
	}//log.info("responseModel--"+responseModel);
	return responseModel;
}


}