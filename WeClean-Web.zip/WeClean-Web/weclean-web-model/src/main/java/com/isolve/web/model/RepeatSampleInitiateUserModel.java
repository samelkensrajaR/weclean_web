package com.isolve.web.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RepeatSampleInitiateUserModel 
{
	private Long sampleid;
	private Long orderid; 
	private String crm_id;
}
