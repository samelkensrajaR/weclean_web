package com.isolve.web.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LabTransferInitiativeRequestModel implements Serializable
{/**
	 * 
	 */
	private static final long serialVersionUID = -4000816659800717120L;
	
	private	Integer sourcelab_id;
	private	Integer destlab_id;
	List<LabTransferInitiativeUserModel> uttlabtranorderid;
	private	Integer trantypeid;
	private	Integer paramedicid;
	
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	@JsonSerialize(using=LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	private	LocalDateTime transferdate;
	
	private	String remarks;
	private	Integer courier_id;
	private	 String podnumber;
	
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	@JsonSerialize(using=LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	private	LocalDateTime courierdate;
	
	private	Integer userid;
	private String lattitude;
	private String longitude;
}
