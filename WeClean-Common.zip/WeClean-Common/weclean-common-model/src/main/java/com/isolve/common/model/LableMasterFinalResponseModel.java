package com.isolve.common.model;

import java.io.Serializable;

import com.isolve.common.model.LableMasterFinalResponseModel;
import com.isolve.common.utils.MyObject;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LableMasterFinalResponseModel implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 881310299499260907L;
	
	private MyObject  GET_LABLE_MASTER;
	private Integer  status;

}
