package com.isolve.web.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.isolve.web.model.RepeatCollectionRequestModel;
import com.isolve.web.model.RepeatCollectionResponseModel;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@Transactional
@Repository
public class RepeatCollectionRepositoryImpl implements IRepeatCollectionRepository
{
	@Autowired
	private EntityManager entityManager;
	
	Logger log = LoggerFactory.getLogger(RepeatCollectionRepositoryImpl.class);
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RepeatCollectionResponseModel> getRepeatCollection(
			RepeatCollectionRequestModel repeatCollectionRequestModel) {

		List<RepeatCollectionResponseModel> responseModel = new ArrayList<>();
		try {
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_REPEAT_COLLECTION_DETAILS,RepeatCollectionResponseModel.class);
			query.registerStoredProcedureParameter(CommonConstants.PARAMEDICID,Long.class,ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.SCHSTARTDATETIME,Date.class,ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.SCHENDDATETIME,Date.class,ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.CLIENTID,Long.class,ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.RPTTYPE,String.class,ParameterMode.IN);
			query.setParameter(CommonConstants.PARAMEDICID, repeatCollectionRequestModel.getParamedicID());
			query.setParameter(CommonConstants.SCHSTARTDATETIME, Utils.utilDateToSqlDate(repeatCollectionRequestModel.getSchStartdatetime()));
			query.setParameter(CommonConstants.SCHENDDATETIME,  Utils.utilDateToSqlDate(repeatCollectionRequestModel.getSchEnddatetime()));
			query.setParameter(CommonConstants.CLIENTID, repeatCollectionRequestModel.getClientID());
			query.setParameter(CommonConstants.RPTTYPE, repeatCollectionRequestModel.getRptType());
			responseModel = query.getResultList();
			//log.info("resp----"+responseModel);
		} finally {
			entityManager.close();
		}
		return responseModel;
	
	}

}

