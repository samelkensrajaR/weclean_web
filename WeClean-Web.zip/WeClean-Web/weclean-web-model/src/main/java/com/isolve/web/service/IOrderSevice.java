package com.isolve.web.service;

import javax.validation.Valid;

import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RiderTimeSlotAvailabilityReqModel;

public interface IOrderSevice {

	ResponseModel getTrainingVideosDetails(RequestModel requestModel);

	ResponseModel insertupdateTrainingVideos(RequestModel requestModel);

	ResponseModel getgrommingstandardsdetailsExports(RequestModel requestModel);

	ResponseModel getTrainingVideosDetailsExports(RequestModel requestModel);


	
}
