package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsertRefundModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long orderid;
	private Long serviceid;
	private Long itemid;
	private Long refundid;
	private Double refundamount;
	private String remarks;
	private String qrcode;
	private Long userid;
	

}
