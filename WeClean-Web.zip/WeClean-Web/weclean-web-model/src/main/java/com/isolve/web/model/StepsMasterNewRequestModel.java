package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor

public class StepsMasterNewRequestModel implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5029545851151446996L;
	private Integer flag;
	 private String processingsteps;
	 private String description;
	 private String imagepath;
	 private String remarks;
	 private Integer stflag;
	 private Integer stId;
	 private Integer start;
	 private Integer end;
	 private String search;
	 private String payload;
	 private String extraVariable;
	 private Integer roleid;
	

}
