package com.isolve.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RiderTimeSlotAvailabilityReqModel;
import com.isolve.web.service.IMasterSevice;
import com.isolve.web.service.IOrderSevice;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;


@RestController
@CrossOrigin(value = "*",maxAge = 3600)
public class OderController {
	
	@Autowired
	private IOrderSevice iOrderSevice;
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_TRAINING_VIDEOS_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getTrainingVideosDetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iOrderSevice.getTrainingVideosDetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_TRAINING_VIDEOS, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdateTrainingVideos(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iOrderSevice.insertupdateTrainingVideos(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_GROOMING_STANDARDS_DETAILS_EXPORTS, method = RequestMethod.POST)
	public ResponseEntity<?> getgrommingstandardsdetailsExports(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iOrderSevice.getgrommingstandardsdetailsExports(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_TRAINING_VIDEOS_DETAILS_EXPORTS, method = RequestMethod.POST)
	public ResponseEntity<?> getTrainingVideosDetailsExports(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iOrderSevice.getTrainingVideosDetailsExports(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
}


	

	
