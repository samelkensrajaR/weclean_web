package com.isolve.web.model;


import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
public class PendingReportRequestModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7156500768392226602L;
	private String startdatetime;
	private String enddatetime;
	private String cityid;
	private String centerid;
    private String type;
    private String rpid;
}
