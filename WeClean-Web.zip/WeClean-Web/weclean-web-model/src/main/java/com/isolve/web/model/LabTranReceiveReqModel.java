package com.isolve.web.model;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LabTranReceiveReqModel implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5876309687908595829L;
	private List<LabTransferInitiativeUserModel> orderdetails;
	private  Integer userid;
	private String lattitude;
	private String longitude;
}
