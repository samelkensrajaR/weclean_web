package com.isolve.common.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VerifyOTPModel implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6462688897894381417L;
	private String 	vendor_id;
	private String 	user_id;
	private String 	lang_id;
	private String 	otp;
	private String 	otp_purpose;
}
