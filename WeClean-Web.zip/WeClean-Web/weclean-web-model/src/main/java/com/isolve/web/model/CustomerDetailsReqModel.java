package com.isolve.web.model;

import java.io.Serializable;
import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerDetailsReqModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -9085781948639781865L;
	private Long customerid;
	private Long userid;
	private String customername;
	private String email;
	private String mobileno;
	private String billingmobile;
	private Long genderid;
	private Date dob;
	private Date doa;
	private String pan_no;
	private String gst_no;
	private String address;
	private String pincode;
	private String floor;
	private String landmark;
	private Integer start;
	private Integer end;
	private String search;
	private Integer flag;
	private Boolean status;
	private String imagepath;
	private String panimage;
	private String billingname;
}
