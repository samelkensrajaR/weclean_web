package com.isolve.common.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class RolesResponseModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2957661285324071608L;
	@Id
	private String LC_RS_ROLEID;
	private String LC_RS_ROLENAME;

}
