package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConfigurationModel implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8603652774789867650L;
	private Long customerid;
	private Long configurationid;
    private Long emailtypeid;

}
