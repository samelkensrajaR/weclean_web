package com.isolve.web.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ImagedetailsModel implements Serializable
{/**
	 * 
	 */
	private static final long serialVersionUID = -614645718536596725L;
	 
	
	@JsonProperty("qrcode")
	private String qrcode;	 
	
	@JsonProperty("imagepath")
	private String imagepath;
	
	@JsonProperty("name")
	private String name;
	 
 
}
