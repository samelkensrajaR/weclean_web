package com.isolve.common.service;

import com.isolve.common.model.RequestModel;
import com.isolve.common.model.ResponseModel;

public interface IRegistrationService {

	
	ResponseModel registrationDetails(RequestModel requestModel);

	ResponseModel registerUserGenerateOtp(RequestModel requestModel);

	ResponseModel verifyRegisterUserOtps(RequestModel requestModel);

	ResponseModel getLableMaster(RequestModel requestModel);

}
