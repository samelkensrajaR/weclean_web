package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderSummaryImageReqModel implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8603652774789867650L;
	
	private String imagepath;
	private Long invoiceid;
    private Long orderid;

}
