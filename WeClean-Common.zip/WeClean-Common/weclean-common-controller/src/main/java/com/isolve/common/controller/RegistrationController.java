package com.isolve.common.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.isolve.common.model.RequestModel;
import com.isolve.common.model.ResponseModel;
import com.isolve.common.service.IRegistrationService;
import com.isolve.common.utils.CommonConstants;
import com.isolve.common.utils.Utils;

@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
public class RegistrationController {

	@Autowired
	private IRegistrationService iRegistrationService;

	/**
	 * @author
	 * @Name registrationDetails - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: registrationDetails method using to insert sign up details for Web
	 */
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/" + CommonConstants.REGISTRATION_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> registrationDetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iRegistrationService.registrationDetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name registerUserGenerateOtp - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: registerUserGenerateOtp method using to generate OTP for Customer and
	 *       Rider
	 */
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/" + CommonConstants.REGISTER_USER_GENERATE_OTP, method = RequestMethod.POST)
	public ResponseEntity<?> registerUserGenerateOtp(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iRegistrationService.registerUserGenerateOtp(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name verifyRegisterUserOtps - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: verifyRegisterUserOtps method using to verify register OTP.
	 */
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/" + CommonConstants.VERIFY_REGISTER_USER_OTP, method = RequestMethod.POST)
	public ResponseEntity<?> verifyRegisterUserOtps(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iRegistrationService.verifyRegisterUserOtps(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name getLableMaster - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getLableMaster method using to get Lable MAster.
	 */
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/" + CommonConstants.GET_LABLE_MASTER, method = RequestMethod.POST)
	public ResponseEntity<?> getLableMaster(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iRegistrationService.getLableMaster(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);

	}

}
