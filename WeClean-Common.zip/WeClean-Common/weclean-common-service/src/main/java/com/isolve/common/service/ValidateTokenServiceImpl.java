package com.isolve.common.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isolve.common.model.ResponseModel;
import com.isolve.common.repository.IValidateTokenRepository;

@Service
public class ValidateTokenServiceImpl implements IValidateTokenService {

	@Autowired
	private IValidateTokenRepository iValidateTokenRepository;

	/**
	 * @author
	 * @Name validateToken - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: validateToken method using to validate the auth Token.
	 */
	@Override
	public ResponseModel validateToken(String jwtToken) {
		ResponseModel responseModel = new ResponseModel();
		try {
			responseModel = iValidateTokenRepository.validateToken(jwtToken);
		} catch (Exception e) {
			responseModel.setStatusCode(400);
			responseModel.setMessage(e.getMessage());
		}
		return responseModel;
	}

}
