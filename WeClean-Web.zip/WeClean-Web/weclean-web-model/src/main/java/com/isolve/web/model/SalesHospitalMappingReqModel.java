package com.isolve.web.model;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class SalesHospitalMappingReqModel implements Serializable{
	
	private static final long serialVersionUID = 6656787372364959922L;
	
	private String userid;
	private String salesid;
	private List<SaleshospitalMappingModel> saleshospitalmappingModelList;


}
