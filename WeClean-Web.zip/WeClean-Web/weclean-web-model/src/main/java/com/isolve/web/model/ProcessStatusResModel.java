package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProcessStatusResModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3281599612534133256L;
	private Integer status;
	private String message;
	private String mobileno;
	private String content;
	private Integer flag;
}
