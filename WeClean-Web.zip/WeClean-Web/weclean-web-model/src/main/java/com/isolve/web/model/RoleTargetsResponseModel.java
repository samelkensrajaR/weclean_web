package com.isolve.web.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class RoleTargetsResponseModel implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3704027233874743010L;
	
	@Id
	private Integer targetid;	
	private String name;
	private String routerlink;
	private String targetdescription;
	private String icon;
	private Integer isactive;
	
}