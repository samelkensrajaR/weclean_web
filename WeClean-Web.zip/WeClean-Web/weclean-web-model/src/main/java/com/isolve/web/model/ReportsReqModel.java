package com.isolve.web.model;


import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
public class ReportsReqModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7156500768392226602L;
	
	private Long flag;
	private Long userid;
	private Long reportid;
    private String reportname;
    private Object inputjson;
    
}
