package com.isolve.web.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseModel implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private Integer statusCode;
    private String decryptResponse;
    private String responseData;
    private String status;
    private String message;
    private Object responseObj;
    private Object responseObject;
    private List<?> respList;
    private String[] respArray;
    private Long orderid;
    private Long userid;
    private List<EmailResponseModel> doalist;
	public void setResponselist(List<TimeSlotReqModel> timeSlotReqModels) {
		// TODO Auto-generated method stub
		
	}
	
	private String mobile_no;
	private String content;
	private Integer flag;
	private String mobileno;
    private String notification;
  
    
    
}
