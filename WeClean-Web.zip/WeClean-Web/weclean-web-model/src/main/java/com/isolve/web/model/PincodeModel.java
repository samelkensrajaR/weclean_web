package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PincodeModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7694858702548432996L;
	
	private String pincode;
    private String location;
}
