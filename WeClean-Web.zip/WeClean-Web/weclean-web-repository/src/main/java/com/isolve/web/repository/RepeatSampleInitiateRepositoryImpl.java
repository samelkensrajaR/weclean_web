package com.isolve.web.repository;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RepeatSampleInitiateRequestModel;
import com.isolve.web.model.RepeatSampleInitiateUserModel;
import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;

@Transactional
@Repository
public class RepeatSampleInitiateRepositoryImpl implements IRepeatSampleInitiateRepository{

	Logger logger = LoggerFactory.getLogger(RepeatSampleInitiateRepositoryImpl.class);
	 
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public ResponseModel updateRepeatSample(RepeatSampleInitiateRequestModel updateRepeatSampleRequestModel) throws SQLException {
		ResponseModel responseModel = new ResponseModel();
		Connection connection = jdbcTemplate.getDataSource().getConnection();
		try {
			SQLServerDataTable utt_uttrepini = new SQLServerDataTable();
			utt_uttrepini.addColumnMetadata("sampleid", java.sql.Types.BIGINT);
			utt_uttrepini.addColumnMetadata("orderid", java.sql.Types.BIGINT);
			utt_uttrepini.addColumnMetadata("crmid", java.sql.Types.VARCHAR);
			for(RepeatSampleInitiateUserModel userModel:updateRepeatSampleRequestModel.getUttrepini())
			{
				utt_uttrepini.addRow(userModel.getSampleid(),userModel.getOrderid(),userModel.getCrm_id());
			}
			CallableStatement csstmt = connection.prepareCall("{call USP_UPDATE_REPEAT_SAMPLE_INITIATE(?, ?, ?, ?)}");
			if (csstmt.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
				// The CallableStatement object can unwrap to
				// SQLServerCallableStatement.
				SQLServerCallableStatement cs = csstmt.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
				cs.setResponseBuffering("adaptive");
				cs.setStructured(1,"dbo.UTT_REPEAT_INITIATE",utt_uttrepini);
				cs.setLong(2, updateRepeatSampleRequestModel.getUserid());
				cs.setString(3, updateRepeatSampleRequestModel.getLattitude());
				cs.setString(4, updateRepeatSampleRequestModel.getLongitude());
				boolean resultSetReturned = cs.execute();
				if (resultSetReturned) {
					try (ResultSet rs = cs.getResultSet()) {
						rs.next();
						responseModel.setStatusCode(rs.getInt(1));
						responseModel.setMessage(rs.getString(2));
					}
				}
			}
		} finally {
			connection.close();
		}
		//logger.info("responseModel--"+responseModel);
		return responseModel;
	}

}
