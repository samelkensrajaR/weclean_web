package com.isolve.web.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isolve.web.model.RepeatSampleInitiateRequestModel;
import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.UserManagementResModel;
import com.isolve.web.repository.IUserManagementRepository;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@Service
public class UserManagementServiceImpl implements IUserManagementService
{
	Logger log = LoggerFactory.getLogger(RosterParamedicServiceImpl.class);

	@Autowired
	private IUserManagementRepository iUserManagementRepository;

	private ObjectMapper objectMapper = new ObjectMapper();

	@Value("${encryptsecretkey}")
	private String encryptsecretkey;





@Override
public ResponseModel getusermanagement(RequestModel requestModel) {

	ResponseModel model = new ResponseModel();
	ResponseModel responsemodel = new ResponseModel();
	log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
	try {
		UserManagementResModel updateRepeatSampleRequestModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), UserManagementResModel.class);
		
		responsemodel = iUserManagementRepository.getusermanagement(updateRepeatSampleRequestModel);
	} catch (Exception e) {			
		e.printStackTrace();
		log.debug(e.getMessage());
		model.setStatusCode(400);
		model.setMessage(e.getMessage());
	}		
	try {
		String iv = Utils.randomKey(16);
		model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey,iv));
		model.setStatusCode(200);
		model.setStatus(iv);
	} catch (Exception e) {
		e.printStackTrace();
		log.debug(e.getMessage());
		model.setStatusCode(400);
		model.setMessage(e.getMessage());
	}
	return model;
}
}
