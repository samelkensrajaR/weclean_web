package com.isolve.web.repository;

import java.sql.SQLException;

import com.isolve.web.model.CourierMasterRequestModel;
import com.isolve.web.model.LabMasterRequestModel;
import com.isolve.web.model.LabTranReceiveReqModel;
import com.isolve.web.model.LabTransferInitiativeRequestModel;
import com.isolve.web.model.LabTransferRequestModel;
import com.isolve.web.model.ResponseModel;

public interface ILabTransferRepository {

	ResponseModel getLabTransfer(LabTransferRequestModel labTransferRequestModel);


	ResponseModel updateLabTransferInitiative(LabTransferInitiativeRequestModel labTransferInitiativeRequestModel) throws SQLException;


	ResponseModel getSampleType();


	ResponseModel getLabMaster(LabMasterRequestModel labMasterRequestModel);


	ResponseModel getCourierMaster(CourierMasterRequestModel courierMasterRequestModel);


	ResponseModel getTransferType();


	ResponseModel updateLabTranReceive(LabTranReceiveReqModel reqModel) throws SQLException;

}
