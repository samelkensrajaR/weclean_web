package com.isolve.web.repository;

import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.UserManagementResModel;
import com.microsoft.sqlserver.jdbc.SQLServerException;

public interface IUserManagementRepository 
{



	ResponseModel getusermanagement(UserManagementResModel updateRepeatSampleRequestModel) throws SQLServerException;

	


}
