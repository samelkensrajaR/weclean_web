package com.isolve.web.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Iterator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.isolve.web.model.AppovalActionResModel;
import com.isolve.web.model.AppovalActionStausResModel;
import com.isolve.web.model.ApprovalActionImagePathResModel;
import com.isolve.web.model.ApprovalsDetResModel;
import com.isolve.web.model.AutomaticProcessReqModel;
import com.isolve.web.model.BrandMasterNewReqModel;
import com.isolve.web.model.CallHestoryReqModel;
import com.isolve.web.model.CenterMasterReqModel;
import com.isolve.web.model.ChallanMasterReqModel;
import com.isolve.web.model.ChatUserReqModel;
import com.isolve.web.model.CollectItemDetailsModel;
import com.isolve.web.model.ColourMasterNewReqModel;
import com.isolve.web.model.CompanyMasterNewReqModel;
import com.isolve.web.model.ComplaintsReqModel;
import com.isolve.web.model.ConfigurationModel;
import com.isolve.web.model.ConfigurationResponseModel;
import com.isolve.web.model.CustomerDetailsReqModel;
import com.isolve.web.model.DamageMasterNewReqModel;
import com.isolve.web.model.DeliveryModeReqModel;
import com.isolve.web.model.DispatchDetailsReqModel;
import com.isolve.web.model.DispatchDetailsRequestModel;
import com.isolve.web.model.DoctorDetailsReqModel;
import com.isolve.web.model.DoctorHospitalMappingReqModel;
import com.isolve.web.model.EmailResponseModel;
import com.isolve.web.model.GrommingstandardsReqModel;
import com.isolve.web.model.HospitalstatecityModel;
import com.isolve.web.model.ImageUploadModel;
import com.isolve.web.model.InsertAutomaticProcessStepsReqModel;
import com.isolve.web.model.InsertComplaintsReqModel;
import com.isolve.web.model.InsertRefundReqModel;
import com.isolve.web.model.InsertSlotNewReqModel;
import com.isolve.web.model.ItemMasterNewReqModel;
import com.isolve.web.model.ItemMasterReqModel;
import com.isolve.web.model.ItemwiseImageReqModel;
import com.isolve.web.model.MessagedetailsModel;
import com.isolve.web.model.NewItemwiseImageReqModel;
import com.isolve.web.model.NewOrderResModel;
import com.isolve.web.model.OrderDetailsReqModel;
import com.isolve.web.model.OrderSummaryImageReqModel;
import com.isolve.web.model.OrdersummaryPdf;
import com.isolve.web.model.ParamedicDetailsReqModel;
import com.isolve.web.model.PaymentInvoiceResModel;
import com.isolve.web.model.PaymentStatusReqModel;
import com.isolve.web.model.PickupDetailsByItemsReqModel;
import com.isolve.web.model.PickupDetailsReqModel;
import com.isolve.web.model.PickupRescheduleReqModel;
import com.isolve.web.model.PinCodeMappingModel;
import com.isolve.web.model.PincodeMasterReqModel;
import com.isolve.web.model.ProcessRescheduleConfiguration;
import com.isolve.web.model.ProcessRescheduleResponseModel;
import com.isolve.web.model.ProcessStatusReqModel;
import com.isolve.web.model.ProcessStatusResModel;
import com.isolve.web.model.ProcessStepsByServiceIdReqModel;
import com.isolve.web.model.ProcessStsConfigModel;
import com.isolve.web.model.QrcodeDetailsReqModel;
import com.isolve.web.model.ReceiveDtailsExportReqModel;
import com.isolve.web.model.ReceiveItemDetailsReqModel;
import com.isolve.web.model.ReceivedItemDetailsReqModel;
import com.isolve.web.model.RequestModel;
import com.isolve.web.model.RescheduleAndCancellationExportReqModel;
import com.isolve.web.model.RescheduleAndCancellationReqModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RiderCancilationReqModel;
import com.isolve.web.model.RiderDetailsReqModel;
import com.isolve.web.model.RiderTimeSlotAvailabilityReqModel;
import com.isolve.web.model.SalesHospitalMappingReqModel;
import com.isolve.web.model.ServiceItemMappingReqModel;
import com.isolve.web.model.ServiceItemMasterNewReqModel;
import com.isolve.web.model.ServiceStepsMapppingReqModel;
import com.isolve.web.model.SlotReqModel;
import com.isolve.web.model.SocietyDetailsReqModel;
import com.isolve.web.model.SocietyReqModel;
import com.isolve.web.model.StainMasterNewReqModel;
import com.isolve.web.model.StepsMasterNewRequestModel;
import com.isolve.web.model.TemplateDetailsReqModel;
import com.isolve.web.model.TestProductMappingReqModel;
import com.isolve.web.model.TrackRiderDetailsReqModel;
import com.isolve.web.model.UpdateSocietyReqModel;
import com.isolve.web.model.UpdateWalletConfigurationReqModel;
import com.isolve.web.model.VendorDetailsMasterReqModel;
import com.isolve.web.model.VendorVisitTimeMappingReqModel;
import com.isolve.web.model.VendorVisitTimeReqModel;
import com.isolve.web.model.VisitTimeReqModel;
import com.isolve.web.model.WalletConfigurationReqModel;
import com.isolve.web.model.WebDashBoardDetails;
import com.isolve.web.model.WebDelierySlotsModel;
import com.isolve.web.repository.IMasterRepository;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@Service
public class MasterServiceImpl implements IMasterSevice {

	@Autowired
	public IMasterRepository iMasterRepository;

	@Value("${encryptsecretkey}")
	private String encryptsecretkey;

	@Autowired
	private TemplateEngine templateEngine;

	@Autowired
	RestTemplate restTemplate;

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

	@Value("${azureconnectionstring}")
	private String azureconnectionstring;

	private ObjectMapper objectMapper = new ObjectMapper();

	Logger log = LoggerFactory.getLogger(MasterServiceImpl.class);

	@Override
	public ResponseModel insertupdatepincodemapping(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			PinCodeMappingModel reqModel = objectMapper.readValue(decrypt, PinCodeMappingModel.class);
			log.info(CommonConstants.INSERTUPDATEPINCODEMAPPING + " " + reqModel);
			responseModel = iMasterRepository.insertupdatepincodemapping(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			// log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getPinCodeMaster(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			PincodeMasterReqModel reqModel = objectMapper.readValue(decrypt, PincodeMasterReqModel.class);
			log.info(CommonConstants.GET_PINCODE_MASTER + " " + reqModel);
			responseModel = iMasterRepository.getPinCodeMaster(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			// log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertupdatevendorvisittimemapping(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			VendorVisitTimeMappingReqModel reqModel = objectMapper.readValue(decrypt,
					VendorVisitTimeMappingReqModel.class);
			log.info(CommonConstants.INSERT_UPDATE_VENDOR_VISITTIME_MAPPING + " " + reqModel);
			responseModel = iMasterRepository.insertupdatevendorvisittimemapping(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			// log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getVendorVisitTime(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			VendorVisitTimeReqModel reqModel = objectMapper.readValue(decrypt, VendorVisitTimeReqModel.class);
			log.info(CommonConstants.GET_VENDOR_VISIT_TIME + " " + reqModel);
			responseModel = iMasterRepository.getVendorVisitTime(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getParamedicDetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			ParamedicDetailsReqModel reqModel = objectMapper.readValue(decrypt, ParamedicDetailsReqModel.class);
			responseModel = iMasterRepository.getParamedicDetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getcitystatecenterbyuserid(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			PinCodeMappingModel reqModel = objectMapper.readValue(decrypt, PinCodeMappingModel.class);
			responseModel = iMasterRepository.getcitystatecenterbyuserid(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel vendorDetailsMaster(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			VendorDetailsMasterReqModel reqModel = objectMapper.readValue(decrypt, VendorDetailsMasterReqModel.class);
			responseModel = iMasterRepository.vendorDetailsMaster(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertUpdateCenterMaster(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			CenterMasterReqModel reqModel = objectMapper.readValue(decrypt, CenterMasterReqModel.class);
			responseModel = iMasterRepository.insertUpdateCenterMaster(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertUpdateVisitTimeMaster(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			VisitTimeReqModel reqModel = objectMapper.readValue(decrypt, VisitTimeReqModel.class);
			responseModel = iMasterRepository.insertUpdateVisitTimeMaster(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getApproveStatus() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getApproveStatus();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getRegion() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getRegion();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getManagement() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getManagement();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertUpdateTestProductMapping(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			TestProductMappingReqModel reqModel = objectMapper.readValue(decrypt, TestProductMappingReqModel.class);
			responseModel = iMasterRepository.insertUpdateTestProductMapping(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getPreconditionMaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getPreconditionMaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getPaymentStatus(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			PaymentStatusReqModel reqModel = objectMapper.readValue(decrypt, PaymentStatusReqModel.class);
			responseModel = iMasterRepository.getPaymentStatus(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getallclientmaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getallclientmaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getallstatusmaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getallstatusmaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getallinvoicetracking(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			PaymentStatusReqModel reqModel = objectMapper.readValue(decrypt, PaymentStatusReqModel.class);
			responseModel = iMasterRepository.getallinvoicetracking(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getQuotationdetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			PaymentStatusReqModel reqModel = objectMapper.readValue(decrypt, PaymentStatusReqModel.class);
			responseModel = iMasterRepository.getQuotationdetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getapprovedstatusmaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getapprovedstatusmaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getaccounttypemaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getaccounttypemaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getInvoiceStatusMaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getInvoiceStatusMaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	public ResponseModel getWebDashBoardDetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			WebDashBoardDetails reqModel = objectMapper.readValue(decrypt, WebDashBoardDetails.class);
			responseModel = iMasterRepository.getWebDashBoardDetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	public ResponseModel getsalesWebDashBoardDetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			WebDashBoardDetails reqModel = objectMapper.readValue(decrypt, WebDashBoardDetails.class);
			responseModel = iMasterRepository.getsalesWebDashBoardDetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertupdatesaleshospitalmapping(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			SalesHospitalMappingReqModel reqModel = objectMapper.readValue(decrypt,
					SalesHospitalMappingReqModel.class);
			log.info(CommonConstants.INSERT_UPDATE_SALES_HOSPITAL_MAPPING + " " + reqModel);
			responseModel = iMasterRepository.insertupdatesaleshospitalmapping(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			// log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getsalesusers(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			WebDashBoardDetails reqModel = objectMapper.readValue(decrypt, WebDashBoardDetails.class);
			responseModel = iMasterRepository.getsalesusers(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertupdatedoctordetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			DoctorDetailsReqModel reqModel = objectMapper.readValue(decrypt,
					DoctorDetailsReqModel.class);
			log.info(CommonConstants.INSERT_UPDATE_DOCTOR_DETAILS + " " + reqModel);
			responseModel = iMasterRepository.insertupdatedoctordetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			// log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertupdatedoctorhospitalmapping(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			DoctorHospitalMappingReqModel reqModel = objectMapper.readValue(decrypt,
					DoctorHospitalMappingReqModel.class);
			log.info(CommonConstants.INSERT_UPDATE_DOCTOR_HOSPITAL_MAPPING + " " + reqModel);
			responseModel = iMasterRepository.insertupdatedoctorhospitalmapping(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			// log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel gethospitalwisestatecity(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			HospitalstatecityModel reqModel = objectMapper.readValue(decrypt, HospitalstatecityModel.class);
			responseModel = iMasterRepository.gethospitalwisestatecity(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getProductForWeb() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getProductForWeb();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getallcleaningcategory() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			responseModel = iMasterRepository.getallcleaningcategory();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getallitemmaster(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			ItemMasterReqModel reqModel = objectMapper.readValue(decrypt, ItemMasterReqModel.class);
			responseModel = iMasterRepository.getallitemmaster(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getallservicemaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			responseModel = iMasterRepository.getallservicemaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getcolourmaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			responseModel = iMasterRepository.getcolourmaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getdamagemaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			responseModel = iMasterRepository.getdamagemaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getstainmaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			responseModel = iMasterRepository.getstainmaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getusermaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			responseModel = iMasterRepository.getusermaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getdeliverymode(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			DeliveryModeReqModel reqModel = objectMapper.readValue(decrypt, DeliveryModeReqModel.class);
			responseModel = iMasterRepository.getdeliverymode(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getriderslotavailability(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			RiderTimeSlotAvailabilityReqModel reqModel = objectMapper.readValue(decrypt,
					RiderTimeSlotAvailabilityReqModel.class);
			responseModel = iMasterRepository.getriderslotavailability(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getPickupDetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			PickupDetailsReqModel reqModel = objectMapper.readValue(decrypt, PickupDetailsReqModel.class);
			responseModel = iMasterRepository.getPickupDetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertUpdateOrderDetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			OrderDetailsReqModel reqModel = objectMapper.readValue(decrypt, OrderDetailsReqModel.class);

			responseModel = iMasterRepository.insertUpdateOrderDetails(reqModel);
			List<NewOrderResModel> newOrderResModel = (List<NewOrderResModel>) responseModel.getResponseObject();

			for (NewOrderResModel detresp : newOrderResModel) {
				OrdersummaryPdf invoice = new OrdersummaryPdf();
				invoice.setOrderid(reqModel.getOrderid());
				invoice.setInvoiceid(detresp.getInvoiceid());
				invoice.setUserid(reqModel.getCustomerid());
				ResponseModel pdfres = iMasterRepository.getOrderSummaryPdf(invoice);

				PaymentInvoiceResModel paymentinvoiceResModel = (PaymentInvoiceResModel) pdfres.getResponseObject();
				if (String.valueOf(paymentinvoiceResModel.getPaymentUserDetails().getStatus())
						.equalsIgnoreCase("200")) {
					Map<String, Object> data = new HashMap<String, Object>();
					data.put("paymentdetails", paymentinvoiceResModel.getPaymentUserDetails());
					data.put("pickupdate", paymentinvoiceResModel.getPaymentUserDetails().getPickupdate());
					data.put("service", paymentinvoiceResModel.getServicename());
					data.put("specialinstruct", paymentinvoiceResModel.getSpecialinstruct());
					data.put("cgst", paymentinvoiceResModel.getCgst());
					data.put("sgst", paymentinvoiceResModel.getSgst());
					String templateName = "ordersummary";
					Assert.notNull(templateName, "The templateName can not be null");
					Context ctx = new Context();
					if (data != null) {
						Iterator itMap = data.entrySet().iterator();
						while (itMap.hasNext()) {
							Map.Entry pair = (Map.Entry) itMap.next();
							ctx.setVariable(pair.getKey().toString(), pair.getValue());
						}
					}
					String processedHtml = templateEngine.process(templateName, ctx);
					String imagePath = Utils.saveImage("",
							"", null, azureconnectionstring, "invoice",
							String.valueOf(reqModel.getCustomerid() + reqModel.getOrderid()),
							Utils.getCurrentDateTime(), "ordersummary", "dynamic", processedHtml);
					OrderSummaryImageReqModel ordersummary = new OrderSummaryImageReqModel();
					System.out.println("imagepath" + imagePath);
					ordersummary.setImagepath(imagePath);
					ordersummary.setInvoiceid(detresp.getInvoiceid());
					ordersummary.setOrderid(reqModel.getOrderid());
					ResponseModel updateimg = iMasterRepository.updateOrderSummaryImagePath(ordersummary);
					System.out.println(imagePath);

					for (CollectItemDetailsModel d : reqModel.getCollectitems()) {
						if (d.getBranddetails().size() < 0 || d.getColordetails().size() < 0 ||
								d.getDamagedetails().size() < 0 || d.getStaindetails().size() < 0) {

							try {
								ConfigurationModel configurationModel = new ConfigurationModel();
								configurationModel.setConfigurationid(Long.valueOf(1));
								configurationModel.setCustomerid(reqModel.getCustomerid());
								;
								configurationModel.setEmailtypeid(Long.valueOf(5));
								ResponseModel res = iMasterRepository.getConfiguration(configurationModel);
								ConfigurationResponseModel configurationResponseModel = (ConfigurationResponseModel) res
										.getResponseObject();
								Utils.sendMail(configurationResponseModel, imagePath, "Order Summary.pdf");
							} catch (Exception e) {
								e.printStackTrace();
							}

						}
					}
				}
			}
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertWebNewOrderDetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			OrderDetailsReqModel reqModel = objectMapper.readValue(decrypt, OrderDetailsReqModel.class);
			responseModel = iMasterRepository.insertWebNewOrderDetails(reqModel);
			List<NewOrderResModel> newOrderResModel = (List<NewOrderResModel>) responseModel.getResponseObject();

			for (NewOrderResModel detresp : newOrderResModel) {
				OrdersummaryPdf invoice = new OrdersummaryPdf();
				invoice.setOrderid(responseModel.getOrderid());
				invoice.setInvoiceid(detresp.getInvoiceid());
				invoice.setUserid(detresp.getNewuserid());
				ResponseModel pdfres = iMasterRepository.getOrderSummaryPdf(invoice);

				PaymentInvoiceResModel paymentinvoiceResModel = (PaymentInvoiceResModel) pdfres.getResponseObject();
				if (String.valueOf(paymentinvoiceResModel.getPaymentUserDetails().getStatus())
						.equalsIgnoreCase("200")) {
					Map<String, Object> data = new HashMap<String, Object>();
					data.put("paymentdetails", paymentinvoiceResModel.getPaymentUserDetails());
					data.put("pickupdate", paymentinvoiceResModel.getPaymentUserDetails().getPickupdate());
					data.put("service", paymentinvoiceResModel.getServicename());
					data.put("specialinstruct", paymentinvoiceResModel.getSpecialinstruct());
					data.put("cgst", paymentinvoiceResModel.getCgst());
					data.put("sgst", paymentinvoiceResModel.getSgst());
					String templateName = "ordersummary";
					Assert.notNull(templateName, "The templateName can not be null");
					Context ctx = new Context();
					if (data != null) {
						Iterator itMap = data.entrySet().iterator();
						while (itMap.hasNext()) {
							Map.Entry pair = (Map.Entry) itMap.next();
							ctx.setVariable(pair.getKey().toString(), pair.getValue());
						}
					}
					String processedHtml = templateEngine.process(templateName, ctx);
					String imagePath = Utils.saveImage("",
							"", null, azureconnectionstring, "invoice",
							String.valueOf(detresp.getNewuserid() + responseModel.getOrderid()),
							Utils.getCurrentDateTime(), "ordersummary", "dynamic", processedHtml);
					OrderSummaryImageReqModel ordersummary = new OrderSummaryImageReqModel();
					System.out.println("imagepath" + imagePath);
					ordersummary.setImagepath(imagePath);
					ordersummary.setInvoiceid(detresp.getInvoiceid());
					ordersummary.setOrderid(responseModel.getOrderid());
					ResponseModel updateimg = iMasterRepository.updateOrderSummaryImagePath(ordersummary);
					System.out.println(imagePath);

					try {
						ConfigurationModel configurationModel = new ConfigurationModel();
						configurationModel.setConfigurationid(Long.valueOf(1));
						configurationModel.setCustomerid(detresp.getNewuserid());
						;
						configurationModel.setEmailtypeid(Long.valueOf(5));
						ResponseModel res = iMasterRepository.getConfiguration(configurationModel);
						ConfigurationResponseModel configurationResponseModel = (ConfigurationResponseModel) res
								.getResponseObject();
						Utils.sendMail(configurationResponseModel, imagePath, "Order Summary.pdf");
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getchallantypemaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			responseModel = iMasterRepository.getchallantypemaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getchallanmaster(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getchallanmaster(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getpickupdetailsbyitems(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			PickupDetailsByItemsReqModel reqModel = objectMapper.readValue(decrypt, PickupDetailsByItemsReqModel.class);
			responseModel = iMasterRepository.getpickupdetailsbyitems(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getchallanmasterexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getchallanmasterexport(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getprocessingmaster(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getprocessingmaster(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getprocessdetailsbyitems(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			PickupDetailsByItemsReqModel reqModel = objectMapper.readValue(decrypt, PickupDetailsByItemsReqModel.class);
			responseModel = iMasterRepository.getprocessdetailsbyitems(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getprocessstepsbyserviceid(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			ProcessStepsByServiceIdReqModel reqModel = objectMapper.readValue(decrypt,
					ProcessStepsByServiceIdReqModel.class);
			responseModel = iMasterRepository.getprocessstepsbyserviceid(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertupdateprocessingstatus(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		// ProcessStatusResModel newStatusResModels = new ProcessStatusResModel();
		ResponseModel configResponse = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			ProcessStatusReqModel reqModel = objectMapper.readValue(decrypt, ProcessStatusReqModel.class);
			responseModel = iMasterRepository.insertupdateprocessingstatus(reqModel);
			ProcessStatusResModel newStatusResModels = (ProcessStatusResModel) responseModel.getResponseObj();
			// List<ProcessStatusResModel> newStatusResModel=(List<ProcessStatusResModel>)
			// responseModel.getRespList();

			// for(ProcessStatusResModel detresp : newStatusResModel) {
			if (newStatusResModels.getFlag() != null) {
				if (newStatusResModels.getFlag() == 1) {
					try {
						configResponse = iMasterRepository.getprocessStsConfig();
						ProcessStsConfigModel processStsConfigModel = (ProcessStsConfigModel) configResponse
								.getResponseObject();

						if (newStatusResModels.getMobileno() != null && newStatusResModels.getMobileno() != "") {
							String finalurl = processStsConfigModel.getLC_CM_SMS_API()
									.replaceAll("phonenumber", "91" + newStatusResModels.getMobileno())
									.replaceAll("msg", newStatusResModels.getContent());
							ResponseEntity<String> responseEntity;
							responseEntity = restTemplate.getForEntity(finalurl, String.class);
							String responseJsonString = responseEntity.getBody();
							log.info("responseJsonString " + responseJsonString.trim());
							if (responseJsonString.equalsIgnoreCase("Success")) {
								System.out.println("resr" + newStatusResModels);
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}

			responseModel.setResponseObj(null);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getdispatchdetailss(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			DispatchDetailsReqModel reqModel = objectMapper.readValue(decrypt, DispatchDetailsReqModel.class);
			responseModel = iMasterRepository.getdispatchdetailss(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertupdatedispatchdetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			DispatchDetailsRequestModel reqModel = objectMapper.readValue(decrypt, DispatchDetailsRequestModel.class);
			responseModel = iMasterRepository.insertupdatedispatchdetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getstatusdetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getstatusdetails(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getprocessingmasterexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getprocessingmasterexport(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getpickupdetailsfilter() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getpickupdetailsfilter();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getdetailsbyqrcode(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			PickupDetailsByItemsReqModel reqModel = objectMapper.readValue(decrypt, PickupDetailsByItemsReqModel.class);
			responseModel = iMasterRepository.getdetailsbyqrcode(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getdeliverychallandetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			PickupDetailsByItemsReqModel reqModel = objectMapper.readValue(decrypt, PickupDetailsByItemsReqModel.class);
			responseModel = iMasterRepository.getdeliverychallandetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getstatusdetailsexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getstatusdetailsexport(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getreceiveddetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getreceiveddetails(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getreceiveitemdetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ReceiveItemDetailsReqModel reciveItemDetailsReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ReceiveItemDetailsReqModel.class);

			responsemodel = iMasterRepository.getreceiveitemdetails(reciveItemDetailsReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel updatereceiveitemdetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			ReceivedItemDetailsReqModel reqModel = objectMapper.readValue(decrypt, ReceivedItemDetailsReqModel.class);

			responseModel = iMasterRepository.updatereceiveitemdetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertupdatesocity(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		log.info("hexIv : " + requestModel.getExtraVariable());
		try {
			SocietyReqModel socityReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					SocietyReqModel.class);
			log.info(CommonConstants.INSERT_UPDATE_SOCITY + socityReqModel);
			String imagePath = null;
			if (socityReqModel.getImagepath() != null) {
				imagePath = Utils.saveImage(socityReqModel.getImagepath(), socityReqModel.getSocietyname(),
						null, azureconnectionstring, "invoice", String.valueOf(socityReqModel.getSocietyid()),
						Utils.getCurrentDate(), "insertupdatesocity", "static", "");
			}
			socityReqModel.setImagepath(imagePath);
			responseModel = iMasterRepository.insertupdatesocity(socityReqModel);
			System.out.println("imageUrl" + socityReqModel.getImagepath());
			System.out.println("imagePath" + imagePath);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}

		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getsocietydetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			SocietyDetailsReqModel societyDetailsReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					SocietyDetailsReqModel.class);

			responsemodel = iMasterRepository.getsocietydetails(societyDetailsReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel updatesocietydetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			UpdateSocietyReqModel reqModel = objectMapper.readValue(decrypt, UpdateSocietyReqModel.class);
			log.info(CommonConstants.USP_GET_PRE_REGISTRATION_DETAILS + " " + reqModel);
			responseModel = iMasterRepository.updatesocietydetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getsocietydetailsexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getsocietydetailsexport(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getreceiveddetailsexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getreceiveddetailsexport(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getreceivedetailsexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ReceiveDtailsExportReqModel receivedDetailsExportReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ReceiveDtailsExportReqModel.class);

			responsemodel = iMasterRepository.getreceivedetailsexport(receivedDetailsExportReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getmanageinovice(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getmanageinovice(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getmanageinvoiceexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getmanageinvoiceexport(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getpaymentstatus(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getpaymentstatus(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel updatecashreceivedetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			ReceivedItemDetailsReqModel reqModel = objectMapper.readValue(decrypt, ReceivedItemDetailsReqModel.class);

			responseModel = iMasterRepository.updatecashreceivedetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getcashreceiveddetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getcashreceiveddetails(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getcashreceivedetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ReceiveItemDetailsReqModel reciveItemDetailsReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ReceiveItemDetailsReqModel.class);

			responsemodel = iMasterRepository.getcashreceivedetails(reciveItemDetailsReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getpaymentstatusdetailsexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getpaymentstatusdetailsexport(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getcashreceivedetailsexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getcashreceivedetailsexport(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getcashreceiveddetailsexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getcashreceiveddetailsexport(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertupdatewalletconfiguration(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			WalletConfigurationReqModel reqModel = objectMapper.readValue(decrypt, WalletConfigurationReqModel.class);
			responseModel = iMasterRepository.insertupdatewalletconfiguration(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getwalletconfiguration(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			SocietyDetailsReqModel societyDetailsReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					SocietyDetailsReqModel.class);

			responsemodel = iMasterRepository.getwalletconfiguration(societyDetailsReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel updatewalletconfiguration(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			UpdateWalletConfigurationReqModel reqModel = objectMapper.readValue(decrypt,
					UpdateWalletConfigurationReqModel.class);
			log.info(CommonConstants.USP_UPDATE_WALLET_CONFIGURATION + " " + reqModel);
			responseModel = iMasterRepository.updatewalletconfiguration(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getwalletconfigurationexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getwalletconfigurationexport(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getwalletDetailsList(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			SocietyDetailsReqModel societyDetailsReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					SocietyDetailsReqModel.class);

			responsemodel = iMasterRepository.getwalletDetailsList(societyDetailsReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getwalletDetailsListExport() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getwalletDetailsListExport();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertupdateCustInfo(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			CustomerDetailsReqModel reqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					CustomerDetailsReqModel.class);
			String imagePath = null;
			if (reqModel.getImagepath() != null) {
				imagePath = Utils.saveImage(reqModel.getImagepath(), reqModel.getMobileno(),
						null, azureconnectionstring, "invoice", String.valueOf(reqModel.getCustomername()),
						String.valueOf(Utils.getCurDateTime()), "PanImage", "static", "");

				reqModel.setImagepath(imagePath);
			}

			else {
				reqModel.setImagepath(null);
			}
			responseModel = iMasterRepository.insertupdateCustInfo(reqModel);
			System.out.println("imageUrl" + reqModel.getImagepath());
			System.out.println("imagePath" + imagePath);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getautomaticprocessdetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			AutomaticProcessReqModel automaticProcessReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					AutomaticProcessReqModel.class);

			responsemodel = iMasterRepository.getautomaticprocessdetails(automaticProcessReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel insertupdateautomaticprocessingstatus(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			InsertAutomaticProcessStepsReqModel reqModel = objectMapper.readValue(decrypt,
					InsertAutomaticProcessStepsReqModel.class);
			responseModel = iMasterRepository.insertupdateautomaticprocessingstatus(reqModel);
			ProcessStatusResModel processres = (ProcessStatusResModel) responseModel.getResponseObj();
			if (processres.getFlag() != null) {
				if (processres.getFlag() == 1) {
					try {
						ResponseModel responseModel1 = iMasterRepository.getprocessStsConfig();

						ProcessStsConfigModel configurationModel = (ProcessStsConfigModel) responseModel1
								.getResponseObject();

						if (processres.getMobileno() != null && processres.getMobileno() != "") {
							String finalurl = configurationModel.getLC_CM_SMS_API().replaceAll("phonenumber",
									"91" + processres.getMobileno()).replaceAll("msg", processres.getContent());
							System.out.println(finalurl);
							ResponseEntity<String> responseEntity;
							responseEntity = restTemplate.getForEntity(finalurl, String.class);
							String responseJsonString = responseEntity.getBody();
							log.info("responseJsonString " + responseJsonString.trim());
							if (responseJsonString.equalsIgnoreCase("Success")) {
								System.out.println("resr" + processres);
							}

						}
						// processres.setContent(null);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			responseModel.setResponseObj(null);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getcustInfoDetailsExport() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getcustInfoDetailsExport();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getstainmasternew(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			StainMasterNewReqModel reqModel = objectMapper.readValue(decrypt, StainMasterNewReqModel.class);
			responseModel = iMasterRepository.getstainmasternew(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getdamagemasternew(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			DamageMasterNewReqModel reqModel = objectMapper.readValue(decrypt, DamageMasterNewReqModel.class);
			responseModel = iMasterRepository.getdamagemasternew(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getcomplaintsdetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ComplaintsReqModel complaintsReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ComplaintsReqModel.class);

			responsemodel = iMasterRepository.getcomplaintsdetails(complaintsReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getrefunddetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ComplaintsReqModel complaintsReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ComplaintsReqModel.class);

			responsemodel = iMasterRepository.getrefunddetails(complaintsReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel insertupdateRiderInfo(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			RiderDetailsReqModel reqModel = objectMapper.readValue(decrypt, RiderDetailsReqModel.class);
			responseModel = iMasterRepository.insertupdateRiderInfo(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getRiderinfoExport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getRiderinfoExport(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getcallhestorydetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			CallHestoryReqModel callHestoryReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					CallHestoryReqModel.class);

			responsemodel = iMasterRepository.getcallhestorydetails(callHestoryReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel insercomplaintsdetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			InsertComplaintsReqModel reqModel = objectMapper.readValue(decrypt, InsertComplaintsReqModel.class);
			responseModel = iMasterRepository.insercomplaintsdetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getclosedcomplaintsdetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ComplaintsReqModel complaintsReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ComplaintsReqModel.class);

			responsemodel = iMasterRepository.getclosedcomplaintsdetails(complaintsReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel insertrefund(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			InsertRefundReqModel reqModel = objectMapper.readValue(decrypt, InsertRefundReqModel.class);
			responseModel = iMasterRepository.insertrefund(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getdetailstorefund(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			CallHestoryReqModel callHestoryReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					CallHestoryReqModel.class);

			responsemodel = iMasterRepository.getdetailstorefund(callHestoryReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getrefundmaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getrefundmaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getrefunddetailsexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getrefunddetailsexport(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getclosedcomplaintsdetailsexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getclosedcomplaintsdetailsexport(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getcomplaintsdetailsexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getcomplaintsdetailsexport(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getrefundeddetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ComplaintsReqModel complaintsReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ComplaintsReqModel.class);

			responsemodel = iMasterRepository.getrefundeddetails(complaintsReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getrefundeddetailsexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getrefundeddetailsexport(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel gettrackriderdetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			TrackRiderDetailsReqModel trackRiderDetailsReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					TrackRiderDetailsReqModel.class);

			responsemodel = iMasterRepository.gettrackriderdetails(trackRiderDetailsReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getapporveldetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			TrackRiderDetailsReqModel trackRiderDetailsReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					TrackRiderDetailsReqModel.class);

			responsemodel = iMasterRepository.getapporveldetails(trackRiderDetailsReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getapporvelsaction(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			CallHestoryReqModel callHestoryReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					CallHestoryReqModel.class);

			responsemodel = iMasterRepository.getapporvelsaction(callHestoryReqModel);

			List<AppovalActionStausResModel> detailslist = new ArrayList<AppovalActionStausResModel>();
			List<ApprovalActionImagePathResModel> imagelsit = new ArrayList<ApprovalActionImagePathResModel>();
			AppovalActionResModel response = (AppovalActionResModel) responsemodel.getResponseObject();

			for (AppovalActionStausResModel t : response.getDetails()) {

				AppovalActionStausResModel details = new AppovalActionStausResModel();
				details.setDamagedetails(t.getDamagedetails());
				details.setWC_OR_ORDERCODE(t.getWC_OR_ORDERCODE());

				details.setWC_OR_ORDERID(t.getWC_OR_ORDERID());
				details.setWC_IM_ITEM_NAME(t.getWC_IM_ITEM_NAME());
				details.setWC_SM_SERVICE_NAME(t.getWC_SM_SERVICE_NAME());

				details.setStatus(t.getStatus());
				details.setInvoice_id(t.getInvoice_id());
				details.setItem_id(t.getItem_id());
				details.setQrcode(t.getQrcode());
				details.setFlag(t.getFlag());
				details.setApprovedby(t.getApprovedby());
				details.setRejectedflag(t.getRejectedflag());
				details.setApprovedflag(t.getApprovedflag());

				for (ApprovalActionImagePathResModel t2 : response.getImagepath()) {
					ApprovalActionImagePathResModel imagepath = new ApprovalActionImagePathResModel();
					if (t.getInvoice_id().equals(t2.getInvoice_id())
							&& t.getItem_id().equals(t2.getItem_id())
							&& t.getWC_OR_ORDERID().equals(t2.getWC_OR_ORDERID())
							&& t.getQrcode().equals(t2.getQrcode())) {
						imagepath.setImagepath(t2.getImagepath());
						imagepath.setName(t2.getName());
						System.out.println("sfdsfdf" + imagepath);
						imagelsit.add(imagepath);
					}

				}
				details.setImagepath(imagelsit);
				imagelsit = new ArrayList<ApprovalActionImagePathResModel>();
				detailslist.add(details);
			}

			// model.setRespList(detailslist);
			// model.setRespList(esg_TitleArray);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(detailslist),
					encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel gettrackriderexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			TrackRiderDetailsReqModel trackRiderDetailsReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					TrackRiderDetailsReqModel.class);

			responsemodel = iMasterRepository.gettrackriderexport(trackRiderDetailsReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getwebdeliveryslots(RequestModel requestModel) {
		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			WebDelierySlotsModel webDelierySlotsModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					WebDelierySlotsModel.class);

			responsemodel = iMasterRepository.getwebdeliveryslots(webDelierySlotsModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getqrcodedetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			QrcodeDetailsReqModel qrcodeDetailsReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					QrcodeDetailsReqModel.class);

			responsemodel = iMasterRepository.getqrcodedetails(qrcodeDetailsReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel imageupload(RequestModel requestModel) {

		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		log.info("hexIv : " + requestModel.getExtraVariable());
		try {
			ImageUploadModel imageUploadModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ImageUploadModel.class);

			String imagePath = null;
			if (imageUploadModel.getFile() != null) {
				imagePath = Utils.saveImage(imageUploadModel.getFile(), imageUploadModel.getFilename(),
						null, azureconnectionstring, "damage", null, Utils.getCurrentDateTime(),
						imageUploadModel.getFilename(), "static", "");
				responseModel.setResponseData(imagePath);
				responseModel.setStatusCode(200);
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}

		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getapporveldetailsexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getapporveldetailsexport(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getcolourmasternew(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			ColourMasterNewReqModel reqModel = objectMapper.readValue(decrypt, ColourMasterNewReqModel.class);
			responseModel = iMasterRepository.getcolourmasternew(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getbrandmasternew(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			BrandMasterNewReqModel reqModel = objectMapper.readValue(decrypt, BrandMasterNewReqModel.class);
			responseModel = iMasterRepository.getbrandmasternew(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getcompanymasternew(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			CompanyMasterNewReqModel reqModel = objectMapper.readValue(decrypt, CompanyMasterNewReqModel.class);
			responseModel = iMasterRepository.getcompanymasternew(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getdaymaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getdaymaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getitemmasternew(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		log.info("hexIv : " + requestModel.getExtraVariable());
		try {
			ItemMasterNewReqModel itemMasterNewReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ItemMasterNewReqModel.class);
			log.info(CommonConstants.GET_INSERT_UPDATE_ITEM_MASTER + itemMasterNewReqModel);
			String imagePath = null;
			if (itemMasterNewReqModel.getImagebase() != null) {
				imagePath = Utils.saveImage(itemMasterNewReqModel.getImagebase(), itemMasterNewReqModel.getItemname(),
						null, azureconnectionstring, "invoice", String.valueOf(itemMasterNewReqModel.getItemcode()),
						Utils.getCurrentDate(), "getitemmasternew", "static", "");
			}
			itemMasterNewReqModel.setImagepath(imagePath);
			responseModel = iMasterRepository.getitemmasternew(itemMasterNewReqModel);
			System.out.println("imageUrl" + itemMasterNewReqModel.getImagepath());
			System.out.println("imagePath" + imagePath);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}

		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getitemmaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getitemmaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getserviceitemmapping(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			ServiceItemMappingReqModel reqModel = objectMapper.readValue(decrypt, ServiceItemMappingReqModel.class);
			responseModel = iMasterRepository.getserviceitemmapping(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getcountrymaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getcountrymaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getservicemasternew(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			ServiceItemMasterNewReqModel reqModel = objectMapper.readValue(decrypt, ServiceItemMasterNewReqModel.class);
			responseModel = iMasterRepository.getservicemasternew(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getrescheduleandcancellationdetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			RescheduleAndCancellationReqModel rescheduleAndCancellationReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					RescheduleAndCancellationReqModel.class);

			responsemodel = iMasterRepository.getrescheduleandcancellationdetails(rescheduleAndCancellationReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertupdatepickuprescheduledetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			PickupRescheduleReqModel reqModel = objectMapper.readValue(decrypt, PickupRescheduleReqModel.class);
			responseModel = iMasterRepository.insertupdatepickuprescheduledetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertupdatedeliveryrescheduledetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			PickupRescheduleReqModel reqModel = objectMapper.readValue(decrypt, PickupRescheduleReqModel.class);
			responseModel = iMasterRepository.insertupdatedeliveryrescheduledetails(reqModel);
			ProcessRescheduleResponseModel processres = (ProcessRescheduleResponseModel) responseModel.getResponseObj();
			if (processres.getStatus() == 200) {
				try {
					ResponseModel responseModel1 = iMasterRepository.getprocessrescheduleconfiguration();

					ProcessRescheduleConfiguration configurationModel = (ProcessRescheduleConfiguration) responseModel1
							.getResponseObject();

					if (processres.getMobileNo() != null && processres.getMobileNo() != "") {
						String finalurl = configurationModel.getLC_CM_SMS_API()
								.replaceAll("phonenumber", "91" + processres.getMobileNo())
								.replaceAll("msg", processres.getNotification());
						String finalurl_new = finalurl.replaceAll(" ", "+");
						ResponseEntity<String> responseEntity;
						responseEntity = restTemplate.getForEntity(finalurl_new, String.class);
						String responseJsonString = responseEntity.getBody();
						log.info("responseJsonString " + responseJsonString.trim());
						if (responseJsonString.equalsIgnoreCase("Success")) {
						}
					}
					processres.setNotification(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			responseModel.setResponseObj(null);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getrescheduledetailsbyorderid(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			PickupDetailsByItemsReqModel reqModel = objectMapper.readValue(decrypt, PickupDetailsByItemsReqModel.class);
			responseModel = iMasterRepository.getrescheduledetailsbyorderid(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertUpdateAssignDetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			PickupRescheduleReqModel reqModel = objectMapper.readValue(decrypt, PickupRescheduleReqModel.class);
			responseModel = iMasterRepository.insertUpdateAssignDetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getManualAssignDetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			RescheduleAndCancellationReqModel rescheduleAndCancellationReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					RescheduleAndCancellationReqModel.class);

			responsemodel = iMasterRepository.getManualAssignDetails(rescheduleAndCancellationReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertslot(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			SlotReqModel reqModel = objectMapper.readValue(decrypt, SlotReqModel.class);
			responseModel = iMasterRepository.insertslot(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getcancilationmaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getcancilationmaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertupdateridercancilation(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			RiderCancilationReqModel reqModel = objectMapper.readValue(decrypt, RiderCancilationReqModel.class);
			responseModel = iMasterRepository.insertupdateridercancilation(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getstainmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getstainmasterexport();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getservicemasterexport() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getservicemasterexport();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getserviceitemmappingmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getserviceitemmappingmasterexport();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getitemmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getitemmasterexport();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getdamagemasterexport() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getdamagemasterexport();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getcolourmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getcolourmasterexport();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getbrandmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getbrandmasterexport();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getmanualassignexport(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			RescheduleAndCancellationExportReqModel reqModel = objectMapper.readValue(decrypt,
					RescheduleAndCancellationExportReqModel.class);
			responseModel = iMasterRepository.getmanualassignexport(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getdurationmaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getdurationmaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertupdateslotmasternew(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			InsertSlotNewReqModel reqModel = objectMapper.readValue(decrypt, InsertSlotNewReqModel.class);
			responseModel = iMasterRepository.insertupdateslotmasternew(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getslotmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getslotmasterexport();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getrescheduleandcanncellationexport(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			RescheduleAndCancellationExportReqModel reqModel = objectMapper.readValue(decrypt,
					RescheduleAndCancellationExportReqModel.class);
			responseModel = iMasterRepository.getrescheduleandcanncellationexport(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getslotcountt() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getslotcountt();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getbrandmaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getbrandmaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getemailpromotionaltemplatemaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getemailpromotionaltemplatemaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getemailtransactionaltemplatemaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getemailtransactionaltemplatemaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertemailtemplatedetailstransactional(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			TemplateDetailsReqModel reqModel = objectMapper.readValue(decrypt, TemplateDetailsReqModel.class);
			responseModel = iMasterRepository.insertemailtemplatedetailstransactional(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertemailtemplatedetailspromotional(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			TemplateDetailsReqModel reqModel = objectMapper.readValue(decrypt, TemplateDetailsReqModel.class);
			responseModel = iMasterRepository.insertemailtemplatedetailspromotional(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getemailcategorymaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getemailcategorymaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getemailcategorydetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			TemplateDetailsReqModel reqModel = objectMapper.readValue(decrypt, TemplateDetailsReqModel.class);
			responseModel = iMasterRepository.getemailcategorydetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getemailtempaltedetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			TemplateDetailsReqModel reqModel = objectMapper.readValue(decrypt, TemplateDetailsReqModel.class);
			responseModel = iMasterRepository.getemailtempaltedetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertupdateemailtempaltedetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			TemplateDetailsReqModel reqModel = objectMapper.readValue(decrypt, TemplateDetailsReqModel.class);
			responseModel = iMasterRepository.insertupdateemailtempaltedetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getbirthdaydetails() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getbirthdaydetails();
			List<EmailResponseModel> daores = (List<EmailResponseModel>) responseModel.getRespList();
			for (EmailResponseModel res : daores) {
				if (res.getEmailsent() == 1) {
					try {
						ConfigurationModel configurationModel = new ConfigurationModel();
						configurationModel.setConfigurationid(Long.valueOf(1));
						configurationModel.setCustomerid(res.getUserid());
						;
						configurationModel.setEmailtypeid(Long.valueOf(6));
						ResponseModel ress = iMasterRepository.getConfiguration(configurationModel);
						ConfigurationResponseModel configurationResponseModel = (ConfigurationResponseModel) ress
								.getResponseObject();
						Utils.sendMail(configurationResponseModel, null, null);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				String iv = Utils.randomKey(16);
				model.setResponseData(
						Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
				model.setStatusCode(200);
				model.setStatus(iv);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getanniversarydetails() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getanniversarydetails();
			List<EmailResponseModel> daores = (List<EmailResponseModel>) responseModel.getRespList();
			for (EmailResponseModel res : daores) {
				if (res.getEmailsent() == 1) {
					try {
						ConfigurationModel configurationModel = new ConfigurationModel();
						configurationModel.setConfigurationid(Long.valueOf(1));
						configurationModel.setCustomerid(res.getUserid());
						;
						configurationModel.setEmailtypeid(Long.valueOf(7));
						ResponseModel ress = iMasterRepository.getConfiguration(configurationModel);
						ConfigurationResponseModel configurationResponseModel = (ConfigurationResponseModel) ress
								.getResponseObject();
						Utils.sendMail(configurationResponseModel, null, null);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				String iv = Utils.randomKey(16);
				model.setResponseData(
						Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
				model.setStatusCode(200);
				model.setStatus(iv);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getnotificationsequencedetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getnotificationsequencedetails(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel getnotificationsequencedetailsexport(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			ChallanMasterReqModel chalanMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ChallanMasterReqModel.class);

			responsemodel = iMasterRepository.getnotificationsequencedetailsexport(chalanMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getgrommingstandardsdetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			SocietyDetailsReqModel societyDetailsReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					SocietyDetailsReqModel.class);

			responsemodel = iMasterRepository.getgrommingstandardsdetails(societyDetailsReqModel);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}

	@Override
	public ResponseModel insertupdategrommingstandards(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		// log.info("hexIv : "+ requestModel.getExtraVariable());
		try {
			GrommingstandardsReqModel grommingstandardsReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					GrommingstandardsReqModel.class);
			// log.info(CommonConstants.INSERT_UPDATE_SOCITY+ grommingstandardsReqModel);
			String imagePath = null;
			if (grommingstandardsReqModel.getImagepath() != null) {
				imagePath = Utils.saveImage(grommingstandardsReqModel.getImagepath(),
						grommingstandardsReqModel.getTitle(),
						null, azureconnectionstring, "invoice", String.valueOf(grommingstandardsReqModel.getGsid()),
						String.valueOf(Utils.getCurDateTime()), "GroomingsImage", "static", "");

				grommingstandardsReqModel.setImagepath(imagePath);
			}

			else {
				grommingstandardsReqModel.setImagepath(null);
			}
			responseModel = iMasterRepository.insertupdategrommingstandards(grommingstandardsReqModel);
			System.out.println("imageUrl" + grommingstandardsReqModel.getImagepath());
			System.out.println("imagePath" + imagePath);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}

		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getChatUserList(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			ChatUserReqModel reqModel = objectMapper.readValue(decrypt, ChatUserReqModel.class);
			responseModel = iMasterRepository.getChatUserList(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getlastmesssage(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			ChatUserReqModel reqModel = objectMapper.readValue(decrypt, ChatUserReqModel.class);
			responseModel = iMasterRepository.getlastmesssage(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getmessageHistory(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			ChatUserReqModel reqModel = objectMapper.readValue(decrypt, ChatUserReqModel.class);
			responseModel = iMasterRepository.getmessageHistory(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getupdateMessageStatus(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			ChatUserReqModel reqModel = objectMapper.readValue(decrypt, ChatUserReqModel.class);
			responseModel = iMasterRepository.getupdateMessageStatus(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertUpdateAppQRcodeDetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			OrderDetailsReqModel reqModel = objectMapper.readValue(decrypt, OrderDetailsReqModel.class);
			responseModel = iMasterRepository.insertUpdateAppQRcodeDetails(reqModel);

			List<NewOrderResModel> newOrderResModel = (List<NewOrderResModel>) responseModel.getResponseObject();

			for (NewOrderResModel detresp : newOrderResModel) {
				if (detresp.getInvoiceid() != null && detresp.getNewuserid() != null) {
					OrdersummaryPdf invoice = new OrdersummaryPdf();
					invoice.setOrderid(reqModel.getOrderid());
					invoice.setInvoiceid(detresp.getInvoiceid());
					invoice.setUserid(reqModel.getCustomerid());
					ResponseModel pdfres = iMasterRepository.getOrderSummaryPdf(invoice);

					PaymentInvoiceResModel paymentinvoiceResModel = (PaymentInvoiceResModel) pdfres.getResponseObject();
					if (String.valueOf(paymentinvoiceResModel.getPaymentUserDetails().getStatus())
							.equalsIgnoreCase("200")) {
						Map<String, Object> data = new HashMap<String, Object>();
						data.put("wecleanuser", paymentinvoiceResModel.getWecleanInvoice());
						data.put("paymentdetails", paymentinvoiceResModel.getPaymentUserDetails());
						data.put("pickupdate", paymentinvoiceResModel.getPaymentUserDetails().getPickupdate());
						data.put("service", paymentinvoiceResModel.getServicename());
						data.put("specialinstruct", paymentinvoiceResModel.getSpecialinstruct());
						data.put("cgst", paymentinvoiceResModel.getCgst());
						data.put("sgst", paymentinvoiceResModel.getSgst());
						String templateName = "ordersummary";
						Assert.notNull(templateName, "The templateName can not be null");
						Context ctx = new Context();
						if (data != null) {
							Iterator itMap = data.entrySet().iterator();
							while (itMap.hasNext()) {
								Map.Entry pair = (Map.Entry) itMap.next();
								ctx.setVariable(pair.getKey().toString(), pair.getValue());
							}
						}
						String processedHtml = templateEngine.process(templateName, ctx);
						String imagePath = Utils.saveImage("",
								"", null, azureconnectionstring, "invoice",
								String.valueOf(reqModel.getCustomerid() + reqModel.getOrderid()),
								Utils.getCurrentDateTime(), "ordersummary", "dynamic", processedHtml);
						OrderSummaryImageReqModel ordersummary = new OrderSummaryImageReqModel();
						System.out.println("imagepath" + imagePath);
						ordersummary.setImagepath(imagePath);
						ordersummary.setInvoiceid(detresp.getInvoiceid());
						ordersummary.setOrderid(reqModel.getOrderid());
						ResponseModel updateimg = iMasterRepository.updateOrderSummaryImagePath(ordersummary);
						System.out.println(imagePath);

						for (CollectItemDetailsModel d : reqModel.getCollectitems()) {
							if (d.getBranddetails().size() < 0 || d.getColordetails().size() < 0 ||
									d.getDamagedetails().size() < 0 || d.getStaindetails().size() < 0) {

								try {
									ConfigurationModel configurationModel = new ConfigurationModel();
									configurationModel.setConfigurationid(Long.valueOf(1));
									configurationModel.setCustomerid(reqModel.getCustomerid());
									;
									configurationModel.setEmailtypeid(Long.valueOf(5));
									ResponseModel res = iMasterRepository.getConfiguration(configurationModel);
									ConfigurationResponseModel configurationResponseModel = (ConfigurationResponseModel) res
											.getResponseObject();
									Utils.sendMail(configurationResponseModel, imagePath, "Order Summary.pdf");
								} catch (Exception e) {
									e.printStackTrace();
								}

							}
						}
					}
				}
			}
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertUpdateOrderSubmitDetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			OrderDetailsReqModel reqModel = objectMapper.readValue(decrypt, OrderDetailsReqModel.class);

			responseModel = iMasterRepository.insertUpdateOrderSubmitDetails(reqModel);
			List<NewOrderResModel> newOrderResModel = (List<NewOrderResModel>) responseModel.getResponseObject();

			NewOrderResModel processres = (NewOrderResModel) responseModel.getResponseObj();

			for (NewOrderResModel detresp : newOrderResModel) {
				if (detresp.getInvoiceid() != null && reqModel.getCustomerid() != null) {
					OrdersummaryPdf invoice = new OrdersummaryPdf();
					invoice.setOrderid(reqModel.getOrderid());
					invoice.setInvoiceid(detresp.getInvoiceid());
					invoice.setUserid(reqModel.getCustomerid());
					ResponseModel pdfres = iMasterRepository.getOrderSummaryPdf(invoice);

					PaymentInvoiceResModel paymentinvoiceResModel = (PaymentInvoiceResModel) pdfres.getResponseObject();
					if (String.valueOf(paymentinvoiceResModel.getPaymentUserDetails().getStatus())
							.equalsIgnoreCase("200")) {
						Map<String, Object> data = new HashMap<String, Object>();
						data.put("wecleanuser", paymentinvoiceResModel.getWecleanInvoice());
						data.put("paymentdetails", paymentinvoiceResModel.getPaymentUserDetails());
						data.put("pickupdate", paymentinvoiceResModel.getPaymentUserDetails().getPickupdate());
						data.put("service", paymentinvoiceResModel.getServicename());
						data.put("specialinstruct", paymentinvoiceResModel.getSpecialinstruct());
						data.put("cgst", paymentinvoiceResModel.getCgst());
						data.put("sgst", paymentinvoiceResModel.getSgst());
						String templateName = "ordersummary";
						Assert.notNull(templateName, "The templateName can not be null");
						Context ctx = new Context();
						if (data != null) {
							Iterator itMap = data.entrySet().iterator();
							while (itMap.hasNext()) {
								Map.Entry pair = (Map.Entry) itMap.next();
								ctx.setVariable(pair.getKey().toString(), pair.getValue());
							}
						}
						String processedHtml = templateEngine.process(templateName, ctx);
						String imagePath = Utils.saveImage("",
								"", null, azureconnectionstring, "invoice",
								String.valueOf(reqModel.getCustomerid() + reqModel.getOrderid()),
								Utils.getCurrentDateTime(), "ordersummary", "dynamic", processedHtml);
						OrderSummaryImageReqModel ordersummary = new OrderSummaryImageReqModel();
						System.out.println("imagepath" + imagePath);
						ordersummary.setImagepath(imagePath);
						ordersummary.setInvoiceid(detresp.getInvoiceid());
						ordersummary.setOrderid(reqModel.getOrderid());
						ResponseModel updateimg = iMasterRepository.updateOrderSummaryImagePath(ordersummary);
						System.out.println(imagePath);

						for (CollectItemDetailsModel d : reqModel.getCollectitems()) {
							if (d.getBranddetails().size() < 0 || d.getColordetails().size() < 0 ||
									d.getDamagedetails().size() < 0 || d.getStaindetails().size() < 0) {

								try {
									ConfigurationModel configurationModel = new ConfigurationModel();
									configurationModel.setConfigurationid(Long.valueOf(1));
									configurationModel.setCustomerid(reqModel.getCustomerid());
									;
									configurationModel.setEmailtypeid(Long.valueOf(5));
									ResponseModel res = iMasterRepository.getConfiguration(configurationModel);
									ConfigurationResponseModel configurationResponseModel = (ConfigurationResponseModel) res
											.getResponseObject();
									Utils.sendMail(configurationResponseModel, imagePath, "Order Summary.pdf");
								} catch (Exception e) {
									e.printStackTrace();
								}

							}
						}
					}
				}
			}

			if (responseModel.getStatusCode() == 200) {
				try {
					ResponseModel responseModel1 = iMasterRepository.getprocessneedapprovalconfig();

					ProcessRescheduleConfiguration configurationModel = (ProcessRescheduleConfiguration) responseModel1
							.getResponseObject();

					if (processres.getMobile_id() != null && processres.getMobile_id() != "") {
						String finalurl = configurationModel.getLC_CM_SMS_API()
								.replaceAll("phonenumber", "91" + processres.getMobile_id())
								.replaceAll("msg", processres.getNotification());
						// String finalurl_new = finalurl.replaceAll(" ", "+");
						ResponseEntity<String> responseEntity;
						responseEntity = restTemplate.getForEntity(finalurl, String.class);
						String responseJsonString = responseEntity.getBody();
						log.info("responseJsonString " + responseJsonString.trim());
						if (responseJsonString.equalsIgnoreCase("Success")) {
						}
					}
					processres.setNotification(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			responseModel.setResponseObj(null);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getWcSocietyMaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getWcSocietyMaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertUpdateWebQrcodeDetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			OrderDetailsReqModel reqModel = objectMapper.readValue(decrypt, OrderDetailsReqModel.class);
			responseModel = iMasterRepository.insertUpdateWebQrcodeDetails(reqModel);
			List<NewOrderResModel> newOrderResModel = (List<NewOrderResModel>) responseModel.getResponseObject();

			for (NewOrderResModel detresp : newOrderResModel) {
				if (detresp.getInvoiceid() != null && detresp.getNewuserid() != null) {

					OrdersummaryPdf invoice = new OrdersummaryPdf();
					invoice.setOrderid(responseModel.getOrderid());
					invoice.setInvoiceid(detresp.getInvoiceid());
					invoice.setUserid(detresp.getNewuserid());
					ResponseModel pdfres = iMasterRepository.getOrderSummaryPdf(invoice);

					PaymentInvoiceResModel paymentinvoiceResModel = (PaymentInvoiceResModel) pdfres.getResponseObject();
					if (String.valueOf(paymentinvoiceResModel.getPaymentUserDetails().getStatus())
							.equalsIgnoreCase("200")) {
						Map<String, Object> data = new HashMap<String, Object>();
						data.put("wecleanuser", paymentinvoiceResModel.getWecleanInvoice());
						data.put("paymentdetails", paymentinvoiceResModel.getPaymentUserDetails());
						data.put("pickupdate", paymentinvoiceResModel.getPaymentUserDetails().getPickupdate());
						data.put("service", paymentinvoiceResModel.getServicename());
						data.put("specialinstruct", paymentinvoiceResModel.getSpecialinstruct());
						data.put("cgst", paymentinvoiceResModel.getCgst());
						data.put("sgst", paymentinvoiceResModel.getSgst());
						String templateName = "ordersummary";
						Assert.notNull(templateName, "The templateName can not be null");
						Context ctx = new Context();
						if (data != null) {
							Iterator itMap = data.entrySet().iterator();
							while (itMap.hasNext()) {
								Map.Entry pair = (Map.Entry) itMap.next();
								ctx.setVariable(pair.getKey().toString(), pair.getValue());
							}
						}
						String processedHtml = templateEngine.process(templateName, ctx);
						String imagePath = Utils.saveImage("",
								"", null, azureconnectionstring, "invoice",
								String.valueOf(detresp.getNewuserid() + responseModel.getOrderid()),
								Utils.getCurrentDateTime(), "ordersummary", "dynamic", processedHtml);
						OrderSummaryImageReqModel ordersummary = new OrderSummaryImageReqModel();
						System.out.println("imagepath" + imagePath);
						ordersummary.setImagepath(imagePath);
						ordersummary.setInvoiceid(detresp.getInvoiceid());
						ordersummary.setOrderid(responseModel.getOrderid());
						ResponseModel updateimg = iMasterRepository.updateOrderSummaryImagePath(ordersummary);
						System.out.println(imagePath);

						try {
							ConfigurationModel configurationModel = new ConfigurationModel();
							configurationModel.setConfigurationid(Long.valueOf(1));
							configurationModel.setCustomerid(detresp.getNewuserid());
							;
							configurationModel.setEmailtypeid(Long.valueOf(5));
							ResponseModel res = iMasterRepository.getConfiguration(configurationModel);
							ConfigurationResponseModel configurationResponseModel = (ConfigurationResponseModel) res
									.getResponseObject();
							Utils.sendMail(configurationResponseModel, imagePath, "Order Summary.pdf");
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertUpdateWebSubmitDetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			OrderDetailsReqModel reqModel = objectMapper.readValue(decrypt, OrderDetailsReqModel.class);
			responseModel = iMasterRepository.insertUpdateWebSubmitDetails(reqModel);
			List<NewOrderResModel> newOrderResModel = (List<NewOrderResModel>) responseModel.getResponseObject();

			for (NewOrderResModel detresp : newOrderResModel) {
				if (detresp.getInvoiceid() != null && detresp.getNewuserid() != null) {
					OrdersummaryPdf invoice = new OrdersummaryPdf();
					invoice.setOrderid(responseModel.getOrderid());
					invoice.setInvoiceid(detresp.getInvoiceid());
					invoice.setUserid(detresp.getNewuserid());
					ResponseModel pdfres = iMasterRepository.getOrderSummaryPdf(invoice);

					PaymentInvoiceResModel paymentinvoiceResModel = (PaymentInvoiceResModel) pdfres.getResponseObject();
					if (String.valueOf(paymentinvoiceResModel.getPaymentUserDetails().getStatus())
							.equalsIgnoreCase("200")) {
						Map<String, Object> data = new HashMap<String, Object>();
						data.put("wecleanuser", paymentinvoiceResModel.getWecleanInvoice());
						data.put("paymentdetails", paymentinvoiceResModel.getPaymentUserDetails());
						data.put("pickupdate", paymentinvoiceResModel.getPaymentUserDetails().getPickupdate());
						data.put("service", paymentinvoiceResModel.getServicename());
						data.put("specialinstruct", paymentinvoiceResModel.getSpecialinstruct());
						data.put("cgst", paymentinvoiceResModel.getCgst());
						data.put("sgst", paymentinvoiceResModel.getSgst());
						// System.out.println("inputdata" + paymentinvoiceResModel);
						String templateName = "ordersummary";
						Assert.notNull(templateName, "The templateName can not be null");
						Context ctx = new Context();
						if (data != null) {
							Iterator itMap = data.entrySet().iterator();
							while (itMap.hasNext()) {
								Map.Entry pair = (Map.Entry) itMap.next();
								ctx.setVariable(pair.getKey().toString(), pair.getValue());
							}
						}
						String processedHtml = templateEngine.process(templateName, ctx);
						String imagePath = Utils.saveImage("",
								"", null, azureconnectionstring, "invoice",
								String.valueOf(detresp.getNewuserid() + responseModel.getOrderid()),
								Utils.getCurrentDateTime(), "ordersummary", "dynamic", processedHtml);
						OrderSummaryImageReqModel ordersummary = new OrderSummaryImageReqModel();
						System.out.println("imagepath" + imagePath);
						ordersummary.setImagepath(imagePath);
						ordersummary.setInvoiceid(detresp.getInvoiceid());
						ordersummary.setOrderid(responseModel.getOrderid());
						ResponseModel updateimg = iMasterRepository.updateOrderSummaryImagePath(ordersummary);
						System.out.println(imagePath);

						try {
							ConfigurationModel configurationModel = new ConfigurationModel();
							configurationModel.setConfigurationid(Long.valueOf(1));
							configurationModel.setCustomerid(detresp.getNewuserid());
							;
							configurationModel.setEmailtypeid(Long.valueOf(5));
							ResponseModel res = iMasterRepository.getConfiguration(configurationModel);
							ConfigurationResponseModel configurationResponseModel = (ConfigurationResponseModel) res
									.getResponseObject();
							Utils.sendMail(configurationResponseModel, imagePath, "Order Summary.pdf");
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getWcServiceType() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getWcServiceType();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getrangemaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getrangemaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getStepsMaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getStepsMaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getinsertupdatestepsmaster(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		log.info("hexIv : " + requestModel.getExtraVariable());
		try {
			StepsMasterNewRequestModel stepsMasterNewRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					StepsMasterNewRequestModel.class);
			log.info(CommonConstants.GET_INSERT_UPDATE_STEPS_MASTER + stepsMasterNewRequestModel);
			String imagePath = null;
			if (stepsMasterNewRequestModel.getImagepath() != null) {
				imagePath = Utils.saveImage(stepsMasterNewRequestModel.getImagepath(),
						stepsMasterNewRequestModel.getProcessingsteps(),
						null, azureconnectionstring, "invoice", String.valueOf(stepsMasterNewRequestModel.getStId()),
						Utils.getCurrentDate(), "getinsertupdatestepsmaster", "static", "");

				stepsMasterNewRequestModel.setImagepath(imagePath);
			} else {
				stepsMasterNewRequestModel.setImagepath(null);
			}
			responseModel = iMasterRepository.getinsertupdatestepsmaster(stepsMasterNewRequestModel);
			System.out.println("imageUrl" + stepsMasterNewRequestModel.getImagepath());
			System.out.println("imagePath" + imagePath);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}

		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertmessagedetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		log.info("hexIv : " + requestModel.getExtraVariable());
		try {

			MessagedetailsModel messagedetailsModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					MessagedetailsModel.class);
			log.info(CommonConstants.INSERT_MESSAGE_DETAILS + messagedetailsModel);

			if (messagedetailsModel.getAudioUrl() != null) {
				String audiofile = Utils.saveAudio(messagedetailsModel.getAudioUrl(),
						String.valueOf("insertmessagedetails" + Utils.getCurrentDateTimeMillisec()),
						azureconnectionstring);
				messagedetailsModel.setAudioUrl(audiofile);
			} else {
				messagedetailsModel.setAudioUrl(null);
			}
			responseModel = iMasterRepository.insertmessagedetails(messagedetailsModel);

		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}

		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getServiceStepsMaster(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			ServiceStepsMapppingReqModel reqModel = objectMapper.readValue(decrypt, ServiceStepsMapppingReqModel.class);
			responseModel = iMasterRepository.getServiceStepsMaster(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getstepmasterreport() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getstepmasterreport();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getservicestepmappingexport() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getservicestepmappingexport();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel updateitemwiseimageupload(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		log.info("hexIv : " + requestModel.getExtraVariable());
		try {

			ItemwiseImageReqModel itemwiseImageReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					ItemwiseImageReqModel.class);
			log.info(CommonConstants.UPDATE_ITEMWISE_IMAGE_UPLOAD + itemwiseImageReqModel);

			responseModel = iMasterRepository.updateitemwiseimageupload(itemwiseImageReqModel);

		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}

		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel insertUpdateOrderApprovelsDetails(RequestModel requestModel) {
		ResponseModel model = new ResponseModel();
		ResponseModel responseModel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			OrderDetailsReqModel reqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					OrderDetailsReqModel.class);
			ApprovalsDetResModel ressmodel = null;
			responseModel = iMasterRepository.insertUpdateOrderApprovelsDetails(reqModel);
			if (responseModel.getStatusCode() == 200) {

				ressmodel = (ApprovalsDetResModel) responseModel.getResponseObject();
				// ResponseModel responseModel1 = iMasterRepository.getprocessOrderAckconfig();

				// ProcessStsConfigModel configurationModel = (ProcessStsConfigModel)
				// responseModel1.getResponseObject();

				if (ressmodel.getSms() != null && !ressmodel.getSms().equals("")) {
					String finalurl = ressmodel.getSms();
					System.out.println(finalurl);
					ResponseEntity<String> responseEntity;
					responseEntity = restTemplate.getForEntity(finalurl, String.class);
					String responseJsonString = responseEntity.getBody();
					log.info("responseJsonString " + responseJsonString.trim());
					System.out.println(responseJsonString);
					System.out.println(finalurl);
					if (responseJsonString != null) {
					}
				}

				responseModel.setNotification(null);

			}
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getCustomerMaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getCustomerMaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getOrderWiseMaster() {

		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getOrderWiseMaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

}
