package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApprovalsDetResModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1241829951439332969L;
	private String statusCode;
	private String message;
	private String sms;

}
