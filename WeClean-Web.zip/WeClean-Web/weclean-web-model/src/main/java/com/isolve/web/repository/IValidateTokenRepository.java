package com.isolve.web.repository;

import com.isolve.web.model.ResponseModel;

public interface IValidateTokenRepository {

	ResponseModel validateToken(String jwtToken);

}
