package com.isolve.common.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class RoleMasterModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1009624638846124536L;
	@Id
	private String WC_RS_ROLEID;
	private String WC_RS_ROLENAME;
}
