package com.isolve.common.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class ClientDetailsResponse 
{
	@Id
	private String LC_PD_PATIENTID;
	private String LC_PD_FIRSTNAME;
	private String LC_PD_MIDDLENAME;
	private String LC_PD_LASTNAME;
	private String LC_PD_FULLNAME;
	private String LC_PD_DOB;
	private String LC_PD_AGE;
	private String LC_PD_PRIMARYCONTACT;
	private String LC_PD_ALTERNATECONTACT;
	private String LC_PD_EMAILID;
	private String LC_PD_ADDRESTYPE;
	private String LC_PD_PATIENTADDRESS;
	private String LC_PD_FLAG;
	private String LC_PD_CREATEDDATE;
	private String LC_PD_CREATEDBY;
	private String LC_PD_MODIFIEDDATE;
	private String LC_PD_MODIFIEDBY;
}
