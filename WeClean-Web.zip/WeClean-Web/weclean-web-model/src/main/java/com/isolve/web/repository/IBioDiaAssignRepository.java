package com.isolve.web.repository;

import java.sql.SQLException;
import java.util.List;

import com.isolve.web.model.AssignParamedicRequestModel;
import com.isolve.web.model.CancelParamedicRequestModel;
import com.isolve.web.model.ParamedicResponseModel;
import com.isolve.web.model.ParamedicUserAvailabiltyRequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.UpdateBioDiaAssignRequestModel;
import com.isolve.web.model.UpdateBioDiaAssignResponseModel;
import com.isolve.web.model.UserPickUpScheduleRequestModel;

public interface IBioDiaAssignRepository 
{
	public List<UpdateBioDiaAssignResponseModel> updateBioDiaAssign(UpdateBioDiaAssignRequestModel requestModel);

	ResponseModel getAssignParamedicUpdate(AssignParamedicRequestModel assignParamedicRequestModel);

	ResponseModel getUserPickupSchedule(UserPickUpScheduleRequestModel userPickUpScheduleRequestModel) throws SQLException;
	
	ResponseModel getParamedicUserAvailability(ParamedicUserAvailabiltyRequestModel userAvailabiltyRequestModel) throws SQLException;

	ResponseModel cancelParamedic(CancelParamedicRequestModel cancelParamedicRequestModel);

	ResponseModel getCancelReason();

	ResponseModel getParamedicUserAvailabilityDay(ParamedicUserAvailabiltyRequestModel reqModel) throws SQLException;

	public ResponseModel insertUpdateTrackSMSDetails(ParamedicResponseModel paramedicResponseModel, String shortenURL, String longURL);

	public ResponseModel getTrackFullUrl(String shortenURL);
}