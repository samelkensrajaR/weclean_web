package com.isolve.common.repository;

import com.isolve.common.model.ResponseModel;

public interface IValidateTokenRepository {

	ResponseModel validateToken(String jwtToken);

}
