package com.isolve.web.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApprovalActionImagePathResModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8714622194718411237L;

	
	private String imagepath;
	
	private String name;
	private Long invoice_id;
	private Long Item_id;
	private Long WC_OR_ORDERID;
	private String qrcode;
}
