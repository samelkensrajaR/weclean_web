package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ItemMasterNewReqModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer flag;
	private String itemname;
	private String itemcode;
	private String userid;
	private Integer im_flag;
	private String description;
	private Integer im_id;
	private String imagepath;
	private Integer start;
	private Integer end;
	private String search;
	private String imagebase;
	

}
