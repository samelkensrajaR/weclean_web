package com.isolve.common.service;

import com.isolve.common.model.RequestModel;
import com.isolve.common.model.ResponseModel;

public interface IAppWebTokenService {

	ResponseModel createAuthenticationToken(RequestModel requestModel);

	ResponseModel signUpDetails(RequestModel requestModel);

	ResponseModel generateOTP(RequestModel requestModel);

	ResponseModel appWebLogin(RequestModel requestModel);

	ResponseModel verifyOTP(RequestModel requestModel);

	ResponseModel logout(RequestModel requestModel);

}
