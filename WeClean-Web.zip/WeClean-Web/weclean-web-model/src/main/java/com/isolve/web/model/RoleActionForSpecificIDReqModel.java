package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RoleActionForSpecificIDReqModel implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4033193316438582519L;
	private Integer roleid;
	private Integer targetid;
	private Integer menutarget;
	
}
