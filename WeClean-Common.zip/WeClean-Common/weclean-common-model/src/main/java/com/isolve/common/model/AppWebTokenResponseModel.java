package com.isolve.common.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQueries;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.isolve.common.utils.CommonConstants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@NamedStoredProcedureQueries({
@NamedStoredProcedureQuery(name = CommonConstants.USP_WECLEAN_APP_WEB_LOGIN, procedureName = CommonConstants.USP_WECLEAN_APP_WEB_LOGIN,
parameters = {
		@StoredProcedureParameter(mode = ParameterMode.IN,name = CommonConstants.LOGIN_USER,type=String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN,name = CommonConstants.PASSWORD,type=String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN,name = CommonConstants.LOGIN_TYPE,type=String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN,name = CommonConstants.LOGIN_MODE,type=String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN,name = CommonConstants.LANG_ID,type=String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN,name = CommonConstants.WC_USD_LATITUDE,type=String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN,name = CommonConstants.WC_USD_LONGITUDE,type=String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN,name = CommonConstants.IMEI,type=String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN,name = CommonConstants.FIREBASE_ID,type=String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN,name = CommonConstants.ANDROID_IOS_WEB,type=String.class)
} )})
@Entity
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AppWebTokenResponseModel implements Serializable {

	private static final long serialVersionUID = -8091879091924046844L;
	@Id	
	private Integer status;
	private String message;
	private String technicianId;
	private String technicianName;
	private String title;
	private String technicianStarted;
	private String Key;
	private String roles;
	private Boolean verified;
	private String cityid;
	private String stateid;
	private String first_name;
	private String last_name;
	private String mobileno;
	private String emailid;
	
	
	
}
