package com.isolve.common.repository;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.isolve.common.model.ConfigurationModel;
import com.isolve.common.model.GenerateOTPForgotPassResModel;
import com.isolve.common.model.RegistrationDetailsReqModel;
import com.isolve.common.model.ResponseModel;
import com.isolve.common.model.VerifyRegisterUserOtp;
import com.isolve.common.utils.CommonConstants;
import com.isolve.common.utils.MyObject;
import com.isolve.common.utils.Utils;
import com.isolve.common.model.LableMasterFinalResponseModel;
import com.isolve.common.model.LableMasterRequestModel;

@Transactional
@Repository
public class RegistrationRepositoryImpl implements IRegistrationRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	/**
	 * @author
	 * @Name registrationDetails - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: registrationDetails method using to insert sign up details for Web.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel registrationDetails(RegistrationDetailsReqModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARBINARY));
			prmtrsList.add(new SqlParameter(Types.VARBINARY));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_REGISTRATION_DETAILS (?,?,?,?,?)}");
				callableStatement.setString(1, requestModel.getName());
				callableStatement.setString(2, requestModel.getEmailid());
				callableStatement.setString(3, requestModel.getMobileno());
				if (requestModel.getGenderid() != null) {
					callableStatement.setInt(4, requestModel.getGenderid());
				} else {
					callableStatement.setString(4, null);
				}
				if (requestModel.getTypeid() != null) {
					callableStatement.setInt(5, requestModel.getTypeid());
				} else {
					callableStatement.setString(5, null);
				}
				return callableStatement;

			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();

			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("RegistrationDetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();

			}
		}
		return responseModel;

	}

	/**
	 * @author
	 * @Name getConfiguration - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getConfiguration method using to get External Api for sending sms.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public ResponseModel getConfiguration() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_CONFIGURATION()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			ConfigurationModel configurationModel = new ConfigurationModel();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				for (int i = 0; i < l_lstResult.size(); i++) {
					LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
					configurationModel.setLC_CM_SMS_API(l_hmColmnData.get("WC_CM_SMS_API"));
					configurationModel.setLC_CM_HOST(l_hmColmnData.get("WC_CM_HOST"));
					configurationModel.setLC_CM_PORT(l_hmColmnData.get("WC_CM_PORT"));
					configurationModel.setLC_CM_USERNAME(l_hmColmnData.get("WC_CM_USERNAME"));
					configurationModel.setLC_CM_PASSWORD(l_hmColmnData.get("WC_CM_PASSWORD"));
					configurationModel.setLC_CM_PURPOSE(l_hmColmnData.get("WC_CM_PURPOSE"));
					configurationModel.setLC_CM_FLAG(String.valueOf(l_hmColmnData.get("WC_CM_FLAG")));
					configurationModel.setLC_CM_DOMAIN(String.valueOf(l_hmColmnData.get("WC_CM_DOMAIN")));
				}
			}
			responseModel.setResponseObject(configurationModel);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();

			}
		}
		return responseModel;
	}

	/**
	 * @author
	 * @Name registerUserGenerateOtp - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: registerUserGenerateOtp method using to generate OTP for Customer and
	 *       Rider
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public GenerateOTPForgotPassResModel registerUserGenerateOtp(VerifyRegisterUserOtp requestModel) {
		GenerateOTPForgotPassResModel responseModels = new GenerateOTPForgotPassResModel();

		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_REGISTER_USER_GENERATE_OTP + "(?,?,?,?,?)}");
				callableStatement.setString(1, requestModel.getMobile());
				if (requestModel.getEmail() != null) {
					callableStatement.setString(2, requestModel.getEmail());
				} else {
					callableStatement.setString(2, null);
				}
				callableStatement.setInt(3, requestModel.getFlag());
				if (requestModel.getDeviceid() != null) {
					callableStatement.setString(4, requestModel.getDeviceid());
				} else {
					callableStatement.setString(4, null);
				}

				if (requestModel.getFirebaseId() != null) {
					callableStatement.setString(5, requestModel.getFirebaseId());
				} else {
					callableStatement.setString(5, null);
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties

			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);

				for (int i = 0; i < l_lstResult.size(); i++) {
					LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
					responseModels.setStatusCode(String.valueOf(l_hmColmnData.get("status")));
					responseModels.setMessage(l_hmColmnData.get("message"));
					if (responseModels.getStatusCode().equalsIgnoreCase("200")) {
						responseModels.setOTPNo(l_hmColmnData.get("OTPNo"));
						responseModels.setMobileNumber(l_hmColmnData.get("MobileNumber"));
						responseModels.setMINS(l_hmColmnData.get("MINS"));
						responseModels
								.setIsNewUser(Utils.checkNullInteger(String.valueOf(l_hmColmnData.get("isNewUser"))));
					}

				}
			}
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();

			}
		}
		return responseModels;
	}

	/**
	 * @author
	 * @Name verifyRegisterUserOtps - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: verifyRegisterUserOtps method using to verify register OTP.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel verifyRegisterUserOtps(VerifyRegisterUserOtp requestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_VERIFY_REGISTER_USER_OTP(?,?)}");

				callableStatement.setString(1, requestModel.getMobile());
				callableStatement.setString(2, requestModel.getOtp());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			MyObject object = null;
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);

				for (int i = 0; i < l_lstResult.size(); i++) {
					LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
					responseModel.setStatusCode(Integer.valueOf(String.valueOf(l_hmColmnData.get("statusCode"))));
					if (responseModel.getStatusCode() == 200) {
						properties.put("verifyotp", l_lstResult);

						object = new MyObject(properties);
						responseModel.setResponseObject(object);
					} else {
						responseModel.setMessage(String.valueOf(l_hmColmnData.get("message")));
					}
				}
			}
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();

			}
		}
		return responseModel;
	}

	/**
	 * @author
	 * @Name getLableMaster - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getLableMaster method using to get Lable MAster.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public LableMasterFinalResponseModel getLableMaster(LableMasterRequestModel lableMasterRequestModel) {
		LableMasterFinalResponseModel lableFinalResponseModel = new LableMasterFinalResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_LABLE_MASTER(?, ?, ?, ?, ?)}");
				callableStatement.setInt(1, Utils.checkInteger(lableMasterRequestModel.getLangId()));
				callableStatement.setInt(2, Utils.checkInteger(lableMasterRequestModel.getControllerId()));
				callableStatement.setInt(3, Utils.checkInteger(lableMasterRequestModel.getUserType()));
				callableStatement.setInt(4, Utils.checkInteger(lableMasterRequestModel.getPageId()));
				callableStatement.setInt(5, Utils.checkInteger(lableMasterRequestModel.getAppID()));

				return callableStatement;
			}, prmtrsList);

			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());

			Map<String, String> map;
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				map = new HashMap<>();
				String pageNO = "";
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				for (int i = 0; i < l_lstResult.size(); i++) {
					LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
					map.put(l_hmColmnData.get("KEYNAME"), l_hmColmnData.get("WC_LLM_LABLE_NAME"));
					pageNO = l_hmColmnData.get("WC_LLM_LABLE_PAGEID");
				}
				properties.put(pageNO, map);
			}

			MyObject object = new MyObject(properties);
			lableFinalResponseModel.setGET_LABLE_MASTER(object);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();

			}
		}
		return lableFinalResponseModel;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public ResponseModel getRiderConfiguration() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_RIDER_CONFIGURATION()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			ConfigurationModel configurationModel = new ConfigurationModel();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				for (int i = 0; i < l_lstResult.size(); i++) {
					LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
					configurationModel.setLC_CM_SMS_API(l_hmColmnData.get("WC_CM_SMS_API"));
					configurationModel.setLC_CM_HOST(l_hmColmnData.get("WC_CM_HOST"));
					configurationModel.setLC_CM_PORT(l_hmColmnData.get("WC_CM_PORT"));
					configurationModel.setLC_CM_USERNAME(l_hmColmnData.get("WC_CM_USERNAME"));
					configurationModel.setLC_CM_PASSWORD(l_hmColmnData.get("WC_CM_PASSWORD"));
					configurationModel.setLC_CM_PURPOSE(l_hmColmnData.get("WC_CM_PURPOSE"));
					configurationModel.setLC_CM_FLAG(String.valueOf(l_hmColmnData.get("WC_CM_FLAG")));
					configurationModel.setLC_CM_DOMAIN(String.valueOf(l_hmColmnData.get("WC_CM_DOMAIN")));
				}
			}
			responseModel.setResponseObject(configurationModel);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();

			}
		}
		return responseModel;
	}

}
