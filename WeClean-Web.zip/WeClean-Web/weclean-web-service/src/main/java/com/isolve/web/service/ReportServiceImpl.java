package com.isolve.web.service;

import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.isolve.web.model.AppUsageStatusReportRequestModel;
import com.isolve.web.model.PendingReportRequestModel;
import com.isolve.web.model.ReportsReqModel;
import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RoleActionForSpecificIDReqModel;
import com.isolve.web.repository.IReportRepository;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@Service
public class ReportServiceImpl implements IReportService {

	
	@Autowired
	public IReportRepository iReportRepository;
	
	
	@Value("${encryptsecretkey}")
	private String encryptsecretkey;

	@Value("${azureconnectionstring}")
	private String azureconnectionstring;

	
	private ObjectMapper objectMapper = new ObjectMapper();

	Logger log = LoggerFactory.getLogger(ReportServiceImpl.class);
	
	@Override
	public ResponseModel getAppUsageStatusReport(RequestModel requestModel)
	{
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,requestModel.getExtraVariable());
			AppUsageStatusReportRequestModel reqModel = objectMapper.readValue(decrypt, AppUsageStatusReportRequestModel.class);
			responseModel = iReportRepository.getAppUsageStatusReport(reqModel);	
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {			
			e.printStackTrace();
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}			
		return model;
		
	}
	
		@Override
	public ResponseModel getCashCollectionTrackReport(RequestModel requestModel) {

		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			AppUsageStatusReportRequestModel reqModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),AppUsageStatusReportRequestModel.class);
			responseModel = iReportRepository.getCashCollectionTrackReport(reqModel);
		} catch (Exception e) {			
			e.printStackTrace();
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}		
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
		
		
		@Override
		public ResponseModel getCenterwiseSampleCollectionStatusReport(RequestModel requestModel)
		{
			ResponseModel responseModel = new ResponseModel();
			ResponseModel model = new ResponseModel();
			try {
				String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
						requestModel.getExtraVariable());
				AppUsageStatusReportRequestModel reqModel = objectMapper.readValue(decrypt,
						AppUsageStatusReportRequestModel.class);
				responseModel = iReportRepository.getCenterwiseSampleCollectionStatusReport(reqModel);
				String iv = Utils.randomKey(16);
				model.setResponseData(
						Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
				model.setStatusCode(200);
				model.setStatus(iv);
			} catch (Exception e) {
				e.printStackTrace();
				model.setStatusCode(400);
				model.setMessage(e.getMessage());
			}
			return model;
		}
		
		
		@Override
		public ResponseModel getParamedicTatReport(RequestModel requestModel)
		{
			ResponseModel responseModel = new ResponseModel();
			ResponseModel model = new ResponseModel();
			try {
				String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,requestModel.getExtraVariable());
				AppUsageStatusReportRequestModel reqModel = objectMapper.readValue(decrypt, AppUsageStatusReportRequestModel.class);
				responseModel = iReportRepository.getParamedicTatReport(reqModel);	
				String iv = Utils.randomKey(16);
				model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
				model.setStatusCode(200);
				model.setStatus(iv);
			} catch (Exception e) {			
				e.printStackTrace();
				log.debug(e.getMessage());
				model.setStatusCode(400);
				model.setMessage(e.getMessage());
			}			
			return model;
			
}
		
		@Override
		public ResponseModel getBeatvsVisitComplianceTrackerReport(RequestModel requestModel)
		{
			ResponseModel responseModel = new ResponseModel();
			ResponseModel model = new ResponseModel();
			
			try {
				String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,requestModel.getExtraVariable());
				AppUsageStatusReportRequestModel reqModel = objectMapper.readValue(decrypt,  AppUsageStatusReportRequestModel.class);
				responseModel = iReportRepository.getBeatvsVisitComplianceTrackerReport(reqModel);	
				String iv = Utils.randomKey(16);
				model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
				model.setStatusCode(200);
				model.setStatus(iv);
			} catch (Exception e) {			
				e.printStackTrace();
				
				model.setStatusCode(400);
				model.setMessage(e.getMessage());
			}			
			return model;			
	}
		
		@Override
		public ResponseModel viewReports(RequestModel requestModel) {
			ResponseModel responseModel = new ResponseModel();
			ResponseModel model = new ResponseModel();
			
			try {
				String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,requestModel.getExtraVariable());
				ReportsReqModel reqModel = objectMapper.readValue(decrypt,  ReportsReqModel.class);
				ReportsReqModel reqModel1 = objectMapper.readValue(decrypt,  ReportsReqModel.class);
				reqModel.setInputjson(objectMapper.writeValueAsString(reqModel1.getInputjson()));				
				responseModel = iReportRepository.viewReports(reqModel);	
				String iv = Utils.randomKey(16);
				model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
				model.setStatusCode(200);
				model.setStatus(iv);
			} catch (Exception e) {			
				e.printStackTrace();
				
				model.setStatusCode(400);
				model.setMessage(e.getMessage());
			}			
			return model;	
		}
		
        	@Override
			public ResponseModel getOrderHandOverType() {
				ResponseModel responseModel = new ResponseModel(); 
				ResponseModel model = new ResponseModel();
				try {
					responseModel = iReportRepository.getOrderHandOverType();
					String iv = Utils.randomKey(16);
					model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
					model.setStatusCode(200);
					model.setStatus(iv);
				} catch (Exception e) {
					e.printStackTrace();
					//log.debug(e.getMessage());
					model.setStatusCode(400);
					model.setMessage(e.getMessage());
				}
				return model;
			}

			@SuppressWarnings("unchecked")
			@Override
			public ResponseModel getPendingReports() {
				ResponseModel responseModel = new ResponseModel(); 
				ResponseModel pendingResponseModel = new ResponseModel(); 
				ResponseModel repositoryResponseModel = new ResponseModel(); 
				ResponseModel model = new ResponseModel();
				ReportsReqModel reqModel = new ReportsReqModel();	
				try {
					ReportsReqModel reportsReqModel = new ReportsReqModel();
					reportsReqModel.setReportid(null);
					reportsReqModel.setFlag(Long.parseLong("1"));
					repositoryResponseModel = iReportRepository. getRepositoryReports(reportsReqModel);
					PendingReportRequestModel reportRequestModel = null;
					for (int i = 0; i < repositoryResponseModel.getRespList().size(); i++) {
						reportsReqModel = new ReportsReqModel();
						reportRequestModel = new PendingReportRequestModel();
					    LinkedCaseInsensitiveMap<String> l_hmColmnData = (LinkedCaseInsensitiveMap<String>) repositoryResponseModel.getRespList().get(i);
					    reportRequestModel.setStartdatetime(l_hmColmnData.get(CommonConstants.LC_RP_STARTDATETIME));
					    reportRequestModel.setEnddatetime(l_hmColmnData.get(CommonConstants.LC_RP_ENDDATETIME));
					    reportRequestModel.setCenterid(l_hmColmnData.get(CommonConstants.LC_RP_CENTERID));
					    reportRequestModel.setCityid(l_hmColmnData.get(CommonConstants.LC_RP_CITYID));
					    reportRequestModel.setType(l_hmColmnData.get(CommonConstants.LC_RP_TYPE));
					    reportRequestModel.setRpid(l_hmColmnData.get(CommonConstants.LC_RP_ID));
					    reportsReqModel.setReportid(Long.parseLong(l_hmColmnData.get(CommonConstants.LC_RP_RMID)));
					    reportsReqModel.setReportname(l_hmColmnData.get(CommonConstants.LC_RP_REPORT_NAME));
					    reportsReqModel.setInputjson(objectMapper.writeValueAsString(reportRequestModel));  
					    pendingResponseModel = iReportRepository.getPendingReports(reportsReqModel);
					    if (pendingResponseModel.getStatusCode() == 200) {
					    	String jsonPath[] = new String[1];	
					    	int j=0;
					    	int k=0;
					    	InputStream is = null;
					    	String path =null;
				    		if (reportsReqModel.getReportid() == 6) {
				    			is = Utils.getInputStream(pendingResponseModel.getRespList());
				    			path = Utils.saveFile(null,azureconnectionstring,pendingResponseModel.getRespArray(),reportsReqModel.getReportid()+reportsReqModel.getReportname()+k++,reportRequestModel.getStartdatetime()+reportRequestModel.getEnddatetime()
				    			,reportsReqModel.getReportid(),is);
								jsonPath[j++] = path;
							} else {
								for (Object iterable_element : pendingResponseModel.getRespList()) {
									List<String[]> list = (List<String[]>) iterable_element;						    	
									path = Utils.saveFile(list,azureconnectionstring,pendingResponseModel.getRespArray(),reportsReqModel.getReportid()+reportsReqModel.getReportname()+k++,reportRequestModel.getStartdatetime()+reportRequestModel.getEnddatetime()
									,null,null);
									jsonPath[j++] = path;
								}
							}
					    	reqModel.setInputjson(Arrays.toString(jsonPath));
					    	reqModel.setReportid(Long.parseLong(pendingResponseModel.getRespArray()[0]));
					    	responseModel = iReportRepository.updateReportPath(reqModel);
					    }
					}
					
					
					String iv = Utils.randomKey(16);
					model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
					model.setStatusCode(200);
					model.setStatus(iv);
				} catch (Exception e) {
					e.printStackTrace();
					//log.debug(e.getMessage());
					model.setStatusCode(400);
					model.setMessage(e.getMessage());
				}
				return model;
			}
				@Override
			public ResponseModel getRepositoryReports(RequestModel requestModel) {

				ResponseModel responseModel = new ResponseModel(); 
				ResponseModel model = new ResponseModel();
				try {
					String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,requestModel.getExtraVariable());
					ReportsReqModel reqModel = objectMapper.readValue(decrypt,  ReportsReqModel.class);
					responseModel = iReportRepository. getRepositoryReports(reqModel);
					responseModel.setRespList(null);
					String iv = Utils.randomKey(16);
					model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
					model.setStatusCode(200);
					model.setStatus(iv);
				} catch (Exception e) {
					e.printStackTrace();
					log.debug(e.getMessage());
					model.setStatusCode(400);
					model.setMessage(e.getMessage());
				}
				return model;
			}
			
				@Override
				public ResponseModel getReportMaster(RequestModel requestModel) {

					ResponseModel responseModel = new ResponseModel(); 
					ResponseModel model = new ResponseModel();
					try {
						String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,requestModel.getExtraVariable());
						ReportsReqModel reqModel = objectMapper.readValue(decrypt,  ReportsReqModel.class);
						responseModel = iReportRepository. getReportMaster(reqModel);
						responseModel.setRespList(null);
						String iv = Utils.randomKey(16);
						model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
						model.setStatusCode(200);
						model.setStatus(iv);
					} catch (Exception e) {
						e.printStackTrace();
						log.debug(e.getMessage());
						model.setStatusCode(400);
						model.setMessage(e.getMessage());
					}
					return model;
				}
				
	}






		
	



	

	
	

	
	

