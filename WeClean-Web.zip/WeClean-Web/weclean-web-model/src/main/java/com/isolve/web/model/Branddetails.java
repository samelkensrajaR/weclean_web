package com.isolve.web.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Branddetails implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8714622194718411237L;

	@JsonProperty("BrandID")
	private Integer BrandID;
	
	@JsonProperty("BrandName")
	private String BrandName;	 
	
	@JsonProperty("imagepath")
	private String imagepath;
	
	@JsonProperty("name")
	private String name;
}
