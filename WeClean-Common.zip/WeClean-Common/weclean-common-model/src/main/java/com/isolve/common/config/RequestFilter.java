package com.isolve.common.config;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.isolve.common.model.ResponseModel;
import com.isolve.common.service.IValidateTokenService;

@Component
public class RequestFilter extends OncePerRequestFilter {

	@Autowired
	private IValidateTokenService iValidateTokenService;

	public static String VALID_METHODS = "DELETE, HEAD, GET, OPTIONS, POST, PUT";

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws ServletException, IOException {
		HttpServletRequest httpReq = request;
		HttpServletResponse httpResp = response;
		httpResp.setHeader("Access-Control-Allow-Origin", "*");
		httpResp.setHeader("Access-Control-Allow-Methods", "POST, PUT, GET, OPTIONS, DELETE");
		httpResp.setHeader("Access-Control-Allow-Headers", "*");
		httpResp.setHeader("Access-Control-Expose-Headers", "Access-Token, Uid, ClientSecret");
		httpResp.setHeader("Access-Control-Max-Age", "3600");
		final String requestTokenHeader = request.getHeader("Authorization");

		String jwtToken = null;
		StringBuffer buffer = request.getRequestURL();
		if (buffer.toString().contains("login") || buffer.toString().contains("welcome")
				|| buffer.toString().contains("validateEmailPhoneno")|| buffer.toString().contains("getcenter")
				|| buffer.toString().contains("generateToken") || buffer.toString().contains("signup")
				|| buffer.toString().contains("generateOTP") || buffer.toString().contains("getRoles")
				|| buffer.toString().contains("getStateMaster")|| buffer.toString().contains("resetPin")
				|| buffer.toString().contains("getCityMaster") || buffer.toString().contains("verifyOTP")
				|| buffer.toString().contains("healthy")|| buffer.toString().contains("registrationDetails")
				|| buffer.toString().contains("registrationUserGenerateOtp")|| buffer.toString().contains("verifyresiteruserotp")
				|| buffer.toString().contains("getLanguageMaster") || buffer.toString().contains("getLableMaster")
				 || buffer.toString().contains("getgender")
				) {
			chain.doFilter(httpReq, httpResp);
		} else {
			if (requestTokenHeader != null) {
				// JWT Token is in the form "Bearer token". Remove Bearer word and get only the
				// Token
				if (requestTokenHeader != null && requestTokenHeader.startsWith("Bearer ")) {
					jwtToken = requestTokenHeader.substring(7);
					ResponseModel responseModel = iValidateTokenService.validateToken(jwtToken);
					if (responseModel.getStatusCode() == 200) {

						if ("OPTIONS".equalsIgnoreCase(httpReq.getMethod())) {
							httpResp.setHeader("Allow", VALID_METHODS);
							httpResp.setStatus(HttpServletResponse.SC_OK);
							return;
						} else {
							chain.doFilter(httpReq, httpResp);
						}

					} else {
						httpResp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
						httpResp.getWriter().write(responseModel.getMessage());
						httpResp.getWriter().flush();
						return;
					}

				} else {
					httpResp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
					httpResp.getWriter().write("JWT Token does not begin with Bearer String");
					httpResp.getWriter().flush();
					return;
				}
			} else {
				httpResp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				httpResp.getWriter().write("Token not available");
				httpResp.getWriter().flush();
				return;
			}

		}

	}

}
