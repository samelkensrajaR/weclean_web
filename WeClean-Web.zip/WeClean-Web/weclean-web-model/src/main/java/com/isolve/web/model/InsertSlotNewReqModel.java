package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InsertSlotNewReqModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer flag;
	private Integer typeid;
	private String deliverystarttime;
	private String deliveryendtime;
	private String duration;
	private String userid;
	private Integer slmflag;
	private Integer slmid;
	private Integer start;
	private Integer end;
	private String search;
	private Integer count;
	
}
