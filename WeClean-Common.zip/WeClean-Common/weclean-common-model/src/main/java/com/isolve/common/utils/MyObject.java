package com.isolve.common.utils;

import java.io.Serializable;
import java.util.HashMap;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MyObject implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 3261794588808966191L;
	private HashMap<String, Object> properties;
	
	private Object object;

    //Create object with properties
    public MyObject(HashMap<String, Object> properties) {
        this.properties = properties;
    }
    
  //Create object with object
    public MyObject(Object object) {
        this.object = object;
    }

    //Set properties
    public Object setProperty(String key, Object value) {
        return this.properties.put(key, value); //Returns old value if existing
    }

    //Get properties
    public Object getProperty(String key) {
        return this.properties.getOrDefault(key, null);
    }
}