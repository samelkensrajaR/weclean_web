package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ParamedicDetailsReqModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7156500768392226602L;
	private Long stateid;
	private Long centerid;
	private Long cityid;

}
