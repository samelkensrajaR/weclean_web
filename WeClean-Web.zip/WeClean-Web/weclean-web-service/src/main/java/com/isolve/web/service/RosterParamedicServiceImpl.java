package com.isolve.web.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isolve.web.model.DeleteRosterRequestModel;
import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RosterDetUserRequestModel;
import com.isolve.web.model.RosterDetUserWithDateRequestModel;
import com.isolve.web.model.RosterInsertUpdateRequestModel;
import com.isolve.web.repository.IRosterParamedicRepository;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@Service
public class RosterParamedicServiceImpl implements IRosterParamedicService
{

	Logger log = LoggerFactory.getLogger(RosterParamedicServiceImpl.class);
	
	@Autowired
	private IRosterParamedicRepository iRosterParamedicRepository;
	
	private ObjectMapper objectMapper = new ObjectMapper();
	
	@Value("${encryptsecretkey}")
	private String encryptsecretkey;
	
	
	@Override
	public ResponseModel getRosterAgent()
	{
		ResponseModel response = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try 
		{
			response = iRosterParamedicRepository.getRosterAgent();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(response), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
	
	
	@Override
	public ResponseModel getRosterDetUser(RequestModel requestModel) {

		ResponseModel responseModel = new ResponseModel(); 
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			RosterDetUserRequestModel detUserRequestModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), RosterDetUserRequestModel.class);
			log.info(CommonConstants.GET_ROSTER_DET_USER_REQUEST_MODEL + detUserRequestModel);
			responseModel = iRosterParamedicRepository.getRosterDetUser(detUserRequestModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
	
	@Override
	public ResponseModel getRosterRider()
	{
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try 
		{
			responseModel = iRosterParamedicRepository.getRosterRider();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
	

	@Override
	public ResponseModel getRosterType()
	{
		ResponseModel model = new ResponseModel();
		ResponseModel responseModel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try 
		{
			responseModel = iRosterParamedicRepository.getRosterType();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}	
	
	@Override
	public ResponseModel getRosterInsertUpdate(RequestModel requestModel) {

		ResponseModel responseModel = new ResponseModel(); 
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			RosterInsertUpdateRequestModel rosterInsertUpdateRequestModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), RosterInsertUpdateRequestModel.class);
			log.info(CommonConstants.ROSTER_INSERT_UPDATE_REQUEST_MODEL + rosterInsertUpdateRequestModel);
			responseModel = iRosterParamedicRepository.getRosterInsertUpdate(rosterInsertUpdateRequestModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
	
	


	@Override
	public ResponseModel deleteRoster(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel(); 
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			DeleteRosterRequestModel deleteRosterRequestModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), DeleteRosterRequestModel.class);
			log.info(CommonConstants.ROSTER_INSERT_UPDATE_REQUEST_MODEL + deleteRosterRequestModel);
			responseModel = iRosterParamedicRepository.deleteRoster(deleteRosterRequestModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
	
	
	@Override
	public ResponseModel getRosterDetUserWithDate(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel(); 
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			RosterDetUserWithDateRequestModel rosterDetUserWithDateRequestModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), RosterDetUserWithDateRequestModel.class);
			log.info(CommonConstants.ROSTER_INSERT_UPDATE_REQUEST_MODEL + rosterDetUserWithDateRequestModel);
			responseModel = iRosterParamedicRepository.getRosterDetUserWithDate(rosterDetUserWithDateRequestModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
}
