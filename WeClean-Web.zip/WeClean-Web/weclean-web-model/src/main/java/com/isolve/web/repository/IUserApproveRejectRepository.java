package com.isolve.web.repository;

import java.sql.SQLException;

import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.UpdateUserApproveRejectRequestModel;

public interface IUserApproveRejectRepository 
{

	ResponseModel updateUserApproveReject(UpdateUserApproveRejectRequestModel approveRejectRequestModel) throws SQLException;

}
