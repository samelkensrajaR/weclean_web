package com.isolve.web.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class UpdateBioDiaAssignResponseModel 
{
	@Id
	private Long orderid;
	private String crm_id;
	private String kit_box_id;
	private String patient_name;
	private String client_name;
	private String paramedic_name;
	private String pickup_type;
	private String phoneno;
	private String emailid;
	private String age;
	private String billing_address;
	private String shipping_address;
	private String paramedic_mobile;
	private String paramedic_email;
	private Date edd;
	private String hospital_name;
	private Date scheduled_date_time;
	private String client_type;
	private String assigned_to;
	private Integer pickup_id;
	private Long paramedic_id;
	private String remarks;
	private String lc_or_enrolement_id;
	private Long started;
	private String 	assigned_by;
	private  int is_pickup_edited;
	private int is_reassigned;
	private int lc_pba_cityid;
}
