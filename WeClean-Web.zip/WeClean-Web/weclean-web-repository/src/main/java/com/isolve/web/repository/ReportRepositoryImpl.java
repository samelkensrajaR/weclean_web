package com.isolve.web.repository;

import java.io.IOException;
import java.sql.CallableStatement;
import java.util.Date;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.*;
//import java.sql.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.isolve.web.model.AppUsageStatusReportRequestModel;
import com.isolve.web.model.ReportsReqModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.MyObject;
import com.isolve.web.utils.Utils;
import com.microsoft.sqlserver.jdbc.SQLServerException;

@Repository
public class ReportRepositoryImpl implements IReportRepository {

	Logger log = LoggerFactory.getLogger(ReportRepositoryImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getAppUsageStatusReport(AppUsageStatusReportRequestModel requestModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
						
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_APP_USAGE_STATUS_REPORT(?,?)}");
				
				callableStatement.setDate(1, Utils.utilDateTojavaSqlDate(requestModel.getStartdatetime()));
				callableStatement.setDate(2,  Utils.utilDateTojavaSqlDate(requestModel.getEnddatetime()));
				return callableStatement;
				
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();		
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getappusagestatusreport", l_lstResult);
			}
			
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				//log.debug(e.getMessage());
			}
		}
		return responseModel;

	}
@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getCashCollectionTrackReport( AppUsageStatusReportRequestModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_CASH_COLLECTION_TRACK_REPORT(?,?,?,?)}");
				callableStatement.setDate(1, Utils.utilDateTojavaSqlDate( reqModel.getStartdatetime()));
				callableStatement.setDate(2,  Utils.utilDateTojavaSqlDate(reqModel.getEnddatetime()));
				callableStatement.setLong(3, reqModel.getCityid());
				callableStatement.setLong(4, reqModel.getCenterid());
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getCashCollectionTrackReport", l_lstResult);
			}
			
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			
			}
		}
		return responseModel;
	}
	

@SuppressWarnings({ "unchecked", "rawtypes" })
@Override
public ResponseModel getCenterwiseSampleCollectionStatusReport(AppUsageStatusReportRequestModel requestModel)  {
	ResponseModel responseModel = new ResponseModel();
	try {
		List prmtrsList = new ArrayList();
		prmtrsList.add(new SqlParameter(Types.DATE));
		prmtrsList.add(new SqlParameter(Types.BIGINT));
					
		Map<String, Object> resultData = jdbcTemplate.call(connection -> {
			CallableStatement callableStatement = connection
					.prepareCall("{call USP_GET_CENTERWISE_SAMPLE_COLLECTION_STATUS_REPORT(?,?)}");
			
			callableStatement.setDate(1,Utils.utilDateTojavaSqlDate(requestModel.getStartdatetime()));
			callableStatement.setLong(2, requestModel.getCityid());
			return callableStatement;
			
		}, prmtrsList);
		Set<String> set = new HashSet<>();
		set = resultData.keySet();		
		
		HashMap<String, Object> properties = new HashMap<>();
		for (String key : set) {
			List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
					.get(key);
			properties.put("getCenterwiseSampleCollectionStatusReport", l_lstResult);
		}
		
		MyObject object = new MyObject(properties);
		responseModel.setResponseObject(object);
		responseModel.setStatusCode(200);
	} finally {
		try {
			jdbcTemplate.getDataSource().getConnection().close();
		} catch (SQLException e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
		}
	}
	return responseModel;
}



@SuppressWarnings({ "unchecked", "rawtypes" })
@Override
public ResponseModel getParamedicTatReport(AppUsageStatusReportRequestModel requestModel)  {
	ResponseModel responseModel = new ResponseModel();
	try {
		List prmtrsList = new ArrayList();
		prmtrsList.add(new SqlParameter(Types.DATE));
		prmtrsList.add(new SqlParameter(Types.DATE));
		prmtrsList.add(new SqlParameter(Types.VARCHAR));
		
		Map<String, Object> resultData = jdbcTemplate.call(connection -> {
			CallableStatement callableStatement = connection
					.prepareCall("{call USP_GET_PARAMEDIC_TAT_REPORT (?,?,?)}");
			callableStatement.setDate(1, Utils.utilDateTojavaSqlDate(requestModel.getStartdatetime()));
			callableStatement.setDate(2,  Utils.utilDateTojavaSqlDate(requestModel.getEnddatetime()));
			callableStatement.setString(3,requestModel.getType());
			
			return callableStatement;
			
		}, prmtrsList);
		Set<String> set = new HashSet<>();
		set = resultData.keySet();		
		
		HashMap<String, Object> properties = new HashMap<>();
		for (String key : set) {
			List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
					.get(key);
			properties.put("getParamedicTatReport", l_lstResult);
		}
		
		MyObject object = new MyObject(properties);
		responseModel.setResponseObject(object);
		responseModel.setStatusCode(200);
	} finally {
		try {
			jdbcTemplate.getDataSource().getConnection().close();
		} catch (SQLException e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
		}
	}
	return responseModel;


}


@SuppressWarnings({ "unchecked", "rawtypes" })
@Override
public ResponseModel getBeatvsVisitComplianceTrackerReport(AppUsageStatusReportRequestModel requestModel)  {
	ResponseModel responseModel = new ResponseModel();
	try {
		List prmtrsList = new ArrayList();
		prmtrsList.add(new SqlParameter(Types.DATE));
		prmtrsList.add(new SqlParameter(Types.DATE));
		prmtrsList.add(new SqlParameter(Types.BIGINT));
		
		Map<String, Object> resultData = jdbcTemplate.call(connection -> {
			CallableStatement callableStatement = connection
					.prepareCall("{call USP_GET_BEATVSVISIT_COMPLIANCE_TRACKER_REPORT (?,?,?)}");
			callableStatement.setDate(1, Utils.utilDateTojavaSqlDate(requestModel.getStartdatetime()));
			callableStatement.setDate(2, Utils.utilDateTojavaSqlDate(requestModel.getEnddatetime()));
			callableStatement.setLong(3,requestModel.getCityid());
			
			return callableStatement;
			
		}, prmtrsList);
		Set<String> set = new HashSet<>();
		set = resultData.keySet();		
		
		HashMap<String, Object> properties = new HashMap<>();
		for (String key : set) {
			List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
					.get(key);
			properties.put("getBeatvsVisitComplianceTrackerReport", l_lstResult);
		}
		
		MyObject object = new MyObject(properties);
		responseModel.setResponseObject(object);
		responseModel.setStatusCode(200);
	} finally {
		try {
			jdbcTemplate.getDataSource().getConnection().close();
		} catch (SQLException e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
		}
	}
	return responseModel;


}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel viewReports(ReportsReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_VIEW_REPORTS (?,?,?,?,?)}");
				callableStatement.setString(1, reqModel.getInputjson().toString());
				callableStatement.setString(2, reqModel.getReportname());
				if (reqModel.getReportid() != null) {
					callableStatement.setLong(3,reqModel.getReportid());
				} else {
					callableStatement.setString(3,null);
				}
				if (reqModel.getUserid() != null) {
					callableStatement.setLong(4,reqModel.getUserid());
				} else {
					callableStatement.setString(4,null);
				}
				if (reqModel.getFlag() != null) {
					callableStatement.setLong(5,reqModel.getFlag());
				} else {
					callableStatement.setString(5,null);
				}
				return callableStatement;
				
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();		
			List<Object> objects = new ArrayList<>(); 
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				objects.add(l_lstResult);
			}
			responseModel.setRespList(objects);;
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				//log.debug(e.getMessage());
			}
		}
		return responseModel;
	}	

@SuppressWarnings({"unchecked","rawtypes"})
@Override
public ResponseModel getOrderHandOverType() {
	ResponseModel responseModel = new ResponseModel();
	try {
		
		List prmtrsList = new ArrayList();
		Map<String, Object> resultData = jdbcTemplate.call(connection -> {
			CallableStatement callableStatement = connection
					.prepareCall("{call USP_GET_ORDER_HANDOVER_TYPE }");	

			return callableStatement;
		}, prmtrsList);
		Set<String> set = new HashSet<>();
		set = resultData.keySet();
		Map<String, Object> properties = new HashMap<>();
		for (String key : set) {
			List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
					.get(key);
			properties.put("orderhandovertype", l_lstResult);
		}
		
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
		responseModel.setStatusCode(200);
	} finally { 
		try {
			jdbcTemplate.getDataSource().getConnection().close();
		} catch (SQLException e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
		}
	}
	return responseModel;
}

@SuppressWarnings({ "unchecked", "rawtypes" })
@Override
public ResponseModel getPendingReports(ReportsReqModel reqModel) throws IOException {
	ResponseModel responseModel = new ResponseModel();
	try {
		List prmtrsList = new ArrayList();
		Map<String, Object> resultData = jdbcTemplate.call(connection -> {
			CallableStatement callableStatement = connection
					.prepareCall("{call USP_GET_PENDING_REPORTS (?,?,?,?)}");	
			callableStatement.setString(1, reqModel.getInputjson().toString());
			callableStatement.setString(2, reqModel.getReportname());
			if (reqModel.getReportid() != null) {
				callableStatement.setLong(3,reqModel.getReportid());
			} else {
				callableStatement.setString(3,null);
			}
			if (reqModel.getFlag() != null) {
				callableStatement.setLong(4,reqModel.getFlag());
			} else {
				callableStatement.setString(4,null);
			}
			return callableStatement;
		}, prmtrsList);
		List<List<String[]>> csvLists = new ArrayList<>();
		Set<String> set = new HashSet<>();
		set = resultData.keySet();
		int count=0;
		 String masterData[] = null;
		for (String key : set) {
			count++;
			List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
					.get(key);
			if (count == 1) {
				for (int i = 0; i < l_lstResult.size(); i++) {
				    LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
				    masterData = new String[l_hmColmnData.keySet().size()];
				    int l=0;
				    for (String k : l_hmColmnData.keySet()) {
				    	masterData[l++] = String.valueOf(l_hmColmnData.get(k));
					}
				}
			} else {
				List<String[]> csvinnerLists = new ArrayList<>();
				int headerCnt=0;
				for (int i = 0; i < l_lstResult.size(); i++) {
					headerCnt++;
				    LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
				    if (headerCnt == 1) {
				    	String header[] = new String[l_hmColmnData.keySet().size()];		          
				    	int j=0;		        
				    	// iterating over the hashset
				    	for(String ele:l_hmColmnData.keySet()){
				    		header[j++] = ele;
				    	}
				    	csvinnerLists.add(header);
					}
			        int l=0;
			        String data[] = new String[l_hmColmnData.keySet().size()];
				    for (String k : l_hmColmnData.keySet()) {
				    	data[l++] = String.valueOf(l_hmColmnData.get(k));
					}
				    csvinnerLists.add(data);
				}
				csvLists.add(csvinnerLists);
			}
		}
		responseModel.setStatusCode(200);
		responseModel.setRespList(csvLists);
		responseModel.setRespArray(masterData);
	} finally { 
		try {
			jdbcTemplate.getDataSource().getConnection().close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	return responseModel;
}

@SuppressWarnings({ "unchecked", "rawtypes" })
@Override
public ResponseModel updateReportPath(ReportsReqModel requestModel) {
	ResponseModel responseModel = new ResponseModel();
	try {
		List prmtrsList = new ArrayList();
		prmtrsList.add(new SqlParameter(Types.VARCHAR));
		prmtrsList.add(new SqlParameter(Types.BIGINT));
		prmtrsList.add(new SqlParameter(Types.BIGINT));
		prmtrsList.add(new SqlParameter(Types.BIGINT));
		Map<String, Object> resultData = jdbcTemplate.call(connection -> {
			CallableStatement callableStatement = connection.prepareCall("{call USP_UPDATE_REPORTS_PATH (?,?,?,?)}");
			callableStatement.setString(1, requestModel.getInputjson().toString());
			if (requestModel.getReportid() != null) {
				callableStatement.setLong(2, requestModel.getReportid());
			} else {
				callableStatement.setString(2, null);
			}
			if (requestModel.getUserid() != null) {
				callableStatement.setLong(3, requestModel.getUserid());
			} else {
				callableStatement.setString(3, null);
			}
			if (requestModel.getFlag() != null) {
				callableStatement.setLong(4, requestModel.getFlag());
			} else {
				callableStatement.setString(4, null);
			}
			return callableStatement;
		}, prmtrsList);
		Set<String> set = new HashSet<>();
		set = resultData.keySet();
		HashMap<String, Object> properties = new HashMap<>();
		for (String key : set) {
			List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
					.get(key);
			properties.put("UpdateReportPath", l_lstResult);
		}
		MyObject object = new MyObject(properties);
		responseModel.setResponseObject(object);
		responseModel.setStatusCode(200);
	} finally {
		try {
			jdbcTemplate.getDataSource().getConnection().close();
		} catch (SQLException e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
		}
	}
	//log.info("res" + responseModel);
	return responseModel;
}

@SuppressWarnings({"unchecked","rawtypes"})
@Override

public ResponseModel getRepositoryReports(ReportsReqModel reqModel)
{
	ResponseModel responseModel = new ResponseModel();
	try {
				
		List prmtrsList = new ArrayList();
		prmtrsList.add(new SqlParameter(Types.BIGINT));
		prmtrsList.add(new SqlParameter(Types.BIGINT));
		prmtrsList.add(new SqlParameter(Types.BIGINT));
		
		Map<String, Object> resultData = jdbcTemplate.call(connection -> {
			CallableStatement callableStatement = connection
					.prepareCall("{call USP_GET_REPOSITORY_REPORTS(?,?,?)}");	
			if (reqModel.getReportid() != null) {
				callableStatement.setLong(1,reqModel.getReportid());
			} else {
				callableStatement.setString(1,null);
			}
			if (reqModel.getUserid() != null) {
				callableStatement.setLong(2,reqModel.getUserid());
			} else {
				callableStatement.setString(2,null);
			}
			if (reqModel.getFlag() != null) {
				callableStatement.setLong(3,reqModel.getFlag());
			} else {
				callableStatement.setString(3,null);
			}
			return callableStatement;
		},prmtrsList);
		Set<String> set = new HashSet<>();
		set = resultData.keySet();
		Map<String, Object> properties = new HashMap<>();
		for (String key : set) {
			List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
					.get(key);
			properties.put("repositoryreports", l_lstResult);
			responseModel.setRespList(l_lstResult);
		}
		
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
		responseModel.setStatusCode(200);
	} finally { 
		try {
			jdbcTemplate.getDataSource().getConnection().close();
		} catch (SQLException e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
		}
	}
	return responseModel;
	
}



@SuppressWarnings({"unchecked","rawtypes"})
@Override

public ResponseModel  getReportMaster(ReportsReqModel reqModel)
{
	ResponseModel responseModel = new ResponseModel();
	try {
				
		List prmtrsList = new ArrayList();
		prmtrsList.add(new SqlParameter(Types.BIGINT));
		
		
		Map<String, Object> resultData = jdbcTemplate.call(connection -> {
			CallableStatement callableStatement = connection
					.prepareCall("{call USP_GET_REPORT_MASTER(?)}");	
			if (reqModel.getUserid() != null) {
				callableStatement.setLong(1,reqModel.getUserid());
			} else {
				callableStatement.setString(1,null);
			}
			
			return callableStatement;
		},prmtrsList);
		Set<String> set = new HashSet<>();
		set = resultData.keySet();
		Map<String, Object> properties = new HashMap<>();
		for (String key : set) {
			List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
					.get(key);
			properties.put("reportmaster", l_lstResult);
			responseModel.setRespList(l_lstResult);
		}
		
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
		responseModel.setStatusCode(200);
	} finally { 
		try {
			jdbcTemplate.getDataSource().getConnection().close();
		} catch (SQLException e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
		}
	}
	return responseModel;
	
}

}
	






	