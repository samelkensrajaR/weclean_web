package com.isolve.web.model;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CollectItemDetailsModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8156769007193236350L;
	private Integer serviceid;
	private Integer itemid;
	
	private String servicename;
	private String itemname;
	private String qrcode;
	private Double itemprice;
	private Integer itemcount;
	private List<List<Damagedetails>> staindetails;
	private List<List<Damagedetails>> damagedetails;
	private List<List<Damagedetails>> colordetails;
	private List<List<Damagedetails>> branddetails;
	private List<List<Imagedetails>> imagedetails;
	private List<List<DamageCommondetails>> commondetails;
	private Integer stainid;
	private Integer damageid;
	private Integer colourid;
	private Integer brandid;
	private String notes;
	private int flag;
	

}
