package com.isolve.common.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RegistrationDetailsReqModel  implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = -2784729885865952017L;
	
	private String name;
	private String emailid;
	private String mobileno;
	private Integer genderid;
	private Integer typeid;

}
