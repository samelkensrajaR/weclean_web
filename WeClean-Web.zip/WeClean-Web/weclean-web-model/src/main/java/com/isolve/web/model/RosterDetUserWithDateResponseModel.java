package com.isolve.web.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class RosterDetUserWithDateResponseModel implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 183096334768493499L;
	@Id
	private Long roster_id;
	private Long user_id;
	private String paramedic;
	private String roster;
	private Date start_date;
	private Date end_date;
	private Integer status;
	private String remarks;
	private String day;
	
	
}
