package com.isolve.web.model;

import java.io.Serializable;
import java.sql.Date;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VendorVisitTimeMappingReqModel implements Serializable {

	/**
	 * 
	 */
	 private static final long serialVersionUID = 6656787372364959922L;

	// private Long user_id;
	// private Long paramedic_id;
	// private Long sale_id;
	// private String firstname;
	// private String lastname;

	// @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	// @JsonSerialize(using=LocalDateTimeSerializer.class)
	// @JsonDeserialize(using = LocalDateTimeDeserializer.class)
	
	
	private Long user_id;
	private Long paramedic_id;
	
	
	private List<VisitTimeModel> visitTimeModelList;

}
