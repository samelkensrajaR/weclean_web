package com.isolve.web.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isolve.web.model.BioBankReceiveSampleModel;
import com.isolve.web.model.BioBankResponseModel;
import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.repository.IBioBankRepository;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;


@Service
public class BioBankServiceImpl implements IBioBankService{

	@Autowired
	private IBioBankRepository bioBankRepository;
	
	@Value("${encryptsecretkey}")
	private String encryptsecretkey;
	
	private ObjectMapper objectMapper = new ObjectMapper();
	
	Logger log = LoggerFactory.getLogger(BioBankServiceImpl.class);

	@Override
	public ResponseModel getReceiveBioBankSample(RequestModel requestModel) {

		List<BioBankResponseModel> bankResponseModels = new ArrayList<BioBankResponseModel>();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			BioBankReceiveSampleModel bankReceiveSampleModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), BioBankReceiveSampleModel.class);
			log.info(CommonConstants.BIOBANK_RECEIVE_SAMPLEMODEL+ bankReceiveSampleModel);
			bankResponseModels = bioBankRepository.getReceiveBioBankSample(bankReceiveSampleModel);			
		} catch (Exception e) {			
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}		
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(bankResponseModels), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	
	}


}
