package com.isolve.common.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseModel implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private Integer statusCode;
    private String decryptResponse;
    private String responseData;
    private String status;
    private String message;
    private Object responseObject;
    private List<?> respList;
    private String[] respArray;
  
    
    
}
