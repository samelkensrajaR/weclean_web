package com.isolve.common.utils;

public class CommonConstants {
	
	//endpoint
	public static final String LOGIN = "login";
	public static final String APP_LOGOUT = "appLogout";
	public static final String GENERATE_TOKEN = "generateToken";
	public static final String SIGNUP = "signup";
	public static final String GENERATE_OTP = "generateOTP";
	public static final String GENERATE_OTP_FORGOT_PASSWORD = "generateOTPForgotPassword";
	public static final String GENERATE_OTP_PAYMENT = "generateOTPPayment";
	public static final String GET_LANGUAGE_MASTER = "getLanguageMaster";
	public static final String GET_LABLE_MASTER = "getLableMaster";
	public static final String CLIENT_SECRET = "ClientSecret";
	public static final String CLIENT_SECRET_NOT_FOUND = "Client secret is mandatory";
	

	
	//USP_LIFECELL_APP_WEB_LOGIN stored procedure parameter
	public static final String USP_WECLEAN_APP_WEB_LOGIN = "USP_WECLEAN_APP_WEB_LOGIN";
	public static final String USP_LOGOUT = "USP_LOGOUT";
	public static final String USP_TOKEN_GENERATION = "USP_Token_Generation";
	public static final String USP_VALIDATE_TOKEN = "USP_Validate_Token";
	public static final String TOKEN = "Token";
	public static final String LOGIN_USER = "Login_User";
	public static final String PASSWORD = "Password";
	public static final String LOGIN_TYPE ="Login_Type";
	public static final String LOGIN_MODE ="Login_Mode";
	public static final String LANG_ID="Lang_Id";
	public static final String WC_USD_LATITUDE="WC_USD_LATITUDE";
	public static final String WC_USD_LONGITUDE ="WC_USD_LONGITUDE";
	public static final String IMEI = "IMEI";
	public static final String FIREBASE_ID = "Firebase_ID";
	public static final String ANDROID_IOS_WEB = "Android_IOS_Web";
	
	//USP_GET_LANGUAGE_MASTER stored procedure parameter
	public static final String USP_GET_LANGUAGE_MASTER = "USP_GET_LANGUAGE_MASTER";
	public static final String FROM_REGISTRATION_MASTER = "FROM_REGISTRATION_MASTER";
	public static final String LANGID = "LANG_ID";
	
	//USP_TECHNICIAN_DAY_START_TIME stored procedure parameter
	public static final String  USP_TECHNICIAN_DAY_START_TIME = "USP_TECHNICIAN_DAY_START_TIME";
	public static final String  TECH_DAY_START_TIME = "techDayStartTime";
	public static final String 	TECHNICIAN_ID = "Technician_Id";
	public static final String 	DATE = "Date";
	public static final String 	TIME = "Time";
	public static final String 	TECH_LATITUDE = "Tech_latitude";
	public static final String 	TECH_LONGITUDE = "Tech_longitude";
	
	//USP_GET_LABLE_MASTER stored procedure parameter
	public static final String USP_GET_LABLE_MASTER = "USP_GET_LABLE_MASTER";
	public static final String 	CONTROLLER_ID = "Controller_Id";
	public static final String 	USER_TYPE = "User_Type";
	public static final String 	PAGE_ID = "Page_Id";
	public static final String 	APP_ID = "App_ID";

	//USP_SIGNUP_DETAILS stored procedure parameter
	public static final String USP_SIGNUP_DETAILS = "USP_SIGNUP_DETAILS";
	public static final String 	USER_TITLE_ID = "USER_TITLE_ID";
	public static final String 	USER_FIRST_NAME = "USER_FIRST_NAME";
	public static final String 	USER_MID_NAME = "USER_MID_NAME";
	public static final String 	USER_LAST_NAME = "USER_LAST_NAME";
	public static final String 	USER_PHONENO = "USER_PHONENO";
	public static final String 	USER_EMAILID = "USER_EMAILID";
	public static final String 	USER_DOB = "USER_DOB";
	public static final String 	USER_DOJ = "USER_DOJ";
	public static final String 	USER_GEN_ID = "USER_GEN_ID";
	public static final String 	USER_CURRENT_ADDRESS = "USER_CURRENT_ADDRESS";
	public static final String 	USER_PERMANENT_ADDRESS = "USER_PERMANENT_ADDRESS";
	public static final String 	USER_ADDRESS_LINE1 = "USER_ADDRESS_LINE1";
	public static final String 	USER_ADDRESS_LINE2 = "USER_ADDRESS_LINE2";
	public static final String 	USER_STATUS = "USER_STATUS";
	public static final String 	USER_PHOTO = "USER_PHOTO";
	public static final String 	BRANCH_ID = "BRANCH_ID";
	public static final String 	REGION_ID = "REGION_ID";
	public static final String 	USER_NAME = "USER_NAME";
	public static final String 	USER_IMEI_NUMBER = "USER_IMEI_NUMBER";
	public static final String 	USER_UDID_NUMBER = "USER_UDID_NUMBER";
	public static final String 	USER_PHONE_CODE = "USER_PHONE_CODE";
	public static final String 	USER_TYPE_ID = "USER_TYPE_ID";
	public static final String 	USER_DESIGNATION_ID = "USER_DESIGNATION_ID";
	public static final String 	USER_ROLEID = "USER_ROLEID";
	public static final String 	USER_PASSWORD = "USER_PASSWORD";
	public static final String 	USER_PIN = "USER_PIN";
	public static final String 	QUALIFICATION = "QUALIFICATION";
	public static final String 	EXP_IN_YEARS = "EXP_IN_YEARS";
	public static final String 	PINCODE = "PINCODE";
	public static final String 	STATE_ID = "STATEID";
	public static final String 	SIGNUP_USER_ID = "UserID";
	public static final String 	LOGINID = "LoginID";
	public static final String 	User_DOA = "User_DOA";
	

	//USP_USER_GENERATE_OTP stored procedure parameter
	public static final String USP_USER_GENERATE_OTP = "USP_USER_GENERATE_OTP";
	public static final String 	MOBILE_EMAIL = "Mobile_Email";
	public static final String 	SMS_VALIDTIMELIMIT = "sms_validtimelimit";
	
	//USP_GET_LC_PARAMEDIC_DETAILS
	public static final String USP_GET_LC_PARAMEDIC_DETAILS="USP_GET_LC_PARAMEDIC_DETAILS";
	public static final String GET_PARAMEDIC_DETAILS="getparamedicdetails";
	
	//USP_GET_LC_CLIENT_DETAILS
	public static final String USP_GET_LC_CLIENT_DETAILS="USP_GET_LC_CLIENT_DETAILS";
	public static final String GET_CLIENT_DETAILS="getclientdetails";
	
	public static final String HEALTHY = "healthy";
	
	//USP_INSERT_UPDATE_FIREBASEID
	public static final String USP_INSERT_UPDATE_FIREBASEID="USP_INSERT_UPDATE_FIREBASEID";
	public static final String INSERT_UPDATE_FIREBASEID="insertUpdateFirebaseId";
	public static final String FIREBASEID="FIREBASEID";
	
	//USP_GET_IMAGE_PATH_MASTER
	public static final String USP_GET_IMAGE_PATH_MASTER="USP_GET_IMAGE_PATH_MASTER";
	public static final String GET_IMAGE_PATH_MASTER="getImagePathMaster";
	
	//USP_GET_THEME_MASTER
	public static final String USP_GET_THEME_MASTER="USP_GET_THEME_MASTER";
	public static final String GET_THEME_MASTER="getThemeMaster";
	
	//USP_GET_APP_VERSION
	public static final String USP_GET_APP_VERSION="USP_GET_APP_VERSION";
	public static final String GET_APP_VERSION="getAppVersion";
	
	//USP_GET_PAGE_MASTER
	public static final String USP_GET_PAGE_MASTER="USP_GET_PAGE_MASTER";
	public static final String GET_PAGE_MASTER="getPageMaster";
	public static final String ROLEID="ROLEID";
	
	//USP_GET_MAINTENANCE
	public static final String USP_GET_MAINTENANCE="USP_GET_MAINTENANCE";
	public static final String GET_MAINTENANCE="getMaintenance";
	
	//USP_LC_GENERATE_OTP_FOR_FORGOTPASSWORD
	public static final String 	USP_LC_GENERATE_OTP_FOR_FORGOTPASSWORD = "USP_LC_GENERATE_OTP_FOR_FORGOTPASSWORD";
	public static final String 	USP_LC_GENERATE_OTP_FOR_PAYMENT = "USP_LC_GENERATE_OTP_FOR_PAYMENT";
	public static final String 	USER_ID = "USER_ID";
	public static final String 	PAYMENTTYPE="PaymentType";
	public static final String 	INVOICEAMOUNT="invoiceamount";
	
	public static final String 	SMS_VALIDTIME_LIMIT = "SMS_VALIDTIMELIMIT";
	public static final String 	USERTYPE = "USER_TYPE";
	
	//USP_VALIDATE_EMAIL_PHONENO
	public static final String 	USP_VALIDATE_EMAIL_PHONENO = "USP_VALIDATE_EMAIL_PHONENO";
	public static final String 	VALIDATE_EMAIL_PHONENO = "validateEmailPhoneno";

	//USP_VERIFY_OTP_VENDOR_VERIFY
	public static final String 	USP_VERIFY_OTP_VENDOR_VERIFY = "USP_VERIFY_OTP_VENDOR_VERIFY";
	public static final String 	VERIFY_OTP_VENDOR_VERIFY = "vendorOTPVerify";
	
	//USP_VERIFY_OTP
	public static final String 	USP_VERIFY_OTP = "USP_VERIFY_OTP";
	public static final String 	VERIFY_OTP = "verifyOTP";
	public static final String  USERID = "User_Id";
	public static final String  OTP = "OTP";
	public static final String  APPLICATION_ID = "Application_Id";
	public static final String  OTP_PURPOSE = "OTP_PURPOSE";
	public static final String  APPOINTMENT_ID = "APPOINTMENT_ID";
	
	//USP_RESET_PIN
	public static final String 	USP_RESET_PIN = "USP_RESET_PIN";
	public static final String 	RESET_PIN = "resetPin";
	public static final String 	RESET_PASSWORD = "PASSWORD";
	
	//USP_GET_STATE_MASTER
	public static final String 	USP_GET_STATE_MASTER = "USP_GET_STATE_MASTER";
	public static final String 	GET_STATE_MASTER = "getStateMaster";
	public static final String 	SEARCH = "SEARCH";
	
	//USP_GET_CITY_MASTER
	public static final String 	USP_GET_CITY_MASTER = "USP_GET_CITY_MASTER";
	public static final String 	GET_CITY_MASTER = "getCityMaster";
	public static final String 	STATEID = "StateID";
	
	//USP_GET_ADDRESS_TYPE
	public static final String USP_GET_ADDRESS_TYPE="USP_GET_ADDRESS_TYPE";
	public static final String GET_ADDRESS_TYPE = "getAddressType";
	
	//USP_GET_PICKUP_TYPE
	public static final String USP_GET_PICKUP_TYPE="USP_GET_PICKUP_TYPE";
	public static final String GET_PICKUP_TYPE = "getPickupType";
	
	//USP_GET_REFER_TYPE
	public static final String USP_GET_REFER_TYPE="USP_GET_REFER_TYPE";
	public static final String GET_REFER_TYPE = "getReferType";
	
	//USP_GET_USERTYPE
	public static final String USP_GET_USER_TYPE="USP_GET_USER_TYPE";
	public static final String GET_USERTYPE = "getUserType";
	public static final String fLAG = "flag";
	
	
	//USP_GET_PRODUCT_DETAILS
	public static final String USP_GET_PRODUCT_DETAILS="USP_GET_PRODUCT_DETAILS";
	public static final String GET_PRODUCT_DETAILS = "getProductDetails";
	
	//USP_GET_ACCOUNTTYPE
	public static final String USP_GET_ACCOUNTTYPE="USP_GET_ACCOUNTTYPE";
	public static final String GET_ACCOUNTTYPE = "getAccountType";
	public static final String FLAG = "Flag";
	
	//USP_GET_TASK_TYPE
	public static final String USP_GET_TASK_TYPE="USP_GET_TASK_TYPE";
	public static final String GET_TASK_TYPE = "getTaskType";
	public static final String TASKID = "TaskID";
	
	//USP_GET_ROLES
	public static final String USP_GET_ROLE="USP_GET_ROLE";
	public static final String GET_ROLE = "getRole";
	public static final String Flag = "Flag";
	
	
	
	//USP_GET_CANCEL_REASON
	public static final String USP_GET_CANCEL_REASON="USP_GET_CANCEL_REASON";
	public static final String GET_CANCEL_REASON = "getCancelReason";
	
	
	//response constants
	public static final String SUCCESS = "Success";
	public static final String FAILED = "Failed";


	public static final String ENCRYPTSECRETKEY = "encryptsecretkey ";
	public static final String APPWEBTOKENREQUESTMODEL = "appWebTokenRequestModel ";
	public static final String LANGUAGE_MASTER_REQUEST_MODEL = "LanguageMasterRequestModel ";
	public static final String LABLE_MASTER_REQUEST_MODEL = "LableMasterRequestModel ";
	
	//USP_LC_GENERATE_OTP_FOR_RESCHDULE
	public static final String USP_LC_GENERATE_OTP_FOR_RESCHDULE="USP_LC_GENERATE_OTP_FOR_RESCHDULE";
	public static final String PATIENT_ID="PATIENT_ID";
	public static final String SMS_VALIDTIMELIMIT_OTP="SMS_VALIDTIMELIMIT";
	public static final String LANG_ID_OTP="LANG_ID";
	public static final String GENERATE_OTP_FOR_RESCHEDULE_REQUESTMODEL="generateotpforreschedulerequestmodel";
	public static final String GENERATEOTPRESCHEDULE="generateotpreschedule";
	
	//USP_LC_GENERATE_OTP_FOR_VENDOR_VERIFY
	public static final String USP_LC_GENERATE_OTP_FOR_VENDOR_VERIFY="USP_LC_GENERATE_OTP_FOR_VENDOR_VERIFY";
	public static final String GENERATE_OTP_FOR_VENDOR_VERIFY="generateOTPVendorVerify";
	public static final String VENDOR_ID="VENDOR_ID";
	
	
	//USP_GET_DOCTOR_LIST
	public static final String USP_GET_DOCTOR_LIST="USP_GET_DOCTOR_LIST";
	public static final String HOSTPITALID="hostpitalid";
	public static final String GETDOCTORLIST="getdoctorlist";
	public static final String DOCTOR_LIST_REQUEST_MODEL="DOCTOR_LIST_REQUEST_MODEL";

	//USP_GET_PAYMENTTYPE
	public static final String USP_GET_PAYMENTTYPE="USP_GET_PAYMENTTYPE";
	public static final String GETPAYMENTTYPE="getpaymenttype";
	
	//USP_GET_BANK
	public static final String USP_GET_BANK="USP_GET_BANK";
	public static final String GET_BANKS="getBanks";
	
	//USP_GET_BANK_BRANCH
	public static final String USP_GET_BANK_BRANCH="USP_GET_BANK_BRANCH";
	public static final String GET_BANK_BRANCH="getBankBranch";
	
	//USP_GET_BANK_DEPOSIT_TIME
	public static final String USP_GET_BANK_DEPOSIT_TIME="USP_GET_BANK_DEPOSIT_TIME";
	public static final String GET_BANK_DEPOSIT_TIME="getBankDepositTime";
	
	
	//USP_GET_CENTER
	public static final String USP_GET_CENTER_MASTER="USP_GET_CENTER_MASTER";
	public static final String GETCENTER="getcenter";
	public static final String CITYID="CITYID";
	public static final String GET_CENTER_REQUEST_MODEL="GET_CENTER_REQUEST_MODEL";
	
	//ENCRYPT and DECRYPT
	public static final String ENCRYPT="encrypt";
	public static final String DECRYPT="decrypt";
	
	public static final String ROLEIDD = "RoleID";
	public static final String EMPLOYEEID = "EmployeeID";
	
//	USP_GET_API_REPORT_DETAILS
	public static final String USP_GET_API_REPORT_DETAILS="USP_GET_API_REPORT_DETAILS";
	public static final String API_REPORT_DETAILS_REQ="API_REPORT_DETAILS_REQ";
	public static final String GET_API_REPORT_DETAILS="getapireportdetails";
	
	//USP_GET_LC_GENDER
	public static final String USP_GET_WC_GENDER = "USP_GET_WC_GENDER";
	public static final String GET_GENDER = "getgender";

	// USP_GET_LC_TITLE_MASTER
	public static final String USP_GET_LC_TITLE_MASTER="USP_GET_LC_TITLE_MASTER";
	public static final String GET_TITLE_MASTER = "gettitlemaster";
	
	
	//USP_GET_HOSPITALS
	public static final String USP_GET_HOSPITALS="USP_GET_HOSPITALS";
	public static final String GET_HOSPITALS_DETAILS="gethospitaldetails";
	
	
//  USP_CHECK_TECHNICIAN_DAY_START_OR_NOT
	public static final String USP_CHECK_TECHNICIAN_DAY_START_OR_NOT="USP_CHECK_TECHNICIAN_DAY_START_OR_NOT";
   public static final String CHECK_TECHNICIAN_DAY_START_OR_NOT = "checktechniciandaystartornot";
			
	//USP_GET_PRODUCT_DETAILS
	public static final String USP_GET_PRODUCT="USP_GET_PRODUCT";
	public static final String GET_PRODUCT = "getProduct";					


	//USP_GET_TIMES
	public static final String USP_GET_TIMES="USP_GET_TIMES";
	public static final String GET_TIMES = "gettime";
	
	//USP_REGISTRATION_DETAILS
	public static final String USP_REGISTRATION_DETAILS="USP_REGISTRATION_DETAILS";
	public static final String REGISTRATION_DETAILS = "registrationDetails";
	
	//USP_REGISTER_USER_GENERATE_OTP
		public static final String USP_REGISTER_USER_GENERATE_OTP="USP_REGISTER_USER_GENERATE_OTP";
		public static final String REGISTER_USER_GENERATE_OTP = "registrationUserGenerateOtp";
			
		   
	// USP_VERIFY_REGISTER_USER_OTP
		public static final String USP_VERIFY_REGISTER_USER_OTP="USP_VERIFY_REGISTER_USER_OTP";
	   public static final String VERIFY_REGISTER_USER_OTP = "verifyresiteruserotp";

	
	
}
