package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PincodeMasterReqModel implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2993180420452612584L;
	
	private Long stateId;
	private Long pinCodeMasterId;

}
