package com.isolve.web.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isolve.web.model.CourierMasterRequestModel;
import com.isolve.web.model.CourierMasterResponseModel;
import com.isolve.web.model.LabMasterRequestModel;
import com.isolve.web.model.LabMasterResponseModel;
import com.isolve.web.model.LabTranReceiveReqModel;
import com.isolve.web.model.LabTransferInitiativeRequestModel;
import com.isolve.web.model.LabTransferRequestModel;
import com.isolve.web.model.LabTransferResponseModel;
import com.isolve.web.model.RepeatSampleInitiateRequestModel;
import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RosterDetUserRequestModel;
import com.isolve.web.repository.ILabTransferRepository;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@Service
public class LabTransferServiceImpl implements ILabTransferService
{

	Logger log = LoggerFactory.getLogger(LabTransferServiceImpl.class);

	@Autowired
	private ILabTransferRepository iLabTransferRepository;

	private ObjectMapper objectMapper = new ObjectMapper();

	@Value("${encryptsecretkey}")
	private String encryptsecretkey;


	@Override
	public ResponseModel getLabTransfer(RequestModel requestModel) {

		ResponseModel responseModel = new ResponseModel(); 
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {

			LabTransferRequestModel transferRequestModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), LabTransferRequestModel.class);
			log.info(CommonConstants.GET_LABTRANSFER_REQUEST_MODEL + transferRequestModel);
			responseModel = iLabTransferRepository.getLabTransfer(transferRequestModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}


	@Override
	public ResponseModel updateLabTransferInitiative(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			LabTransferInitiativeRequestModel labTransferInitiativeRequestModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), LabTransferInitiativeRequestModel.class);
			log.info(CommonConstants.LABTRANSFER_INITIATIVE_REQUEST_MODEL + labTransferInitiativeRequestModel);
			responsemodel = iLabTransferRepository.updateLabTransferInitiative(labTransferInitiativeRequestModel);
		} catch (Exception e) {			
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}		
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getSampleType()
	{
		ResponseModel model = new ResponseModel();
		ResponseModel responseModel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try 
		{
			responseModel = iLabTransferRepository.getSampleType();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}	
	
	
	@Override
	public ResponseModel getLabMaster(RequestModel requestModel) {

		ResponseModel responseModel = new ResponseModel(); 
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			LabMasterRequestModel labMasterRequestModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), LabMasterRequestModel.class);
			log.info(CommonConstants.LAB_MASTER_REQUEST_MODEL + labMasterRequestModel);
			responseModel = iLabTransferRepository.getLabMaster(labMasterRequestModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
	
	@Override
	public ResponseModel getCourierMaster(RequestModel requestModel) {

		ResponseModel responseModel = new ResponseModel(); 
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			CourierMasterRequestModel courierMasterRequestModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), CourierMasterRequestModel.class);
			log.info(CommonConstants.COURIER_MASTER_REQUEST_MODEL + courierMasterRequestModel);
			responseModel = iLabTransferRepository.getCourierMaster(courierMasterRequestModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	
	
	@Override
	public ResponseModel getTransferType() {

		ResponseModel responseModel = new ResponseModel(); 
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			responseModel = iLabTransferRepository.getTransferType();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
	
	
	@Override
	public ResponseModel updateLabTranReceive(RequestModel requestModel) {

		ResponseModel responseModel = new ResponseModel(); 
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			LabTranReceiveReqModel courierMasterRequestModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), LabTranReceiveReqModel.class);
			log.info(CommonConstants.UPDATE_LAB_TRAN_RECEIVE_REQUEST_MODEL + courierMasterRequestModel);
			responseModel = iLabTransferRepository.updateLabTranReceive(courierMasterRequestModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
}
