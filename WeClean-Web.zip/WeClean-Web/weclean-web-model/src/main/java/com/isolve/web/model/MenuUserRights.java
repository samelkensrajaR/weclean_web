package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MenuUserRights implements Serializable
{/**
	 * 
	 */
	private static final long serialVersionUID = -614645718536596725L;
	private Integer roleid;
	private Integer targetactionid;
	private Long createdby;
	private Integer menutarget;
	private Integer execute;
	private Integer landing;
}
