package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChatUserReqModel implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6478883006343795159L;
	private Long user_id;
	private Integer role_id;
	private Long from_user_id;
	private Long to_user_id;
	private Integer page_number;
	private Long returnvalues;
	private Long orderid;
	private Long invoiceid;
}