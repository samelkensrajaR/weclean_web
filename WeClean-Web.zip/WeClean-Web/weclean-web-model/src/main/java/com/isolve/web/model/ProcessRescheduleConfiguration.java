package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProcessRescheduleConfiguration implements Serializable {
	private static final long serialVersionUID = 1L;
	private String LC_CM_SMS_API;
	private String LC_CM_HOST;
	private String LC_CM_PORT;
	private String LC_CM_USERNAME;
	private String LC_CM_PASSWORD;
	private String LC_CM_PURPOSE;
	private String LC_CM_FLAG;
	private String LC_CM_DOMAIN;
}