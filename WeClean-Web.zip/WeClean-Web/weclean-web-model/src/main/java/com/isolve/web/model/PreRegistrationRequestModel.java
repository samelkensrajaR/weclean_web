package com.isolve.web.model;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PreRegistrationRequestModel {

	private String crmno;
	private String orderid;
	private String patientfirstname ;
	private String patientlastname ;
	private String primarycontact ;
	private String alternatecontact ;
	private String emailid ;
	private String addressname;
	private String addressemail ;
	private String addressmobile ;
	private String addressstreet1 ;
	private String addressstreet2 ;
	private Integer addresscity ;
	private Integer addressstate ;
	private String addresscountry ;
	private String addresspincode ;
	private Integer patientage ;

	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	@JsonSerialize(using=LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	private LocalDateTime dob ;
	private String servicetype ;
	private List<PlanCode> code;
	
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	@JsonSerialize(using=LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	private LocalDateTime collectiondatetime;
	private String hospitalid ;
	private String hospitalname ;
	private Long doctorid;
	private String doctorcode ;
	private String doctorname ;
	private Integer genderid ;
	private Integer titleid ;
	private Long userid ;
	private String remarks;
	private Integer referid ;
	private String lattitude ;
	private String longitude;
	private String ageyear;
	private String agemonth;
	private String ageday;
	
}
