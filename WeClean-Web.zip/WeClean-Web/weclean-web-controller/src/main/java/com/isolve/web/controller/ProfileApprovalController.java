package com.isolve.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.service.IUserApproveRejectService;
import com.isolve.web.service.IUserPendingApprovalService;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@RestController
@CrossOrigin(value = "*",maxAge = 3600)
public class ProfileApprovalController 
{
	@Autowired
	private IUserPendingApprovalService iApprovalService;
	
	@Autowired
	private IUserApproveRejectService iApproveRejectService;
	
	@RequestMapping(value = "/"+CommonConstants.USERPENDINGAPPROVAL, method = RequestMethod.POST)
	public ResponseEntity<?> userPendingApproval(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iApprovalService.userPendingApproval(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}	
	
	
	@RequestMapping(value = "/"+CommonConstants.UPDATE_USER_APPROVE_REJECT, method = RequestMethod.POST)
	public ResponseEntity<?> getReceiveBioBankSample(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iApproveRejectService.userApproveReject(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
}
