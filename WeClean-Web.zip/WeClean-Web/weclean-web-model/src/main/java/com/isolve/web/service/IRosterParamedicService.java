package com.isolve.web.service;

import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;

public interface IRosterParamedicService 
{
	ResponseModel getRosterAgent();

	ResponseModel getRosterDetUser(RequestModel requestModel);
	
	ResponseModel getRosterRider();

	ResponseModel getRosterType();

	ResponseModel getRosterInsertUpdate(RequestModel requestModel);

	ResponseModel deleteRoster(RequestModel requestModel);

	ResponseModel getRosterDetUserWithDate(RequestModel requestModel);

	
}
