package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LabTransferInitiativeUserModel implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1016645541778162537L;
	private long orderid;
	private String crmid;
}
