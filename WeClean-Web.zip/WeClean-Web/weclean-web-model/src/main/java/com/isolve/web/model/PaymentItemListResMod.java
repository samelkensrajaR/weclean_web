package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentItemListResMod implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4513252752608714423L;
	private String itemname;
	private Long quantity;
	private Double rate;
	private String amount;



}
