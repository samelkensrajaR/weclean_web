package com.isolve.web.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class RosterTypeResponseModel 
{	
	@Id
	private Long lc_rt_id;
	private String lc_rt_description;
}
