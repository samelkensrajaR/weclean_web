package com.isolve.common.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserTypeReqModel implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4764077336864852092L;
	
	private Integer flag;

}
