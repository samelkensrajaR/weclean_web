package com.isolve.common.service;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isolve.common.model.LanguageMasterRequestModel;
import com.isolve.common.model.LanguageMasterResponseModel;
import com.isolve.common.model.RequestModel;
import com.isolve.common.model.ResponseModel;
import com.isolve.common.model.RoleReqModel;
import com.isolve.common.model.StateMasterReqModel;
import com.isolve.common.model.TaskTypeReqModel;
import com.isolve.common.model.UserTypeReqModel;
import com.isolve.common.repository.IMasterRepository;
import com.isolve.common.utils.Utils;

@Service
public class MasterServiceImpl implements IMasterService {

	@Autowired
	private IMasterRepository iMasterRepository;

	private ObjectMapper objectMapper = new ObjectMapper();

	@Value("${encryptsecretkey}")
	private String encryptsecretkey;

	/**
	 * @author
	 * @Name getStateMaster - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getStateMaster method using to get all state lists.
	 */
	@Override
	public ResponseModel getStateMaster(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			StateMasterReqModel stateMasterReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					StateMasterReqModel.class);
			responseModel = iMasterRepository.getStateMaster(stateMasterReqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	/**
	 * @author
	 * @Name getCityMaster - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getCityMaster method using to get City list based on State.
	 */
	@Override
	public ResponseModel getCityMaster(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			StateMasterReqModel stateMasterReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					StateMasterReqModel.class);
			responseModel = iMasterRepository.getCityMaster(stateMasterReqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	/**
	 * @author
	 * @Name getAddressType - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getAddressType method using to get Address type master.
	 */
	@Override
	public ResponseModel getAddressType() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getAddressType();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	/**
	 * @author
	 * @Name getPickupType - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getPickupType method using to get pickup type master.
	 */
	@Override
	public ResponseModel getPickupType() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getPickupType();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	/**
	 * @author
	 * @Name getAccountType - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getAccountType method using to get account type master.
	 */
	@Override
	public ResponseModel getAccountType(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			TaskTypeReqModel typeReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					TaskTypeReqModel.class);
			responseModel = iMasterRepository.getAccountType(typeReqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	/**
	 * @author
	 * @Name getTaskType - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getTaskType method using to get task type master.
	 */
	@Override
	public ResponseModel getTaskType(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			TaskTypeReqModel typeReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					TaskTypeReqModel.class);
			responseModel = iMasterRepository.getTaskType(typeReqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	/**
	 * @author
	 * @Name getUserType - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getUserType method using to get User Type master.
	 */
	@Override
	public ResponseModel getUserType(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			UserTypeReqModel userTypeReqModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					UserTypeReqModel.class);
			responseModel = iMasterRepository.getUserType(userTypeReqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	/**
	 * @author
	 * @Name getRole - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getRole method using to get all roles list.
	 */
	@Override
	public ResponseModel getRole(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			RoleReqModel reoleReqmodel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					RoleReqModel.class);
			responseModel = iMasterRepository.getRole(reoleReqmodel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	/**
	 * @author
	 * @Name decrypt - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: decrypt method using to decrypt given data.
	 */
	@Override
	public ResponseModel decrypt(RequestModel requestModel) {
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(decrypt);
			model.setResponseObject(obj);
			model.setStatusCode(200);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	/**
	 * @author
	 * @Name encrypt - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: encrypt method using to encrypt given data.
	 */
	@Override
	public ResponseModel encrypt(String requestModel) {
		ResponseModel model = new ResponseModel();

		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(requestModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	/**
	 * @author
	 * @Name getgenderDetails - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getgenderDetails method using to get gender list master.
	 */
	@Override
	public ResponseModel getGenderDetails() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getGenderDetails();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	/**
	 * @author
	 * @Name getTitleMaster - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getTitleMaster method using to get Title MAster.
	 */
	@Override
	public ResponseModel getTitleMaster() {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iMasterRepository.getTitleMaster();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	/**
	 * @author
	 * @Name getLanguageMaster - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getLanguageMaster method using to get all language names.
	 */
	@Override
	public ResponseModel getLanguageMaster(RequestModel requestModel) {
		List<LanguageMasterResponseModel> responseModel = new ArrayList<>();
		ResponseModel model = new ResponseModel();

		try {
			LanguageMasterRequestModel languageMasterResponseModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					LanguageMasterRequestModel.class);
			// log.info(CommonConstants.LANGUAGE_MASTER_REQUEST_MODEL +
			// languageMasterResponseModel);
			responseModel = iMasterRepository.getLanguageMaster(languageMasterResponseModel);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}

		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

}
