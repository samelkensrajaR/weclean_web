package com.isolve.common.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class ProductDetailsModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8225799528619561752L;
	@Id
	private String LC_PD_PRODUCT_CODE;
	private String LC_PD_PRODUCT_NAME;
	private String TOTAL_TEST_COUNT;
	private String LC_PD_ICON_IMAGE_PATH;

	
}
