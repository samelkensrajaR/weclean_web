package com.isolve.web.utils;

public class CommonConstants {
	
	public static final String BIOBANK = "biobank";
	public static final String HOME = "home";
	public static final String ENCRYPTSECRETKEY = "encryptsecretkey ";
	public static final String BIOBANK_RECEIVE_SAMPLEMODEL = "bioBankReceiveSampleModel ";
	public static final String CLIENT_SECRET = "ClientSecret";
	public static final String CLIENT_SECRET_NOT_FOUND = "Client secret is mandatory";
	public static final String PRE_REGISTRATION="preregistration";
	public static final String REPORT="report";
	
	
	//USP_LIFECELL_LOGIN stored procedure parameter
	public static final String USP_LIFECELL_LOGIN = "USP_LIFECELL_LOGIN";
	public static final String USP_TOKEN_GENERATION = "USP_Token_Generation";
	public static final String USP_VALIDATE_TOKEN = "USP_Validate_Token";
	public static final String TOKEN = "Token";
	public static final String USP_GET_BIO_RECEIVE_DETAILS = "USP_GET_BIO_Receive_Details";
	public static final String LOGIN_USER = "Login_User";
	public static final String PASSWORD = "Password";
	public static final String IMEI = "IMEI";
	public static final String FIREBASE_ID = "Firebase_ID";
	public static final String ANDROID_IOS_WEB = "Android_IOS_Web";
	public static final String PARAMEDICID = "ParamedicID"; 
	public static final String SCHSTARTDATETIME = "schStartdatetime";
	public static final String SCHENDDATETIME = "schEnddatetime";
	public static final String RPTTYPE= "RptType";
	public static final String ORDERORIGINATION = "OrderOrigination";
	public static final String CLIENTID = "ClientID";
	
	//response constants
	public static final String SUCCESS = "Success";
	public static final String FAILED = "Failed";
	
	//USP_GET_REPEAT_COLLECTION_DETAILS
	public static final String USP_GET_REPEAT_COLLECTION_DETAILS = "USP_GET_REPEAT_COLLECTION_DETAILS";
	public static final String REPEATCOLLECTION_REQUEST_MODEL = "repeatcollectionRequestModel";
	public static final String GETREPEATCOLLECTION = "getrepeatcollection";
	
	//USP_UPDATE_BIO_RECEIVE_DETAILS
	public static final String USP_UPDATE_BIO_RECEIVE_DETAILS = "USP_UPDATE_BIO_RECEIVE_DETAILS";
	public static final String UTTBIOORDERID = "UTTBIOORDERID";
	public static final String USERID="UserID";
	public static final String UPDATEBIORECEIVE="updatebioreceive";
	public static final String UPDATEBIO_RECEIVE_REQUEST_MODEL="updateBioReceiveRequestModel";
	
	//USP_GET_REPEAT_COLLECTION_ACTION
	public static final String USP_GET_REPEAT_COLLECTION_ACTION = "USP_GET_REPEAT_COLLECTION_ACTION";
	public static final String REPEATCOLLECTION_ACTION_REQUEST_MODEL = "repeatcollectionActionRequestModel";
	public static final String GETREPEATCOLLECTIONACTION = "getrepeatcollectionaction";
	public static final String ORDERID="OrderID";
	
	//USP_GET_USER_PENDING_APPROVAL
	public static final String USP_GET_USER_PENDING_APPROVAL="USP_GET_USER_PENDING_APPROVAL";
	public static final String USERTYPE="UserType";
	public static final String CITY="City";
	public static final String CRESTARTDATETIME="CreStartdatetime";
	public static final String CREENDDATETIME="CreEnddatetime";
	public static final String USER_PENDING_APPROVAL_REQUEST_MODEL="userpendingApprovalRequestModel";
	public static final String USERPENDINGAPPROVAL="userpendingapproval";
	
	//USP_UPDATE_REPEAT_SAMPLE_INITIATE
	public static final String USP_UPDATE_REPEAT_SAMPLE_INITIATE="USP_UPDATE_REPEAT_SAMPLE_INITIATE";
	public static final String REPEAT_SAMPLE_INITIATE_REQUESTMODEL="repeatsampleinitiaterequestmodel";
	public static final String REPEATSAMPLEINITIATE="repeatsampleinitiate";
	
	//USP_UPDATE_USER_APPROVE
	public static final String USP_UPDATE_USER_APPROVE="USP_UPDATE_USER_APPROVE";
	public static final String UPDATE_USER_APPROVE_REJECT_REQUESTMODEL="updateuserapproverejectrequestmodel";
	public static final String UPDATE_USER_APPROVE_REJECT="updateuserapprovereject";
	public static final String APPROVERID="ApproverID";
	public static final String APPREJSTS="Apprejsts";
	public static final String ROLEID="RoleID";
	public static final String REMARKS="Remarks";
	
	 //USP_GET_BIO_DIA_ASSIGN_DETAILS
	public static final String USP_GET_BIO_DIA_ASSIGN_DETAILS="USP_GET_BIO_DIA_ASSIGN_DETAILS";
	public static final String UPDATE_BIO_DIA_ASSIGN_REQUEST_MODEL="updatebiodiaassignrequestmodel";
	public static final String TASKID="TaskID";
	public static final String CENTERID="CenterID";
	public static final String PICKUPID="PickupID";
	public static final String CLIENTTYPEID="ClientTypeID";
	public static final String UPDATEBIODIAASSIGN="updatebiodiaassign";	
	
	//USP_GET_RECEIVE_SAMPLE_ACTION
	public static final String USP_GET_RECEIVE_SAMPLE_ACTION="USP_GET_RECEIVE_SAMPLE_ACTION";
	public static final String RECEIVESAMPLEACTION_REQUEST_MODEL="receivesampleactionrequestmodel";
	public static final String RECEIVESAMPLEACTION="receivesampleaction";
	
	//usp_Get_Roster_Agent_Assign
	public static final String USP_GET_ROSTER_AGENT_ASSIGN="USP_Get_Roster_Agent_Assign";
	public static final String PICKUP_DATE="PICKUP_DATE";
	public static final String ROSTER_AGENT_ASSIGN_REQUEST_MODEL="rosteragentassignrequestmodel";
	public static final String GETROSTERAGENTASSIGN="getrosteragentassign";
	
	
	//USP_GET_ROSTER_AGENT_AVAIL_BASED_ON_LOCATION
	public static final String USP_GET_ROSTER_AGENT_AVAIL_BASED_ON_LOCATION="USP_GET_ROSTER_AGENT_AVAIL_BASED_ON_LOCATION";
	//public static final String PICKUP_DATE="PICKUP_DATE";
	public static final String LOCATION="Location";
	public static final String PINCODE="Pincode";
	public static final String LOCATIONID="LocationID";
	public static final String ROSTER_AGENT_BASED_ON_LOCATION_REQUEST_MODEL="rosteragentbasedonlocationrequestmodel";
	public static final String GETROSTERAGENTBASEDONLOCATION="getrosteragentbasedonlocation";	
	
	//USP_GET_ROSTER_AGENT_AVAILABILITY
	public static final String USP_GET_ROSTER_AGENT_AVAILABILITY="usp_Get_Roster_Agent_availability";
	public static final String ROSTER_AGENT_AVAILABILITY_REQUEST_MODEL="rosteragentavailabilityrequestmodel";
	public static final String GETROSTERAGENTAVAILABILITY="getrosteragentavailability";
	
	//USP_GET_VKYC_ROSTER_CUSTOMER_AVAILABILITY
	public static final String USP_GET_VKYC_ROSTER_CUSTOMER_AVAILABILITY="usp_Get_Vkyc_Roster_Customer_availability";
	public static final String CUSTOMER_ID="CUSTOMER_ID";
	public static final String VKYC_ROSTER_CUSTOMER_AVAILABILITY_REQUEST_MODEL="vkycrostercustomeravailabilityrequestmodel";
	public static final String GETVKYCROSTERCUSTOMER="getvkycrostercustomer";
	
	//USP_GETAGENTAVAILABILITY
	public static final String USP_GETAGENTAVAILABILITY="usp_GetAgentAvailability";
	public static final String GETAGENTAVAILABILITY="getagentavailability";
	
	//USP_GETROSTERAGENCY
	public static final String USP_GETROSTERAGENCY="USP_GETROSTERAGENCY";
	public static final String GETROSTERAGENCY="getrosteragency";
	
	//USP_GET_AGENT_ROSTER
	public static final String USP_GET_AGENT_ROSTER="USP_GET_AGENT_ROSTER";
	public static final String GET_ROSTER_AGENT="getrosteragent";
	
	//USP_GET_ROSTER_DET_USER
	public static final String USP_GET_ROSTER_DET_USER="USP_GET_ROSTER_DET_USER";
	public static final String GET_ROSTER_DET_USER_REQUEST_MODEL="getrosterdetuserrequestmodel";
	public static final String GETROSTERDETUSER="getrosterdetuser";
	public static final String USERIDD="USERID";
	
	//USP_GETROSTERPARAMEDIC
	public static final String USP_GETROSTERRIDER="USP_GETROSTERRIDER";
	public static final String GETROSTERRIDER="getrosterrider";
	
	//usp_GetRosterType
	public static final String USP_GETROSTERTYPE="usp_GetRosterType";
	public static final String usp_Get_ROSTERTYPE="usp_Get_ROSTERTYPE";
	public static final String GETROSTERTYPE="getrostertype";
	
	
	//USP_INSERTUPDATEROSTER
	public static final String USP_INSERTUPDATEROSTER="USP_INSERTUPDATEROSTER";
	public static final String GETROSTERINSERTUPDATE="getrosterinsertupdate";
	public static final String ROSTER_INSERT_UPDATE_REQUEST_MODEL="rosterinsertupdaterequestmodel";
	public static final String RA_ID="RA_ID";
	public static final String WC_RA_RIDER_ID="WC_RA_RIDER_ID";
	public static final String WC_RA_RIDER_TYPE_ID="WC_RA_RIDER_TYPE_ID";
	public static final String WC_RA_REMARKS="WC_RA_REMARKS";
	public static final String WC_RA_START_DATE="WC_RA_START_DATE";
	public static final String WC_RA_END_DATE="WC_RA_END_DATE";
	public static final String WC_RA_DAY="WC_RA_DAY";
	public static final String WC_RA_STATUS="WC_RA_STATUS";
	public static final String WC_RA_CREATED_BY="WC_RA_CREATED_BY";
	
	
	//USP_GET_LAB_TRANSFER
	public static final String USP_GET_LAB_TRANSFER="USP_GET_LAB_TRANSFER";
	public static final String GETLABTRANSFER="getlabtransfer";
	public static final String GET_LABTRANSFER_REQUEST_MODEL="getlabtransfer";
	public static final String SAMPLETYPE="SampleType";
	public static final String TRANSFERTYPE="TransferType";
	public static final String LAB="Lab";
	
	
	
	//USP_UPDATE_LAB_TRAN_INITIATE
	public static final String USP_UPDATE_LAB_TRAN_INITIATE="USP_UPDATE_LAB_TRAN_INITIATE";
	public static final String LABTRANSFER_INITIATIVE_REQUEST_MODEL="labtransferinitiativerequestmodel";
	public static final String UPDATE_LABTRANSFER_INITIATE="updatelabtransferinitiate";
	public static final String SOURCELAB_ID="SOURCELAB_ID";
	public static final String DESTLAB_ID="DESTLAB_ID";
	public static final String UTT_LAB_TRAN_ORDERID="UTT_LAB_TRAN_ORDERID";
	public static final String TRANTYPEID="TRANTYPEID";
//	public static final String PARAMEDICIDD="PARAMEDICID";
	public static final String TRANSFERDATE="TRANSFERDATE";
//	public static final String REMARKSS="REMARKS";
	public static final String COURIER_ID="COURIER_ID";
	public static final String PODNUMBER="PODNUMBER";
	public static final String COURIERDATE="COURIERDATE";
//	public static final String USERID="USERID";
	
	
	
	
	//USP_GET_USER_AVAILABILITY
	public static final String USP_GET_RIDER_AVAILABILITY="USP_GET_RIDER_AVAILABILITY";
	public static final String GETPARAMEDICUSERAVAILABILITY="getparamedicuseravailability";
	public static final String PICKUPDATE="PICKUPDATE";
	public static final String GET_USER_PARAMEDIC_AVAILABILITY_REQUEST_MODEL="getuserparamedicavailabilityrequestmodel";
	
	
	//USP_UPDATE_ASSIGN_PARAMEDIC
	public static final String USP_UPDATE_ASSIGN_PARAMEDIC="USP_UPDATE_ASSIGN_PARAMEDIC";
	public static final String GET_ASSIGN_PARAMEDIC_REQUEST_MODEL="ASSIGN_PARAMEDIC_REQUEST_MODEL";
	public static final String UPDATEASSIGNPARAMEDIC="updateassignparamedic";
	public static final String PICKUPDATETIME="PICKUPDATETIME";
	public static final String REMARKSS="REMARKS";
	public static final String PICKUPIDD="PICKUPID";
	public static final String PARAMEDICIDD="PARAMEDICID";
	public static final String TYPE="TYPE";
	public static final String ORDERIDD="ORDERID";
	public static final String LATTITUDE="LATTITUDE";
	public static final String LONGITUDE="LONGITUDE";
	public static final String ispickupedit="ispickupedit";
	public static final String isreassigned="isreassigned";
	
	
	//USP_GET_USER_PICKUP_SCHEDULE
	public static final String USP_GET_USER_PICKUP_SCHEDULE="USP_GET_USER_PICKUP_SCHEDULE";
	public static final String GETUSERPICKUPSCHEDULE="getuserpickupschedule";
	public static final String GET_USER_PICKUP_SCHEDULE_REQUEST_MODEL="getuserpickupschedulerequestmodel";
	public static final String GET_USER_PICKUP_SCHEDULE_RESPONSE_MODEL="getuserpickupscheduleresponsemodel";
	
	//USP_GET_ORDER_TYPE
	public static final String USP_GET_ORDER_TYPE="USP_GET_ORDER_TYPE";
	public static final String GETORDERTYPE="getSampleType";
	
	
	//USP_GET_LAB_MASTER
	public static final String USP_GET_LAB_MASTER="USP_GET_LAB_MASTER";
	public static final String LANG_ID="LANG_ID";
	public static final String LAB_MASTER_REQUEST_MODEL="labmasterrequestmodel";
	public static final String GETLABMASTER="getlabmaster";
	
	
	//USP_GET_COURIER_MASTER
	public static final String USP_GET_COURIER_MASTER="USP_GET_COURIER_MASTER";
	public static final String COURIER_MASTER_REQUEST_MODEL="couriermasterrequestmodel";
	public static final String GETCOURIERMASTER="getcouriermaster";
	
	//USP_DELETE_ROSTER
	public static final String USP_DELETE_ROSTER="USP_DELETE_ROSTER";
	public static final String DELETE_ROSTER_REQUEST_MODEL="DELETE_ROSTER_REQUEST_MODEL";
	public static final String DELETEROSTER="deleteroster";
	
	
	//USP_GET_ROSTER_DET_USER_WITHDATE
	public static final String USP_GET_ROSTER_DET_USER_WITHDATE="USP_GET_ROSTER_DET_USER_WITHDATE";
	public static final String ROSTER_DET_USER_WITHDATE_REQUEST_MODEL="rosterdetuserwithdaterequestmodel";
	public static final String GET_ROSTER_DET_USER_WITHDATE="getrosterdetuserwithdate";
//	public static final String USERIDD="USERIDD";
	public static final String STARTDATE="STARTDATE";
	public static final String ENDDATE="ENDDATE";
	
	//USP_GET_USER_MGMT
	public static final String USP_GET_USER_MGMT="USP_GET_USER_MGMT";
	public static final String GETUSERMGMT="getusermanagement";
	
	//USP_CANCEL_PARAMEDIC
	public static final String USP_CANCEL_PARAMEDIC="USP_CANCEL_PARAMEDIC";
//	public static final String ORDERIDD="ORDERID";
	public static final String REASON="REASON";
//	public static final String REMARKSS="REMARKS";
//	public static final String USERIDD="USERID";
	public static final String CANCELPARAMEDIC="cancelparamedic";
	public static final String CANCEL_PARAMEDIC_REQUEST_MODEL="CANCEL_PARAMEDIC_REQUEST_MODEL";
	
//	USP_GET_TRANSFER_TYPE
	public static final String USP_GET_TRANSFER_TYPE="USP_GET_TRANSFER_TYPE";
	public static final String GETTRANSFERTYPE="gettransfertype";
	
	
//	USP_GET_CANCEL_REASON
	public static final String USP_GET_CANCEL_REASON="USP_GET_CANCEL_REASON";
	public static final String GETCANCELREASON="getcancelreason";

	
//	USP_UPDATE_LAB_TRAN_RECEIVE
	public static final String USP_UPDATE_LAB_TRAN_RECEIVE="USP_UPDATE_LAB_TRAN_RECEIVE";
	public static final String UPDATE_LAB_TRAN_RECEIVE="updatelabtranreceive";
	public static final String UPDATE_LAB_TRAN_RECEIVE_REQUEST_MODEL="UPDATE_LAB_TRAN_RECEIVE_REQUEST_MODEL";
	public static final String UPDATE_LAB_TRAN_RECEIVE_RESPONSE="UPDATE_LAB_TRAN_RECEIVE_RESPONSE";
	
	
//	USP_GET_PARAMEDIC_AVAILABILITY_Day
	public static final String USP_GET_PARAMEDIC_AVAILABILITY_Day="USP_GET_PARAMEDIC_AVAILABILITY_Day";
	public static final String GET_PARAMEDIC_AVAILABILITY_DAY="getparamedicavailabilityday";
	public static final String PARAMEDIC_AVAILABILITY_DAY_RESPONSE="PARAMEDIC_AVAILABILITY_DAY_RESPONSE";
	public static final String PARAMEDIC_AVAILABILITY_DAY_REQUEST_MODEL="PARAMEDIC_AVAILABILITY_DAY_REQUEST_MODEL";
	
//	USP_GET_ROLE_MANAGEMENT_MENU
	public static final String USP_GET_ROLE_TARGETS="USP_GET_ROLE_TARGETS";
	public static final String GET_ROLE_TARGETS="getroletargetmenu";
	
//	USP_GET_ROLE_ROLES
	public static final String USP_GET_ROLE_ROLES="USP_GET_ROLE_ROLES";
	public static final String GET_ROLE_ROLES="getroles";
	
//	USP_INSERT_ROLE_SAVETARGETACTIONROLE
	public static final String USP_INSERT_ROLE_SAVETARGETACTIONROLE="USP_INSERT_ROLE_SAVETARGETACTIONROLE";
	public static final String SAVE_TARGET_ACTION_ROLE="savetargetactionrole";
	public static final String SAVE_TARGET_ACTION_ROLE_REQ_MODEL="SAVE_TARGET_ACTION_ROLE_REQ_MODEL";
	public static final String ROLEIDD="ROLEID";
	public static final String TARGETACTIONID="TARGETACTIONID";
	public static final String CREATEDBY="CREATEDBY";
	public static final String MENUTARGET="MENUTARGET";
	public static final String Actionstatus="Actionstatus";
	
//	USP_GET_ROLE_ACTIONSFORSPECIFICTARGETID
	public static final String USP_GET_ROLE_ACTIONSFORSPECIFICTARGETID="USP_GET_ROLE_ACTIONSFORSPECIFICTARGETID";
	public static final String GET_ROLE_ACTIONS_FOR_SPECIFIC_TARGETID="getroleactionsforspecifictargetid";
	public static final String GET_ROLE_ACTIONSFORSPECIFICTARGETID_REQ_MODEL="GET_ROLE_ACTIONSFORSPECIFICTARGETID_REQ_MODEL";
//	public static final String ROLEIDD="ROLEID";
	public static final String TARGETID="TARGETID";
//	public static final String MENUTARGET="MENUTARGET";
	
//	USP_GET_ROLE_USERROLE_VIEWPERMISSION_REPORTS
	public static final String USP_GET_ROLE_USERROLE_VIEWPERMISSION_REPORTS = "USP_GET_ROLE_USERROLE_VIEWPERMISSION_REPORTS";
	public static final String USERROLE_PERMISSION_REQ_MODEL = "USERROLE_PERMISSION_REQ_MODEL";
	public static final String GET_USER_ROLE_PERMISSION= "getuserpermission";
	
// USP_GET_PRE_REGISTRATION_DETAILS
	public static final String USP_GET_PRE_REGISTRATION_DETAILS="USP_GET_PRE_REGISTRATION_DETAILS";
	public static final String GET_PRE_REGISTRATION_DETAILS="getpreregistrationdetails";
	
//	USP_INSERT_UPDATE_PRE_REGISTRATION
	public static final String USP_INSERT_UPDATE_PRE_REGISTRATION="USP_INSERT_UPDATE_PRE_REGISTRATION";
	public static final String SUBMIT_PRE_REGISTRATION="submitpreregistration";
	public static final String PRE_REGISTRATION_INSERT_UPDATE_REQUEST_MODEL="PRE_REGISTRATION_INSERT_UPDATE_REQUEST_MODEL";
	public static final String PLAN_CODE="PLAN_CODE";
	public static final String USP_INSERT_UPDATE_PRE_REGISTRATION_PROCESS="USP_INSERT_UPDATE_PRE_REGISTRATION_PROCESS";
	public static final String PRE_REGISTRATION_PROCESS="preRegistrationProcess";
	
// USP_GET_APP_USAGE_STATUS_REPORT
	public static final String USP_GET_APP_USAGE_STATUS_REPORT="USP_GET_APP_USAGE_STATUS_REPORT";
	public static final String GET_APP_USAGE_STATUS_REPORT="getappusagestatusreport";

//	USP_GET_CASH_COLLECTION_TRACK_REPORT
	public static final String USP_GET_CASH_COLLECTION_TRACK_REPORT="USP_GET_CASH_COLLECTION_TRACK_REPORT";
	public static final String GET_CASH_COLLECTION_TRACK_REPORT="getcashcollectiontrackreport";
	
//	USP_GET_CENTERWISE_SAMPLE_COLLECTION_STATUS_REPORT
	public static final String USP_GET_CENTERWISE_SAMPLE_COLLECTION_STATUS_REPORT="USP_GET_CENTERWISE_SAMPLE_COLLECTION_STATUS_REPORT";
	public static final String GET_CENTERWISE_SAMPLE_COLLECTION_STATUS_REPORT="getcenterwisesamplecollectionstatusreport";
	
	
//	USP_GET_PARAMEDIC_TAT_REPORT 
	public static final String USP_GET_PARAMEDIC_TAT_REPORT ="USP_GET_PARAMEDIC_TAT_REPORT";
	public static final String GET_PARAMEDIC_TAT_REPORT="getparamedictatreport";

//	USP_GET_BEATVSVISIT_COMPLIANCE_TRACKER_REPORT
	public static final String USP_GET_BEATVSVISIT_COMPLIANCE_TRACKER_REPORT ="USP_GET_BEATVSVISIT_COMPLIANCE_TRACKER_REPORT";
	public static final String GET_BEATVSVISIT_COMPLIANCE_TRACKER_REPORT="getbeatvsvisitcompliancetrackerreport";
	
//	USP_VIEW_REPORTS
	public static final String USP_VIEW_REPORTS ="USP_VIEW_REPORTS";
	public static final String VIEW_REPORTS="viewReports";	

	//	USP_GET_REPORT_MASTER
	public static final String USP_GET_REPORT_MASTER="USP_GET_REPORT_MASTER";
	public static final String GET_REPORT_MASTER="getreportmaster";
	
	
	// USP_GET_ORDER_HANDOVER_TYPE
	public static final String USP_GET_ORDER_HANDOVER_TYPE="USP_GET_ORDER_HANDOVER_TYPE";
	public static final String GET_ORDER_HANDOVER_TYPE="getorderhandovertype";
	
	public static final String HEALTHY = "healthy";
	
	// USP_GET_PENDING_REPORTS
	public static final String USP_GET_PENDING_REPORTS="USP_GET_PENDING_REPORTS";
	public static final String GET_PENDING_REPORTS="getPendingReports";
	
	
//USP_GET_REPOSITORY_REPORTS
	public static final String USP_GET_REPOSITORY_REPORTS="USP_GET_REPOSITORY_REPORTS";
	public static final String GET_REPOSITORY_REPORTS="getrepositoryreports";
	
	public static final Object LC_RP_RMID = "LC_RP_RMID";
	public static final Object LC_RP_REPORT_NAME = "LC_RP_REPORT_NAME";
	public static final Object LC_RP_STARTDATETIME = "LC_RP_STARTDATETIME";
	public static final Object LC_RP_ENDDATETIME = "LC_RP_ENDDATETIME";
	public static final Object LC_RP_CITYID = "LC_RP_CITYID";
	public static final Object LC_RP_CENTERID = "LC_RP_CENTERID";
	public static final Object LC_RP_TYPE = "LC_RP_TYPE";
	public static final Object LC_RP_ID = "LC_RP_ID";
	
	public static final String PARAMEDICWISE_TAT_REPORT = "PARAMEDIC WISE TAT REPORT";
	public static final String HOSPITALWISE_TAT_REPORT = "HOSPITAL WISE TAT REPORT";
	public static final String OVERALL_TAT_REPORT = "OVERALL TAT REPORT";
	
	
	// USP_INSERT_UPDATE_PINCODE_MAPPINGUSP_GET_COMPLAINTS_DETAILS_EXPORT
	
	public static final String INSERTUPDATEPINCODEMAPPING="insertupdatepincodemapping";
	public static final String USP_INSERT_UPDATE_PINCODE_MAPPING="USP_INSERT_UPDATE_PINCODE_MAPPING";
	public static final String USP_GET_PINCODE_MASTER="USP_GET_PINCODE_MASTER";
	public static final String GET_PINCODE_MASTER="getpincodemaster";	
	
	
	// USP_INSERT_UPDATE_VENDOR_VISITTIME_MAPPING
	public static final String USP_INSERT_UPDATE_VENDOR_VISITTIME_MAPPING="USP_INSERT_UPDATE_VENDOR_VISITTIME_MAPPING";
	public static final String INSERT_UPDATE_VENDOR_VISITTIME_MAPPING="insertupdatevendorvisittimemapping";	
	public static final String USP_GET_VENDOR_VISIT_TIME="USP_GET_VENDOR_VISIT_TIME";
	public static final String GET_VENDOR_VISIT_TIME="getvendorvisittime";
	
	// USP_GET_PARAMEDIC_DETAILS 
		public static final String USP_GET_PARAMEDIC_DETAILS ="USP_GET_PARAMEDIC_DETAILS ";
		public static final String GET_PARAMEDIC_DETAILS ="getparamedicdetails";
		
		// USP_GET_CITY_STATE_CENTER_BY_USERID 
			public static final String USP_GET_CITY_STATE_CENTER_BY_USERID ="USP_GET_CITY_STATE_CENTER_BY_USERID";
			public static final String GET_CITY_STATE_CENTER_BY_USERID ="getcitystatecenterbyuserid";

// USP_VENDOR_DETAILS_MASTER
				public static final String USP_VENDOR_DETAILS_MASTER ="USP_VENDOR_DETAILS_MASTER ";
				public static final String VENDOR_DETAILS_MASTER ="vendordetailsmaster";
				
					// USP_INSERT_UPDATE_CENTER_MASTER
		public static final String USP_INSERT_UPDATE_CENTER_MASTER ="USP_INSERT_UPDATE_CENTER_MASTER ";
		public static final String INSERT_UPDATE_CENTER_MASTER ="insertupdatecentermaster";

	// USP_INSERT_UPDATE_VISIT_TIME_MASTER
			public static final String USP_INSERT_UPDATE_VISIT_TIME_MASTER ="USP_INSERT_UPDATE_VISIT_TIME_MASTER ";
			public static final String INSERT_UPDATE_VISIT_TIME_MASTER ="insertupdatevisittimemaster";
	
	// USP_GET_LC_APPROVE_STATUS
		public static final String USP_GET_LC_APPROVE_STATUS ="USP_GET_LC_APPROVE_STATUS ";
		public static final String GET_LC_APPROVE_STATUS ="getapprovestatus";

		
		// USP_GET_REGION
		public static final String USP_GET_REGION ="USP_GET_REGION ";
		public static final String GET_REGION ="getregion";
	
				
	// USP_GET_MANAGEMENT
	public static final String USP_GET_MANAGEMENT ="USP_GET_MANAGEMENT ";
	public static final String GET_MANAGEMENT ="getmanagement";	

	// USP_INSERT_UPDATE_TEST_PRODUCT_MAPPING
	public static final String USP_INSERT_UPDATE_TEST_PRODUCT_MAPPING ="USP_INSERT_UPDATE_TEST_PRODUCT_MAPPING ";
	public static final String INSERT_UPDATE_TEST_PRODUCT_MAPPING ="insertupdatetestproductmapping";
	
	
	//USP_GET_PRECONDITION_MASTER
	public static final String USP_GET_PRECONDITION_MASTER ="USP_GET_PRECONDITION_MASTER ";
	public static final String GET_PRECONDITION_MASTER ="getpreconditionmaster";
	
	
	//USP_GET_PAYMENTSTATUS
		public static final String USP_GET_PAYMENTSTATUS ="USP_GET_PAYMENTSTATUS ";
		public static final String GET_PAYMENTSTATUS ="getpayamentstatus";
	
	//USP_GET_ALLCLIENT_MASTER
		public static final String USP_GET_ALLCLIENT_MASTER ="USP_GET_ALLCLIENT_MASTER";
		public static final String GET_ALLCLIENT_MASTER ="getallclientmaster";
					
	//USP_GET_ALLCLIENT_MASTER
		public static final String USP_GET_ALLSTATUS_MASTER ="USP_GET_ALLSTATUS_MASTER";
		public static final String GET_ALLSTATUS_MASTER ="getallstatusmaster";
			
	//USP_GET_ALLCLIENT_MASTER
		public static final String USP_GET_ALLINVOICETRACKING ="USP_GET_ALLINVOICETRACKING";
		public static final String GET_ALLINVOICETRACKING ="getallinvoicetracking";

      //USP_GET_QUOTATION_DETAILS
		public static final String USP_GET_QUOTATION_DETAILS ="USP_GET_QUOTATION_DETAILS";
		public static final String GET_QUOTATION_DETAILS ="getquotationdetails";
		  
    //USP_GET_ALLCLIENT_MASTER
		public static final String USP_GET_APPROVEDSTATUS_MASTER ="USP_GET_APPROVEDSTATUS_MASTER";
		public static final String GET_APPROVEDSTATUS_MASTER ="getapprovedstatusmaster";

    //USP_GET_ACCOUNT_TYPE_MASTER
		public static final String USP_GET_ACCOUNT_TYPE_MASTER ="USP_GET_ACCOUNT_TYPE_MASTER";
		public static final String GET_ACCOUNT_TYPE_MASTER ="getaccounttypemaster";
		
	  //USP_GET_ALLINVOICESTATUS_MASTER
			public static final String USP_GET_ALLINVOICESTATUS_MASTER ="USP_GET_ALLINVOICESTATUS_MASTER";
			public static final String GET_ALLINVOICESTATUS_MASTER ="getallinvoicestatusmaster";


		 //USP_GET_WEB_DASHBOARD_DETAILS
		public static final String USP_GET_WEB_DASHBOARD_DETAILS ="USP_GET_WEB_DASHBOARD_DETAILS";
		public static final String GET_WEB_DASHBOARD_DETAILS ="getwebdashboarddetails";

		
		 //USP_GET_SALES_WEB_DASHBOARD_DETAILS
		public static final String USP_GET_SALES_WEB_DASHBOARD_DETAILS ="USP_GET_SALES_WEB_DASHBOARD_DETAILS";
		public static final String GET_SALES_WEB_DASHBOARD_DETAILS ="getsaleswebdashboarddetails";

		public static final String USP_INSERT_UPDATE_SALES_HOSPITAL_MAPPING="USP_INSERT_UPDATE_SALES_HOSPITAL_MAPPING";
		public static final String INSERT_UPDATE_SALES_HOSPITAL_MAPPING="insertupdatesaleshospitalmapping";	
		
		//USP_GET_WEB_DASUSP_GET_SALES_USERSHBOARD_DETAILS
				public static final String USP_GET_SALES_USERS ="USP_GET_SALES_USERS";
				public static final String GET_SALES_USERS ="getsalesusers";
		
	   //USP_INSERT_UPDATE_DOCTOR_DETAILS
				public static final String USP_INSERT_UPDATE_DOCTOR_DETAILS="USP_INSERT_UPDATE_DOCTOR_DETAILS";
				public static final String INSERT_UPDATE_DOCTOR_DETAILS="insertupdatedoctordetails";	
				
				public static final String USP_INSERT_UPDATE_DOCTOR_HOSPITAL_MAPPING="USP_INSERT_UPDATE_DOCTOR_HOSPITAL_MAPPING";
				public static final String INSERT_UPDATE_DOCTOR_HOSPITAL_MAPPING="insertupdatedoctorhospitalmapping";		

				//
				public static final String USP_GET_HOSPITAL_WISE_STATE_CITY ="USP_GET_HOSPITAL_WISE_STATE_CITY";
				public static final String GET_HOSPITAL_WISE_STATE_CITY ="gethospitalwisestatecity";

				//USP_GET_PRODUCT_DETAILS
		public static final String USP_GET_PRODUCT_FOR_WEB="USP_GET_PRODUCT_FOR_WEB";
		public static final String GET_PRODUCT_FOR_WEB = "getProductForWeb";	
		
		//USP_GET_ALL_CLEANING_CATEGORY
 
				public static final String USP_GET_ALL_CLEANING_CATEGORY="USP_GET_ALL_CLEANING_CATEGORY";
				public static final String GET_ALL_CLEANING_CATEGORY = "getallcleaningcategory";
				
				//USP_GET_ALL_ITEM_MASTER
				public static final String USP_GET_ALL_ITEM_MASTER="USP_GET_ALL_ITEM_MASTER";
				public static final String GET_ALL_ITEM_MASTER = "getallitemmaster";
				
				//USP_GET_ALL_ITEM_MASTER
				public static final String USP_GET_ALL_SERVICE_MASTER="USP_GET_ALL_SERVICE_MASTER";
				public static final String GET_ALL_SERVICE_MASTER = "getallservicemaster";
				
				//USP_GET_COLOUR_MASTER
				public static final String USP_GET_COLOUR_MASTER="USP_GET_COLOUR_MASTER";
				public static final String GET_COLOUR_MASTER = "getcolourmaster";
				
				//USP_GET_DAMAGE_MASTER
				public static final String USP_GET_DAMAGE_MASTER="USP_GET_DAMAGE_MASTER";
				public static final String GET_DAMAGE_MASTER = "getdamagemaster";
				
				//USP_GET_STAIN_MASTER
				public static final String USP_GET_STAIN_MASTER="USP_GET_STAIN_MASTER";
				public static final String GET_STAIN_MASTER = "getstainmaster";
				

				//USP_GET_USER_MASTER
				public static final String USP_GET_USER_MASTER="USP_GET_USER_MASTER";
				public static final String GET_USER_MASTER = "getusermaster";
 
				//USP_GET_USER_MASTER
				public static final String USP_GET_DELIVERY_MODE="USP_GET_DELIVERY_MODE";
				public static final String GET_DELIVERY_MODE = "getdeliverymode";
				
				//USP_GET_RIDER_SLOT_AVAILABILITY
				public static final String USP_GET_RIDER_SLOT_AVAILABILITY="USP_GET_RIDER_SLOT_AVAILABILITY";
				public static final String GET_RIDER_SLOT_AVAILABILITY = "getriderslotavailability";
				//USP_GET_PICKUP_DETAILS
				public static final String USP_GET_PICKUP_DETAILS="USP_GET_PICKUP_DETAILS";
				public static final String GET_PICKUP_DETAILS = "getPickupDetails";
				
				
				//USP_INSERT_UPDATE_ORDER_DETAILS
				public static final String USP_INSERT_UPDATE_ORDER_DETAILS="USP_INSERT_UPDATE_ORDER_DETAILS";
				public static final String INSERT_UPDATE_ORDER_DETAILS = "insertUpdateOrderDetails";	 
	 
				//USP_INSERT_WEB_NEW_ORDER_DETAILS
				public static final String USP_INSERT_WEB_NEW_ORDER_DETAILS="USP_INSERT_WEB_NEW_ORDER_DETAILS";
				public static final String INSERT_WEB_NEW_ORDER_DETAILS = "insertWebNewOrderDetails";	 
				
				//USP_GET_CHALLAN_TYPE_MASTER
				public static final String USP_GET_CHALLAN_TYPE_MASTER="USP_GET_CHALLAN_TYPE_MASTER";
				public static final String GET_CHALLAN_TYPE_MASTER = "getchallantypemaster";
				
				//USP_GET_CHALLAN_MASTER
				public static final String USP_GET_CHALLAN_MASTER="USP_GET_CHALLAN_MASTER";
				public static final String GET_CHALLAN_MASTER="getchallanmaster";
				
				//USP_GET_PICKUP_DETAILS_BY_ITEMS
				public static final String USP_GET_PICKUP_DETAILS_BY_ITEMS="USP_GET_PICKUP_DETAILS_BY_ITEMS";
				public static final String GET_PICKUP_DETAILS_BY_ITEMS="getpickupdetailsbyitems";
				
				//USP_GET_CHALLAN_MASTER_EXPORT
				public static final String USP_GET_CHALLAN_MASTER_EXPORT="USP_GET_CHALLAN_MASTER_EXPORT";
				public static final String GET_CHALLAN_MASTER_EXPORT="getchallanmasterexport";
	 
				
				//USP_GET_PROCESSING_MASTER
				public static final String USP_GET_PROCESSING_MASTER="USP_GET_PROCESSING_MASTER";
				public static final String GET_PROCESSING_MASTER="getprocessingmaster";
				
				//USP_GET_PROCESS_DETAILS_BY_ITEMS
				public static final String USP_GET_PROCESS_DETAILS_BY_ITEMS="USP_GET_PROCESS_DETAILS_BY_ITEMS";
				public static final String GET_PROCESS_DETAILS_BY_ITEMS="getprocessdetailsbyitems";
				
				//USP_GET_PROCESS_STEPS_BY_SERVICEID
				public static final String USP_GET_PROCESS_STEPS_BY_SERVICEID="USP_GET_PROCESS_STEPS_BY_SERVICEID";
				public static final String GET_PROCESS_STEPS_BY_SERVICEID="getprocessstepsbyserviceid";
				
				// USP_INSERT_UPDATE_PROCESS_STATUS
				public static final String USP_INSERT_UPDATE_PROCESS_STATUS ="USP_INSERT_UPDATE_PROCESS_STATUS ";
				public static final String INSERT_UPDATE_PROCESS_STATUS ="insertupdateprocessingstatus";
				
				// USP_GET_REGION
				public static final String USP_GET_DISPATCH_DETAILS ="USP_GET_DISPATCH_DETAILS ";
				public static final String GET_DISPATCH_DETAILS ="getdispatchdetailss";
				
				// USP_INSERT_UPDATE_DISPATCH_DETAILS
				public static final String USP_INSERT_UPDATE_DISPATCH_DETAILS ="USP_INSERT_UPDATE_DISPATCH_DETAILS ";
				public static final String INSERT_UPDATE_DISPATCH_DETAILS ="insertupdatedispatchdetails";
				
				// USP_GET_STATUS_DETAILS
				public static final String USP_GET_STATUS_DETAILS ="USP_GET_STATUS_DETAILS ";
				public static final String GET_STATUS_DETAILS ="getstatusdetails";
				
				//USP_GET_CHALLAN_MASTER_EXPORT
				public static final String USP_GET_PROCESSING_MASTER_EXPORT="USP_GET_PROCESSING_MASTER_EXPORT";
				public static final String GET_PROCESSING_MASTER_EXPORT="getprocessingmasterexport";
				
				
				//USP_GET_ALLCLIENT_MASTER
				public static final String USP_GET_PICKUP_DETAILS_FILTER ="USP_GET_PICKUP_DETAILS_FILTER";
				public static final String GET_PICKUP_DETAILS_FILTER ="getpickupdetailsfilter";
				
				//USP_GET_DETAILS_BY_QRCODE
				public static final String USP_GET_DETAILS_BY_QRCODE="USP_GET_DETAILS_BY_QRCODE";
				public static final String GET_DETAILS_BY_QRCODE="getdetailsbyqrcode";
				
				//USP_GET_DETAILS_BY_QRCODE
				public static final String USP_GET_DELIVERY_CHALLAN_DETAILS="USP_GET_DELIVERY_CHALLAN_DETAILS";
				public static final String GET_DELIVERY_CHALLAN_DETAILS="getdeliverychallandetails";
				
				//USP_GET_CHALLAN_MASTER_EXPORT
				public static final String USP_GET_STATUS_DETAILS_EXPORT="USP_GET_STATUS_DETAILS_EXPORT";
				public static final String GET_STATUS_DETAILS_EXPORT="getstatusdetailsexport";
				
				// USP_GET_RECEIVED_DETAILS
				public static final String USP_GET_RECEIVED_DETAILS ="USP_GET_RECEIVED_DETAILS ";
				public static final String GET_RECEIVED_DETAILS ="getreceiveddetails";
				
				
				// USP_GET_RECEIVED_DETAILS
				public static final String USP_GET_RECEIVE_ITEM_DETAILS ="USP_GET_RECEIVE_DETAILS ";
				public static final String GET_RECEIVE_ITEM_DETAILS ="getreceiveitemdetails";
				
				// USP_UPDATE_RECEIVE_ITEM_DETAILS
				public static final String USP_UPDATE_RECEIVE_ITEM_DETAILS ="USP_UPDATE_RECEIVE_ITEM_DETAILS ";
				public static final String UPDATE_RECEIVE_ITEM_DETAILS ="updatereceiveitemdetails";
				
				// USP_UPDATE_RECEIVE_ITEM_DETAILS
				public static final String USP_INSERT_UPDATE_SOCITY ="USP_INSERT_UPDATE_SOCITY ";
				public static final String INSERT_UPDATE_SOCITY ="insertupdatesocity";
				
//				USP_GET_ROLE_USERROLE_SERVICE_STEPS
				public static final String USP_GET_ROLE_USERROLE_SERVICE_STEPS = "USP_GET_ROLE_USERROLE_SERVICE_STEPS";
				public static final String USERROLEE_PERMISSION_REQ_MODEL = "USERROLE_PERMISSION_REQ_MODEL";
				public static final String GET_ROLE_USERROLE_SERVICE_STEPS= "getroleuseroleservicesteps";
				
				// USP_GET_SOCIETY_DETAILS
				public static final String USP_GET_SOCIETY_DETAILS ="USP_GET_RECEIVE_DETAILS ";
				public static final String GET_SOCIETY_DETAILS ="getsocietydetails";
				
				// USP_UPDATE_SOCIETY_DETAILS
				public static final String USP_UPDATE_SOCIETY_DETAILS ="USP_UPDATE_SOCIETY_DETAILS ";
				public static final String UPDATE_SOCIETY_DETAILS ="updatesocietydetails";
				
				//USP_GET_SOCIETY_DETAILS_EXPORT
				public static final String USP_GET_SOCIETY_DETAILS_EXPORT="USP_GET_SOCIETY_DETAILS_EXPORT";
				public static final String GET_SOCIETY_DETAILS_EXPORT="getsocietydetailsexport";
				
				//USP_GET_RECEIVED_DETAILS_EXPORT
				public static final String USP_GET_RECEIVED_DETAILS_EXPORT="USP_GET_RECEIVED_DETAILS_EXPORT";
				public static final String GET_RECEIVED_DETAILS_EXPORT="getreceiveddetailsexport";
				
				//USP_GET_RECEIVE_DETAILS_EXPORT
				public static final String USP_GET_RECEIVE_DETAILS_EXPORT="USP_GET_RECEIVE_DETAILS_EXPORT";
				public static final String GET_RECEIVE_DETAILS_EXPORT="getreceivedetailsexport";
				
				//USP_GET_MANAGE_INVOICE
				public static final String USP_GET_MANAGE_INVOICE="USP_GET_MANAGE_INVOICE";
				public static final String GET_MANAGE_INVOICE="getmanageinovice";
				
				//USP_GET_MANAGE_INVOICE_EXPORT
				public static final String USP_GET_MANAGE_INVOICE_EXPORT="USP_GET_MANAGE_INVOICE_EXPORT";
				public static final String GET_MANAGE_INVOICE_EXPORT="getmanageinvoiceexport";
				
				//USP_GET_PAYMENT_STATUS
				public static final String USP_GET_PAYMENT_STATUS="USP_GET_PAYMENT_STATUS";
				public static final String GET_PAYMENT_STATUS="getpaymentstatus";
				
				//USP_UPDATE_CASH_RECEIVE_ITEM_DETAILS
				
				public static final String USP_UPDATE_CASH_RECEIVE_ITEM_DETAILS ="USP_UPDATE_CASH_RECEIVE_ITEM_DETAILS ";
				public static final String UPDATE_CASH_RECEIVE_ITEM_DETAILS ="updatecashreceivedetails";
				
				// USP_GET_CASH_RECEIVED_DETAILS
				public static final String USP_GET_CASH_RECEIVED_DETAILS ="USP_GET_CASH_RECEIVED_DETAILS ";
				public static final String GET_CASH_RECEIVED_DETAILS ="getcashreceiveddetails";
				
				// USP_GET_CASH_RECEIVE_DETAILS
				public static final String USP_GET_CASH_RECEIVE_DETAILS ="USP_GET_CASH_RECEIVE_DETAILS ";
				public static final String GET_CASH_RECEIVE_DETAILS ="getcashreceivedetails";
				
				//USP_GET_PAYMENT_STATUS_DETAILS_EXPORT
				public static final String USP_GET_PAYMENT_STATUS_DETAILS_EXPORT="USP_GET_PAYMENT_STATUS_DETAILS_EXPORT";
				public static final String GET_PAYMENT_STATUS_DETAILS_EXPORT="getpaymentstatusdetailsexport";
				
				//USP_GET_CASH_RECEIVE_DETAILS_EXPORT
				public static final String USP_GET_CASH_RECEIVE_DETAILS_EXPORT="USP_GET_CASH_RECEIVE_DETAILS_EXPORT";
				public static final String GET_CASH_RECEIVE_DETAILS_EXPORT="getcashreceivedetailsexport";
				
				//USP_GET_CASH_RECEIVED_DETAILS_EXPORT
				public static final String USP_GET_CASH_RECEIVED_DETAILS_EXPORT="USP_GET_CASH_RECEIVED_DETAILS_EXPORT";
				public static final String GET_CASH_RECEIVED_DETAILS_EXPORT="getcashreceiveddetailsexport";
				
				// USP_INSERT_UPDATE_WALLET_CONFIGURATION
				public static final String USP_INSERT_UPDATE_WALLET_CONFIGURATION ="USP_INSERT_UPDATE_WALLET_CONFIGURATION ";
				public static final String INSERT_UPDATE_WALLET_CONFIGURATION ="insertupdatewalletconfiguration";
				
				// USP_GET_SOCIETY_DETAILS
				public static final String USP_GET_WALLET_CONFIGURATION ="USP_GET_WALLET_CONFIGURATION ";
				public static final String GET_WALLET_CONFIGURATION ="getwalletconfiguration";
				
				// USP_UPDATE_SOCIETY_DETAILS
				public static final String USP_UPDATE_WALLET_CONFIGURATION ="USP_UPDATE_WALLET_CONFIGURATION ";
				public static final String UPDATE_WALLET_CONFIGURATION ="updatewalletconfiguration";
				
				//USP_GET_SOCIETY_DETAILS_EXPORT
				public static final String USP_GET_WALLET_CONFIGURATION_EXPORT="USP_GET_WALLET_CONFIGURATION_EXPORT";
				public static final String GET_WALLET_CONFIGURATION_EXPORT="getwalletconfigurationexport";
				
				// USP_GET_WALLET_DETAILS_LIST_EXPORT
				public static final String USP_GET_WALLET_DETAILS_LIST_EXPORT ="USP_GET_WALLET_DETAILS_LIST_EXPORT ";
				public static final String GET_WALLET_DETAILS_LIST_EXPORT ="getwalletDetailsListExport";
				
				//USP_GET_WALLET_DETAILS_LIST
				public static final String USP_GET_WALLET_DETAILS_LIST="USP_GET_WALLET_DETAILS_LIST";
				public static final String GET_WALLET_DETAILS_LIST="getwalletDetailsList";
				
				//USP_INSERT_UPDATE_CUST_INFO
				public static final String USP_INSERT_UPDATE_CUST_INFO="USP_INSERT_UPDATE_CUST_INFO";
				public static final String INSERT_UPDATE_CUST_INFO="insertupdateCustInfo";
				
				//USP_GET_AUTOMATIC_PROCESS_DETAILS
				public static final String USP_GET_AUTOMATIC_PROCESS_DETAILS="USP_GET_AUTOMATIC_PROCESS_DETAILS";
				public static final String GET_AUTOMATIC_PROCESS_DETAILS="getautomaticprocessdetails";
				
				// USP_INSERT_UPDATE_PROCESS_STATUS
				public static final String USP_INSERT_UPDATE_AUTOMATIC_PROCESS_STATUS ="USP_INSERT_UPDATE_AUTOMATIC_PROCESS_STATUS ";
				public static final String INSERT_UPDATE_AUTOMATIC_PROCESS_STATUS ="insertupdateautomaticprocessingstatus";
				
				// USP_GET_CUST_INFO_DETAILS_EXPORT
				public static final String USP_GET_CUST_INFO_DETAILS_EXPORT ="USP_GET_CUST_INFO_DETAILS_EXPORT ";
				public static final String GET_CUST_INFO_DETAILS_EXPORT ="getcustInfoDetailsExport";
				
				//USP_GET_STAIN_MASTERS_NEW
				public static final String USP_GET_STAIN_MASTERS_NEW="USP_GET_STAIN_MASTERS_NEW";
				public static final String GET_STAIN_MASTERS_NEW="getstainmasternew";
				
				//USP_GET_STAIN_MASTERS_NEW
				public static final String USP_GET_DAMAGE_MASTERS_NEW="USP_GET_DAMAGE_MASTERS_NEW";
				public static final String GET_DAMAGE_MASTERS_NEW="getdamagemasternew";
				
				// USP_GET_COMPLAINTS_DETAILS
				public static final String USP_GET_COMPLAINTS_DETAILS ="USP_GET_COMPLAINTS_DETAILS ";
				public static final String GET_COMPLAINTS_DETAILS ="getcomplaintsdetails";
				
				// USP_GET_REFUND_DETAILS
				public static final String USP_GET_REFUND_DETAILS ="USP_GET_REFUND_DETAILS ";
				public static final String GET_REFUND_DETAILS ="getrefunddetails";
				
				// USP_INSERT_UPDATE_RIDER_INFO
				public static final String USP_INSERT_UPDATE_RIDER_INFO ="USP_INSERT_UPDATE_RIDER_INFO ";
				public static final String INSERT_UPDATE_RIDER_INFO ="insertupdateRiderInfo";
				
				// USP_GET_RIDER_INFO_EXPORT
				public static final String USP_GET_RIDER_INFO_EXPORT ="USP_GET_RIDER_INFO_EXPORT ";
				public static final String GET_RIDER_INFO_EXPORT ="getRiderinfoExport";
				
				// USP_GET_REFUND_DETAILS
				public static final String USP_GET_CALL_HESTORY_DETAILS ="USP_GET_CALL_HESTORY_DETAILS ";
				public static final String GET_CALL_HESTORY_DETAILS ="getcallhestorydetails";
				
				// USP_INSERT_UPDATE_RIDER_INFO
				public static final String USP_INSERT_COMPLAINTS_DETAILS ="USP_INSERT_COMPLAINTS_DETAILS ";
				public static final String INSERT_COMPLAINTS_DETAILS ="insercomplaintsdetails";
				
				// USP_GET_CLOSED_COMPLAINTS_DETAILS
				public static final String USP_GET_CLOSED_COMPLAINTS_DETAILS ="USP_GET_CLOSED_COMPLAINTS_DETAILS";
				public static final String GET_CLOSED_COMPLAINTS_DETAILS ="getclosedcomplaintsdetails";
				
				// USP_INSERT_REFUND
				public static final String USP_INSERT_REFUND ="USP_INSERT_REFUND ";
				public static final String INSERT_REFUND ="insertrefund";
				
				// USP_GET_DETAILS_TO_REFUND
				public static final String USP_GET_DETAILS_TO_REFUND ="USP_GET_DETAILS_TO_REFUND ";
				public static final String GET_DETAILS_TO_REFUND ="getdetailstorefund";
				
				// USP_GET_REFUND_MASTER
				public static final String USP_GET_REFUND_MASTER ="USP_GET_REFUND_MASTER ";
				public static final String GET_REFUND_MASTER ="getrefundmaster";
				
				//USP_GET_REFUND_DETAILS_EXPORT
				public static final String USP_GET_REFUND_DETAILS_EXPORT="USP_GET_REFUND_DETAILS_EXPORT";
				public static final String GET_REFUND_DETAILS_EXPORT="getrefunddetailsexport";
				
				//USP_GET_CLOSED_COMPLAINTS_DETAILS_EXPORT
				public static final String USP_GET_CLOSED_COMPLAINTS_DETAILS_EXPORT="USP_GET_CLOSED_COMPLAINTS_DETAILS_EXPORT";
				public static final String GET_CLOSED_COMPLAINTS_DETAILS_EXPORT="getclosedcomplaintsdetailsexport";
				
				//USP_GET_CLOSED_COMPLAINTS_DETAILS_EXPORT
				public static final String USP_GET_COMPLAINTS_DETAILS_EXPORT="USP_GET_COMPLAINTS_DETAILS_EXPORT";
				public static final String GET_COMPLAINTS_DETAILS_EXPORT="getcomplaintsdetailsexport";
				
				
				// USP_GET_REFUNDED_DETAILS
				public static final String USP_GET_REFUNDED_DETAILS ="USP_GET_REFUNDED_DETAILS ";
				public static final String GET_REFUNDED_DETAILS ="getrefundeddetails";

				//USP_GET_REFUNDED_DETAILS_EXPORT
				public static final String USP_GET_REFUNDED_DETAILS_EXPORT="USP_GET_REFUNDED_DETAILS_EXPORT";
				public static final String GET_REFUNDED_DETAILS_EXPORT="getrefundeddetailsexport";
				
				// USP_GET_TRACK_RIDERS_DETAILS
				public static final String USP_GET_TRACK_RIDERS_DETAILS ="USP_GET_TRACK_RIDERS_DETAILS ";
				public static final String GET_TRACK_RIDERS_DETAILS ="gettrackriderdetails";
				
				// USP_GET_TRACK_RIDERS_DETAILS
				public static final String USP_GET_APPORVEL_DETAILS ="USP_GET_APPORVEL_DETAILS ";
				public static final String GET_APPORVEL_DETAILS ="getapporveldetails";
				
				// USP_GET_DETAILS_TO_REFUND
				public static final String USP_GET_APPORVEL_ACTION ="USP_GET_APPORVEL_ACTION ";
				public static final String GET_APPORVEL_ACTION ="getapporvelsaction";
				
				// USP_GET_TRACK_RIDERS_EXPORT
				public static final String USP_GET_TRACK_RIDERS_EXPORT ="USP_GET_TRACK_RIDERS_EXPORT ";
				public static final String GET_TRACK_RIDERS_EXPORT ="gettrackriderexport";
				
				// USP_GET_WEB_DELIVERY_SLOTS
				public static final String USP_GET_WEB_DELIVERY_SLOTS ="USP_GET_WEB_DELIVERY_SLOTS ";
				public static final String GET_WEB_DELIVERY_SLOTS ="getwebdeliveryslots";
				
				// USP_GET_QRCODE_DETAILS
				public static final String USP_GET_QRCODE_DETAILS ="USP_GET_QRCODE_DETAILS ";
				public static final String GET_QRCODE_DETAILS ="getqrcodedetails";
				
				public static final String IMAGE_UPLOAD ="imageupload";
				
				//USP_GET_APPORVEL_DETAILS_EXPORT
				public static final String USP_GET_APPORVEL_DETAILS_EXPORT="USP_GET_APPORVEL_DETAILS_EXPORT";
				public static final String GET_APPORVEL_DETAILS_EXPORT="getapporveldetailsexport";
				
				//USP_GET_COLOUR_MASTER_NEW
				public static final String USP_GET_COLOUR_MASTER_NEW="USP_GET_COLOUR_MASTER_NEW";
				public static final String GET_COLOUR_MASTER_NEW="getcolourmasternew";
				
				//USP_GET_INSERT_UPDATE_BRAND_MASTER
				public static final String USP_GET_INSERT_UPDATE_BRAND_MASTER="USP_GET_INSERT_UPDATE_BRAND_MASTER";
				public static final String GET_INSERT_UPDATE_BRAND_MASTER="getbrandmasternew";
				
				//USP_GET_INSERT_UPDATE_COMPANY_MASTER
				public static final String USP_GET_INSERT_UPDATE_COMPANY_MASTER="USP_GET_INSERT_UPDATE_COMPANY_MASTER";
				public static final String GET_INSERT_UPDATE_COMPANY_MASTER="getcompanymasternew";
				
				// USP_GET_DAY_MASTER
				public static final String USP_GET_DAY_MASTER ="USP_GET_DAY_MASTER ";
				public static final String GET_DAY_MASTER ="getdaymaster";
				
				//USP_GET_INSERT_UPDATE_ITEM_MASTER
				public static final String USP_GET_INSERT_UPDATE_ITEM_MASTER="USP_GET_INSERT_UPDATE_ITEM_MASTER";
				public static final String GET_INSERT_UPDATE_ITEM_MASTER="getitemmasternew";
				
				// USP_GET_ITEM_MASTER
				public static final String USP_GET_ITEM_MASTER ="USP_GET_ITEM_MASTER ";
				public static final String GET_ITEM_MASTER ="getitemmaster";
				
				//USP_INSERT_UPDATE_SERVICE_ITEM_MAPPING_NEW
				public static final String USP_INSERT_UPDATE_SERVICE_ITEM_MAPPING_NEW="USP_INSERT_UPDATE_SERVICE_ITEM_MAPPING_NEW";
				public static final String INSERT_UPDATE_SERVICE_ITEM_MAPPING_NEW="getserviceitemmapping";
				
				// USP_GET_COUNTRY_MASTER
				public static final String USP_GET_COUNTRY_MASTER ="USP_GET_COUNTRY_MASTER ";
				public static final String GET_COUNTRY_MASTER ="getcountrymaster";
				
				//USP_GET_INSERT_UPDATE_SERVICE_MASTER
				public static final String USP_GET_INSERT_UPDATE_SERVICE_MASTER="USP_GET_INSERT_UPDATE_SERVICE_MASTER";
				public static final String GET_INSERT_UPDATE_SERVICE_MASTER="getservicemasternew";
				
				//USP_GET_RESCHEDULE_AND_CANNCELLATION_DETAILS
				public static final String USP_GET_RESCHEDULE_AND_CANNCELLATION_DETAILS="USP_GET_RESCHEDULE_AND_CANNCELLATION_DETAILS";
				public static final String GET_RESCHEDULE_AND_CANNCELLATION_DETAILS="getrescheduleandcancellationdetails";
				
				//USP_INSERT_UPDATE_PICKUP_RESCHEDLUE_DETAILS
				public static final String USP_INSERT_UPDATE_PICKUP_RESCHEDLUE_DETAILS="USP_INSERT_UPDATE_PICKUP_RESCHEDLUE_DETAILS";
				public static final String INSERT_UPDATE_PICKUP_RESCHEDLUE_DETAILS="insertupdatepickuprescheduledetails";
				
				//USP_INSERT_UPDATE_DELIVERY_RESCHEDLUE_DETAILS
				public static final String USP_INSERT_UPDATE_DELIVERY_RESCHEDLUE_DETAILS="USP_INSERT_UPDATE_DELIVERY_RESCHEDLUE_DETAILS";
				public static final String INSERT_UPDATE_DELIVERY_RESCHEDLUE_DETAILS="insertupdatedeliveryrescheduledetails";
				
				//USP_GET_RESCHEDULE_DETAILS_BY_ORDERID
				public static final String USP_GET_RESCHEDULE_DETAILS_BY_ORDERID="USP_GET_RESCHEDULE_DETAILS_BY_ORDERID";
				public static final String GET_RESCHEDULE_DETAILS_BY_ORDERID="getrescheduledetailsbyorderid";
				
				//USP_INSERT_UPDATE_ASSIGN_DETAILS
				public static final String USP_INSERT_UPDATE_ASSIGN_DETAILS="USP_INSERT_UPDATE_ASSIGN_DETAILS";
				public static final String INSERT_UPDATE_ASSIGN_DETAILS="insertUpdateAssignDetails";
								
				//USP_GET_MANUAL_ASSIGN_DETAILS
				public static final String USP_GET_MANUAL_ASSIGN_DETAILS="USP_GET_MANUAL_ASSIGN_DETAILS";
				public static final String GET_MANUAL_ASSIGN_DETAILS="getManualAssignDetails";
	
				//USP_INSERT_SLOT
				public static final String USP_INSERT_SLOT="USP_INSERT_SLOT";
				public static final String INSERT_SLOT="insertslot";
				
				// USP_GET_ALL_CANCILATION_MASTER
				public static final String USP_GET_ALL_CANCILATION_MASTER ="USP_GET_ALL_CANCILATION_MASTER";
				public static final String GET_ALL_CANCILATION_MASTER ="getcancilationmaster";
				
				//USP_INSERT_UPDATE_RIDER_CANCILLATION
				public static final String USP_INSERT_UPDATE_RIDER_CANCILLATION="USP_INSERT_UPDATE_RIDER_CANCILLATION";
				public static final String INSERT_UPDATE_RIDER_CANCILLATION="insertupdateridercancilation";
				
				// USP_GET_STAIN_MASTER_EXPORT
				public static final String USP_GET_STAIN_MASTER_EXPORT ="USP_GET_STAIN_MASTER_EXPORT";
				public static final String GET_STAIN_MASTER_EXPORT ="getstainmasterexport";
				
				// USP_GET_SERVICE_MASTER_EXPORT
				public static final String USP_GET_SERVICE_MASTER_EXPORT ="USP_GET_SERVICE_MASTER_EXPORT";
				public static final String GET_SERVICE_MASTER_EXPORT ="getservicemasterexport";
				
				// USP_GET_SERVICE_ITEM_MAPPING_EXPORT
				public static final String USP_GET_SERVICE_ITEM_MAPPING_EXPORT ="USP_GET_SERVICE_ITEM_MAPPING_EXPORT";
				public static final String GET_SERVICE_ITEM_MAPPING_EXPORT ="getserviceitemmappingmasterexport";
				
				// USP_GET_ITEM_MASTER_EXPORT
				public static final String USP_GET_ITEM_MASTER_EXPORT ="USP_GET_ITEM_MASTER_EXPORT";
				public static final String GET_ITEM_MASTER_EXPORT ="getitemmasterexport";
				
				// USP_GET_DAMAGE_MASTER_EXPORT
				public static final String USP_GET_DAMAGE_MASTER_EXPORT ="USP_GET_DAMAGE_MASTER_EXPORT";
				public static final String GET_DAMAGE_MASTER_EXPORT ="getdamagemasterexport";
				
				// USP_GET_COLOUR_MASTER_EXPORT
				public static final String USP_GET_COLOUR_MASTER_EXPORT ="USP_GET_COLOUR_MASTER_EXPORT";
				public static final String GET_COLOUR_MASTER_EXPORT ="getcolourmasterexport";
				
				// USP_GET_BRAND_MASTER_EXPORT
				public static final String USP_GET_BRAND_MASTER_EXPORT ="USP_GET_BRAND_MASTER_EXPORT";
				public static final String GET_BRAND_MASTER_EXPORT ="getbrandmasterexport";
				
				// USP_GET_MANUAL_ASSIGN_EXPORT
				public static final String USP_GET_MANUAL_ASSIGN_EXPORT ="USP_GET_MANUAL_ASSIGN_EXPORT";
				public static final String GET_MANUAL_ASSIGN_EXPORT ="getmanualassignexport";
				
				// USP_GET_WC_DURATION_MASTER
				public static final String USP_GET_WC_DURATION_MASTER ="USP_GET_WC_DURATION_MASTER";
				public static final String GET_WC_DURATION_MASTER ="getdurationmaster";
				
				// USP_INSERT_UPDATE_SLOT_MASTER_NEW
				public static final String USP_INSERT_UPDATE_SLOT_MASTER_NEW ="USP_INSERT_UPDATE_SLOT_MASTER_NEW";
				public static final String INSERT_UPDATE_SLOT_MASTER_NEW ="insertupdateslotmasternew";
				
				// USP_GET_SLOT_MASTER_EXPORT
				public static final String USP_GET_SLOT_MASTER_EXPORT ="USP_GET_SLOT_MASTER_EXPORT";
				public static final String GET_SLOT_MASTER_EXPORT ="getslotmasterexport";
				
				// USP_GET_RESCHEDULE_AND_CANNCELLATION_DETAILS_EXPORT
				public static final String USP_GET_RESCHEDULE_AND_CANNCELLATION_DETAILS_EXPORT ="USP_GET_RESCHEDULE_AND_CANNCELLATION_DETAILS_EXPORT";
				public static final String GET_RESCHEDULE_AND_CANNCELLATION_DETAILS_EXPORT ="getrescheduleandcanncellationexport";
				
				// USP_GET_SLOT_COUNT
				public static final String USP_GET_SLOT_COUNT ="USP_GET_SLOT_COUNT";
				public static final String GET_SLOT_COUNT ="getslotcountt";
				
				// USP_GET_BRAND_MASTER
				public static final String USP_GET_BRAND_MASTER ="USP_GET_BRAND_MASTER";
				public static final String GET_BRAND_MASTER ="getbrandmaster";
				
				// USP_GET_EMAIL_PEOMOTIONAL_TEMPLATE_MASTER
				public static final String USP_GET_EMAIL_PEOMOTIONAL_TEMPLATE_MASTER ="USP_GET_EMAIL_PEOMOTIONAL_TEMPLATE_MASTER";
				public static final String GET_EMAIL_PEOMOTIONAL_TEMPLATE_MASTER ="getemailpromotionaltemplatemaster";
				
				// USP_GET_EMAIL_TRANSACTIONAL_TEMPLATE_MASTER
				public static final String USP_GET_EMAIL_TRANSACTIONAL_TEMPLATE_MASTER ="USP_GET_EMAIL_TRANSACTIONAL_TEMPLATE_MASTER";
				public static final String GET_EMAIL_TRANSACTIONAL_TEMPLATE_MASTER ="getemailtransactionaltemplatemaster";
				
				//USP_INSERT_EMAIL_TEMPLATE_DETAILS_TRANSACTIONAL
				public static final String USP_INSERT_EMAIL_TEMPLATE_DETAILS_TRANSACTIONAL="USP_INSERT_EMAIL_TEMPLATE_DETAILS_TRANSACTIONAL";
				public static final String INSERT_EMAIL_TEMPLATE_DETAILS_TRANSACTIONAL="insertemailtemplatedetailstransactional";
				
				//USP_INSERT_EMAIL_TEMPLATE_DETAILS_PEOMOTIONAL
				public static final String USP_INSERT_EMAIL_TEMPLATE_DETAILS_PEOMOTIONAL="USP_INSERT_EMAIL_TEMPLATE_DETAILS_PEOMOTIONAL";
				public static final String INSERT_EMAIL_TEMPLATE_DETAILS_PEOMOTIONAL="insertemailtemplatedetailspromotional";
				
				// USP_GET_EMAIL_CATEGORY_MASTER
				public static final String USP_GET_EMAIL_CATEGORY_MASTER ="USP_GET_EMAIL_CATEGORY_MASTER";
				public static final String GET_EMAIL_CATEGORY_MASTER ="getemailcategorymaster";
				
				// USP_GET_EMAIL_CATEGORY_DETAILS
				public static final String USP_GET_EMAIL_CATEGORY_DETAILS ="USP_GET_EMAIL_CATEGORY_DETAILS";
				public static final String GET_EMAIL_CATEGORY_DETAILS ="getemailcategorydetails";
				
				// USP_GET_EMAIL_TEMPLATE_DETAILS
				public static final String USP_GET_EMAIL_TEMPLATE_DETAILS ="USP_GET_EMAIL_TEMPLATE_DETAILS";
				public static final String GET_EMAIL_TEMPLATE_DETAILS ="getemailtempaltedetails";
				
				// USP_INSERT_UPDATE_EMAIL_TEMPLATE_DETAILS
				public static final String USP_INSERT_UPDATE_EMAIL_TEMPLATE_DETAILS ="USP_INSERT_UPDATE_EMAIL_TEMPLATE_DETAILS";
				public static final String INSERT_UPDATE_EMAIL_TEMPLATE_DETAILS ="insertupdateemailtempaltedetails";
				
				
				// USP_GET_CONFIGURATION_DETAILS
				public static final String USP_GET_CONFIGURATION_DETAILS ="USP_GET_CONFIGURATION_DETAILS";
				public static final String GET_CONFIGURATION_DETAILS ="getConfiguration";

				// USP_GET_BIRTHDAY_DETAILS
				public static final String USP_GET_BIRTHDAY_DETAILS ="USP_GET_BIRTHDAY_DETAILS";
				public static final String GET_BIRTHDAY_DETAILS ="getbirthdaydetails";
				
				// USP_GET_BIRTHDAY_DETAILS
				public static final String USP_GET_ANNIVERSARY_DETAILS ="USP_GET_ANNIVERSARY_DETAILS";
				public static final String GET_ANNIVERSARY_DETAILS ="getanniversarydetails";
				

				// USP_GET_NOTIFICATION_SEQUENCE_DETAILS
				public static final String USP_GET_NOTIFICATION_SEQUENCE_DETAILS ="USP_GET_NOTIFICATION_SEQUENCE_DETAILS ";
				public static final String GET_NOTIFICATION_SEQUENCE_DETAILS ="getnotificationsequencedetails";


				//USP_GET_NOTIFICATION_SEQUENCE_DETAILS_EXPORT
				public static final String USP_GET_NOTIFICATION_SEQUENCE_DETAILS_EXPORT="USP_GET_NOTIFICATION_SEQUENCE_DETAILS_EXPORT";
				public static final String GET_NOTIFICATION_SEQUENCE_DETAILS_EXPORT="getnotificationsequencedetailsexport";
				
				// USP_GET_GROOMING_STANDARDS_DETAILS
				public static final String USP_GET_GROOMING_STANDARDS_DETAILS ="USP_GET_GROOMING_STANDARDS_DETAILS ";
				public static final String GET_GROOMING_STANDARDS_DETAILS ="getgrommingstandardsdetails";
				
				// USP_INSERT_UPDATE_GROOMING_STANDARDS
				public static final String USP_INSERT_UPDATE_GROOMING_STANDARDS ="USP_INSERT_UPDATE_GROOMING_STANDARDS ";
				public static final String INSERT_UPDATE_GROOMING_STANDARDS ="insertupdategrommingstandards";
				
				// USP_GET_TRAINING_VIDEOS_DETAILS
				public static final String USP_GET_TRAINING_VIDEOS_DETAILS ="USP_GET_TRAINING_VIDEOS_DETAILS ";
				public static final String GET_TRAINING_VIDEOS_DETAILS ="getTrainingVideosDetails";
				
				// USP_INSERT_UPDATE_TRAINING_VIDEOS
				public static final String USP_INSERT_UPDATE_TRAINING_VIDEOS ="USP_INSERT_UPDATE_TRAINING_VIDEOS ";
				public static final String INSERT_UPDATE_TRAINING_VIDEOS ="insertupdateTrainingVideos";
				
				// USP_GET_GROOMING_STANDARDS_DETAILS_EXPORTS
				public static final String USP_GET_GROOMING_STANDARDS_DETAILS_EXPORTS ="USP_GET_GROOMING_STANDARDS_DETAILS_EXPORTS ";
				public static final String GET_GROOMING_STANDARDS_DETAILS_EXPORTS ="getgrommingstandardsdetailsExports";
				
				// USP_GET_TRAINING_VIDEOS_DETAILS_EXPORTS
				public static final String USP_GET_TRAINING_VIDEOS_DETAILS_EXPORTS ="USP_GET_TRAINING_VIDEOS_DETAILS_EXPORTS ";
				public static final String GET_TRAINING_VIDEOS_DETAILS_EXPORTS ="getTrainingVideosDetailsExports";
				
				//usp_GetChatUserList
				public static final String usp_GetChatUserList="usp_GetChatUserList";
				public static final String GetChatUserList="getChatUserList";
				
				//usp_GetLastMessage
				public static final String usp_GetLastMessage="usp_GetLastMessage";
				public static final String GetLastMessage="getlastmesssage";
				
				//usp_GetMessageHistory
				public static final String usp_GetMessageHistory="usp_GetMessageHistory";
				public static final String GetMessageHistory="getmessageHistory";
				
				//usp_UpdateMessageStatus
				public static final String usp_UpdateMessageStatus="usp_UpdateMessageStatus";
				public static final String UpdateMessageStatus="getupdateMessageStatus";
				
				//USP_INSERT_UPDATE_APP_QRCODE_DETAILS
				public static final String USP_INSERT_UPDATE_APP_QRCODE_DETAILS="USP_INSERT_UPDATE_APP_QRCODE_DETAILS";
				public static final String INSERT_UPDATE_APP_QRCODE_DETAILS = "insertUpdateAppQRcodeDetails";	
				
				//USP_INSERT_UPDATE_ORDER_SUBMIT_DETAIL
				public static final String USP_INSERT_UPDATE_ORDER_SUBMIT_DETAILS="USP_INSERT_UPDATE_ORDER_SUBMIT_DETAILS";
				public static final String INSERT_UPDATE_ORDER_SUBMIT_DETAILS = "insertUpdateOrderSubmitDetails";	 
	 
				//USP_GET_WC_SOCIETY_MASTER
				public static final String USP_GET_WC_SOCIETY_MASTER="USP_GET_WC_SOCIETY_MASTER";
				public static final String GET_WC_SOCIETY_MASTER = "getWcSocietyMaster";
				
				//USP_INSERT_UPDATE_WEB_QRCODE_DETAILS
				public static final String USP_INSERT_UPDATE_WEB_QRCODE_DETAILS="USP_INSERT_UPDATE_WEB_QRCODE_DETAILS";
				public static final String INSERT_UPDATE_WEB_QRCODE_DETAILS = "insertUpdateWebQrcodeDetails";	 
				
				//USP_INSERT_UPDATE_WEB_SUBMIT_DETAILS
				public static final String USP_INSERT_UPDATE_WEB_SUBMIT_DETAILS="USP_INSERT_UPDATE_WEB_SUBMIT_DETAILS";
				public static final String INSERT_UPDATE_WEB_SUBMIT_DETAILS = "insertUpdateWebSubmitDetails";	
				
				//USP_GET_WC_SERVICE_TYPE
				public static final String USP_GET_WC_SERVICE_TYPE="USP_GET_WC_SERVICE_TYPE";
				public static final String GET_WC_SERVICE_TYPE = "getWcServiceType";
				
				//USP_GET_AGE_RANGE_MASTER
				public static final String USP_GET_AGE_RANGE_MASTER="USP_GET_AGE_RANGE_MASTER";
				public static final String GET_AGE_RANGE_MASTER = "getrangemaster";
				
				//USP_GET_STEPS_MASTER
				public static final String USP_GET_STEPS_MASTER="USP_GET_STEPS_MASTER";
				public static final String GET_STEPS_MASTER = "getStepsMaster";
				
				//USP_GET_INSERT_UPDATE_STEPS_MASTER
				public static final String USP_GET_INSERT_UPDATE_STEPS_MASTER="USP_GET_INSERT_UPDATE_STEPS_MASTER";
				public static final String GET_INSERT_UPDATE_STEPS_MASTER = "getinsertupdatestepsmaster";
				

				//USP_INSERT_MESSAGE_DETAILS
				public static final String USP_INSERT_MESSAGE_DETAILS="USP_INSERT_MESSAGE_DETAILS";
				public static final String INSERT_MESSAGE_DETAILS = "insertmessagedetails";

				//USP_SERVICE_STEPS_MASTER 
				public static final String USP_SERVICE_STEPS_MASTER="USP_SERVICE_STEPS_MASTER";
				public static final String SERVICE_STEPS_MASTER = "getServiceStepsMaster";
				
				//USP_GET_STEP_MASTER_REPORT 
				public static final String USP_GET_STEP_MASTER_REPORT="USP_GET_STEP_MASTER_REPORT";
				public static final String GET_STEP_MASTER_REPORT = "getstepmasterreport";
				
				//USP_GET_SERVICE_STEP_MAPPING_EXPORT
				public static final String USP_GET_SERVICE_STEP_MAPPING_EXPORT="USP_GET_SERVICE_STEP_MAPPING_EXPORT";
				public static final String GET_SERVICE_STEP_MAPPING_EXPORT = "getservicestepmappingexport";

				
				//USP_UPDATE_ITEMWISE_IMAGE_UPLOAD
				public static final String USP_UPDATE_ITEMWISE_IMAGE_UPLOAD="USP_UPDATE_ITEMWISE_IMAGE_UPLOAD";
				public static final String UPDATE_ITEMWISE_IMAGE_UPLOAD = "updateitemwiseimageupload";
				
				//USP_INSERT_UPDATE_ORDER_APPROVALS_DETAILS
				public static final String USP_INSERT_UPDATE_ORDER_APPROVALS_DETAILS="USP_INSERT_UPDATE_ORDER_APPROVALS_DETAILS";
				public static final String INSERT_UPDATE_ORDER_APPROVALS_DETAILS = "insertUpdateOrderApprovelsDetails";
				
				//USP_GET_CUSTOMER_MASTER 
				public static final String USP_GET_CUSTOMER_MASTER="USP_GET_CUSTOMER_MASTER";
				public static final String GET_CUSTOMER_MASTER = "getCustomerMaster";
				
				//USP_GET_ORDER_WISE_MASTER 
				public static final String USP_GET_ORDER_WISE_MASTER="USP_GET_ORDER_WISE_MASTER";
				public static final String GET_ORDER_WISE_MASTER = "getOrderWiseMaster";

}


