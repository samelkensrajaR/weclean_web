package com.isolve.common.service;

import com.isolve.common.model.RequestModel;
import com.isolve.common.model.ResponseModel;

public interface IMasterService {

	public ResponseModel getStateMaster(RequestModel requestModel);

	public ResponseModel getCityMaster(RequestModel requestModel);

	ResponseModel getAddressType();

	ResponseModel getPickupType();

	ResponseModel getAccountType(RequestModel requestModel);

	public ResponseModel getTaskType(RequestModel requestModel);

	public ResponseModel decrypt(RequestModel requestModel);

	public ResponseModel encrypt(String requestModel);

	public ResponseModel getGenderDetails();

	public ResponseModel getTitleMaster();

	ResponseModel getLanguageMaster(RequestModel requestModel);

	public ResponseModel getUserType(RequestModel requestModel);

	public ResponseModel getRole(RequestModel requestModel);

}
