package com.isolve.web.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class RoleActionForSpecificIDResModel implements Serializable
{/**
	 * 
	 */
	private static final long serialVersionUID = 869899951090007209L;
	@Id
	private Integer targetactionid;
	private String name;
	private String description;
	private Integer lc_ta_targetid;

}
