package com.isolve.common.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class ParamedicDetailsResponse 
{
	@Id
	private Long LC_MU_USER_ID;
	private Integer LC_MU_USER_TITLE_ID;
	private String LC_MU_USER_FIRST_NAME;
	private String LC_MU_USER_MID_NAME;
	private String LC_MU_USER_LAST_NAME;
	private String LC_MU_USER_PHONENO;
	private String LC_MU_USER_EMAILID;
	private Date LC_MU_USER_DOB;
	private Date LC_MU_USER_DOJ;
	private Integer LC_MU_USER_GEN_ID;
	private String LC_MU_USER_CURRENT_ADDRESS;
	private String LC_MU_USER_PERMANENT_ADDRESS;
	private Integer LC_MU_USER_STATUS;
	private String LC_MU_USER_PHOTO;
	private Long LC_MU_BRANCH_ID;
	private Long LC_MU_REGION_ID;
	private String LC_MU_USER_NAME;
	private String LC_MU_USER_IMEI_NUMBER;
	private String LC_MU_USER_UDID_NUMBER;
	private String LC_MU_USER_PHONE_CODE;
	private Long LC_MU_USER_TYPE_ID;
	private Long LC_MU_USER_DESIGNATION_ID;
	private String LC_MU_USER_ROLEID;
	private String LC_MU_USER_CREATEDBY;
	private String LC_MU_USER_CREATEDDATE;
	private String LC_MU_USER_UPDATEDBY;
	private Date LC_MU_USER_UPDATEDDATE;
	private String LC_MU_USER_PASSWORD;
	private String LC_MU_USER_PIN;
	
	
}
