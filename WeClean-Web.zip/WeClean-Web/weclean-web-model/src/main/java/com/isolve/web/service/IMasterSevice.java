package com.isolve.web.service;

import javax.validation.Valid;

import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RiderTimeSlotAvailabilityReqModel;
import com.isolve.web.model.StepsMasterNewRequestModel;

public interface IMasterSevice {

	ResponseModel insertupdatepincodemapping(RequestModel requestModel);

	ResponseModel getPinCodeMaster(RequestModel requestModel);

	ResponseModel insertupdatevendorvisittimemapping(RequestModel requestModel);

	ResponseModel getVendorVisitTime(RequestModel requestModel);

	ResponseModel getParamedicDetails(RequestModel requestModel);
	
	ResponseModel vendorDetailsMaster(RequestModel requestModel);

	ResponseModel getcitystatecenterbyuserid(RequestModel requestModel);

	ResponseModel insertUpdateCenterMaster(RequestModel requestModel);

	ResponseModel insertUpdateVisitTimeMaster(RequestModel requestModel);

	ResponseModel getApproveStatus();

	ResponseModel getRegion();

	ResponseModel getManagement();

	ResponseModel insertUpdateTestProductMapping(RequestModel requestModel);

	ResponseModel getPreconditionMaster();

	ResponseModel getPaymentStatus(RequestModel requestModel);

	ResponseModel getallclientmaster();

	ResponseModel getallstatusmaster();

	ResponseModel getallinvoicetracking(RequestModel requestModel);

	ResponseModel getapprovedstatusmaster();

	ResponseModel getaccounttypemaster();

	ResponseModel getQuotationdetails(RequestModel requestModel);

	ResponseModel getInvoiceStatusMaster();

	ResponseModel getWebDashBoardDetails(RequestModel requestModel);

	ResponseModel getsalesWebDashBoardDetails(RequestModel requestModel);

	ResponseModel insertupdatesaleshospitalmapping(RequestModel requestModel);

	ResponseModel getsalesusers(RequestModel requestModel);

	ResponseModel insertupdatedoctordetails(RequestModel requestModel);

	ResponseModel insertupdatedoctorhospitalmapping(RequestModel requestModel);

	ResponseModel gethospitalwisestatecity(RequestModel requestModel);

	ResponseModel getProductForWeb();

	ResponseModel getallcleaningcategory();

	ResponseModel getallservicemaster();

	ResponseModel getcolourmaster();

	ResponseModel getdamagemaster();

	ResponseModel getstainmaster();

	ResponseModel getusermaster();

	ResponseModel getallitemmaster(RequestModel requestModel);



	ResponseModel getPickupDetails(RequestModel requestModel);

	ResponseModel insertUpdateOrderDetails(RequestModel requestModel);

	ResponseModel insertWebNewOrderDetails(RequestModel requestModel);

	ResponseModel getriderslotavailability(RequestModel requestModel);

	ResponseModel getchallantypemaster();

	ResponseModel getchallanmaster(RequestModel requestModel);

	ResponseModel getpickupdetailsbyitems(RequestModel requestModel);

	ResponseModel getchallanmasterexport(RequestModel requestModel);

	ResponseModel getprocessingmaster(RequestModel requestModel);

	ResponseModel getprocessdetailsbyitems(RequestModel requestModel);

	ResponseModel getprocessstepsbyserviceid(RequestModel requestModel);

	ResponseModel insertupdateprocessingstatus(RequestModel requestModel);

	

	ResponseModel getdispatchdetailss(RequestModel requestModel);

	ResponseModel insertupdatedispatchdetails(RequestModel requestModel);

	ResponseModel getstatusdetails(RequestModel requestModel);

	ResponseModel getprocessingmasterexport(RequestModel requestModel);

	ResponseModel getpickupdetailsfilter();

	ResponseModel getdetailsbyqrcode(RequestModel requestModel);

	ResponseModel getdeliverychallandetails(RequestModel requestModel);

	ResponseModel getstatusdetailsexport(RequestModel requestModel);

	ResponseModel getreceiveddetails(RequestModel requestModel);

	ResponseModel getreceiveitemdetails(RequestModel requestModel);

	ResponseModel updatereceiveitemdetails(RequestModel requestModel);

	ResponseModel insertupdatesocity(RequestModel requestModel);

	ResponseModel getsocietydetails(RequestModel requestModel);

	ResponseModel updatesocietydetails(RequestModel requestModel);

	ResponseModel getsocietydetailsexport(RequestModel requestModel);

	ResponseModel getreceiveddetailsexport(RequestModel requestModel);

	ResponseModel getreceivedetailsexport(RequestModel requestModel);

	ResponseModel getmanageinovice(RequestModel requestModel);

	ResponseModel getmanageinvoiceexport(RequestModel requestModel);

	ResponseModel getpaymentstatus(RequestModel requestModel);

	ResponseModel updatecashreceivedetails(RequestModel requestModel);

	ResponseModel getcashreceiveddetails(RequestModel requestModel);

	ResponseModel getcashreceivedetails(RequestModel requestModel);

	ResponseModel getpaymentstatusdetailsexport(RequestModel requestModel);

	ResponseModel getcashreceivedetailsexport(RequestModel requestModel);

	ResponseModel getcashreceiveddetailsexport(RequestModel requestModel);

	ResponseModel insertupdatewalletconfiguration(RequestModel requestModel);

	ResponseModel getwalletconfiguration(RequestModel requestModel);

	ResponseModel updatewalletconfiguration(RequestModel requestModel);

	ResponseModel getwalletconfigurationexport(RequestModel requestModel);

	ResponseModel getwalletDetailsList(RequestModel requestModel);

	ResponseModel getwalletDetailsListExport();

	ResponseModel insertupdateCustInfo(RequestModel requestModel);

	ResponseModel getautomaticprocessdetails(RequestModel requestModel);

	ResponseModel insertupdateautomaticprocessingstatus(RequestModel requestModel);

	ResponseModel getcustInfoDetailsExport();

	ResponseModel getstainmasternew(RequestModel requestModel);

	ResponseModel getdamagemasternew(RequestModel requestModel);

	ResponseModel getcomplaintsdetails(RequestModel requestModel);

	ResponseModel getrefunddetails(RequestModel requestModel);

	ResponseModel insertupdateRiderInfo(RequestModel requestModel);

	ResponseModel getRiderinfoExport(RequestModel requestModel);

	ResponseModel getcallhestorydetails(RequestModel requestModel);

	ResponseModel insercomplaintsdetails(RequestModel requestModel);

	ResponseModel getclosedcomplaintsdetails(RequestModel requestModel);

	ResponseModel insertrefund(RequestModel requestModel);

	ResponseModel getdetailstorefund(RequestModel requestModel);

	ResponseModel getrefundmaster();

	ResponseModel getrefunddetailsexport(RequestModel requestModel);

	ResponseModel getclosedcomplaintsdetailsexport(RequestModel requestModel);

	ResponseModel getcomplaintsdetailsexport(RequestModel requestModel);

	ResponseModel getrefundeddetails(RequestModel requestModel);

	ResponseModel getrefundeddetailsexport(RequestModel requestModel);

	ResponseModel gettrackriderdetails(RequestModel requestModel);

	ResponseModel getapporveldetails(RequestModel requestModel);

	ResponseModel getapporvelsaction(RequestModel requestModel);

	ResponseModel gettrackriderexport(RequestModel requestModel);

	ResponseModel getdeliverymode(RequestModel requestModel);

	ResponseModel getwebdeliveryslots(RequestModel requestModel);

	ResponseModel getqrcodedetails(RequestModel requestModel);

	ResponseModel imageupload(RequestModel requestModel);

	ResponseModel getapporveldetailsexport(RequestModel requestModel);

	ResponseModel getcolourmasternew(RequestModel requestModel);

	ResponseModel getbrandmasternew(RequestModel requestModel);

	ResponseModel getcompanymasternew(RequestModel requestModel);

	ResponseModel getdaymaster();

	ResponseModel getitemmasternew(RequestModel requestModel);

	ResponseModel getitemmaster();

	ResponseModel getserviceitemmapping(RequestModel requestModel);

	ResponseModel getcountrymaster();

	ResponseModel getservicemasternew(RequestModel requestModel);

	ResponseModel getrescheduleandcancellationdetails(RequestModel requestModel);

	ResponseModel insertupdatepickuprescheduledetails(RequestModel requestModel);

	ResponseModel insertupdatedeliveryrescheduledetails(RequestModel requestModel);

	ResponseModel getrescheduledetailsbyorderid(RequestModel requestModel);

	ResponseModel insertUpdateAssignDetails(RequestModel requestModel);

	ResponseModel getManualAssignDetails(RequestModel requestModel);

	ResponseModel insertslot(RequestModel requestModel);

	ResponseModel getcancilationmaster();

	ResponseModel insertupdateridercancilation(RequestModel requestModel);

	ResponseModel getstainmasterexport();

	ResponseModel getservicemasterexport();

	ResponseModel getserviceitemmappingmasterexport();

	ResponseModel getitemmasterexport();

	ResponseModel getdamagemasterexport();

	ResponseModel getcolourmasterexport();

	ResponseModel getbrandmasterexport();

	ResponseModel getmanualassignexport(RequestModel requestModel);

	ResponseModel getdurationmaster();

	ResponseModel insertupdateslotmasternew(RequestModel requestModel);

	ResponseModel getslotmasterexport();

	ResponseModel getrescheduleandcanncellationexport(RequestModel requestModel);

	ResponseModel getslotcountt();

	ResponseModel getbrandmaster();

	ResponseModel getemailpromotionaltemplatemaster();

	ResponseModel getemailtransactionaltemplatemaster();

	ResponseModel insertemailtemplatedetailstransactional(RequestModel requestModel);

	ResponseModel insertemailtemplatedetailspromotional(RequestModel requestModel);

	ResponseModel getemailcategorymaster();

	ResponseModel getemailcategorydetails(RequestModel requestModel);

	ResponseModel getemailtempaltedetails(RequestModel requestModel);

	ResponseModel insertupdateemailtempaltedetails(RequestModel requestModel);

	ResponseModel getbirthdaydetails();

	ResponseModel getanniversarydetails();

	ResponseModel getnotificationsequencedetails(RequestModel requestModel);

	ResponseModel getnotificationsequencedetailsexport(RequestModel requestModel);

	ResponseModel getgrommingstandardsdetails(RequestModel requestModel);

	ResponseModel insertupdategrommingstandards(RequestModel requestModel);

	ResponseModel getChatUserList(RequestModel requestModel);

	ResponseModel getlastmesssage(RequestModel requestModel);

	ResponseModel getmessageHistory(RequestModel requestModel);

	ResponseModel getupdateMessageStatus(RequestModel requestModel);

	ResponseModel insertUpdateAppQRcodeDetails(RequestModel requestModel);

	ResponseModel insertUpdateOrderSubmitDetails(RequestModel requestModel);

	ResponseModel getWcSocietyMaster();

	ResponseModel insertUpdateWebQrcodeDetails(RequestModel requestModel);

	ResponseModel insertUpdateWebSubmitDetails(RequestModel requestModel);

	ResponseModel getWcServiceType();

	ResponseModel getrangemaster();

	ResponseModel getStepsMaster();

	ResponseModel getinsertupdatestepsmaster(RequestModel requestModel);

	ResponseModel insertmessagedetails(RequestModel requestModel);

	ResponseModel getServiceStepsMaster(RequestModel requestModel);

	ResponseModel getstepmasterreport();

	ResponseModel getservicestepmappingexport();

	ResponseModel updateitemwiseimageupload(RequestModel requestModel);

	ResponseModel insertUpdateOrderApprovelsDetails(RequestModel requestModel);

	ResponseModel getCustomerMaster();

	ResponseModel getOrderWiseMaster();



	

}
