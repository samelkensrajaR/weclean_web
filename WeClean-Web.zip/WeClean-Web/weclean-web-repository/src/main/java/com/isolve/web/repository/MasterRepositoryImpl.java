package com.isolve.web.repository;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.isolve.web.model.*;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.MyObject;
import com.isolve.web.utils.Utils;
import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;
import com.microsoft.sqlserver.jdbc.SQLServerException;

@Repository
public class MasterRepositoryImpl implements IMasterRepository {

	Logger log = LoggerFactory.getLogger(MasterRepositoryImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public ResponseModel insertupdatepincodemapping(PinCodeMappingModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			SQLServerDataTable menuUser = new SQLServerDataTable();
			menuUser.addColumnMetadata("LC_PPM_PINCODE", java.sql.Types.VARCHAR);
			menuUser.addColumnMetadata("LC_PPM_LOCATION", java.sql.Types.VARCHAR);

			for (PincodeModel d : reqModel.getPincodeModelList()) {
				menuUser.addRow(d.getPincode(), d.getLocation());
			}
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_PINCODE_MAPPING + "(?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					cs.setStructured(1, "dbo.UTT_PINCODE_LIST", menuUser);
					if (reqModel.getUser_id() != null) {
						cs.setLong(2, reqModel.getUser_id());
					} else {
						cs.setString(2, null);
					}
					if (reqModel.getParamedic_id() != null) {
						cs.setLong(3, reqModel.getParamedic_id());
					} else {
						cs.setString(3, null);
					}
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("Response", l_lstResult);
			}
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getPinCodeMaster(PincodeMasterReqModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_PINCODE_MASTER + "(?,?)}");

				if (requestModel.getStateId() != null) {
					callableStatement.setLong(1, requestModel.getStateId());
				} else {
					callableStatement.setString(1, null);
				}
				if (requestModel.getPinCodeMasterId() != null) {
					callableStatement.setLong(2, requestModel.getPinCodeMasterId());
				} else {
					callableStatement.setString(2, null);
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getpincodemaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@Override
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public ResponseModel insertupdatevendorvisittimemapping(
			VendorVisitTimeMappingReqModel vendorVisitTimeMappingReqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			SQLServerDataTable menuVisitTime = new SQLServerDataTable();
			menuVisitTime.addColumnMetadata("LC_VVTM_VISITTIME_ID", java.sql.Types.INTEGER);
			menuVisitTime.addColumnMetadata("LC_VVTM_VISIT_VENDOR_ID", java.sql.Types.BIGINT);

			for (VisitTimeModel d : vendorVisitTimeMappingReqModel.getVisitTimeModelList()) {
				menuVisitTime.addRow(d.getVisitTimeId(), d.getVisitVendorId());
			}
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall(
								"{call " + CommonConstants.USP_INSERT_UPDATE_VENDOR_VISITTIME_MAPPING + "(?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					cs.setStructured(1, "dbo.UTT_VISITTIME_LIST", menuVisitTime);
					if (vendorVisitTimeMappingReqModel.getUser_id() != null) {
						cs.setLong(2, vendorVisitTimeMappingReqModel.getUser_id());
					} else {
						cs.setString(2, null);
					}
					if (vendorVisitTimeMappingReqModel.getParamedic_id() != null) {
						cs.setLong(3, vendorVisitTimeMappingReqModel.getParamedic_id());
					} else {
						cs.setString(3, null);
					}
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("Response", l_lstResult);
			}
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getVendorVisitTime(VendorVisitTimeReqModel vendorVisitTimeReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_VENDOR_VISIT_TIME + "(?)}");

				if (vendorVisitTimeReqModel.getVisitId() != null) {
					callableStatement.setLong(1, vendorVisitTimeReqModel.getVisitId());
				} else {
					callableStatement.setString(1, null);
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getvendorvisittime", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getParamedicDetails(ParamedicDetailsReqModel reqmodel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_PARAMEDIC_DETAILS + "(?,?,?)}");

				if (reqmodel.getStateid() != null) {
					callableStatement.setLong(1, reqmodel.getStateid());
				} else {
					callableStatement.setString(1, null);
				}

				if (reqmodel.getCityid() != null) {
					callableStatement.setLong(2, reqmodel.getCityid());
				} else {
					callableStatement.setString(2, null);
				}

				if (reqmodel.getCenterid() != null) {
					callableStatement.setLong(3, reqmodel.getCenterid());
				} else {
					callableStatement.setString(3, null);
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getparamedicdetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("res" +responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getcitystatecenterbyuserid(PinCodeMappingModel reqmodel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_CITY_STATE_CENTER_BY_USERID + "(?)}");

				if (reqmodel.getUser_id() != null) {
					callableStatement.setLong(1, reqmodel.getUser_id());
				} else {
					callableStatement.setString(1, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getcitystatecenterbyuserid", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel vendorDetailsMaster(VendorDetailsMasterReqModel reqmodel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_VENDOR_DETAILS_MASTER
								+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

				if (reqmodel.getVendorid() != null) {
					callableStatement.setLong(1, reqmodel.getVendorid());
				} else {
					callableStatement.setString(1, null);
				}

				if (reqmodel.getVendorcode() != null) {
					callableStatement.setString(2, reqmodel.getVendorcode());
				} else {
					callableStatement.setString(2, null);
				}

				if (reqmodel.getHosiptalname() != null) {
					callableStatement.setString(3, reqmodel.getHosiptalname());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqmodel.getContactpersonname() != null) {
					callableStatement.setString(4, reqmodel.getContactpersonname());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqmodel.getPrimarycontact() != null) {
					callableStatement.setString(5, reqmodel.getPrimarycontact());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqmodel.getAlternatecontact() != null) {
					callableStatement.setString(6, reqmodel.getAlternatecontact());
				} else {
					callableStatement.setString(6, null);
				}
				if (reqmodel.getEmailid() != null) {
					callableStatement.setString(7, reqmodel.getEmailid());
				} else {
					callableStatement.setString(7, null);
				}
				if (reqmodel.getAddresstype() != null) {
					callableStatement.setInt(8, reqmodel.getAddresstype());
				} else {
					callableStatement.setString(8, null);
				}
				if (reqmodel.getHospitaladdress() != null) {
					callableStatement.setString(9, reqmodel.getHospitaladdress());
				} else {
					callableStatement.setString(9, null);
				}
				if (reqmodel.getAccounttypeid() != null) {
					callableStatement.setInt(10, reqmodel.getAccounttypeid());
				} else {
					callableStatement.setString(10, null);
				}
				if (reqmodel.getApprovedby() != null) {
					callableStatement.setLong(11, reqmodel.getApprovedby());
				} else {
					callableStatement.setString(11, null);
				}
				if (reqmodel.getApproveddate() != null) {
					callableStatement.setDate(12, Utils.utilDateTojavaSqlDate(reqmodel.getApproveddate()));
				} else {
					callableStatement.setString(12, null);
				}
				if (reqmodel.getOrginated() != null) {
					callableStatement.setString(13, reqmodel.getOrginated());
				} else {
					callableStatement.setString(13, null);
				}
				if (reqmodel.getOrginatedtypeid() != null) {
					callableStatement.setInt(14, reqmodel.getOrginatedtypeid());
				} else {
					callableStatement.setString(14, null);
				}
				if (reqmodel.getQuotationid() != null) {
					callableStatement.setLong(15, reqmodel.getQuotationid());
				} else {
					callableStatement.setString(15, null);
				}
				if (reqmodel.getQuotationimage() != null) {
					callableStatement.setString(16, reqmodel.getQuotationimage());
				} else {
					callableStatement.setString(16, null);
				}
				if (reqmodel.getMouid() != null) {
					callableStatement.setString(17, reqmodel.getMouid());
				} else {
					callableStatement.setString(17, null);
				}
				if (reqmodel.getMouimage() != null) {
					callableStatement.setString(18, reqmodel.getMouimage());
				} else {
					callableStatement.setString(18, null);
				}
				if (reqmodel.getStatus() != null) {
					callableStatement.setString(19, reqmodel.getStatus());
				} else {
					callableStatement.setString(19, null);
				}
				if (reqmodel.getStatusdatetime() != null) {
					callableStatement.setDate(20, Utils.utilDateTojavaSqlDate(reqmodel.getStatusdatetime()));
				} else {
					callableStatement.setString(20, null);
				}
				if (reqmodel.getRemarks() != null) {
					callableStatement.setString(21, reqmodel.getRemarks());
				} else {
					callableStatement.setString(21, null);
				}
				if (reqmodel.getAddress() != null) {
					callableStatement.setString(22, reqmodel.getAddress());
				} else {
					callableStatement.setString(22, null);
				}
				if (reqmodel.getCity() != null) {
					callableStatement.setString(23, reqmodel.getCity());
				} else {
					callableStatement.setString(23, null);
				}
				if (reqmodel.getState() != null) {
					callableStatement.setString(24, reqmodel.getState());
				} else {
					callableStatement.setString(24, null);
				}
				if (reqmodel.getPincode() != null) {
					callableStatement.setString(25, reqmodel.getPincode());
				} else {
					callableStatement.setString(25, null);
				}
				if (reqmodel.getInvoiceamount() != null) {
					callableStatement.setDouble(26, reqmodel.getInvoiceamount());
				} else {
					callableStatement.setString(26, null);
				}
				if (reqmodel.getApprovedstatus() != null) {
					callableStatement.setInt(27, reqmodel.getApprovedstatus());
				} else {
					callableStatement.setString(27, null);
				}
				if (reqmodel.getOtpverified() != null) {
					callableStatement.setInt(28, reqmodel.getOtpverified());
				} else {
					callableStatement.setString(28, null);
				}
				if (reqmodel.getMgrapprovedby() != null) {
					callableStatement.setLong(29, reqmodel.getMgrapprovedby());
				} else {
					callableStatement.setString(29, null);
				}
				if (reqmodel.getMgrapproveddate() != null) {
					callableStatement.setDate(30, Utils.utilDateTojavaSqlDate(reqmodel.getMgrapproveddate()));
				} else {
					callableStatement.setString(30, null);
				}
				if (reqmodel.getQuotationfname() != null) {
					callableStatement.setString(31, reqmodel.getQuotationfname());
				} else {
					callableStatement.setString(31, null);
				}
				if (reqmodel.getMoufname() != null) {
					callableStatement.setString(32, reqmodel.getMoufname());
				} else {
					callableStatement.setString(32, null);
				}

				if (reqmodel.getCustomercode() != null) {
					callableStatement.setString(33, reqmodel.getCustomercode());
				} else {
					callableStatement.setString(33, null);
				}
				if (reqmodel.getVendorcreatedby() != null) {
					callableStatement.setInt(34, reqmodel.getVendorcreatedby());
				} else {
					callableStatement.setString(34, null);
				}
				if (reqmodel.getSalescompleted() != null) {
					callableStatement.setInt(35, reqmodel.getSalescompleted());
				} else {
					callableStatement.setString(35, null);
				}
				if (reqmodel.getSalescompby() != null) {
					callableStatement.setInt(36, reqmodel.getSalescompby());
				} else {
					callableStatement.setString(36, null);
				}
				if (reqmodel.getSalescompdate() != null) {
					callableStatement.setDate(37, Utils.utilDateTojavaSqlDate(reqmodel.getSalescompdate()));
				} else {
					callableStatement.setString(37, null);
				}
				if (reqmodel.getLatitude() != null) {
					callableStatement.setString(38, reqmodel.getLatitude());
				} else {
					callableStatement.setString(38, null);
				}
				if (reqmodel.getLongitude() != null) {
					callableStatement.setString(39, reqmodel.getLongitude());
				} else {
					callableStatement.setString(39, null);
				}

				if (reqmodel.getUserid() != null) {
					callableStatement.setLong(40, reqmodel.getUserid());
				} else {
					callableStatement.setString(40, null);
				}
				if (reqmodel.getFlag() != null) {
					callableStatement.setInt(41, reqmodel.getFlag());
				} else {
					callableStatement.setString(41, null);
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("vendordetailsmaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		log.info("res" + responseModel);
		return responseModel;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertUpdateCenterMaster(CenterMasterReqModel reqmodel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.NVARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_CENTER_MASTER
								+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

				if (reqmodel.getCenterid() != null) {
					callableStatement.setLong(1, reqmodel.getCenterid());
				} else {
					callableStatement.setString(1, null);
				}

				if (reqmodel.getLangid() != null) {
					callableStatement.setInt(2, reqmodel.getLangid());
				} else {
					callableStatement.setString(2, null);
				}

				if (reqmodel.getCentercode() != null) {
					callableStatement.setString(3, reqmodel.getCentercode());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqmodel.getCentername() != null) {
					callableStatement.setString(4, reqmodel.getCentername());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqmodel.getDescriptionname() != null) {
					callableStatement.setString(5, reqmodel.getDescriptionname());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqmodel.getCityid() != null) {
					callableStatement.setInt(6, reqmodel.getCityid());
				} else {
					callableStatement.setString(6, null);
				}
				if (reqmodel.getStateid() != null) {
					callableStatement.setInt(7, reqmodel.getStateid());
				} else {
					callableStatement.setString(7, null);
				}
				if (reqmodel.getAddress() != null) {
					callableStatement.setString(8, reqmodel.getAddress());
				} else {
					callableStatement.setString(8, null);
				}
				if (reqmodel.getPincode() != null) {
					callableStatement.setString(9, reqmodel.getPincode());
				} else {
					callableStatement.setString(9, null);
				}
				if (reqmodel.getMgmt() != null) {
					callableStatement.setString(10, reqmodel.getMgmt());
				} else {
					callableStatement.setString(10, null);
				}
				if (reqmodel.getCenterheadname() != null) {
					callableStatement.setString(11, reqmodel.getCenterheadname());
				} else {
					callableStatement.setString(11, null);
				}
				if (reqmodel.getEmail() != null) {
					callableStatement.setString(12, reqmodel.getEmail());
				} else {
					callableStatement.setString(12, null);
				}
				if (reqmodel.getContactno() != null) {
					callableStatement.setString(13, reqmodel.getContactno());
				} else {
					callableStatement.setString(13, null);
				}
				if (reqmodel.getRegionalheadcontactno() != null) {
					callableStatement.setString(14, reqmodel.getRegionalheadcontactno());
				} else {
					callableStatement.setString(14, null);
				}
				if (reqmodel.getRegionalheademailid() != null) {
					callableStatement.setString(15, reqmodel.getRegionalheademailid());
				} else {
					callableStatement.setString(15, null);
				}
				if (reqmodel.getRegionid() != null) {
					callableStatement.setLong(16, reqmodel.getRegionid());
				} else {
					callableStatement.setString(16, null);
				}
				if (reqmodel.getRegionalheadname() != null) {
					callableStatement.setString(17, reqmodel.getRegionalheadname());
				} else {
					callableStatement.setString(17, null);
				}
				if (reqmodel.getCity() != null) {
					callableStatement.setString(18, reqmodel.getCity());
				} else {
					callableStatement.setString(18, null);
				}
				if (reqmodel.getState() != null) {
					callableStatement.setString(19, reqmodel.getState());
				} else {
					callableStatement.setString(19, null);
				}
				if (reqmodel.getRegionname() != null) {
					callableStatement.setString(20, reqmodel.getRegionname());
				} else {
					callableStatement.setString(20, null);
				}
				if (reqmodel.getLatitude() != null) {
					callableStatement.setString(21, reqmodel.getLatitude());
				} else {
					callableStatement.setString(21, null);
				}
				if (reqmodel.getLongitude() != null) {
					callableStatement.setString(22, reqmodel.getLongitude());
				} else {
					callableStatement.setString(22, null);
				}
				if (reqmodel.getUserid() != null) {
					callableStatement.setLong(23, reqmodel.getUserid());
				} else {
					callableStatement.setString(23, null);
				}
				if (reqmodel.getFlag() != null) {
					callableStatement.setInt(24, reqmodel.getFlag());
				} else {
					callableStatement.setString(24, null);
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("insertupdatecenterMaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		log.info("res" + responseModel);
		return responseModel;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertUpdateVisitTimeMaster(VisitTimeReqModel reqmodel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall(
								"{call " + CommonConstants.USP_INSERT_UPDATE_VISIT_TIME_MASTER + "(?,?,?,?,?,?,?)}");

				if (reqmodel.getVisitid() != null) {
					callableStatement.setLong(1, reqmodel.getVisitid());
				} else {
					callableStatement.setString(1, null);
				}

				if (reqmodel.getVisittime() != null) {
					callableStatement.setString(2, reqmodel.getVisittime());
				} else {
					callableStatement.setString(2, null);
				}

				if (reqmodel.getVisitname() != null) {
					callableStatement.setString(3, reqmodel.getVisitname());
				} else {
					callableStatement.setString(3, null);
				}

				if (reqmodel.getUsertype() != null) {
					callableStatement.setLong(4, reqmodel.getUsertype());
				} else {
					callableStatement.setString(4, null);
				}

				if (reqmodel.getLangid() != null) {
					callableStatement.setLong(5, reqmodel.getLangid());
				} else {
					callableStatement.setString(5, null);
				}

				if (reqmodel.getUserid() != null) {
					callableStatement.setLong(6, reqmodel.getUserid());
				} else {
					callableStatement.setString(6, null);
				}

				if (reqmodel.getFlag() != null) {
					callableStatement.setLong(7, reqmodel.getFlag());
				} else {
					callableStatement.setString(7, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("insertupdatevisittimeMaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		log.info("res" + responseModel);
		return responseModel;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getApproveStatus() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_LC_APPROVE_STATUS + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getApproveStatus", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getRegion() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_REGION + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getRegion", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getManagement() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_MANAGEMENT + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getManagement", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		System.out.println(responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertUpdateTestProductMapping(TestProductMappingReqModel reqmodel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_TEST_PRODUCT_MAPPING
								+ "(?,?,?,?,?,?,?,?,?,?,?,?)}");

				if (reqmodel.getTestid() != null) {
					callableStatement.setInt(1, reqmodel.getTestid());
				} else {
					callableStatement.setString(1, null);
				}

				if (reqmodel.getTestcode() != null) {
					callableStatement.setString(2, reqmodel.getTestcode());
				} else {
					callableStatement.setString(2, null);
				}

				if (reqmodel.getTestname() != null) {
					callableStatement.setString(3, reqmodel.getTestname());
				} else {
					callableStatement.setString(3, null);
				}

				if (reqmodel.getTestmaxprice() != null) {
					callableStatement.setDouble(4, reqmodel.getTestmaxprice());
				} else {
					callableStatement.setString(4, null);
				}

				if (reqmodel.getTestminprice() != null) {
					callableStatement.setDouble(5, reqmodel.getTestminprice());
				} else {
					callableStatement.setString(5, null);
				}

				if (reqmodel.getPrecondition() != null) {
					callableStatement.setString(6, reqmodel.getPrecondition());
				} else {
					callableStatement.setString(6, null);
				}

				if (reqmodel.getSampletype() != null) {
					callableStatement.setString(7, reqmodel.getSampletype());
				} else {
					callableStatement.setString(7, null);
				}

				if (reqmodel.getProductid() != null) {
					callableStatement.setInt(8, reqmodel.getProductid());
				} else {
					callableStatement.setString(8, null);
				}

				if (reqmodel.getUserid() != null) {
					callableStatement.setLong(9, reqmodel.getUserid());
				} else {
					callableStatement.setString(9, null);
				}

				if (reqmodel.getFlag() != null) {
					callableStatement.setInt(10, reqmodel.getFlag());
				} else {
					callableStatement.setString(10, null);
				}
				if (reqmodel.getProductcode() != null) {
					callableStatement.setString(11, reqmodel.getProductcode());
				} else {
					callableStatement.setString(11, null);
				}

				if (reqmodel.getStatus() != null) {
					callableStatement.setLong(12, reqmodel.getStatus());
				} else {
					callableStatement.setString(12, null);
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("insertupdatetestproductmapping", l_lstResult);
				}
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		log.info("res" + responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getPreconditionMaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_PRECONDITION_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getPreconditionMaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		System.out.println("resss" + responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getPaymentStatus(PaymentStatusReqModel reqmodel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_PAYMENTSTATUS + "(?,?,?,?)}");

				callableStatement.setString(1, reqmodel.getAllpaymentstatus());

				if (reqmodel.getAllclient() != null) {
					callableStatement.setLong(2, reqmodel.getAllclient());
				} else {
					callableStatement.setString(2, null);
				}

				callableStatement.setDate(3, Utils.utilDateTojavaSqlDate(reqmodel.getStartdate()));
				callableStatement.setDate(4, Utils.utilDateTojavaSqlDate(reqmodel.getEnddate()));
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("getpaymentstatus", l_lstResult);
				}
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		log.info("res" + responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getallclientmaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_ALLCLIENT_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getallclientmaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getallstatusmaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_ALLSTATUS_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getallstatusmaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getallinvoicetracking(PaymentStatusReqModel reqmodel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_ALLINVOICETRACKING + "(?,?,?,?)}");

				if (reqmodel.getAllstatus() != null) {
					callableStatement.setLong(1, reqmodel.getAllstatus());
				} else {
					callableStatement.setString(1, null);
				}

				if (reqmodel.getAllclient() != null) {
					callableStatement.setLong(2, reqmodel.getAllclient());
				} else {
					callableStatement.setString(2, null);
				}

				callableStatement.setDate(3, Utils.utilDateTojavaSqlDate(reqmodel.getStartdate()));
				callableStatement.setDate(4, Utils.utilDateTojavaSqlDate(reqmodel.getEnddate()));
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("getallinvoicetracking", l_lstResult);
				}
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		log.info("res" + responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getQuotationdetails(PaymentStatusReqModel reqmodel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_QUOTATION_DETAILS + "(?,?,?,?)}");

				if (reqmodel.getAllstatus() != null) {
					callableStatement.setLong(1, reqmodel.getAllstatus());
				} else {
					callableStatement.setString(1, null);
				}

				if (reqmodel.getAllclient() != null) {
					callableStatement.setLong(2, reqmodel.getAlltype());
				} else {
					callableStatement.setString(2, null);
				}

				callableStatement.setDate(3, Utils.utilDateTojavaSqlDate(reqmodel.getStartdate()));
				callableStatement.setDate(4, Utils.utilDateTojavaSqlDate(reqmodel.getEnddate()));
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("getquotationdetails", l_lstResult);
				}
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		log.info("res" + responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getapprovedstatusmaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_APPROVEDSTATUS_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getapprovedstatusmaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getaccounttypemaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_ACCOUNT_TYPE_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getaccounttypemaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		System.out.println("resss" + responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getInvoiceStatusMaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_ALLINVOICESTATUS_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getInvoiceStatusMaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		System.out.println("resss" + responseModel);
		return responseModel;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel getWebDashBoardDetails(WebDashBoardDetails reqModel) {

		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_WEB_DASHBOARD_DETAILS(?,?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					if (reqModel.getParamedicid() != null) {
						callableStatement.setLong(1, reqModel.getParamedicid());
					} else {
						callableStatement.setString(1, null);
					}
					callableStatement.setDate(2, Utils.utilDateTojavaSqlDate(reqModel.getStartdate()));
					callableStatement.setDate(3, Utils.utilDateTojavaSqlDate(reqModel.getEnddate()));
					callableStatement.setString(4, reqModel.getType());
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			System.out.println("ress" + resultData);

			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					String report = null;
					for (int i = 0; i < l_lstResult.size(); i++) {
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
						report = l_hmColmnData.get("REPORT");
					}
					properties.put(report, l_lstResult);
				}
			}
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		log.info("res" + responseModel);
		return responseModel;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel getsalesWebDashBoardDetails(WebDashBoardDetails reqModel) {

		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_SALES_WEB_DASHBOARD_DETAILS(?,?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					if (reqModel.getSalesid() != null) {
						callableStatement.setLong(1, reqModel.getSalesid());
					} else {
						callableStatement.setString(1, null);
					}
					callableStatement.setDate(2, Utils.utilDateTojavaSqlDate(reqModel.getStartdate()));
					callableStatement.setDate(3, Utils.utilDateTojavaSqlDate(reqModel.getEnddate()));
					callableStatement.setString(4, reqModel.getType());
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			System.out.println("ress" + resultData);

			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					String report = null;
					for (int i = 0; i < l_lstResult.size(); i++) {
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
						report = l_hmColmnData.get("REPORT");
					}
					properties.put(report, l_lstResult);
				}
			}
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		log.info("res" + responseModel);
		return responseModel;
	}

	@Override
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public ResponseModel insertupdatesaleshospitalmapping(
			SalesHospitalMappingReqModel SalesHospitalMappingReqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			SQLServerDataTable menuVisitTime = new SQLServerDataTable();
			menuVisitTime.addColumnMetadata("LC_SHM_SALES_ID", java.sql.Types.INTEGER);
			menuVisitTime.addColumnMetadata("LC_SHM_HOSPITAL_ID", java.sql.Types.BIGINT);

			for (SaleshospitalMappingModel d : SalesHospitalMappingReqModel.getSaleshospitalmappingModelList()) {
				menuVisitTime.addRow(d.getShmsalesid(), d.getShmhospitalid());
			}
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_SALES_HOSPITAL_MAPPING + "(?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					cs.setStructured(1, "dbo.UTT_SALES_HOSPITAL_MAPPING_LIST", menuVisitTime);
					if (SalesHospitalMappingReqModel.getUserid() != null) {
						cs.setString(2, SalesHospitalMappingReqModel.getUserid());
					} else {
						cs.setString(2, null);
					}
					if (SalesHospitalMappingReqModel.getSalesid() != null) {
						cs.setString(3, SalesHospitalMappingReqModel.getSalesid());
					} else {
						cs.setString(3, null);
					}
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("Response", l_lstResult);
			}
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return responseModel;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel getsalesusers(WebDashBoardDetails reqModel) {

		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection.prepareCall("{call USP_GET_SALES_USERS(?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");

					callableStatement.setLong(1, reqModel.getUserid());

				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("Response", l_lstResult);

			}
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		log.info("res" + responseModel);
		return responseModel;
	}

	@Override
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public ResponseModel insertupdatedoctordetails(
			DoctorDetailsReqModel DoctorDetailsReqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall(
								"{call " + CommonConstants.USP_INSERT_UPDATE_DOCTOR_DETAILS + "(?,?,?,?,?,?,?,?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					// cs.setResponseBuffering("adaptive");
					cs.setString(1, DoctorDetailsReqModel.getFirstname());
					cs.setString(2, DoctorDetailsReqModel.getLastname());
					if (DoctorDetailsReqModel.getDob() != null) {
						cs.setTimestamp(3, Utils.LocalDateToTimeStamp(DoctorDetailsReqModel.getDob()));
					} else {
						cs.setString(3, null);
					}
					cs.setString(4, DoctorDetailsReqModel.getPrimarycontact());
					cs.setString(5, DoctorDetailsReqModel.getEmailid());
					cs.setString(6, DoctorDetailsReqModel.getAddress());
					if (DoctorDetailsReqModel.getSpeciality() != null) {
						cs.setLong(7, DoctorDetailsReqModel.getSpeciality());
					} else {
						cs.setString(7, null);
					}
					cs.setString(8, DoctorDetailsReqModel.getAction());
					if (DoctorDetailsReqModel.getUserid() != null) {
						cs.setLong(9, DoctorDetailsReqModel.getUserid());
					} else {
						cs.setString(9, null);
					}
					if (DoctorDetailsReqModel.getDoctorid() != null) {
						cs.setLong(10, DoctorDetailsReqModel.getDoctorid());
					} else {
						cs.setString(10, null);
					}
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("Response", l_lstResult);
			}
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return responseModel;
	}

	@Override
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public ResponseModel insertupdatedoctorhospitalmapping(
			DoctorHospitalMappingReqModel DoctorHospitalMappingReqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			SQLServerDataTable menuVisitTime = new SQLServerDataTable();
			menuVisitTime.addColumnMetadata("LC_SHM_SALES_ID", java.sql.Types.INTEGER);
			menuVisitTime.addColumnMetadata("LC_SHM_HOSPITAL_ID", java.sql.Types.BIGINT);

			for (DoctorHospitalMappingModel d : DoctorHospitalMappingReqModel.getDoctorhospitalmappingModelList()) {
				menuVisitTime.addRow(d.getDhmdoctorid(), d.getDhmhospitalid());
			}
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_DOCTOR_HOSPITAL_MAPPING + "(?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					cs.setStructured(1, "dbo.UTT_DOCTOR_HOSPITAL_MAPPING_LIST", menuVisitTime);
					if (DoctorHospitalMappingReqModel.getUserid() != null) {
						cs.setString(2, DoctorHospitalMappingReqModel.getUserid());
					} else {
						cs.setString(2, null);
					}
					if (DoctorHospitalMappingReqModel.getHospitalid() != null) {
						cs.setString(3, DoctorHospitalMappingReqModel.getHospitalid());
					} else {
						cs.setString(3, null);
					}
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("Response", l_lstResult);
			}
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return responseModel;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel gethospitalwisestatecity(HospitalstatecityModel reqModel) {

		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_HOSPITAL_WISE_STATE_CITY(?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");

					callableStatement.setLong(1, reqModel.getUserid());
					callableStatement.setLong(2, reqModel.getHospitalid());

				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("Response", l_lstResult);

			}
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		log.info("res" + responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getProductForWeb() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_PRODUCT_FOR_WEB + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getProductDetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		log.info("responseModel" + responseModel);
		return responseModel;
	}

	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getallcleaningcategory() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_ALL_CLEANING_CATEGORY + "}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				MyObject object = new MyObject(l_lstResult);
				responseModel.setResponseObject(object);
			}
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());

			} // log.info("res" +responseModel);

		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getallitemmaster(ItemMasterReqModel requestModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_ALL_ITEM_MASTER(?)}");

				callableStatement.setInt(1, requestModel.getServiceid());

				return callableStatement;

			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getallitemmaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;

	}

	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getallservicemaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_ALL_SERVICE_MASTER + "}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				MyObject object = new MyObject(l_lstResult);
				responseModel.setResponseObject(object);
			}
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());

			} // log.info("res" +responseModel);

		}
		return responseModel;
	}

	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getcolourmaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_COLOUR_MASTER + "}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				MyObject object = new MyObject(l_lstResult);
				responseModel.setResponseObject(object);
			}
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();

			} // log.info("res" +responseModel);

		}
		return responseModel;
	}

	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getdamagemaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_DAMAGE_MASTER + "}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				MyObject object = new MyObject(l_lstResult);
				responseModel.setResponseObject(object);
			}
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();

			} // log.info("res" +responseModel);

		}
		return responseModel;
	}

	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getstainmaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_STAIN_MASTER + "}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				MyObject object = new MyObject(l_lstResult);
				responseModel.setResponseObject(object);
			}
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());

			} // log.info("res" +responseModel);
		}
		return responseModel;
	}

	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getusermaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_USER_MASTER + "}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				MyObject object = new MyObject(l_lstResult);
				responseModel.setResponseObject(object);
			}
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());

			} // log.info("res" +responseModel);
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getdeliverymode(DeliveryModeReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_DELIVERY_MODE(?)}");

				callableStatement.setLong(1, reqModel.getFlag());

				return callableStatement;

			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			int count = 0;
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				count++;
				if (count == 1) {
					properties.put("orderResponse", l_lstResult);
				} else if (count == 2) {
					properties.put("specialinstruction", l_lstResult);
				} else if (count == 3) {
					properties.put("autoapprovals", l_lstResult);
				}
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		System.out.println(responseModel);
		return responseModel;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getriderslotavailability(RiderTimeSlotAvailabilityReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();

		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_RIDER_SLOT_AVAILABILITY + "(?,?)}");

				callableStatement.setDate(1, reqModel.getVardate());
				callableStatement.setString(2, reqModel.getPincode());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());

			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					TimeSlotReqModel timeSlotReqModel = null;

					List<TimeSlotReqModel> timeSlotReqModels = new ArrayList<>();
					for (int i = 0; i < l_lstResult.size(); i++) {
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);

						responseModel.setStatusCode(Integer.valueOf(String.valueOf(l_hmColmnData.get("status"))));
						// responseModel.setOrderid(Long.valueOf(String.valueOf(l_hmColmnData.get("id"))));

						if (responseModel.getStatusCode() == 200) {
							timeSlotReqModel = new TimeSlotReqModel();
							timeSlotReqModel.setTimeslot(String.valueOf(l_hmColmnData.get("Timeslot")));
							// timeSlotReqModel.setId(Integer.valueOf(String.valueOf(l_hmColmnData.get("id"))));

							timeSlotReqModels.add(timeSlotReqModel);

							responseModel.setRespList(timeSlotReqModels);
						} else {
							responseModel.setMessage(String.valueOf(l_hmColmnData.get("message")));
						}
					}

				}

			}

		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getPickupDetails(PickupDetailsReqModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_PICKUP_DETAILS(?,?,?)}");

				callableStatement.setLong(1, requestModel.getOrderid());
				callableStatement.setString(2, requestModel.getQrcode());
				callableStatement.setInt(3, requestModel.getFlag());

				return callableStatement;

			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			int count = 0;
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				count++;
				if (count == 1) {
					properties.put("orderResponse", l_lstResult);
				} else if (count == 2) {
					properties.put("specialinstruction", l_lstResult);
				} else if (count == 3) {
					properties.put("autoapprovals", l_lstResult);
				}
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		System.out.println(responseModel);
		return responseModel;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertUpdateOrderDetails(OrderDetailsReqModel orderReqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();

		try {
			List prmtrsList = new ArrayList();

			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			SQLServerDataTable collectitemsdetails = new SQLServerDataTable();
			collectitemsdetails.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMCOUNT", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMPRICE", java.sql.Types.DOUBLE);
			collectitemsdetails.addColumnMetadata("STAINID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("DAMAGEID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("COLOURID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("NOTES", java.sql.Types.VARCHAR);

			SQLServerDataTable damageitemsdetails = new SQLServerDataTable();
			damageitemsdetails.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMCOUNT", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMPRICE", java.sql.Types.DOUBLE);
			damageitemsdetails.addColumnMetadata("STAINID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("DAMAGEID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("COLOURID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("NOTES", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("BRANDID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("IMAGEPATH", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("IMAGENAME", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("ITEMQTYID", java.sql.Types.INTEGER);

			for (CollectItemDetailsModel d : orderReqModel.getCollectitems()) {
				if (d.getDamagedetails().size() == 0) {
					if (d.getStaindetails().size() == 0) {
						if (d.getColordetails().size() == 0) {
							if (d.getBranddetails().size() == 0) {
								collectitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()),
										Utils.checkNullandEmpty(d.getNotes()));
							}

						}
					}

				}
			}

			for (CollectItemDetailsModel d : orderReqModel.getCollectitems()) {
				int itemqtyid = 0;
				if (d.getDamagedetails() != null && d.getDamagedetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getDamagedetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid);
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									null, Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid);
						}

					}

				}
				if (d.getStaindetails() != null && d.getStaindetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getStaindetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid);
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), null,
									Utils.checkNullandEmpty(d.getDamageid()), Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid);
						}

					}
				}
				if (d.getColordetails() != null && d.getColordetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getColordetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(object.getId()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid);
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									Utils.checkNullandEmpty(d.getDamageid()), null,
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid);
						}

					}

				}
				if (d.getBranddetails() != null && d.getBranddetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getBranddetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid);
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									Utils.checkNullandEmpty(d.getDamageid()), Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), null, null, null, itemqtyid);
						}

					}

				}
			}

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_ORDER_DETAILS
								+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					cs.setLong(1, orderReqModel.getOrderid());
					cs.setLong(2, orderReqModel.getCustomerid());
					cs.setStructured(3, "dbo.UTT_COLLECT_ITEMS_DETAILS", collectitemsdetails);
					cs.setString(4, Utils.checkNull(orderReqModel.getRemarks()));
					cs.setDouble(5, orderReqModel.getInvoiceamount());
					cs.setDouble(6, orderReqModel.getSubtotal());
					cs.setDouble(7, orderReqModel.getDiscount());
					cs.setDouble(8, orderReqModel.getDeliveryfee());
					cs.setDouble(9, orderReqModel.getTotal());
					cs.setDouble(10, orderReqModel.getTax());
					if (orderReqModel.getDeliverymode() != null) {
						cs.setLong(11, orderReqModel.getDeliverymode());
					} else {
						cs.setString(11, null);
					}
					cs.setInt(12, orderReqModel.getIsnotification());
					cs.setDouble(13, orderReqModel.getDiscountpercent());
					cs.setDouble(14, orderReqModel.getDeliverypercent());
					cs.setStructured(15, "dbo.UTT_ITEMS_DAMAGE_QTY_DETAILS_NEW", damageitemsdetails);
					if (orderReqModel.getUserid() != null) {
						cs.setLong(16, orderReqModel.getUserid());
					} else {
						cs.setString(16, null);
					}
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());

			for (String key : set) {
				if (key.contains("result")) {
					List<NewOrderResModel> newOrderResModel = new ArrayList<>();
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);

					NewOrderResModel newOrderResModels = null;
					for (int i = 0; i < l_lstResult.size(); i++) {
						newOrderResModels = new NewOrderResModel();
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);

						responseModel.setStatusCode(Integer.valueOf(String.valueOf(l_hmColmnData.get("status"))));
						if (responseModel.getStatusCode() == 200) {
							responseModel.setMessage(String.valueOf(l_hmColmnData.get("message")));

							newOrderResModels.setItemid(Integer.valueOf(String.valueOf(l_hmColmnData.get("ITEMID"))));
							newOrderResModels
									.setItemcount(Integer.valueOf(String.valueOf(l_hmColmnData.get("ITEMCOUNT"))));
							newOrderResModels.setItemname(String.valueOf(l_hmColmnData.get("ITEMNAME")));
							newOrderResModels.setServicename(String.valueOf(l_hmColmnData.get("SERVICENAME")));
							newOrderResModels.setQrcode(String.valueOf(l_hmColmnData.get("QRCODE")));
							newOrderResModels.setCustomername(String.valueOf(l_hmColmnData.get("CUSTOMERNAME")));
							newOrderResModels
									.setInvoiceid(Long.valueOf(String.valueOf(l_hmColmnData.get("invoiceid"))));
							newOrderResModels.setSocietyname(String.valueOf(l_hmColmnData.get("SOCIETYNAME")));
							newOrderResModels.setFlatno(String.valueOf(l_hmColmnData.get("FLATNO")));
							newOrderResModels.setOrdercode(String.valueOf(l_hmColmnData.get("ORDERCODE")));
							;
							newOrderResModel.add(newOrderResModels);
						}

						else {
							responseModel.setMessage(String.valueOf(l_hmColmnData.get("message")));
						}
					}
					responseModel.setResponseObject(newOrderResModel);
				}
			}
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertWebNewOrderDetails(OrderDetailsReqModel orderReqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();

		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			SQLServerDataTable collectitemsdetails = new SQLServerDataTable();
			collectitemsdetails.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMCOUNT", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMPRICE", java.sql.Types.DOUBLE);
			collectitemsdetails.addColumnMetadata("STAINID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("DAMAGEID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("COLOURID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("NOTES", java.sql.Types.VARCHAR);

			SQLServerDataTable damageitemsdetails = new SQLServerDataTable();
			damageitemsdetails.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMCOUNT", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMPRICE", java.sql.Types.DOUBLE);
			damageitemsdetails.addColumnMetadata("STAINID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("DAMAGEID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("COLOURID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("NOTES", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("BRANDID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("IMAGEPATH", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("IMAGENAME", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("ITEMQTYID", java.sql.Types.INTEGER);

			for (CollectItemDetailsModel d : orderReqModel.getCollectitems()) {
				if (d.getDamagedetails().size() == 0) {
					if (d.getStaindetails().size() == 0) {
						if (d.getColordetails().size() == 0) {
							if (d.getBranddetails().size() == 0) {

								collectitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()),
										Utils.checkNullandEmpty(d.getNotes()));
							}

						}
					}

				}
			}

			for (CollectItemDetailsModel d : orderReqModel.getCollectitems()) {
				int itemqtyid = 0;
				if (d.getDamagedetails() != null && d.getDamagedetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getDamagedetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid);
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									null, Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid);
						}

					}

				}
				if (d.getStaindetails() != null && d.getStaindetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getStaindetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid);
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), null,
									Utils.checkNullandEmpty(d.getDamageid()), Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid);
						}

					}
				}
				if (d.getColordetails() != null && d.getColordetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getColordetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(object.getId()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid);
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									Utils.checkNullandEmpty(d.getDamageid()), null,
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid);
						}

					}

				}
				if (d.getBranddetails() != null && d.getBranddetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getBranddetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid);
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									Utils.checkNullandEmpty(d.getDamageid()), Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), null, null, null, itemqtyid);
						}

					}

				}
			}

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_WEB_NEW_ORDER_DETAILS
								+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					cs.setString(1, orderReqModel.getName());
					cs.setString(2, orderReqModel.getEmailid());
					cs.setString(3, orderReqModel.getMobileno());
					cs.setLong(4, orderReqModel.getTypeid());
					if (orderReqModel.getDob() != null) {
						cs.setDate(5, Utils.utilDateTojavaSqlDate(orderReqModel.getDob()));
					} else {
						cs.setString(5, null);
					}
					if (orderReqModel.getDoa() != null) {
						cs.setDate(6, Utils.utilDateTojavaSqlDate(orderReqModel.getDoa()));
					} else {
						cs.setString(6, null);
					}
					cs.setString(7, orderReqModel.getAddressline1());
					cs.setString(8, orderReqModel.getAddressline2());
					cs.setString(9, orderReqModel.getPincode());
					cs.setStructured(10, "dbo.UTT_COLLECT_ITEMS_DETAILS", collectitemsdetails);

					if (orderReqModel.getPickupdate() != null) {
						cs.setString(11, orderReqModel.getPickupdate());
					} else {
						cs.setString(11, null);
					}
					if (orderReqModel.getPickuptimeid() != null) {
						cs.setLong(12, orderReqModel.getPickuptimeid());
					} else {
						cs.setString(12, null);
					}
					if (orderReqModel.getDeliverymode() != null) {
						cs.setLong(13, orderReqModel.getDeliverymode());
					} else {
						cs.setString(13, null);
					}
					cs.setString(14, orderReqModel.getRemarks());

					if (orderReqModel.getInvoiceamount() != null) {
						cs.setDouble(15, orderReqModel.getInvoiceamount());
					} else {
						cs.setString(15, null);
					}

					if (orderReqModel.getSubtotal() != null) {
						cs.setDouble(16, orderReqModel.getSubtotal());
					} else {
						cs.setString(16, null);
					}
					if (orderReqModel.getDiscount() != null) {
						cs.setDouble(17, orderReqModel.getDiscount());
					} else {
						cs.setString(17, null);
					}
					if (orderReqModel.getDeliveryfee() != null) {
						cs.setDouble(18, orderReqModel.getDeliveryfee());
					} else {
						cs.setString(18, null);
					}
					if (orderReqModel.getTotal() != null) {
						cs.setDouble(19, orderReqModel.getTotal());
					} else {
						cs.setString(19, null);
					}
					if (orderReqModel.getTax() != null) {
						cs.setDouble(20, orderReqModel.getTax());
					} else {
						cs.setString(20, null);
					}
					if (orderReqModel.getIsnotification() != null) {
						cs.setLong(21, orderReqModel.getIsnotification());
					} else {
						cs.setString(21, null);
					}
					if (orderReqModel.getOrderid() != null) {
						cs.setLong(22, orderReqModel.getOrderid());
					} else {
						cs.setString(22, null);
					}

					if (orderReqModel.getCustomerid() != null) {
						cs.setLong(23, orderReqModel.getCustomerid());
					} else {
						cs.setString(23, null);
					}
					if (orderReqModel.getUserid() != null) {
						cs.setLong(24, orderReqModel.getUserid());
					} else {
						cs.setString(24, null);
					}
					if (orderReqModel.getInvoiceid() != null) {
						cs.setInt(25, orderReqModel.getInvoiceid());
					} else {
						cs.setString(25, null);
					}
					if (orderReqModel.getDiscountpercent() != null) {
						cs.setDouble(26, orderReqModel.getDiscountpercent());
					} else {
						cs.setString(26, null);
					}
					if (orderReqModel.getDeliverypercent() != null) {
						cs.setDouble(27, orderReqModel.getDeliverypercent());
					} else {
						cs.setString(27, null);
					}
					if (orderReqModel.getDeliverytypeid() != null) {
						cs.setInt(28, orderReqModel.getDeliverytypeid());
					} else {
						cs.setString(28, null);
					}
					if (orderReqModel.getQuckdeliveryid() != null) {
						cs.setInt(29, orderReqModel.getQuckdeliveryid());
					} else {
						cs.setString(29, null);
					}
					cs.setStructured(30, "dbo.UTT_ITEMS_DAMAGE_QTY_DETAILS_NEW", damageitemsdetails);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());

			for (String key : set) {
				if (key.contains("result")) {
					List<NewOrderResModel> newOrderResModel = new ArrayList<>();
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);

					NewOrderResModel newOrderResModels = null;
					for (int i = 0; i < l_lstResult.size(); i++) {
						newOrderResModels = new NewOrderResModel();
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);

						responseModel.setStatusCode(Integer.valueOf(String.valueOf(l_hmColmnData.get("status"))));
						if (responseModel.getStatusCode() == 200) {
							responseModel.setMessage(String.valueOf(l_hmColmnData.get("message")));
							responseModel.setOrderid(Long.valueOf(String.valueOf(l_hmColmnData.get("ORDERID"))));

							newOrderResModels.setItemid(Integer.valueOf(String.valueOf(l_hmColmnData.get("ITEMID"))));
							newOrderResModels
									.setItemcount(Integer.valueOf(String.valueOf(l_hmColmnData.get("ITEMCOUNT"))));
							newOrderResModels.setItemname(String.valueOf(l_hmColmnData.get("ITEMNAME")));
							newOrderResModels
									.setServicename(Utils.checkNull(String.valueOf(l_hmColmnData.get("SERVICENAME"))));
							newOrderResModels.setQrcode(String.valueOf(l_hmColmnData.get("QRCODE")));
							newOrderResModels.setCustomername(String.valueOf(l_hmColmnData.get("CUSTOMERNAME")));
							newOrderResModels
									.setInvoiceid(Long.valueOf(String.valueOf(l_hmColmnData.get("invoiceid"))));
							newOrderResModels
									.setNewuserid(Long.valueOf(String.valueOf(l_hmColmnData.get("newuserid"))));
							newOrderResModels.setSocietyname(String.valueOf(l_hmColmnData.get("SOCIETYNAME")));
							newOrderResModels.setFlatno(String.valueOf(l_hmColmnData.get("FLATNO")));
							newOrderResModels.setOrdercode(String.valueOf(l_hmColmnData.get("ORDERCODE")));
							newOrderResModel.add(newOrderResModels);
						}

						else {
							responseModel.setMessage(String.valueOf(l_hmColmnData.get("message")));
						}
					}
					responseModel.setResponseObject(newOrderResModel);
				}
			}
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		System.out.println(responseModel);
		return responseModel;
	}

	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getchallantypemaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_CHALLAN_TYPE_MASTER + "}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				MyObject object = new MyObject(l_lstResult);
				responseModel.setResponseObject(object);
			}
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());

			} // log.info("res" +responseModel);
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getchallanmaster(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_CHALLAN_MASTER(?,?,?,?,?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());
				callableStatement.setInt(3, chalanMasterRequestModel.getStart());
				callableStatement.setInt(4, chalanMasterRequestModel.getEnd());
				callableStatement.setString(5, chalanMasterRequestModel.getStatus());
				callableStatement.setString(6, chalanMasterRequestModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getchallanmaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getpickupdetailsbyitems(PickupDetailsByItemsReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_PICKUP_DETAILS_BY_ITEMS(?,?,?)}");

				callableStatement.setLong(1, reqModel.getOrderid());
				callableStatement.setString(2, reqModel.getQrcode());
				callableStatement.setInt(3, reqModel.getInvoiceid());

				return callableStatement;

			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			int count = 0;
			int damagecount = 0;
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			List<CollectItemDamageDetailsModel> itemDetailsModels = new ArrayList<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				count++;
				if (count == 1) {
					properties.put("orderResponse", l_lstResult);
				} else if (count == 2) {
					properties.put("specialinstruction", l_lstResult);
				} else if (count == 3) {
					properties.put("autoapprovals", l_lstResult);
				} else if (count == 4) {
					CollectItemDamageDetailsModel itemDetailsModel = null;
					DamagedetailsModel damagedetail = null;
					Staindetails staindetail = null;
					Colordetails colordetail = null;
					Branddetails branddetail = null;
					DamageCommondetails commondetail = null;
					ImagedetailsModel imagedetail = null;

					List<DamagedetailsModel> damagedetails = null;
					List<Staindetails> staindetails = null;
					List<Colordetails> colordetails = null;
					List<Branddetails> branddetails = null;
					List<DamageCommondetails> commondetails = null;
					List<ImagedetailsModel> imagedetails = null;

					List<List<DamagedetailsModel>> damagedetailss = null;
					List<List<Staindetails>> staindetailss = null;
					List<List<Colordetails>> colordetailss = null;
					List<List<Branddetails>> branddetailss = null;
					List<List<DamageCommondetails>> commondetailss = null;
					List<List<ImagedetailsModel>> imagedetailss = null;

					String damages = "";
					int itemqtyid = 0;
					int itemid = 0;
					int serviceid = 0;
					int previtemqtyid = 0;
					Set<String> itemids = new HashSet<>();
					for (int i = 0; i < l_lstResult.size(); i++) {
						damagecount++;
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
						if (String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_ID")) != null) {
							if (damagecount == 1) {
								itemDetailsModel = new CollectItemDamageDetailsModel();
								damagedetails = new ArrayList<>();
								staindetails = new ArrayList<>();
								colordetails = new ArrayList<>();
								branddetails = new ArrayList<>();
								commondetails = new ArrayList<>();
								imagedetails = new ArrayList<>();

								damagedetailss = new ArrayList<>();
								staindetailss = new ArrayList<>();
								colordetailss = new ArrayList<>();
								branddetailss = new ArrayList<>();
								commondetailss = new ArrayList<>();
								imagedetailss = new ArrayList<>();

								itemDetailsModel.setServiceid(
										Utils.checkNullInteger(String.valueOf(l_hmColmnData.get("WC_IDD_SERVICE_ID"))));
								itemDetailsModel.setItemid(
										Utils.checkNullInteger(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_ID"))));
								itemDetailsModel
										.setServicename(String.valueOf(l_hmColmnData.get("WC_SM_SERVICE_NAME")));
								itemDetailsModel.setItemname(String.valueOf(l_hmColmnData.get("WC_IM_ITEM_NAME")));
								itemDetailsModel.setItemprice(
										Double.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_PRICE"))));
								itemDetailsModel.setItemcount(
										Integer.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_COUNT"))));
								itemDetailsModel.setIs_curtain(
										Utils.checkNullInteger(String.valueOf(l_hmColmnData.get("is_curtain"))));

								itemqtyid = Integer.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_QTY_ID")));
								itemid = Integer.parseInt(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_ID")));
								serviceid = Integer.parseInt(String.valueOf(l_hmColmnData.get("WC_IDD_SERVICE_ID")));

								imagedetail = new ImagedetailsModel();
								imagedetail.setQrcode(String.valueOf(l_hmColmnData.get("QRCODE")));
								imagedetails.add(imagedetail);

								if (l_hmColmnData.get("WC_IDD_STAIN_ID") != null) {
									staindetail = new Staindetails();
									staindetail.setStainId(
											Integer.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_STAIN_ID"))));
									staindetail.setImagepath(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGEPATH")));
									staindetail.setStainName(String.valueOf(l_hmColmnData.get("WC_SM_STAIN_NAME")));
									staindetail.setName(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGENAME")));
									staindetails.add(staindetail);
									// if (damages == "") {
									// damages=damages+String.valueOf(l_hmColmnData.get("WC_SM_STAIN_NAME"));
									// } else {
									// damages=damages+"/"+String.valueOf(l_hmColmnData.get("WC_SM_STAIN_NAME"));
									// }

									commondetail = new DamageCommondetails();
									commondetail.setFinalName(String.valueOf(l_hmColmnData.get("WC_SM_STAIN_NAME")));
									commondetails.add(commondetail);
								}

								if (l_hmColmnData.get("WC_IDD_DAMAGE_ID") != null) {
									damagedetail = new DamagedetailsModel();
									damagedetail.setDamageID(
											Integer.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_DAMAGE_ID"))));
									damagedetail.setImagepath(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGEPATH")));
									damagedetail.setDamageName(String.valueOf(l_hmColmnData.get("WC_DM_DAMAGE_NAME")));
									damagedetail.setName(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGENAME")));
									damagedetails.add(damagedetail);
									// if (damages == "") {
									// damages=damages+String.valueOf(l_hmColmnData.get("WC_DM_DAMAGE_NAME"));
									// } else {
									// damages=damages+"/"+String.valueOf(l_hmColmnData.get("WC_DM_DAMAGE_NAME"));
									// }

									commondetail = new DamageCommondetails();
									commondetail.setFinalName(String.valueOf(l_hmColmnData.get("WC_DM_DAMAGE_NAME")));
									commondetails.add(commondetail);
								}

								if (l_hmColmnData.get("WC_IDD_COLOUR_ID") != null) {
									colordetail = new Colordetails();
									colordetail.setColorID(
											Integer.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_COLOUR_ID"))));
									colordetail.setImagepath(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGEPATH")));
									colordetail.setColorName(String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME")));
									colordetail.setName(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGENAME")));
									colordetails.add(colordetail);
									// if (damages == "") {
									// damages=damages+String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME"));
									// } else {
									// damages=damages+"/"+String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME"));
									// }

									commondetail = new DamageCommondetails();
									commondetail.setFinalName(String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME")));
									commondetails.add(commondetail);
								}

								if (l_hmColmnData.get("WC_CIQD_BRAND_ID") != null) {
									if (branddetails.size() == 0) {
										branddetail = new Branddetails();
										branddetail.setBrandID(
												Integer.valueOf(String.valueOf(l_hmColmnData.get("WC_CIQD_BRAND_ID"))));
										branddetail.setImagepath(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGEPATH")));
										branddetail.setBrandName(String.valueOf(l_hmColmnData.get("WC_BM_NAME")));
										branddetail.setName(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGENAME")));
										branddetails.add(branddetail);
									}
									// if (damages == "") {
									// damages=damages+String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME"));
									// } else {
									// damages=damages+"/"+String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME"));
									// }

									commondetail = new DamageCommondetails();
									commondetail.setFinalName(String.valueOf(l_hmColmnData.get("WC_BM_NAME")));
									commondetails.add(commondetail);
								}
								itemids.add(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_ID")));
							} else {
								// if (itemids.contains(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_ID")))) {
								if (itemid == Integer.parseInt(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_ID")))
										&& serviceid == Integer
												.parseInt(String.valueOf(l_hmColmnData.get("WC_IDD_SERVICE_ID")))) {

									itemDetailsModel.setServiceid(Utils
											.checkNullInteger(String.valueOf(l_hmColmnData.get("WC_IDD_SERVICE_ID"))));
									itemDetailsModel.setItemid(Utils
											.checkNullInteger(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_ID"))));
									itemDetailsModel
											.setServicename(String.valueOf(l_hmColmnData.get("WC_SM_SERVICE_NAME")));
									itemDetailsModel.setItemname(String.valueOf(l_hmColmnData.get("WC_IM_ITEM_NAME")));
									itemDetailsModel.setItemprice(
											Double.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_PRICE"))));
									itemDetailsModel.setItemcount(
											Integer.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_COUNT"))));
									itemDetailsModel.setIs_curtain(
											Utils.checkNullInteger(String.valueOf(l_hmColmnData.get("is_curtain"))));

									if (itemqtyid == Integer
											.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_QTY_ID")))
											|| previtemqtyid == Integer
													.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_QTY_ID")))) {
										// imagedetails.add(imagedetail);
									} else {
										imagedetail = new ImagedetailsModel();
										imagedetail.setQrcode(String.valueOf(l_hmColmnData.get("QRCODE")));
										imagedetailss.add(imagedetails);

										imagedetails = new ArrayList<>();
										imagedetails.add(imagedetail);
									}

									if (l_hmColmnData.get("WC_IDD_STAIN_ID") != null) {
										staindetail = new Staindetails();
										staindetail.setStainId(
												Integer.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_STAIN_ID"))));
										staindetail.setStainName(String.valueOf(l_hmColmnData.get("WC_SM_STAIN_NAME")));
										staindetail.setImagepath(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGEPATH")));
										staindetail.setName(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGENAME")));
										if (itemqtyid == Integer
												.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_QTY_ID")))
												|| previtemqtyid == Integer.valueOf(
														String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_QTY_ID")))) {
											staindetails.add(staindetail);
											/*
											 * if (damages == "") {
											 * damages=damages+String.valueOf(l_hmColmnData.get("WC_SM_STAIN_NAME")); }
											 * else
											 * {
											 * damages=damages+"/"+String.valueOf(l_hmColmnData.get("WC_SM_STAIN_NAME"))
											 * ;
											 * }
											 */

											commondetail = new DamageCommondetails();
											commondetail.setFinalName(
													String.valueOf(l_hmColmnData.get("WC_SM_STAIN_NAME")));
											commondetails.add(commondetail);
										} else {
											// commondetail = new Damagedetails();
											// commondetail.setName(damages);
											// commondetails.add(commondetail);

											commondetailss.add(commondetails);
											damages = "";
											commondetails = new ArrayList<>();

											commondetail = new DamageCommondetails();
											commondetail.setFinalName(
													String.valueOf(l_hmColmnData.get("WC_SM_STAIN_NAME")));
											commondetails.add(commondetail);

											staindetailss.add(staindetails);
											// staindetails.clear();
											staindetails = new ArrayList<>();
											staindetails.add(staindetail);
											damagedetailss.add(damagedetails);
											// damagedetails.clear();
											damagedetails = new ArrayList<>();
											// damagedetails.add(damagedetail);
											colordetailss.add(colordetails);
											// colordetails.clear();
											colordetails = new ArrayList<>();
											branddetailss.add(branddetails);
											// colordetails.clear();
											branddetails = new ArrayList<>();
											// colordetails.add(colordetail);
										}
									}

									if (l_hmColmnData.get("WC_IDD_DAMAGE_ID") != null) {
										damagedetail = new DamagedetailsModel();
										damagedetail.setDamageID(
												Integer.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_DAMAGE_ID"))));
										damagedetail
												.setImagepath(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGEPATH")));
										damagedetail
												.setDamageName(String.valueOf(l_hmColmnData.get("WC_DM_DAMAGE_NAME")));
										damagedetail.setName(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGENAME")));
										if (itemqtyid == Integer
												.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_QTY_ID")))
												|| previtemqtyid == Integer.valueOf(
														String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_QTY_ID")))) {
											damagedetails.add(damagedetail);
											// if (damages == "") {
											// damages=damages+String.valueOf(l_hmColmnData.get("WC_DM_DAMAGE_NAME"));
											// } else {
											// damages=damages+"/"+String.valueOf(l_hmColmnData.get("WC_DM_DAMAGE_NAME"));
											// }

											commondetail = new DamageCommondetails();
											commondetail.setFinalName(
													String.valueOf(l_hmColmnData.get("WC_DM_DAMAGE_NAME")));
											commondetails.add(commondetail);
										} else {
											// commondetail = new Damagedetails();
											// commondetail.setName(damages);
											// commondetails.add(commondetail);

											commondetailss.add(commondetails);
											damages = "";
											commondetails = new ArrayList<>();

											commondetail = new DamageCommondetails();
											commondetail.setFinalName(
													String.valueOf(l_hmColmnData.get("WC_DM_DAMAGE_NAME")));
											commondetails.add(commondetail);

											staindetailss.add(staindetails);
											// staindetails.clear();
											staindetails = new ArrayList<>();
											// staindetails.add(staindetail);
											damagedetailss.add(damagedetails);
											// damagedetails.clear();
											damagedetails = new ArrayList<>();
											damagedetails.add(damagedetail);
											colordetailss.add(colordetails);
											// colordetails.clear();
											colordetails = new ArrayList<>();
											// colordetails.add(colordetail);
											branddetailss.add(branddetails);
											// colordetails.clear();
											branddetails = new ArrayList<>();
											// colordetails.add(colordetail);
										}
									}

									if (l_hmColmnData.get("WC_IDD_COLOUR_ID") != null) {
										colordetail = new Colordetails();
										colordetail.setColorID(
												Integer.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_COLOUR_ID"))));
										colordetail.setImagepath(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGEPATH")));
										colordetail
												.setColorName(String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME")));
										colordetail.setName(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGENAME")));
										if (itemqtyid == Integer
												.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_QTY_ID")))
												|| previtemqtyid == Integer.valueOf(
														String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_QTY_ID")))) {
											colordetails.add(colordetail);
											// if (damages == "") {
											// damages=damages+String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME"));
											// } else {
											// damages=damages+"/"+String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME"));
											// }

											commondetail = new DamageCommondetails();
											commondetail.setFinalName(
													String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME")));
											commondetails.add(commondetail);
										} else {
											// commondetail = new Damagedetails();
											// commondetail.setName(damages);
											// commondetails.add(commondetail);

											commondetailss.add(commondetails);
											damages = "";
											commondetails = new ArrayList<>();

											commondetail = new DamageCommondetails();
											commondetail.setFinalName(
													String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME")));
											commondetails.add(commondetail);

											staindetailss.add(staindetails);
											// staindetails.clear();
											staindetails = new ArrayList<>();
											// staindetails.add(staindetail);
											damagedetailss.add(damagedetails);
											// damagedetails.clear();
											damagedetails = new ArrayList<>();
											// damagedetails.add(damagedetail);
											colordetailss.add(colordetails);
											// colordetails.clear();
											colordetails = new ArrayList<>();
											colordetails.add(colordetail);
											branddetailss.add(branddetails);
											// colordetails.clear();
											branddetails = new ArrayList<>();
											// colordetails.add(colordetail);
										}
									}
									if (l_hmColmnData.get("WC_CIQD_BRAND_ID") != null) {
										if (branddetails.size() == 0) {
											branddetail = new Branddetails();
											branddetail.setBrandID(Integer
													.valueOf(String.valueOf(l_hmColmnData.get("WC_CIQD_BRAND_ID"))));
											branddetail.setImagepath(
													String.valueOf(l_hmColmnData.get("WC_IDD_IMAGEPATH")));
											branddetail.setBrandName(String.valueOf(l_hmColmnData.get("WC_BM_NAME")));
											branddetail.setName(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGENAME")));

											// if (itemqtyid ==
											// Integer.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_QTY_ID")))
											// || previtemqtyid ==
											// Integer.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_QTY_ID"))))
											// {
											branddetails.add(branddetail);
											// }
											// if (damages == "") {
											// damages=damages+String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME"));
											// } else {
											// damages=damages+"/"+String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME"));
											// }

											commondetail = new DamageCommondetails();
											commondetail.setFinalName(String.valueOf(l_hmColmnData.get("WC_BM_NAME")));
											commondetails.add(commondetail);
										}
										// else {
										//// commondetail = new Damagedetails();
										//// commondetail.setName(damages);
										//// commondetails.add(commondetail);
										// commondetailss.add(commondetails);
										// damages="";
										// commondetails = new ArrayList<>();
										//
										// staindetailss.add(staindetails);
										//// staindetails.clear();
										// staindetails = new ArrayList<>();
										//// staindetails.add(staindetail);
										// damagedetailss.add(damagedetails);
										//// damagedetails.clear();
										// damagedetails = new ArrayList<>();
										//// damagedetails.add(damagedetail);
										// colordetailss.add(colordetails);
										//// colordetails.clear();
										// colordetails = new ArrayList<>();
										//// colordetails.add(colordetail);
										//// branddetailss.add(branddetails);
										//// colordetails.clear();
										//// branddetails = new ArrayList<>();
										//// branddetails.add(branddetail);
										// }
									}
									itemids.add(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_ID")));
									if (itemqtyid != Integer
											.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_QTY_ID")))) {
										previtemqtyid = itemqtyid;
										itemqtyid = Integer
												.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_QTY_ID")));
									}
								} else {
									// commondetail = new Damagedetails();
									// commondetail.setName(damages);
									// commondetails.add(commondetail);
									if (commondetails.size() > 0) {
										commondetailss.add(commondetails);
									}
									// else {
									// commondetailss.add(new ArrayList<>());
									// }
									damages = "";
									commondetails = new ArrayList<>();

									if (staindetails.size() > 0) {
										staindetailss.add(staindetails);
									}
									// else {
									// staindetailss.add(new ArrayList<>());
									// }
									if (damagedetails.size() > 0) {
										damagedetailss.add(damagedetails);
									}
									// else {
									// damagedetailss.add(new ArrayList<>());
									// }
									if (colordetails.size() > 0) {
										colordetailss.add(colordetails);
									}
									// else {
									// colordetailss.add(new ArrayList<>());
									// }
									// commondetailss.add(commondetails);
									if (branddetails.size() > 0) {
										branddetailss.add(branddetails);
									}

									if (imagedetails.size() > 0) {
										imagedetailss.add(imagedetails);
									}

									itemDetailsModel.setDamagedetails(damagedetailss);
									itemDetailsModel.setStaindetails(staindetailss);
									itemDetailsModel.setColordetails(colordetailss);
									itemDetailsModel.setBranddetails(branddetailss);
									itemDetailsModel.setCommondetails(commondetailss);
									itemDetailsModel.setImagedetails(imagedetailss);
									itemDetailsModels.add(itemDetailsModel);

									// damagedetails.clear();
									// staindetails.clear();
									// colordetails.clear();
									damagedetails = new ArrayList<>();
									staindetails = new ArrayList<>();
									colordetails = new ArrayList<>();
									branddetails = new ArrayList<>();
									commondetails = new ArrayList<>();
									imagedetails = new ArrayList<>();

									// damagedetailss.clear();
									// staindetailss.clear();
									// colordetailss.clear();
									damagedetailss = new ArrayList<>();
									staindetailss = new ArrayList<>();
									colordetailss = new ArrayList<>();
									branddetailss = new ArrayList<>();
									commondetailss = new ArrayList<>();
									imagedetailss = new ArrayList<>();

									itemDetailsModel = new CollectItemDamageDetailsModel();

									itemDetailsModel.setServiceid(Utils
											.checkNullInteger(String.valueOf(l_hmColmnData.get("WC_IDD_SERVICE_ID"))));
									itemDetailsModel.setItemid(Utils
											.checkNullInteger(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_ID"))));
									itemDetailsModel
											.setServicename(String.valueOf(l_hmColmnData.get("WC_SM_SERVICE_NAME")));
									itemDetailsModel.setItemname(String.valueOf(l_hmColmnData.get("WC_IM_ITEM_NAME")));
									itemDetailsModel.setItemprice(
											Double.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_PRICE"))));
									itemDetailsModel.setItemcount(
											Integer.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_COUNT"))));
									itemDetailsModel.setIs_curtain(
											Utils.checkNullInteger(String.valueOf(l_hmColmnData.get("is_curtain"))));

									imagedetail = new ImagedetailsModel();
									imagedetail.setQrcode(String.valueOf(l_hmColmnData.get("QRCODE")));
									imagedetails.add(imagedetail);

									if (l_hmColmnData.get("WC_IDD_STAIN_ID") != null) {
										staindetail = new Staindetails();
										staindetail.setStainId(
												Integer.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_STAIN_ID"))));
										staindetail.setImagepath(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGEPATH")));
										staindetail.setStainName(String.valueOf(l_hmColmnData.get("WC_SM_STAIN_NAME")));
										staindetail.setName(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGENAME")));
										staindetails.add(staindetail);
										// if (damages == "") {
										// damages=damages+String.valueOf(l_hmColmnData.get("WC_SM_STAIN_NAME"));
										// } else {
										// damages=damages+"/"+String.valueOf(l_hmColmnData.get("WC_SM_STAIN_NAME"));
										// }

										commondetail = new DamageCommondetails();
										commondetail
												.setFinalName(String.valueOf(l_hmColmnData.get("WC_SM_STAIN_NAME")));
										commondetails.add(commondetail);

									}

									if (l_hmColmnData.get("WC_IDD_DAMAGE_ID") != null) {
										damagedetail = new DamagedetailsModel();
										damagedetail.setDamageID(
												Integer.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_DAMAGE_ID"))));
										damagedetail
												.setImagepath(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGEPATH")));
										damagedetail
												.setDamageName(String.valueOf(l_hmColmnData.get("WC_DM_DAMAGE_NAME")));
										damagedetail.setName(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGENAME")));
										damagedetails.add(damagedetail);
										// if (damages == "") {
										// damages=damages+String.valueOf(l_hmColmnData.get("WC_DM_DAMAGE_NAME"));
										// } else {
										// damages=damages+"/"+String.valueOf(l_hmColmnData.get("WC_DM_DAMAGE_NAME"));
										// }
										commondetail = new DamageCommondetails();
										commondetail
												.setFinalName(String.valueOf(l_hmColmnData.get("WC_DM_DAMAGE_NAME")));
										commondetails.add(commondetail);
									}

									if (l_hmColmnData.get("WC_IDD_COLOUR_ID") != null) {
										colordetail = new Colordetails();
										colordetail.setColorID(
												Integer.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_COLOUR_ID"))));
										colordetail.setImagepath(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGEPATH")));
										colordetail
												.setColorName(String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME")));
										colordetail.setName(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGENAME")));
										colordetails.add(colordetail);
										// if (damages == "") {
										// damages=damages+String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME"));
										// } else {
										// damages=damages+"/"+String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME"));
										// }
										commondetail = new DamageCommondetails();
										commondetail
												.setFinalName(String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME")));
										commondetails.add(commondetail);
									}
									if (l_hmColmnData.get("WC_CIQD_BRAND_ID") != null) {
										if (branddetails.size() == 0) {
											branddetail = new Branddetails();
											branddetail.setBrandID(Integer
													.valueOf(String.valueOf(l_hmColmnData.get("WC_CIQD_BRAND_ID"))));
											branddetail.setImagepath(
													String.valueOf(l_hmColmnData.get("WC_IDD_IMAGEPATH")));
											branddetail.setBrandName(String.valueOf(l_hmColmnData.get("WC_BM_NAME")));
											branddetail.setName(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGENAME")));
											branddetails.add(branddetail);
										}
										// if (damages == "") {
										// damages=damages+String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME"));
										// } else {
										// damages=damages+"/"+String.valueOf(l_hmColmnData.get("WC_CM_COLOUR_NAME"));
										// }
										commondetail = new DamageCommondetails();
										commondetail.setFinalName(String.valueOf(l_hmColmnData.get("WC_BM_NAME")));
										commondetails.add(commondetail);
									}

									itemids.add(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_ID")));
									itemqtyid = Integer
											.valueOf(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_QTY_ID")));
									itemid = Integer.parseInt(String.valueOf(l_hmColmnData.get("WC_IDD_ITEM_ID")));
									serviceid = Integer
											.parseInt(String.valueOf(l_hmColmnData.get("WC_IDD_SERVICE_ID")));
									previtemqtyid = 0;
								}
							}
						} else {

						}
					}
					if (itemids.size() == 1) {
						// commondetail = new Damagedetails();
						// commondetail.setName(damages);
						// commondetails.add(commondetail);
						commondetailss.add(commondetails);
						damages = "";
						commondetails = new ArrayList<>();
						damagedetailss.add(damagedetails);
						staindetailss.add(staindetails);
						colordetailss.add(colordetails);
						branddetailss.add(branddetails);
						imagedetailss.add(imagedetails);

						itemDetailsModel.setDamagedetails(damagedetailss);
						itemDetailsModel.setStaindetails(staindetailss);
						itemDetailsModel.setColordetails(colordetailss);
						itemDetailsModel.setBranddetails(branddetailss);
						itemDetailsModel.setCommondetails(commondetailss);
						itemDetailsModel.setImagedetails(imagedetailss);

						itemDetailsModels.add(itemDetailsModel);
					} else if (damagedetails.size() > 0 || staindetails.size() > 0 || colordetails.size() > 0
							|| commondetails.size() > 0 || imagedetails.size() > 0) {
						// commondetail = new Damagedetails();
						// commondetail.setName(damages);
						// commondetails.add(commondetail);
						commondetailss.add(commondetails);
						damages = "";
						commondetails = new ArrayList<>();

						staindetailss.add(staindetails);
						damagedetailss.add(damagedetails);
						colordetailss.add(colordetails);
						branddetailss.add(branddetails);

						imagedetailss.add(imagedetails);
						// commondetailss.add(commondetails);

						itemDetailsModel.setDamagedetails(damagedetailss);
						itemDetailsModel.setStaindetails(staindetailss);
						itemDetailsModel.setColordetails(colordetailss);
						itemDetailsModel.setBranddetails(branddetailss);
						itemDetailsModel.setCommondetails(commondetailss);
						itemDetailsModel.setImagedetails(imagedetailss);

						itemDetailsModels.add(itemDetailsModel);
					} else if (damagedetails.size() == 0 || staindetails.size() == 0 || colordetails.size() == 0
							|| commondetails.size() == 0 || imagedetails.size() > 0) {
						if (commondetails.size() > 0) {
							commondetailss.add(commondetails);
						}
						// else {
						// commondetailss.add(new ArrayList<>());
						// }
						damages = "";
						commondetails = new ArrayList<>();
						if (staindetails.size() > 0) {
							staindetailss.add(staindetails);
						}
						// else {
						// staindetailss.add(new ArrayList<>());
						// }
						if (damagedetails.size() > 0) {
							damagedetailss.add(damagedetails);
						}
						// else {
						// damagedetailss.add(new ArrayList<>());
						// }
						if (colordetails.size() > 0) {
							colordetailss.add(colordetails);
						}
						// else {
						// colordetailss.add(new ArrayList<>());
						// }
						if (branddetails.size() > 0) {
							branddetailss.add(branddetails);
						}

						if (imagedetails.size() > 0) {
							imagedetailss.add(imagedetails);
						}

						itemDetailsModel.setDamagedetails(damagedetailss);
						itemDetailsModel.setStaindetails(staindetailss);
						itemDetailsModel.setColordetails(colordetailss);
						itemDetailsModel.setBranddetails(branddetailss);
						itemDetailsModel.setCommondetails(commondetailss);
						itemDetailsModel.setImagedetails(imagedetailss);
						itemDetailsModels.add(itemDetailsModel);
					}

					if (itemDetailsModels.size() > 0) {
						properties.put("itemdamagedetails", itemDetailsModels);
					} else {
						properties.put("itemdamagedetails", new ArrayList<>());
					}
				}
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getchallanmasterexport(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_CHALLAN_MASTER_EXPORT(?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getchallanmaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getprocessingmaster(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_PROCESSING_MASTER(?,?,?,?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());
				callableStatement.setInt(3, chalanMasterRequestModel.getStart());
				callableStatement.setInt(4, chalanMasterRequestModel.getEnd());
				callableStatement.setString(5, chalanMasterRequestModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getchallanmaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getprocessdetailsbyitems(PickupDetailsByItemsReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.BOOLEAN));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_PROCESS_DETAILS_BY_ITEMS(?,?,?,?)}");

				callableStatement.setLong(1, reqModel.getOrderid());
				callableStatement.setString(2, reqModel.getQrcode());
				callableStatement.setInt(3, reqModel.getInvoiceid());
				callableStatement.setBoolean(4, reqModel.getProcessflag());

				return callableStatement;

			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			int count = 0;
			for (String key : set) {
				count++;
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				if (count == 1) {
					properties.put("getprocessdetailsbyitems", l_lstResult);
				} else {
					properties.put("specialinstructions", l_lstResult);
				}
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getprocessstepsbyserviceid(ProcessStepsByServiceIdReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_PROCESS_STEPS_BY_SERVICEID(?,?)}");

				callableStatement.setLong(1, reqModel.getServiceid());
				callableStatement.setString(2, reqModel.getOrcode());

				return callableStatement;

			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("getprocessdetailsbyitems", l_lstResult);
				}
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertupdateprocessingstatus(ProcessStatusReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		// ProcessStatusResModel processStatusResModel = new ProcessStatusResModel();

		try {
			// List<ProcessStatusResModel> processStatusResModels = new
			// ArrayList<ProcessStatusResModel>();
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.STRUCT));

			SQLServerDataTable menuUser = new SQLServerDataTable();
			menuUser.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			menuUser.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			menuUser.addColumnMetadata("ITEMCOUNT", java.sql.Types.INTEGER);
			menuUser.addColumnMetadata("QRCODE", java.sql.Types.VARCHAR);

			for (ProcessDetailsModel d : reqModel.getDetails()) {
				menuUser.addRow(d.getServiceid(), d.getItemid(), d.getItemcount(), d.getQrcode());
			}

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_PROCESS_STATUS + "(?,?,?,?,?,?)}");

				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					if (reqModel.getUserid() != null) {
						cs.setLong(1, reqModel.getUserid());
					} else {
						cs.setString(1, null);
					}

					if (reqModel.getCustomerid() != null) {
						cs.setLong(2, reqModel.getCustomerid());
					} else {
						cs.setString(2, null);
					}

					if (reqModel.getOrderid() != null) {
						cs.setLong(3, reqModel.getOrderid());
					} else {
						cs.setString(3, null);
					}

					if (reqModel.getStepsid() != null) {
						cs.setInt(4, reqModel.getStepsid());
					} else {
						cs.setString(4, null);
					}
					cs.setString(5, reqModel.getRemarks());
					cs.setStructured(6, "dbo.UTT_PROCESS_DETAILS", menuUser);
					// cs.execute();
				}
				return callableStatement;
			}, prmtrsList);

			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties

			// List<ProcessStatusResModel> processStatusResModels = new ArrayList<>();
			// ProcessStatusResModel processStatusResModel = null;
			HashMap<String, Object> properties = new HashMap<>();
			ProcessStatusResModel processStatusResModel = new ProcessStatusResModel();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);

					for (int i = 0; i < l_lstResult.size(); i++) {
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);

						processStatusResModel.setStatus(Integer.valueOf(String.valueOf(l_hmColmnData.get("status"))));
						if (processStatusResModel.getStatus() == 200) {
							processStatusResModel.setMessage(String.valueOf(l_hmColmnData.get("message")));
							processStatusResModel.setMobileno(String.valueOf(l_hmColmnData.get("mobile_no")));
							processStatusResModel.setFlag(Integer.valueOf(String.valueOf(l_hmColmnData.get("flag"))));
							processStatusResModel.setContent(String.valueOf(l_hmColmnData.get("content")));

						}
						if (processStatusResModel.getStatus() == 400) {
							processStatusResModel.setMessage(String.valueOf(l_hmColmnData.get("message")));
						}
						properties.put("processstatusresponse", l_lstResult);
						// processStatusResModels.add(processStatusResModel);

					}
				}
				responseModel.setStatusCode(200);
				MyObject object = new MyObject(properties);
				responseModel.setResponseObject(object);
				responseModel.setResponseObj(processStatusResModel);
			}
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		log.info("res" + responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getdispatchdetailss(DispatchDetailsReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_DISPATCH_DETAILS(?)}");

				if (reqModel.getUserid() != null) {
					callableStatement.setLong(1, reqModel.getUserid());
				} else {
					callableStatement.setString(1, null);
				}

				return callableStatement;

			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getprocessdetailsbyitems", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertupdatedispatchdetails(DispatchDetailsRequestModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			SQLServerDataTable menuUser = new SQLServerDataTable();
			menuUser.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			menuUser.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			menuUser.addColumnMetadata("ITEMCOUNT", java.sql.Types.INTEGER);
			menuUser.addColumnMetadata("QRCODE", java.sql.Types.VARCHAR);

			for (ProcessDetailsModel d : reqModel.getDetails()) {
				menuUser.addRow(d.getServiceid(), d.getItemid(), d.getItemcount(), d.getQrcode());
			}

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall(
								"{call " + CommonConstants.USP_INSERT_UPDATE_DISPATCH_DETAILS + "(?,?,?,?,?,?,?,?)}");

				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					if (reqModel.getUserid() != null) {
						cs.setLong(1, reqModel.getUserid());
					} else {
						cs.setString(1, null);
					}

					if (reqModel.getCustomerid() != null) {
						cs.setLong(2, reqModel.getCustomerid());
					} else {
						cs.setString(2, null);
					}

					if (reqModel.getOrderid() != null) {
						cs.setLong(3, reqModel.getOrderid());
					} else {
						cs.setString(3, null);
					}

					if (reqModel.getAssignto() != null) {
						cs.setLong(4, reqModel.getAssignto());
					} else {
						cs.setString(4, null);
					}

					cs.setString(5, reqModel.getDeliverydatetime());
					cs.setString(6, reqModel.getRemarks());
					cs.setStructured(7, "dbo.UTT_PROCESS_DETAILS", menuUser);
					if (reqModel.getInvoiceid() != null) {
						cs.setLong(8, reqModel.getInvoiceid());
					} else {
						cs.setString(8, null);
					}
					// cs.execute();
				}

				return callableStatement;
			}, prmtrsList);

			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("dispatchresponse", l_lstResult);
				}
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		log.info("res" + responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getstatusdetails(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_STATUS_DETAILS(?,?,?,?,?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());
				callableStatement.setInt(3, chalanMasterRequestModel.getStart());
				callableStatement.setInt(4, chalanMasterRequestModel.getEnd());
				callableStatement.setString(5, chalanMasterRequestModel.getStatus());
				callableStatement.setString(6, chalanMasterRequestModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getchallanmaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getprocessingmasterexport(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_PROCESSING_MASTER_EXPORT(?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getchallanmaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getpickupdetailsfilter() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_PICKUP_DETAILS_FILTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getpickupdetailsfilter", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getdetailsbyqrcode(PickupDetailsByItemsReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_DETAILS_BY_QRCODE(?,?)}");

				callableStatement.setLong(1, reqModel.getOrderid());
				callableStatement.setString(2, reqModel.getQrcode());

				return callableStatement;

			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			int count = 0;
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				count++;
				if (count == 1) {
					properties.put("orderResponse", l_lstResult);
				} else if (count == 2) {
					properties.put("specialinstruction", l_lstResult);
				} else if (count == 3) {
					properties.put("autoapprovals", l_lstResult);
				}
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getdeliverychallandetails(PickupDetailsByItemsReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_DELIVERY_CHALLAN_DETAILS(?,?)}");

				callableStatement.setLong(1, reqModel.getOrderid());
				callableStatement.setLong(2, reqModel.getInvoicecode());

				return callableStatement;

			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			int count = 0;
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				count++;
				if (count == 1) {
					properties.put("orderResponse", l_lstResult);
				} else if (count == 2) {
					properties.put("specialinstruction", l_lstResult);
				} else if (count == 3) {
					properties.put("autoapprovals", l_lstResult);
				}
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getstatusdetailsexport(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_STATUS_DETAILS_EXPORT(?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getstatusdetailsexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getreceiveddetails(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_RECEIVED_DETAILS(?,?,?,?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());
				callableStatement.setInt(3, chalanMasterRequestModel.getStart());
				callableStatement.setInt(4, chalanMasterRequestModel.getEnd());
				callableStatement.setString(5, chalanMasterRequestModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getreceiveddetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getreceiveitemdetails(ReceiveItemDetailsReqModel reciveItemDetailsReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_RECEIVE_DETAILS(?,?,?,?,?,?,?)}");
				callableStatement.setString(1, reciveItemDetailsReqModel.getScanqrcode());
				callableStatement.setDate(2, reciveItemDetailsReqModel.getStartdate());
				callableStatement.setDate(3, reciveItemDetailsReqModel.getEnddate());
				callableStatement.setInt(4, reciveItemDetailsReqModel.getStart());
				callableStatement.setInt(5, reciveItemDetailsReqModel.getEnd());
				callableStatement.setString(6, reciveItemDetailsReqModel.getSearch());
				callableStatement.setString(7, reciveItemDetailsReqModel.getHandovercode());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getreceiveitemdetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel updatereceiveitemdetails(ReceivedItemDetailsReqModel reqModel) throws SQLServerException {

		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			SQLServerDataTable receivedDetails = new SQLServerDataTable();
			receivedDetails.addColumnMetadata("UTTORDERID", java.sql.Types.BIGINT);
			receivedDetails.addColumnMetadata("INVOICEID", java.sql.Types.BIGINT);

			for (ReceivedItemDetails d : reqModel.getReceivedItemDetails()) {
				receivedDetails.addRow(d.getOrderid(), d.getInvoiceid());
			}

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_UPDATE_RECEIVE_ITEM_DETAILS(?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					cs.setStructured(1, "dbo.UTT_RECEIVED_ITEM_DETAILS", receivedDetails);
					cs.setLong(2, reqModel.getUserid());

					// cs.execute();
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info("set--" + set);
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("Response", l_lstResult);
			}
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} // log.info("responseModel---"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertupdatesocity(SocietyReqModel socityReqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.STRUCT));

			SQLServerDataTable riderids = new SQLServerDataTable();
			riderids.addColumnMetadata("RIDERID", java.sql.Types.INTEGER);

			for (RiderInstructionReqModel d : socityReqModel.getRiderids()) {
				riderids.addRow(d.getRiderid());
			}

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall(
								"{call " + CommonConstants.USP_INSERT_UPDATE_SOCITY + "(?,?,?,?,?,?,?,?,?,?,?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");

					if (socityReqModel.getSocietyid() != null) {
						callableStatement.setLong(1, socityReqModel.getSocietyid());
					} else {
						callableStatement.setString(1, null);
					}
					if (socityReqModel.getSocietyname() != null) {
						callableStatement.setString(2, socityReqModel.getSocietyname());
					} else {
						callableStatement.setString(2, null);
					}
					if (socityReqModel.getSocietyaddress() != null) {
						callableStatement.setString(3, socityReqModel.getSocietyaddress());
					} else {
						callableStatement.setString(3, null);
					}
					if (socityReqModel.getPincode() != null) {
						callableStatement.setLong(4, socityReqModel.getPincode());
					} else {
						callableStatement.setString(4, null);
					}
					if (socityReqModel.getBoundry() != null) {
						callableStatement.setString(5, socityReqModel.getBoundry());
					} else {
						callableStatement.setString(5, null);
					}
					if (socityReqModel.getLatitude() != null) {
						callableStatement.setString(6, socityReqModel.getLatitude());
					} else {
						callableStatement.setString(6, null);
					}
					if (socityReqModel.getLongitude() != null) {
						callableStatement.setString(7, socityReqModel.getLongitude());
					} else {
						callableStatement.setString(7, null);
					}
					if (socityReqModel.getStatus() != null) {
						callableStatement.setLong(8, socityReqModel.getStatus());
					} else {
						callableStatement.setString(8, null);
					}
					if (socityReqModel.getRemarks() != null) {
						callableStatement.setString(9, socityReqModel.getRemarks());
					} else {
						callableStatement.setString(9, null);
					}
					if (socityReqModel.getImagepath() != null) {
						callableStatement.setString(10, socityReqModel.getImagepath());
					} else {
						callableStatement.setString(10, null);
					}
					if (socityReqModel.getFilename() != null) {
						callableStatement.setString(11, socityReqModel.getFilename());
					} else {
						callableStatement.setString(11, null);
					}
					if (socityReqModel.getUserid() != null) {
						callableStatement.setLong(12, socityReqModel.getUserid());
					} else {
						callableStatement.setString(12, null);
					}
					cs.setStructured(13, "dbo.UTT_RIDER_INSTRUCTION", riderids);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("insertupdatesocity", l_lstResult);
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getsocietydetails(SocietyDetailsReqModel societyDetailsReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_SOCIETY_DETAILS(?,?,?,?)}");

				callableStatement.setInt(1, societyDetailsReqModel.getStart());
				callableStatement.setInt(2, societyDetailsReqModel.getEnd());
				callableStatement.setString(3, societyDetailsReqModel.getStatus());
				callableStatement.setString(4, societyDetailsReqModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			int count = 0;
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				count++;
				if (count == 1) {
					properties.put("getsocietydetails", l_lstResult);
				} else if (count == 2) {
					properties.put("riderlist", l_lstResult);
				}

			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel updatesocietydetails(UpdateSocietyReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_UPDATE_SOCIETY_DETAILS(?)}");
				callableStatement.setLong(1, reqModel.getSocietyid());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("updatesocietydetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getsocietydetailsexport(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_SOCIETY_DETAILS_EXPORT(?,?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());
				callableStatement.setString(3, chalanMasterRequestModel.getStatus());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getsocietydetailsexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getreceiveddetailsexport(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_RECEIVED_DETAILS_EXPORT(?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getreceiveddetailsexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getreceivedetailsexport(ReceiveDtailsExportReqModel receivedDetailsExportReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_RECEIVE_DETAILS_EXPORT(?)}");
				callableStatement.setString(1, receivedDetailsExportReqModel.getHandovercode());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getreceivedetailsexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getmanageinovice(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_MANAGE_INVOICE(?,?,?,?,?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());
				callableStatement.setInt(3, chalanMasterRequestModel.getStart());
				callableStatement.setInt(4, chalanMasterRequestModel.getEnd());
				callableStatement.setString(5, chalanMasterRequestModel.getStatus());
				callableStatement.setString(6, chalanMasterRequestModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getchallanmaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getmanageinvoiceexport(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_MANAGE_INVOICE_EXPORT(?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getmanageinvoiceexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getpaymentstatus(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_PAYMENT_STATUS(?,?,?,?,?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());
				callableStatement.setInt(3, chalanMasterRequestModel.getStart());
				callableStatement.setInt(4, chalanMasterRequestModel.getEnd());
				callableStatement.setString(5, chalanMasterRequestModel.getStatus());
				callableStatement.setString(6, chalanMasterRequestModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getpaymentstatus", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel updatecashreceivedetails(ReceivedItemDetailsReqModel reqModel) throws SQLServerException {

		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			SQLServerDataTable receivedItemDetails = new SQLServerDataTable();
			receivedItemDetails.addColumnMetadata("UTTORDERID", java.sql.Types.BIGINT);
			receivedItemDetails.addColumnMetadata("INVOICEID", java.sql.Types.BIGINT);

			for (ReceivedItemDetails d : reqModel.getReceivedItemDetails()) {
				receivedItemDetails.addRow(d.getOrderid(), d.getInvoiceid());
			}

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_UPDATE_CASH_RECEIVE_ITEM_DETAILS(?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					cs.setStructured(1, "dbo.UTT_RECEIVED_ITEM_DETAILS", receivedItemDetails);
					cs.setLong(2, reqModel.getUserid());

					// cs.execute();
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info("set--" + set);
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("Response", l_lstResult);
			}
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} // log.info("responseModel---"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getcashreceiveddetails(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_CASH_RECEIVED_DETAILS(?,?,?,?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());
				callableStatement.setInt(3, chalanMasterRequestModel.getStart());
				callableStatement.setInt(4, chalanMasterRequestModel.getEnd());
				callableStatement.setString(5, chalanMasterRequestModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getcashreceiveddetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getcashreceivedetails(ReceiveItemDetailsReqModel reciveItemDetailsReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_CASH_RECEIVE_DETAILS(?,?,?,?,?,?)}");
				callableStatement.setInt(1, reciveItemDetailsReqModel.getStart());
				callableStatement.setInt(2, reciveItemDetailsReqModel.getEnd());
				callableStatement.setDate(3, reciveItemDetailsReqModel.getStartdate());
				callableStatement.setDate(4, reciveItemDetailsReqModel.getEnddate());
				callableStatement.setString(5, reciveItemDetailsReqModel.getHandovercode());
				callableStatement.setString(6, reciveItemDetailsReqModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getcashreceivedetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getpaymentstatusdetailsexport(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_PAYMENT_STATUS_DETAILS_EXPORT(?,?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());
				callableStatement.setString(3, chalanMasterRequestModel.getStatus());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getpaymentstatusdetailsexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getcashreceivedetailsexport(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_CASH_RECEIVE_DETAILS_EXPORT(?,?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());
				callableStatement.setString(2, chalanMasterRequestModel.getHandover());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getcashreceivedetailsexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getcashreceiveddetailsexport(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_CASH_RECEIVED_DETAILS_EXPORT(?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getcashreceiveddetailsexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertupdatewalletconfiguration(WalletConfigurationReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall(
								"{call " + CommonConstants.USP_INSERT_UPDATE_WALLET_CONFIGURATION + "(?,?,?,?,?,?)}");

				if (reqModel.getOfferid() != null) {
					callableStatement.setInt(1, reqModel.getOfferid());
				} else {
					callableStatement.setString(1, null);
				}

				if (reqModel.getFromamount() != null) {
					callableStatement.setString(2, reqModel.getFromamount());
				} else {
					callableStatement.setString(2, null);
				}

				if (reqModel.getToamount() != null) {
					callableStatement.setString(3, reqModel.getToamount());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getStatus() != null) {
					callableStatement.setLong(4, reqModel.getStatus());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getCreditpercentage() != null) {
					callableStatement.setLong(5, reqModel.getCreditpercentage());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getCreditamount() != null) {
					callableStatement.setDouble(6, reqModel.getCreditamount());
				} else {
					callableStatement.setString(6, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("insertupdatewalletconfiguration", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		log.info("res" + responseModel);
		return responseModel;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getwalletconfiguration(SocietyDetailsReqModel societyDetailsReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_WALLET_CONFIGURATION(?,?,?,?)}");

				callableStatement.setInt(1, societyDetailsReqModel.getStart());
				callableStatement.setInt(2, societyDetailsReqModel.getEnd());
				callableStatement.setString(3, societyDetailsReqModel.getStatus());
				callableStatement.setString(4, societyDetailsReqModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getsocietydetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel updatewalletconfiguration(UpdateWalletConfigurationReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_UPDATE_WALLET_CONFIGURATION(?)}");
				callableStatement.setLong(1, reqModel.getOfferid());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("updatewalletconfiguration", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getwalletconfigurationexport(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_WALLET_CONFIGURATION_EXPORT(?)}");

				callableStatement.setString(1, chalanMasterRequestModel.getStatus());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getwalletconfigurationexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getwalletDetailsList(SocietyDetailsReqModel societyDetailsReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_WALLET_DETAILS_LIST(?,?,?)}");

				callableStatement.setInt(1, societyDetailsReqModel.getStart());
				callableStatement.setInt(2, societyDetailsReqModel.getEnd());
				callableStatement.setString(3, societyDetailsReqModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getwalletDetailsList", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getwalletDetailsListExport() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_WALLET_DETAILS_LIST_EXPORT + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getwalletDetailsListExport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertupdateCustInfo(CustomerDetailsReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR)); // panimage
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.BOOLEAN));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_CUST_INFO
								+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

				if (reqModel.getCustomerid() != null) {
					callableStatement.setLong(1, reqModel.getCustomerid());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getUserid() != null) {
					callableStatement.setLong(2, reqModel.getUserid());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getCustomername() != null) {
					callableStatement.setString(3, reqModel.getCustomername());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getEmail() != null) {
					callableStatement.setString(4, reqModel.getEmail());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getMobileno() != null) {
					callableStatement.setString(5, reqModel.getMobileno());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getBillingname() != null) {
					callableStatement.setString(6, reqModel.getBillingname());
				} else {
					callableStatement.setString(6, null);
				}
				if (reqModel.getBillingmobile() != null) {
					callableStatement.setString(7, reqModel.getBillingmobile());
				} else {
					callableStatement.setString(7, null);
				}
				if (reqModel.getGenderid() != null) {
					callableStatement.setLong(8, reqModel.getGenderid());
				} else {
					callableStatement.setString(8, null);
				}
				if (reqModel.getDob() != null) {
					callableStatement.setDate(9, reqModel.getDob());
				} else {
					callableStatement.setString(9, null);
				}
				if (reqModel.getDoa() != null) {
					callableStatement.setDate(10, reqModel.getDoa());
				} else {
					callableStatement.setString(10, null);
				}
				if (reqModel.getPan_no() != null) {
					callableStatement.setString(11, reqModel.getPan_no());
				} else {
					callableStatement.setString(11, null);
				}
				if (reqModel.getImagepath() != null) {
					callableStatement.setString(12, reqModel.getImagepath());
				} else {
					callableStatement.setString(12, null);
				}
				if (reqModel.getGst_no() != null) {
					callableStatement.setString(13, reqModel.getGst_no());
				} else {
					callableStatement.setString(13, null);
				}
				if (reqModel.getAddress() != null) {
					callableStatement.setString(14, reqModel.getAddress());
				} else {
					callableStatement.setString(14, null);
				}
				if (reqModel.getPincode() != null) {
					callableStatement.setString(15, reqModel.getPincode());
				} else {
					callableStatement.setString(15, null);
				}
				if (reqModel.getFloor() != null) {
					callableStatement.setString(16, reqModel.getFloor());
				} else {
					callableStatement.setString(16, null);
				}
				if (reqModel.getLandmark() != null) {
					callableStatement.setString(17, reqModel.getLandmark());
				} else {
					callableStatement.setString(17, null);
				}
				if (reqModel.getStart() != null) {
					callableStatement.setInt(18, reqModel.getStart());
				} else {
					callableStatement.setString(18, null);
				}
				if (reqModel.getEnd() != null) {
					callableStatement.setInt(19, reqModel.getEnd());
				} else {
					callableStatement.setString(19, null);
				}
				if (reqModel.getSearch() != null) {
					callableStatement.setString(20, reqModel.getSearch());
				} else {
					callableStatement.setString(20, null);
				}
				if (reqModel.getFlag() != null) {
					callableStatement.setInt(21, reqModel.getFlag());
				} else {
					callableStatement.setString(21, null);
				}
				if (reqModel.getStatus() != null) {
					callableStatement.setBoolean(22, reqModel.getStatus());
				} else {
					callableStatement.setString(22, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("insertupdateCustInfo", l_lstResult);
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getautomaticprocessdetails(AutomaticProcessReqModel automaticProcessReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_AUTOMATIC_PROCESS_DETAILS(?,?)}");

				callableStatement.setString(1, automaticProcessReqModel.getQrcode());
				callableStatement.setLong(2, automaticProcessReqModel.getUserid());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			int count = 0;
			for (String key : set) {
				count++;
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				if (count == 1) {
					properties.put("itemdetails", l_lstResult);
				} else if (count == 2) {
					properties.put("specialinstructiondetails", l_lstResult);
				} else if (count == 3) {
					properties.put("stepsdetails", l_lstResult);
				} else if (count == 4) {
					properties.put("remarks", l_lstResult);
				} else if (count == 5) {
					properties.put("autoapprovals", l_lstResult);
				}
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertupdateautomaticprocessingstatus(InsertAutomaticProcessStepsReqModel reqModel)
			throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.STRUCT));

			SQLServerDataTable menuUser = new SQLServerDataTable();
			menuUser.addColumnMetadata("STEPSID", java.sql.Types.INTEGER);
			menuUser.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			menuUser.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			menuUser.addColumnMetadata("ITEMCOUNT", java.sql.Types.INTEGER);
			menuUser.addColumnMetadata("QRCODE", java.sql.Types.VARCHAR);

			for (AutomaticProcessModel d : reqModel.getDetails()) {
				menuUser.addRow(d.getStepsid(), d.getServiceid(), d.getItemid(), d.getItemcount(), d.getQrcode());
			}

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall(
								"{call " + CommonConstants.USP_INSERT_UPDATE_AUTOMATIC_PROCESS_STATUS + "(?,?,?,?,?)}");

				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					if (reqModel.getUserid() != null) {
						cs.setLong(1, reqModel.getUserid());
					} else {
						cs.setString(1, null);
					}

					if (reqModel.getCustomerid() != null) {
						cs.setLong(2, reqModel.getCustomerid());
					} else {
						cs.setString(2, null);
					}

					if (reqModel.getOrderid() != null) {
						cs.setLong(3, reqModel.getOrderid());
					} else {
						cs.setString(3, null);
					}

					cs.setString(4, reqModel.getRemarks());
					cs.setStructured(5, "dbo.UTT_STEPS_ID", menuUser);
					// cs.execute();
				}
				return callableStatement;
			}, prmtrsList);

			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			ProcessStatusResModel processStatusResModel = new ProcessStatusResModel();
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					for (int i = 0; i < l_lstResult.size(); i++) {
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);

						processStatusResModel.setStatus(Integer.valueOf(String.valueOf(l_hmColmnData.get("status"))));
						if (processStatusResModel.getStatus() == 200) {
							processStatusResModel.setMessage(String.valueOf(l_hmColmnData.get("message")));
							processStatusResModel.setMobileno(String.valueOf(l_hmColmnData.get("mobile_no")));
							processStatusResModel.setFlag(Integer.valueOf(String.valueOf(l_hmColmnData.get("flag"))));
							processStatusResModel.setContent(String.valueOf(l_hmColmnData.get("content")));

						} else if (processStatusResModel.getStatus() == 400) {
							processStatusResModel.setMessage(String.valueOf(l_hmColmnData.get("message")));
						}

						// processStatusResModels.add(processStatusResModel);

					}

					properties.put("insertupdateautomaticprocessingstatus", l_lstResult);
				}
			}

			// MyObject object = new MyObject(properties);
			responseModel.setResponseObj(processStatusResModel);
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		log.info("res" + responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getcustInfoDetailsExport() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_CUST_INFO_DETAILS_EXPORT + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getcustInfoDetailsExport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getstainmasternew(StainMasterNewReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_STAIN_MASTERS_NEW + "(?,?,?,?,?,?,?,?,?,?)}");

				if (reqModel.getFlag() != null) {
					callableStatement.setInt(1, reqModel.getFlag());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getStainname() != null) {
					callableStatement.setString(2, reqModel.getStainname());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getCatid() != null) {
					callableStatement.setString(3, reqModel.getCatid());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getUserid() != null) {
					callableStatement.setString(4, reqModel.getUserid());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getSmflag() != null) {
					callableStatement.setInt(5, reqModel.getSmflag());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getDiscription() != null) {
					callableStatement.setString(6, reqModel.getDiscription());
				} else {
					callableStatement.setString(6, null);
				}
				if (reqModel.getStainid() != null) {
					callableStatement.setInt(7, reqModel.getStainid());
				} else {
					callableStatement.setString(7, null);
				}
				if (reqModel.getStart() != null) {
					callableStatement.setInt(8, reqModel.getStart());
				} else {
					callableStatement.setString(8, null);
				}
				if (reqModel.getEnd() != null) {
					callableStatement.setInt(9, reqModel.getEnd());
				} else {
					callableStatement.setString(9, null);
				}
				if (reqModel.getSearch() != null) {
					callableStatement.setString(10, reqModel.getSearch());
				} else {
					callableStatement.setString(10, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getstainmasternew", l_lstResult);
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getdamagemasternew(DamageMasterNewReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_DAMAGE_MASTERS_NEW + "(?,?,?,?,?,?,?,?,?,?)}");

				if (reqModel.getFlag() != null) {
					callableStatement.setInt(1, reqModel.getFlag());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getDamagename() != null) {
					callableStatement.setString(2, reqModel.getDamagename());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getCategoryid() != null) {
					callableStatement.setString(3, reqModel.getCategoryid());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getUserid() != null) {
					callableStatement.setString(4, reqModel.getUserid());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getDmflag() != null) {
					callableStatement.setInt(5, reqModel.getDmflag());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getDiscription() != null) {
					callableStatement.setString(6, reqModel.getDiscription());
				} else {
					callableStatement.setString(6, null);
				}
				if (reqModel.getDmid() != null) {
					callableStatement.setInt(7, reqModel.getDmid());
				} else {
					callableStatement.setString(7, null);
				}
				if (reqModel.getStart() != null) {
					callableStatement.setInt(8, reqModel.getStart());
				} else {
					callableStatement.setString(8, null);
				}
				if (reqModel.getEnd() != null) {
					callableStatement.setInt(9, reqModel.getEnd());
				} else {
					callableStatement.setString(9, null);
				}
				if (reqModel.getSearch() != null) {
					callableStatement.setString(10, reqModel.getSearch());
				} else {
					callableStatement.setString(10, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getdamagemasternew", l_lstResult);
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getcomplaintsdetails(ComplaintsReqModel complaintsReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_COMPLAINTS_DETAILS(?,?,?,?,?)}");
				callableStatement.setDate(1, complaintsReqModel.getStartdate());
				callableStatement.setDate(2, complaintsReqModel.getEnddate());
				callableStatement.setInt(3, complaintsReqModel.getStart());
				callableStatement.setInt(4, complaintsReqModel.getEnd());
				callableStatement.setString(5, complaintsReqModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getcomplaintsdetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getrefunddetails(ComplaintsReqModel complaintsReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_REFUND_DETAILS(?,?,?,?,?)}");
				callableStatement.setDate(1, complaintsReqModel.getStartdate());
				callableStatement.setDate(2, complaintsReqModel.getEnddate());
				callableStatement.setInt(3, complaintsReqModel.getStart());
				callableStatement.setInt(4, complaintsReqModel.getEnd());
				callableStatement.setString(5, complaintsReqModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getcomplaintsdetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertupdateRiderInfo(RiderDetailsReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BOOLEAN));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_RIDER_INFO
								+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

				if (reqModel.getRiderid() != null) {
					callableStatement.setLong(1, reqModel.getRiderid());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getRidercode() != null) {
					callableStatement.setString(2, reqModel.getRidercode());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getUserid() != null) {
					callableStatement.setLong(3, reqModel.getUserid());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getFirstname() != null) {
					callableStatement.setString(4, reqModel.getFirstname());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getLastname() != null) {
					callableStatement.setString(5, reqModel.getLastname());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getEmail() != null) {
					callableStatement.setString(6, reqModel.getEmail());
				} else {
					callableStatement.setString(6, null);
				}
				if (reqModel.getMobileno() != null) {
					callableStatement.setString(7, reqModel.getMobileno());
				} else {
					callableStatement.setString(7, null);
				}
				if (reqModel.getAlternatemobile() != null) {
					callableStatement.setString(8, reqModel.getAlternatemobile());
				} else {
					callableStatement.setString(8, null);
				}
				if (reqModel.getStatus() != null) {
					callableStatement.setBoolean(9, reqModel.getStatus());
				} else {
					callableStatement.setString(9, null);
				}
				if (reqModel.getAddress() != null) {
					callableStatement.setString(10, reqModel.getAddress());
				} else {
					callableStatement.setString(10, null);
				}
				if (reqModel.getFloor() != null) {
					callableStatement.setString(11, reqModel.getFloor());
				} else {
					callableStatement.setString(11, null);
				}
				if (reqModel.getLandmark() != null) {
					callableStatement.setString(12, reqModel.getLandmark());
				} else {
					callableStatement.setString(12, null);
				}
				if (reqModel.getStart() != null) {
					callableStatement.setInt(13, reqModel.getStart());
				} else {
					callableStatement.setString(13, null);
				}
				if (reqModel.getEnd() != null) {
					callableStatement.setInt(14, reqModel.getEnd());
				} else {
					callableStatement.setString(14, null);
				}
				if (reqModel.getSearch() != null) {
					callableStatement.setString(15, reqModel.getSearch());
				} else {
					callableStatement.setString(15, null);
				}
				if (reqModel.getFlag() != null) {
					callableStatement.setInt(16, reqModel.getFlag());
				} else {
					callableStatement.setString(16, null);
				}
				if (reqModel.getRidertypeid() != null) {
					callableStatement.setLong(17, reqModel.getRidertypeid());
				} else {
					callableStatement.setString(17, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("insertupdateRiderInfo", l_lstResult);
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getRiderinfoExport(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_RIDER_INFO_EXPORT(?)}");

				callableStatement.setString(1, chalanMasterRequestModel.getStatus());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getRiderinfoExport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getcallhestorydetails(CallHestoryReqModel callHestoryReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_CALL_HESTORY_DETAILS(?,?)}");

				callableStatement.setLong(1, callHestoryReqModel.getOrderid());
				callableStatement.setLong(2, callHestoryReqModel.getComplaintid());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getcallhestorydetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insercomplaintsdetails(InsertComplaintsReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_COMPLAINTS_DETAILS + "(?,?,?,?,?,?)}");

				if (reqModel.getComplaintid() != null) {
					callableStatement.setLong(1, reqModel.getComplaintid());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getOrderid() != null) {
					callableStatement.setLong(2, reqModel.getOrderid());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getRaisecomplaintid() != null) {
					callableStatement.setLong(3, reqModel.getRaisecomplaintid());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getRemarks() != null) {
					callableStatement.setString(4, reqModel.getRemarks());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getUserid() != null) {
					callableStatement.setLong(5, reqModel.getUserid());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getInvoiceid() != null) {
					callableStatement.setLong(6, reqModel.getInvoiceid());
				} else {
					callableStatement.setString(6, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("insercomplaintsdetails", l_lstResult);
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getclosedcomplaintsdetails(ComplaintsReqModel complaintsReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_CLOSED_COMPLAINTS_DETAILS(?,?,?,?,?)}");
				callableStatement.setDate(1, complaintsReqModel.getStartdate());
				callableStatement.setDate(2, complaintsReqModel.getEnddate());
				callableStatement.setInt(3, complaintsReqModel.getStart());
				callableStatement.setInt(4, complaintsReqModel.getEnd());
				callableStatement.setString(5, complaintsReqModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getclosedcomplaintsdetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertrefund(InsertRefundReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			SQLServerDataTable menuUser = new SQLServerDataTable();
			menuUser.addColumnMetadata("ORDERID", java.sql.Types.BIGINT);
			menuUser.addColumnMetadata("SERVICEID", java.sql.Types.BIGINT);
			menuUser.addColumnMetadata("ITEMID", java.sql.Types.BIGINT);
			menuUser.addColumnMetadata("REFUNDID", java.sql.Types.BIGINT);
			menuUser.addColumnMetadata("REFUNDAMOUNT", java.sql.Types.DOUBLE);
			menuUser.addColumnMetadata("REMARKS", java.sql.Types.VARCHAR);
			menuUser.addColumnMetadata("QRCODE", java.sql.Types.VARCHAR);
			menuUser.addColumnMetadata("USERID", java.sql.Types.BIGINT);

			for (InsertRefundModel d : reqModel.getInsertrefundmodellist()) {
				menuUser.addRow(d.getOrderid(), d.getServiceid(), d.getItemid(), d.getRefundid(), d.getRefundamount(),
						d.getRemarks(), d.getQrcode(), d.getUserid());
			}

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_REFUND + "(?,?,?)}");

				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					cs.setStructured(1, "dbo.UTT_REFUND_DETAILS", menuUser);
					if (reqModel.getUserid() != null) {
						callableStatement.setLong(2, reqModel.getUserid());
					} else {
						callableStatement.setString(2, null);
					}
					if (reqModel.getInvoiceid() != null) {
						callableStatement.setLong(3, reqModel.getInvoiceid());
					} else {
						callableStatement.setString(3, null);
					}
					// cs.execute();
				}
				return callableStatement;
			}, prmtrsList);

			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("insertrefund", l_lstResult);
				}
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		log.info("res" + responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getdetailstorefund(CallHestoryReqModel callHestoryReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_DETAILS_TO_REFUND(?,?)}");

				callableStatement.setLong(1, callHestoryReqModel.getOrderid());
				if (callHestoryReqModel.getInvoiceid() != null) {
					callableStatement.setLong(2, callHestoryReqModel.getInvoiceid());
				} else {
					callableStatement.setString(2, null);
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			int count = 0;
			for (String key : set) {
				count++;
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				if (count == 1) {
					properties.put("getdetailstorefund", l_lstResult);
				} else if (count == 2) {
					properties.put("getdetailstorefunded", l_lstResult);
				}
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getrefundmaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_REFUND_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getrefundmaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getrefunddetailsexport(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_REFUND_DETAILS_EXPORT(?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getrefunddetailsexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getclosedcomplaintsdetailsexport(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_CLOSED_COMPLAINTS_DETAILS_EXPORT(?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getclosedcomplaintsdetailsexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getcomplaintsdetailsexport(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_COMPLAINTS_DETAILS_EXPORT(?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getcomplaintsdetailsexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getrefundeddetails(ComplaintsReqModel complaintsReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_REFUNDED_DETAILS(?,?,?,?,?)}");
				callableStatement.setDate(1, complaintsReqModel.getStartdate());
				callableStatement.setDate(2, complaintsReqModel.getEnddate());
				callableStatement.setInt(3, complaintsReqModel.getStart());
				callableStatement.setInt(4, complaintsReqModel.getEnd());
				callableStatement.setString(5, complaintsReqModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getrefundeddetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getrefundeddetailsexport(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_REFUNDED_DETAILS_EXPORT(?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getrefundeddetailsexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel gettrackriderdetails(TrackRiderDetailsReqModel trackRiderDetailsReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_TRACK_RIDERS_DETAILS(?,?,?,?,?)}");
				if (trackRiderDetailsReqModel.getStartdate() != null) {
					callableStatement.setDate(1, Utils.utilDateToJavaSqlDate(trackRiderDetailsReqModel.getStartdate()));
				} else {
					callableStatement.setString(1, null);
				}
				if (trackRiderDetailsReqModel.getEnddate() != null) {
					callableStatement.setDate(2, Utils.utilDateToJavaSqlDate(trackRiderDetailsReqModel.getEnddate()));
				} else {
					callableStatement.setString(2, null);
				}
				if (trackRiderDetailsReqModel.getStart() != null) {
					callableStatement.setInt(3, trackRiderDetailsReqModel.getStart());
				} else {
					callableStatement.setString(3, null);
				}
				if (trackRiderDetailsReqModel.getEnd() != null) {
					callableStatement.setInt(4, trackRiderDetailsReqModel.getEnd());
				} else {
					callableStatement.setString(4, null);
				}
				callableStatement.setString(5, trackRiderDetailsReqModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getrefundeddetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getapporveldetails(TrackRiderDetailsReqModel trackRiderDetailsReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_APPORVEL_DETAILS(?,?,?,?,?)}");
				callableStatement.setInt(1, trackRiderDetailsReqModel.getStart());
				callableStatement.setInt(2, trackRiderDetailsReqModel.getEnd());
				callableStatement.setDate(3, trackRiderDetailsReqModel.getStartdate());
				callableStatement.setDate(4, trackRiderDetailsReqModel.getEnddate());
				callableStatement.setString(5, trackRiderDetailsReqModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getrefundeddetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getapporvelsaction(CallHestoryReqModel callHestoryReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_APPORVEL_ACTION(?,?)}");

				callableStatement.setLong(1, callHestoryReqModel.getOrderid());
				callableStatement.setLong(2, callHestoryReqModel.getInvoiceid());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties

			List<AppovalActionStausResModel> detailslist = new ArrayList<AppovalActionStausResModel>();
			List<ApprovalActionImagePathResModel> imagelsit = new ArrayList<ApprovalActionImagePathResModel>();
			;
			AppovalActionResModel response = new AppovalActionResModel();
			for (String key : set) {
				if (key.contains("#result-set-1")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					for (int i = 0; i < l_lstResult.size(); i++) {
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
						AppovalActionStausResModel details = new AppovalActionStausResModel();
						details.setDamagedetails(String.valueOf(String.valueOf(l_hmColmnData.get("damagedetails"))));
						details.setWC_OR_ORDERCODE(
								String.valueOf(String.valueOf(l_hmColmnData.get("WC_OR_ORDERCODE"))));

						details.setWC_OR_ORDERID(Long.valueOf(String.valueOf(l_hmColmnData.get("WC_OR_ORDERID"))));
						details.setWC_IM_ITEM_NAME(
								String.valueOf(String.valueOf(l_hmColmnData.get("WC_IM_ITEM_NAME"))));
						details.setWC_SM_SERVICE_NAME(String.valueOf(l_hmColmnData.get("WC_SM_SERVICE_NAME")));

						details.setStatus(String.valueOf(String.valueOf(l_hmColmnData.get("status"))));
						details.setInvoice_id(Long.valueOf(String.valueOf(l_hmColmnData.get("invoice_id"))));
						details.setItem_id(Long.valueOf(String.valueOf(l_hmColmnData.get("Item_id"))));
						details.setQrcode(String.valueOf(String.valueOf(l_hmColmnData.get("qrcode"))));
						details.setFlag(Long.valueOf(String.valueOf(l_hmColmnData.get("flag"))));
						details.setApprovedby(String.valueOf(String.valueOf(l_hmColmnData.get("approvedby"))));
						details.setRejectedflag(Long.valueOf(String.valueOf(l_hmColmnData.get("rejectedflag"))));
						details.setApprovedflag(Long.valueOf(String.valueOf(l_hmColmnData.get("approvedflag"))));

						detailslist.add(details);
					}
					response.setDetails(detailslist);

				} else if (key.contains("#result-set-2")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					for (int i = 0; i < l_lstResult.size(); i++) {
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
						ApprovalActionImagePathResModel imagpath = new ApprovalActionImagePathResModel();
						;
						imagpath.setImagepath(String.valueOf(l_hmColmnData.get("WC_IDD_IMAGEPATH")));
						imagpath.setName(String.valueOf(l_hmColmnData.get("name")));
						imagpath.setWC_OR_ORDERID(Long.valueOf(String.valueOf(l_hmColmnData.get("WC_OR_ORDERID"))));
						imagpath.setInvoice_id(Long.valueOf(String.valueOf(l_hmColmnData.get("invoice_id"))));
						imagpath.setItem_id(Long.valueOf(String.valueOf(l_hmColmnData.get("Item_id"))));
						imagpath.setQrcode(String.valueOf(l_hmColmnData.get("qrcode")));
						imagelsit.add(imagpath);
					}
					response.setImagepath(imagelsit);
					System.out.println(imagelsit);

				}

			}
			responseModel.setResponseObject(response);
			// }
			//
			// else if(count==2) {
			// properties.put("getdetailstorefunded", l_lstResult);
			// }

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		System.out.println(responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel gettrackriderexport(TrackRiderDetailsReqModel trackRiderDetailsReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_TRACK_RIDERS_EXPORT(?,?)}");
				callableStatement.setDate(1, trackRiderDetailsReqModel.getStartdate());
				callableStatement.setDate(2, trackRiderDetailsReqModel.getEnddate());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("gettrackriderexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getwebdeliveryslots(WebDelierySlotsModel webDelierySlotsModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_WEB_DELIVERY_SLOTS(?,?,?,?,?)}");
				callableStatement.setString(1, webDelierySlotsModel.getDate());
				callableStatement.setString(2, webDelierySlotsModel.getPincode());
				callableStatement.setLong(3, webDelierySlotsModel.getType());
				if (webDelierySlotsModel.getOrderid() != null) {
					callableStatement.setLong(4, webDelierySlotsModel.getOrderid());
				} else {
					callableStatement.setString(4, null);
				}

				if (webDelierySlotsModel.getInvoiceid() != null) {
					callableStatement.setLong(5, webDelierySlotsModel.getInvoiceid());
				} else {
					callableStatement.setString(5, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			List<WebDelierySlotsResModel> webDelierySlotsResModels = new ArrayList<>();
			List<WebDelierySlotsRiderModel> webDelierySlotsRiderModels = null;

			WebDelierySlotsResModel webDelierySlotsResModel = null;
			WebDelierySlotsRiderModel webDelierySlotsRiderModel = null;
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					int count = 0;
					Integer assigned = 0;
					Integer free = 0;
					String status = null;
					for (int i = 0; i < l_lstResult.size(); i++) {
						count++;
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
						status = String.valueOf(l_hmColmnData.get("status"));
						if (String.valueOf(l_hmColmnData.get("status")).equalsIgnoreCase("200")) {

							if (count == 1) {
								webDelierySlotsResModel = new WebDelierySlotsResModel();
								webDelierySlotsRiderModels = new ArrayList<>();
								webDelierySlotsResModel.setTime(String.valueOf(l_hmColmnData.get("subtitle")));
								webDelierySlotsResModel.setAvailable(String.valueOf(l_hmColmnData.get("Avail")));
								if (String.valueOf(l_hmColmnData.get("Avail")).equalsIgnoreCase("A")) {
									webDelierySlotsRiderModel = new WebDelierySlotsRiderModel();
									webDelierySlotsRiderModel.setUserid(String.valueOf(l_hmColmnData.get("Userid")));
									webDelierySlotsRiderModel
											.setUsername(String.valueOf(l_hmColmnData.get("username")));
									free++;
									webDelierySlotsRiderModels.add(webDelierySlotsRiderModel);
								}
								if (String.valueOf(l_hmColmnData.get("Avail")).equalsIgnoreCase("NA")) {
									assigned++;
								}

							} else {
								if (String.valueOf(l_hmColmnData.get("Avail")).equalsIgnoreCase("A")) {
									webDelierySlotsRiderModel = new WebDelierySlotsRiderModel();
									webDelierySlotsRiderModel.setUserid(String.valueOf(l_hmColmnData.get("Userid")));
									webDelierySlotsRiderModel
											.setUsername(String.valueOf(l_hmColmnData.get("username")));
									free++;
									webDelierySlotsRiderModels.add(webDelierySlotsRiderModel);
								}
								if (String.valueOf(l_hmColmnData.get("Avail")).equalsIgnoreCase("NA")) {
									assigned++;
								}
							}

						}
					}
					if (!status.equalsIgnoreCase("400")) {
						webDelierySlotsResModel.setAssigned(assigned);
						webDelierySlotsResModel.setFree(free);
						webDelierySlotsResModel.setSlotsRiderModels(webDelierySlotsRiderModels);
						webDelierySlotsResModels.add(webDelierySlotsResModel);
					}

				}
			}
			if (webDelierySlotsResModels.size() > 0) {
				properties.put("deliveryslots", webDelierySlotsResModels);
			} else {
				properties.put("deliveryslots", new ArrayList<>());
			}
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel getOrderSummaryPdf(OrdersummaryPdf reqModel) {

		ResponseModel responseModel = new ResponseModel();

		WecleanInvoiceResModel wecleandetaillist = new WecleanInvoiceResModel();
		PaymentInvoiceDetails paymentuserdetails = new PaymentInvoiceDetails();
		PaymentInvoiceResModel paymentinvoice = new PaymentInvoiceResModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection.prepareCall("{call USP_GET_SUMMARY_PDF_GENE(?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");

					if (reqModel.getOrderid() != null) {
						callableStatement.setLong(1, reqModel.getOrderid());
					} else {
						callableStatement.setString(1, null);
					}

					if (reqModel.getUserid() != null) {
						callableStatement.setLong(2, reqModel.getUserid());
					} else {
						callableStatement.setString(2, null);
					}

					if (reqModel.getInvoiceid() != null) {
						callableStatement.setLong(3, reqModel.getInvoiceid());
					} else {
						callableStatement.setString(3, null);
					}

				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());

			int count = 0;

			for (String key : set) {

				if (key.contains("result")) {
					count++;
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);

					if (count == 1) {
						for (int i = 0; i < l_lstResult.size(); i++) {

							LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
							paymentuserdetails.setStatus(Integer.valueOf(String.valueOf(l_hmColmnData.get("status"))));

							if (paymentuserdetails.getStatus() == 200) {
								paymentuserdetails.setUsername(String.valueOf(l_hmColmnData.get("name")));
								paymentuserdetails.setMobileno(String.valueOf(l_hmColmnData.get("mobileno")));
								paymentuserdetails.setInvoicecode(String.valueOf(l_hmColmnData.get("invoicecode")));

								paymentuserdetails.setPickupdate(String.valueOf(l_hmColmnData.get("pickupdate")));
								paymentuserdetails.setDeliverydate(String.valueOf(l_hmColmnData.get("deliverydate")));
								paymentuserdetails.setAddress(String.valueOf(l_hmColmnData.get("address")));
								paymentuserdetails
										.setCustomer_gst_no(String.valueOf(l_hmColmnData.get("customer_gst_no")));
								paymentuserdetails.setSubtotal(Utils.checkNull(l_hmColmnData.get("subtotal")));
								paymentuserdetails.setCoupon(Utils.checkNull(l_hmColmnData.get("coupon")));
								paymentuserdetails
										.setPickupcharges(Utils.checkNull(l_hmColmnData.get("pickupcharges")));
								paymentuserdetails.setScheduled_delivery_charges(
										Utils.checkNull(l_hmColmnData.get("scheduled_delivery_charges")));
								paymentuserdetails.setNet_total(Utils.checkNull(l_hmColmnData.get("net_total")));
								paymentuserdetails.setCgst(Utils.checkNull(l_hmColmnData.get("cgst")));
								paymentuserdetails.setSgst(Utils.checkNull(l_hmColmnData.get("sgst")));
								paymentuserdetails.setTax(Utils.checkNull(l_hmColmnData.get("Tax")));
								paymentuserdetails.setRoundoff(Utils.checkNull(l_hmColmnData.get("Roundoff")));
								paymentuserdetails.setGrand_total(Utils.checkNull(l_hmColmnData.get("grand_total")));
								paymentuserdetails.setDiscount(Utils.checkNull(l_hmColmnData.get("discount")));
								paymentuserdetails
										.setQuickdelivery(Utils.checkNull(l_hmColmnData.get("quickdeliveryfee")));
								paymentuserdetails
										.setDeliverycharges(Utils.checkNull(l_hmColmnData.get("deliverycharges")));

							}
						}
						paymentinvoice.setPaymentUserDetails(paymentuserdetails);
					}

					else if (count == 2) {
						List<PaymentServiceDetailsResModel> servicelist = new ArrayList<PaymentServiceDetailsResModel>();
						List<PaymentItemListResMod> itemlist = null;
						PaymentServiceDetailsResModel serviceres = null;
						PaymentItemListResMod itemdetail = null;

						HashSet<Long> serviceid = new HashSet<>();
						for (int i = 0; i < l_lstResult.size(); i++) {
							LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
							if (!serviceid.contains(Long.valueOf(String.valueOf(l_hmColmnData.get("serviceid"))))) {
								serviceres = new PaymentServiceDetailsResModel();
								itemlist = new ArrayList<PaymentItemListResMod>();
								serviceres.setServiceid(Long.valueOf(String.valueOf(l_hmColmnData.get("serviceid"))));

								serviceres.setServicename(String.valueOf(l_hmColmnData.get("servicename")));
							}
							itemdetail = new PaymentItemListResMod();

							itemdetail.setQuantity(Long.valueOf(String.valueOf(l_hmColmnData.get("itemcount"))));
							itemdetail.setItemname(String.valueOf(l_hmColmnData.get("itemname")));
							itemdetail.setAmount(String.valueOf(l_hmColmnData.get("amount")));
							itemdetail.setRate(Double.valueOf(String.valueOf(l_hmColmnData.get("rate"))));
							itemlist.add(itemdetail);
							serviceres.setItemlist(itemlist);
							if (!serviceid.contains(Long.valueOf(String.valueOf(l_hmColmnData.get("serviceid"))))) {
								servicelist.add(serviceres);
							}
							serviceid.add(Long.valueOf(String.valueOf(l_hmColmnData.get("serviceid"))));
						}
						paymentinvoice.setServicename(servicelist);
					}

					else if (count == 3) {
						List<PaymentSpecialInstructModel> specialist = new ArrayList<PaymentSpecialInstructModel>();
						PaymentSpecialInstructModel specialres = null;
						for (int i = 0; i < l_lstResult.size(); i++) {
							specialres = new PaymentSpecialInstructModel();
							LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);

							specialres.setName(String.valueOf(Utils.checkNull(l_hmColmnData.get("specialinstruct"))));
							specialist.add(specialres);
						}

						paymentinvoice.setSpecialinstruct(specialist);
					}

					else if (count == 4) {
						for (int i = 0; i < l_lstResult.size(); i++) {

							LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
							paymentinvoice.setCgst(Utils.checkNull(l_hmColmnData.get("WC_TXM_CGST")));
							paymentinvoice.setSgst(Utils.checkNull(l_hmColmnData.get("WC_TXM_SGST")));
						}

					}

					else if (count == 5) {
						for (int i = 0; i < l_lstResult.size(); i++) {

							LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
							wecleandetaillist.setWecleanname(String.valueOf(l_hmColmnData.get("WC_WM_WECLEAN_NAME")));
							wecleandetaillist.setAddresslin1(String.valueOf(l_hmColmnData.get("WC_WM_ADDRESSLINE1")));
							wecleandetaillist.setAddressline2(String.valueOf(l_hmColmnData.get("WC_WM_ADDRESSLINE2")));
							wecleandetaillist
									.setPrimarycontact(String.valueOf(l_hmColmnData.get("WC_WM_PRIMARYCONTACT")));
							wecleandetaillist
									.setWecleanservice(String.valueOf(l_hmColmnData.get("WC_WM_WECLEANSERVICE")));
							wecleandetaillist.setWebsite(String.valueOf(l_hmColmnData.get("WC_WM_WEBSITE")));
							wecleandetaillist.setApplink(String.valueOf(l_hmColmnData.get("WC_WM_APPLINK")));
							wecleandetaillist.setGst(String.valueOf(l_hmColmnData.get("WC_WM_GST")));
							wecleandetaillist.setImagepath(String.valueOf(l_hmColmnData.get("WC_WM_IMAGEPATH")));

						}
						paymentinvoice.setWecleanInvoice(wecleandetaillist);
					}

				}

			}
			responseModel.setResponseObject(paymentinvoice);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("res" + responseModel);
		return responseModel;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel updateOrderSummaryImagePath(OrderSummaryImageReqModel reqModel) {

		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_UPDATE_ORDER_SUMMARY_IMAGE_PATH(?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					if (reqModel.getOrderid() != null) {
						callableStatement.setLong(1, reqModel.getOrderid());
					} else {
						callableStatement.setString(1, null);
					}
					if (reqModel.getInvoiceid() != null) {
						callableStatement.setLong(2, reqModel.getInvoiceid());
					} else {
						callableStatement.setString(2, null);
					}

					if (reqModel.getImagepath() != null) {
						callableStatement.setString(3, reqModel.getImagepath());
					} else {
						callableStatement.setString(3, null);
					}

				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();

			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("updateOrderSummaryImagePath", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} // log.info("res"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getqrcodedetails(QrcodeDetailsReqModel qrcodeDetailsReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_QRCODE_DETAILS(?,?)}");

				callableStatement.setString(1, qrcodeDetailsReqModel.getQrcode());
				callableStatement.setInt(2, qrcodeDetailsReqModel.getInvoiceid());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getqrcodedetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getapporveldetailsexport(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_APPORVEL_DETAILS_EXPORT(?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getapporveldetailsexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getcolourmasternew(ColourMasterNewReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_COLOUR_MASTER_NEW + "(?,?,?,?,?,?,?,?,?,?,?)}");

				if (reqModel.getFlag() != null) {
					callableStatement.setInt(1, reqModel.getFlag());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getColourname() != null) {
					callableStatement.setString(2, reqModel.getColourname());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getCategoryid() != null) {
					callableStatement.setString(3, reqModel.getCategoryid());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getUserid() != null) {
					callableStatement.setString(4, reqModel.getUserid());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getDmflag() != null) {
					callableStatement.setInt(5, reqModel.getDmflag());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getDiscription() != null) {
					callableStatement.setString(6, reqModel.getDiscription());
				} else {
					callableStatement.setString(6, null);
				}
				if (reqModel.getCmid() != null) {
					callableStatement.setInt(7, reqModel.getCmid());
				} else {
					callableStatement.setString(7, null);
				}
				if (reqModel.getStart() != null) {
					callableStatement.setInt(8, reqModel.getStart());
				} else {
					callableStatement.setString(8, null);
				}
				if (reqModel.getEnd() != null) {
					callableStatement.setInt(9, reqModel.getEnd());
				} else {
					callableStatement.setString(9, null);
				}
				if (reqModel.getSearch() != null) {
					callableStatement.setString(10, reqModel.getSearch());
				} else {
					callableStatement.setString(10, null);
				}
				if (reqModel.getColourcode() != null) {
					callableStatement.setString(11, reqModel.getColourcode());
				} else {
					callableStatement.setString(11, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getcolourmasternew", l_lstResult);
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getbrandmasternew(BrandMasterNewReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_INSERT_UPDATE_BRAND_MASTER
								+ "(?,?,?,?,?,?,?,?,?,?,?)}");

				if (reqModel.getFlag() != null) {
					callableStatement.setInt(1, reqModel.getFlag());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getBrandname() != null) {
					callableStatement.setString(2, reqModel.getBrandname());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getBrandcode() != null) {
					callableStatement.setString(3, reqModel.getBrandcode());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getUserid() != null) {
					callableStatement.setString(4, reqModel.getUserid());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getBmflag() != null) {
					callableStatement.setInt(5, reqModel.getBmflag());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getDiscription() != null) {
					callableStatement.setString(6, reqModel.getDiscription());
				} else {
					callableStatement.setString(6, null);
				}
				if (reqModel.getBmid() != null) {
					callableStatement.setInt(7, reqModel.getBmid());
				} else {
					callableStatement.setString(7, null);
				}
				if (reqModel.getImagepath() != null) {
					callableStatement.setString(8, reqModel.getImagepath());
				} else {
					callableStatement.setString(8, null);
				}
				if (reqModel.getStart() != null) {
					callableStatement.setInt(9, reqModel.getStart());
				} else {
					callableStatement.setString(9, null);
				}
				if (reqModel.getEnd() != null) {
					callableStatement.setInt(10, reqModel.getEnd());
				} else {
					callableStatement.setString(10, null);
				}
				if (reqModel.getSearch() != null) {
					callableStatement.setString(11, reqModel.getSearch());
				} else {
					callableStatement.setString(11, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getbrandmasternew", l_lstResult);
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getcompanymasternew(CompanyMasterNewReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_INSERT_UPDATE_COMPANY_MASTER
								+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

				if (reqModel.getFlag() != null) {
					callableStatement.setInt(1, reqModel.getFlag());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getCompanyname() != null) {
					callableStatement.setString(2, reqModel.getCompanyname());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getCompanydiscription() != null) {
					callableStatement.setString(3, reqModel.getCompanydiscription());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getFrom() != null) {
					callableStatement.setLong(4, reqModel.getFrom());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getTo() != null) {
					callableStatement.setLong(5, reqModel.getTo());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getEmailid() != null) {
					callableStatement.setString(6, reqModel.getEmailid());
				} else {
					callableStatement.setString(6, null);
				}
				if (reqModel.getContactnumber() != null) {
					callableStatement.setString(7, reqModel.getContactnumber());
				} else {
					callableStatement.setString(7, null);
				}
				if (reqModel.getAlternatenumber() != null) {
					callableStatement.setString(8, reqModel.getAlternatenumber());
				} else {
					callableStatement.setString(8, null);
				}
				if (reqModel.getGst_no() != null) {
					callableStatement.setString(9, reqModel.getGst_no());
				} else {
					callableStatement.setString(9, null);
				}
				if (reqModel.getPan_no() != null) {
					callableStatement.setString(10, reqModel.getPan_no());
				} else {
					callableStatement.setString(10, null);
				}
				if (reqModel.getAddress1() != null) {
					callableStatement.setString(11, reqModel.getAddress1());
				} else {
					callableStatement.setString(11, null);
				}
				if (reqModel.getAddress2() != null) {
					callableStatement.setString(12, reqModel.getAddress2());
				} else {
					callableStatement.setString(12, null);
				}
				if (reqModel.getPincode() != null) {
					callableStatement.setString(13, reqModel.getPincode());
				} else {
					callableStatement.setString(13, null);
				}
				if (reqModel.getCountryid() != null) {
					callableStatement.setLong(14, reqModel.getCountryid());
				} else {
					callableStatement.setString(14, null);
				}
				if (reqModel.getStateid() != null) {
					callableStatement.setLong(15, reqModel.getStateid());
				} else {
					callableStatement.setString(15, null);
				}
				if (reqModel.getCityid() != null) {
					callableStatement.setLong(16, reqModel.getCityid());
				} else {
					callableStatement.setString(16, null);
				}
				if (reqModel.getWmid() != null) {
					callableStatement.setLong(17, reqModel.getWmid());
				} else {
					callableStatement.setString(17, null);
				}
				if (reqModel.getUserid() != null) {
					callableStatement.setLong(18, reqModel.getUserid());
				} else {
					callableStatement.setString(18, null);
				}
				if (reqModel.getState() != null) {
					callableStatement.setString(19, reqModel.getState());
				} else {
					callableStatement.setString(19, null);
				}
				if (reqModel.getCity() != null) {
					callableStatement.setString(20, reqModel.getCity());
				} else {
					callableStatement.setString(20, null);
				}
				if (reqModel.getCountry() != null) {
					callableStatement.setString(21, reqModel.getCountry());
				} else {
					callableStatement.setString(21, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getcompanymasternew", l_lstResult);
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getdaymaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_DAY_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getdaymaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getitemmasternew(ItemMasterNewReqModel itemMasterNewReqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_INSERT_UPDATE_ITEM_MASTER
								+ "(?,?,?,?,?,?,?,?,?,?,?)}");

				if (itemMasterNewReqModel.getFlag() != null) {
					callableStatement.setInt(1, itemMasterNewReqModel.getFlag());
				} else {
					callableStatement.setString(1, null);
				}
				if (itemMasterNewReqModel.getItemname() != null) {
					callableStatement.setString(2, itemMasterNewReqModel.getItemname());
				} else {
					callableStatement.setString(2, null);
				}
				if (itemMasterNewReqModel.getItemcode() != null) {
					callableStatement.setString(3, itemMasterNewReqModel.getItemcode());
				} else {
					callableStatement.setString(3, null);
				}
				if (itemMasterNewReqModel.getUserid() != null) {
					callableStatement.setString(4, itemMasterNewReqModel.getUserid());
				} else {
					callableStatement.setString(4, null);
				}
				if (itemMasterNewReqModel.getIm_flag() != null) {
					callableStatement.setInt(5, itemMasterNewReqModel.getIm_flag());
				} else {
					callableStatement.setString(5, null);
				}
				if (itemMasterNewReqModel.getDescription() != null) {
					callableStatement.setString(6, itemMasterNewReqModel.getDescription());
				} else {
					callableStatement.setString(6, null);
				}
				if (itemMasterNewReqModel.getIm_id() != null) {
					callableStatement.setInt(7, itemMasterNewReqModel.getIm_id());
				} else {
					callableStatement.setString(7, null);
				}
				if (itemMasterNewReqModel.getImagepath() != null) {
					callableStatement.setString(8, itemMasterNewReqModel.getImagepath());
				} else {
					callableStatement.setString(8, null);
				}
				if (itemMasterNewReqModel.getStart() != null) {
					callableStatement.setInt(9, itemMasterNewReqModel.getStart());
				} else {
					callableStatement.setString(9, null);
				}
				if (itemMasterNewReqModel.getEnd() != null) {
					callableStatement.setInt(10, itemMasterNewReqModel.getEnd());
				} else {
					callableStatement.setString(10, null);
				}
				if (itemMasterNewReqModel.getSearch() != null) {
					callableStatement.setString(11, itemMasterNewReqModel.getSearch());
				} else {
					callableStatement.setString(11, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("insertupdatesocity", l_lstResult);
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getitemmaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_ITEM_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getitemmaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getserviceitemmapping(ServiceItemMappingReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_SERVICE_ITEM_MAPPING_NEW
								+ "(?,?,?,?,?,?,?,?,?,?)}");

				if (reqModel.getFlag() != null) {
					callableStatement.setInt(1, reqModel.getFlag());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getServiceid() != null) {
					callableStatement.setInt(2, reqModel.getServiceid());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getItemid() != null) {
					callableStatement.setInt(3, reqModel.getItemid());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getUserid() != null) {
					callableStatement.setString(4, reqModel.getUserid());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getSmm_flag() != null) {
					callableStatement.setInt(5, reqModel.getSmm_flag());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getAmount() != null) {
					callableStatement.setLong(6, reqModel.getAmount());
				} else {
					callableStatement.setString(6, null);
				}
				if (reqModel.getSmmid() != null) {
					callableStatement.setInt(7, reqModel.getSmmid());
				} else {
					callableStatement.setString(7, null);
				}
				if (reqModel.getStart() != null) {
					callableStatement.setInt(8, reqModel.getStart());
				} else {
					callableStatement.setString(8, null);
				}
				if (reqModel.getEnd() != null) {
					callableStatement.setInt(9, reqModel.getEnd());
				} else {
					callableStatement.setString(9, null);
				}
				if (reqModel.getSearch() != null) {
					callableStatement.setString(10, reqModel.getSearch());
				} else {
					callableStatement.setString(10, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getserviceitemmapping", l_lstResult);
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getcountrymaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_COUNTRY_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getcountrymaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getservicemasternew(ServiceItemMasterNewReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_INSERT_UPDATE_SERVICE_MASTER
								+ "(?,?,?,?,?,?,?,?,?,?)}");

				if (reqModel.getFlag() != null) {
					callableStatement.setInt(1, reqModel.getFlag());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getServicename() != null) {
					callableStatement.setString(2, reqModel.getServicename());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getServicecode() != null) {
					callableStatement.setString(3, reqModel.getServicecode());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getUserid() != null) {
					callableStatement.setString(4, reqModel.getUserid());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getSmflag() != null) {
					callableStatement.setInt(5, reqModel.getSmflag());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getDiscription() != null) {
					callableStatement.setString(6, reqModel.getDiscription());
				} else {
					callableStatement.setString(6, null);
				}
				if (reqModel.getSmid() != null) {
					callableStatement.setInt(7, reqModel.getSmid());
				} else {
					callableStatement.setString(7, null);
				}
				if (reqModel.getStart() != null) {
					callableStatement.setInt(8, reqModel.getStart());
				} else {
					callableStatement.setString(8, null);
				}
				if (reqModel.getEnd() != null) {
					callableStatement.setInt(9, reqModel.getEnd());
				} else {
					callableStatement.setString(9, null);
				}
				if (reqModel.getSearch() != null) {
					callableStatement.setString(10, reqModel.getSearch());
				} else {
					callableStatement.setString(10, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getservicemasternew", l_lstResult);
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getrescheduleandcancellationdetails(
			RescheduleAndCancellationReqModel rescheduleAndCancellationReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_RESCHEDULE_AND_CANNCELLATION_DETAILS(?,?,?,?,?,?)}");
				callableStatement.setDate(1, rescheduleAndCancellationReqModel.getStartdate());
				callableStatement.setDate(2, rescheduleAndCancellationReqModel.getEnddate());
				callableStatement.setInt(3, rescheduleAndCancellationReqModel.getStart());
				callableStatement.setInt(4, rescheduleAndCancellationReqModel.getEnd());
				callableStatement.setString(5, rescheduleAndCancellationReqModel.getStatus());
				callableStatement.setString(6, rescheduleAndCancellationReqModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {

				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getrescheduleandcancellationdetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertupdatepickuprescheduledetails(PickupRescheduleReqModel reqModel)
			throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_PICKUP_RESCHEDLUE_DETAILS
								+ "(?,?,?,?,?,?)}");

				if (reqModel.getUserid() != null) {
					callableStatement.setLong(1, reqModel.getUserid());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getOrderid() != null) {
					callableStatement.setLong(2, reqModel.getOrderid());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getAssignto() != null) {
					callableStatement.setLong(3, reqModel.getAssignto());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getDeliverydatetime() != null) {
					callableStatement.setString(4, reqModel.getDeliverydatetime());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getRemark() != null) {
					callableStatement.setString(5, reqModel.getRemark());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getInvoiceid() != null) {
					callableStatement.setLong(6, reqModel.getInvoiceid());
				} else {
					callableStatement.setString(6, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("insertupdatepickuprescheduledetails", l_lstResult);
				}
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertupdatedeliveryrescheduledetails(PickupRescheduleReqModel reqModel)
			throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_DELIVERY_RESCHEDLUE_DETAILS
								+ "(?,?,?,?,?,?)}");

				if (reqModel.getUserid() != null) {
					callableStatement.setLong(1, reqModel.getUserid());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getOrderid() != null) {
					callableStatement.setLong(2, reqModel.getOrderid());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getAssignto() != null) {
					callableStatement.setLong(3, reqModel.getAssignto());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getDeliverydatetime() != null) {
					callableStatement.setString(4, reqModel.getDeliverydatetime());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getRemark() != null) {
					callableStatement.setString(5, reqModel.getRemark());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getInvoiceid() != null) {
					callableStatement.setLong(6, reqModel.getInvoiceid());
				} else {
					callableStatement.setString(6, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			ProcessRescheduleResponseModel processRescheduleResponseModel = new ProcessRescheduleResponseModel();
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					for (int i = 0; i < l_lstResult.size(); i++) {
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
						processRescheduleResponseModel
								.setStatus(Long.valueOf(String.valueOf(l_hmColmnData.get("status"))));
						if (processRescheduleResponseModel.getStatus() == 200) {
							processRescheduleResponseModel.setMessage(l_hmColmnData.get("message"));
							processRescheduleResponseModel.setNotification(l_hmColmnData.get("notification"));
							processRescheduleResponseModel.setMobileNo(l_hmColmnData.get("mobile_no"));
						}

						else {
							processRescheduleResponseModel.setMessage(l_hmColmnData.get("message"));
						}

					}
					properties.put("insertupdatedeliveryrescheduledetails", l_lstResult);
				}
			}
			responseModel.setResponseObject(properties);
			responseModel.setResponseObj(processRescheduleResponseModel);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getrescheduledetailsbyorderid(PickupDetailsByItemsReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_RESCHEDULE_DETAILS_BY_ORDERID(?,?)}");

				callableStatement.setLong(1, reqModel.getOrderid());
				if (reqModel.getInvoiceid() != null) {
					callableStatement.setInt(2, reqModel.getInvoiceid());
				} else {
					callableStatement.setString(2, null);
				}
				return callableStatement;

			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			int count = 0;
			for (String key : set) {
				count++;
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				if (count == 1) {
					properties.put("getrescheduledetailsbyorderid", l_lstResult);
				} else if (count == 2) {
					properties.put("raistowecleansupport", l_lstResult);
				} else {
					properties.put("specialinstructions", l_lstResult);
				}
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertUpdateAssignDetails(PickupRescheduleReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_ASSIGN_DETAILS + "(?,?,?,?,?,?)}");

				if (reqModel.getUserid() != null) {
					callableStatement.setLong(1, reqModel.getUserid());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getOrderid() != null) {
					callableStatement.setLong(2, reqModel.getOrderid());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getAssignto() != null) {
					callableStatement.setLong(3, reqModel.getAssignto());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getScheduledatetime() != null) {
					callableStatement.setString(4, reqModel.getScheduledatetime());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getRemark() != null) {
					callableStatement.setString(5, reqModel.getRemark());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getInvoiceid() != null) {
					callableStatement.setLong(6, reqModel.getInvoiceid());
				} else {
					callableStatement.setString(6, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("insertUpdateAssignDetails", l_lstResult);
				}
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getManualAssignDetails(RescheduleAndCancellationReqModel rescheduleAndCancellationReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_MANUAL_ASSIGN_DETAILS(?,?,?,?,?)}");
				callableStatement.setDate(1, rescheduleAndCancellationReqModel.getStartdate());
				callableStatement.setDate(2, rescheduleAndCancellationReqModel.getEnddate());
				callableStatement.setInt(3, rescheduleAndCancellationReqModel.getStart());
				callableStatement.setInt(4, rescheduleAndCancellationReqModel.getEnd());
				callableStatement.setString(5, rescheduleAndCancellationReqModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {

				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getManualAssignDetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertslot(SlotReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_SLOT + "(?,?,?,?)}");

				if (reqModel.getDeliveryid() != null) {
					callableStatement.setLong(1, reqModel.getDeliveryid());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getDeliverystarttime() != null) {
					callableStatement.setString(2, reqModel.getDeliverystarttime());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getDeliveryendtime() != null) {
					callableStatement.setString(3, reqModel.getDeliveryendtime());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getUserid() != null) {
					callableStatement.setLong(4, reqModel.getUserid());
				} else {
					callableStatement.setString(4, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("insertslot", l_lstResult);
				}
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getcancilationmaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_ALL_CANCILATION_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getcancilationmaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertupdateridercancilation(RiderCancilationReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_RIDER_CANCILLATION + "(?,?,?,?)}");

				if (reqModel.getUserid() != null) {
					callableStatement.setLong(1, reqModel.getUserid());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getOrderid() != null) {
					callableStatement.setLong(2, reqModel.getOrderid());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getResionid() != null) {
					callableStatement.setLong(3, reqModel.getResionid());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getRemarks() != null) {
					callableStatement.setString(4, reqModel.getRemarks());
				} else {
					callableStatement.setString(4, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("insertupdateridercancilation", l_lstResult);
				}
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getstainmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_STAIN_MASTER_EXPORT + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getstainmasterexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getservicemasterexport() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_SERVICE_MASTER_EXPORT + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getservicemasterexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getserviceitemmappingmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_SERVICE_ITEM_MAPPING_EXPORT + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getserviceitemmappingmasterexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getitemmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_ITEM_MASTER_EXPORT + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getitemmasterexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getdamagemasterexport() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_DAMAGE_MASTER_EXPORT + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getdamagemasterexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getcolourmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_COLOUR_MASTER_EXPORT + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getcolourmasterexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getbrandmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_BRAND_MASTER_EXPORT + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getbrandmasterexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getmanualassignexport(RescheduleAndCancellationExportReqModel reqModel)
			throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_MANUAL_ASSIGN_EXPORT + "(?,?)}");

				if (reqModel.getStartdate() != null) {
					callableStatement.setDate(1, reqModel.getStartdate());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getEnddate() != null) {
					callableStatement.setDate(2, reqModel.getEnddate());
				} else {
					callableStatement.setString(2, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("getmanualassignexport", l_lstResult);
				}
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getdurationmaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_WC_DURATION_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getdurationmaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertupdateslotmasternew(InsertSlotNewReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_SLOT_MASTER_NEW
								+ "(?,?,?,?,?,?,?,?,?,?,?,?)}");

				if (reqModel.getFlag() != null) {
					callableStatement.setInt(1, reqModel.getFlag());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getTypeid() != null) {
					callableStatement.setInt(2, reqModel.getTypeid());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getDeliverystarttime() != null) {
					callableStatement.setString(3, reqModel.getDeliverystarttime());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getDeliveryendtime() != null) {
					callableStatement.setString(4, reqModel.getDeliveryendtime());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getDuration() != null) {
					callableStatement.setString(5, reqModel.getDuration());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getUserid() != null) {
					callableStatement.setString(6, reqModel.getUserid());
				} else {
					callableStatement.setString(6, null);
				}
				if (reqModel.getSlmflag() != null) {
					callableStatement.setInt(7, reqModel.getSlmflag());
				} else {
					callableStatement.setString(7, null);
				}
				if (reqModel.getSlmid() != null) {
					callableStatement.setInt(8, reqModel.getSlmid());
				} else {
					callableStatement.setString(8, null);
				}
				if (reqModel.getStart() != null) {
					callableStatement.setInt(9, reqModel.getStart());
				} else {
					callableStatement.setString(9, null);
				}
				if (reqModel.getEnd() != null) {
					callableStatement.setInt(10, reqModel.getEnd());
				} else {
					callableStatement.setString(10, null);
				}
				if (reqModel.getSearch() != null) {
					callableStatement.setString(11, reqModel.getSearch());
				} else {
					callableStatement.setString(11, null);
				}
				if (reqModel.getCount() != null) {
					callableStatement.setInt(12, reqModel.getCount());
				} else {
					callableStatement.setString(12, null);
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("insertupdateslotmasternew", l_lstResult);
				}
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getslotmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_SLOT_MASTER_EXPORT + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getslotmasterexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getrescheduleandcanncellationexport(RescheduleAndCancellationExportReqModel reqModel)
			throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_RESCHEDULE_AND_CANNCELLATION_DETAILS_EXPORT
								+ "(?,?,?)}");

				if (reqModel.getStartdate() != null) {
					callableStatement.setDate(1, reqModel.getStartdate());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getEnddate() != null) {
					callableStatement.setDate(2, reqModel.getEnddate());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getStatus() != null) {
					callableStatement.setString(3, reqModel.getStatus());
				} else {
					callableStatement.setString(3, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("getrescheduleandcanncellationexport", l_lstResult);
				}
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getslotcountt() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_SLOT_COUNT + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getslotcountt", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getbrandmaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_BRAND_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getbrandmaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getemailpromotionaltemplatemaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_EMAIL_PEOMOTIONAL_TEMPLATE_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getemailpromotionaltemplatemaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getemailtransactionaltemplatemaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_EMAIL_TRANSACTIONAL_TEMPLATE_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getemailtransactionaltemplatemaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertemailtemplatedetailstransactional(TemplateDetailsReqModel reqModel)
			throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_EMAIL_TEMPLATE_DETAILS_TRANSACTIONAL
								+ "(?,?,?,?)}");

				if (reqModel.getTypeid() != null) {
					callableStatement.setLong(1, reqModel.getTypeid());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getSubject() != null) {
					callableStatement.setString(2, reqModel.getSubject());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getTemplate() != null) {
					callableStatement.setString(3, reqModel.getTemplate());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getUserid() != null) {
					callableStatement.setInt(4, reqModel.getUserid());
				} else {
					callableStatement.setString(4, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("insertemailtemplatedetailstransactional", l_lstResult);
				}
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertemailtemplatedetailspromotional(TemplateDetailsReqModel reqModel)
			throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_EMAIL_TEMPLATE_DETAILS_PEOMOTIONAL
								+ "(?,?,?,?,?)}");

				if (reqModel.getTypeid() != null) {
					callableStatement.setLong(1, reqModel.getTypeid());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getSubject() != null) {
					callableStatement.setString(2, reqModel.getSubject());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getTemplate() != null) {
					callableStatement.setString(3, reqModel.getTemplate());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getUserid() != null) {
					callableStatement.setInt(4, reqModel.getUserid());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getStatus() != null) {
					callableStatement.setInt(5, reqModel.getStatus());
				} else {
					callableStatement.setString(5, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("insertemailtemplatedetailspromotional", l_lstResult);
				}
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getemailcategorymaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_EMAIL_CATEGORY_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getemailcategorymaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getemailcategorydetails(TemplateDetailsReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_EMAIL_CATEGORY_DETAILS + "(?)}");

				if (reqModel.getTypeid() != null) {
					callableStatement.setLong(1, reqModel.getTypeid());
				} else {
					callableStatement.setString(1, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("getemailcategorydetails", l_lstResult);
				}
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getemailtempaltedetails(TemplateDetailsReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_EMAIL_TEMPLATE_DETAILS + "(?)}");

				if (reqModel.getTypeid() != null) {
					callableStatement.setLong(1, reqModel.getTypeid());
				} else {
					callableStatement.setString(1, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("getemailtempaltedetails", l_lstResult);
				}
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertupdateemailtempaltedetails(TemplateDetailsReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall(
								"{call " + CommonConstants.USP_INSERT_UPDATE_EMAIL_TEMPLATE_DETAILS + "(?,?,?,?,?,?)}");

				if (reqModel.getTypeid() != null) {
					callableStatement.setLong(1, reqModel.getTypeid());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getEmailtypeid() != null) {
					callableStatement.setLong(2, reqModel.getEmailtypeid());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getSubject() != null) {
					callableStatement.setString(3, reqModel.getSubject());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getTemplate() != null) {
					callableStatement.setString(4, reqModel.getTemplate());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getUserid() != null) {
					callableStatement.setInt(5, reqModel.getUserid());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getStatus() != null) {
					callableStatement.setInt(6, reqModel.getStatus());
				} else {
					callableStatement.setString(6, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("insertemailtemplatedetailspromotional", l_lstResult);
				}
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getConfiguration(ConfigurationModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_CONFIGURATION_DETAILS + "(?,?,?)}");

				if (reqModel.getConfigurationid() != null) {
					callableStatement.setLong(1, reqModel.getConfigurationid());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getCustomerid() != null) {
					callableStatement.setLong(2, reqModel.getCustomerid());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getEmailtypeid() != null) {
					callableStatement.setLong(3, reqModel.getEmailtypeid());
				} else {
					callableStatement.setString(3, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			ConfigurationResponseModel configurationResponseModel = new ConfigurationResponseModel();
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				if (key.contains("result")) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					for (int i = 0; i < l_lstResult.size(); i++) {
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);

						configurationResponseModel.setFromaddress(l_hmColmnData.get("WC_CM_USERNAME"));
						configurationResponseModel.setToaddress(l_hmColmnData.get("EMAIL"));
						configurationResponseModel.setHost(l_hmColmnData.get("WC_CM_HOST"));
						configurationResponseModel.setPort(l_hmColmnData.get("WC_CM_PORT"));
						configurationResponseModel.setUsername(l_hmColmnData.get("WC_CM_USERNAME"));
						configurationResponseModel.setPassword(l_hmColmnData.get("WC_CM_PASSWORD"));
						configurationResponseModel.setTemplate(l_hmColmnData.get("TEMPLATE"));
						configurationResponseModel.setSubject(l_hmColmnData.get("TEMPLATE_SUBJECT"));

					}
				}
			}
			responseModel.setResponseObject(configurationResponseModel);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getbirthdaydetails() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_BIRTHDAY_DETAILS + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			int count = 0;
			// HashMap<String, Object> properties = new HashMap<>();
			List<EmailResponseModel> pickupfromCustResModels = new ArrayList<>();

			EmailResponseModel pickupfromCustResModel = null;

			for (String key : set) {
				count++;
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);

				for (int i = 0; i < l_lstResult.size(); i++) {
					pickupfromCustResModel = new EmailResponseModel();
					LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
					pickupfromCustResModel.setUserid(Long.valueOf(String.valueOf(l_hmColmnData.get("WC_MU_USER_ID"))));
					pickupfromCustResModel.setDoa(String.valueOf(l_hmColmnData.get("WC_UD_DOB")));
					pickupfromCustResModel.setEmailsent(Long.valueOf(String.valueOf(l_hmColmnData.get("sentmail"))));
					pickupfromCustResModels.add(pickupfromCustResModel);
				}

				responseModel.setRespList(pickupfromCustResModels);

			}

			// MyObject object = new MyObject(properties);
			// responseModel.setResponseObject(object);
			// responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		System.out.println(responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getanniversarydetails() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_ANNIVERSARY_DETAILS + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			int count = 0;
			// HashMap<String, Object> properties = new HashMap<>();
			List<EmailResponseModel> pickupfromCustResModels = new ArrayList<>();

			EmailResponseModel pickupfromCustResModel = null;

			for (String key : set) {
				count++;
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);

				for (int i = 0; i < l_lstResult.size(); i++) {
					pickupfromCustResModel = new EmailResponseModel();
					LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
					pickupfromCustResModel.setUserid(Long.valueOf(String.valueOf(l_hmColmnData.get("WC_MU_USER_ID"))));
					pickupfromCustResModel.setDoa(String.valueOf(l_hmColmnData.get("WC_UD_DOA")));
					pickupfromCustResModel.setEmailsent(Long.valueOf(String.valueOf(l_hmColmnData.get("sentmail"))));
					pickupfromCustResModels.add(pickupfromCustResModel);
				}

				responseModel.setRespList(pickupfromCustResModels);

			}

			// MyObject object = new MyObject(properties);
			// responseModel.setResponseObject(object);
			// responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		System.out.println(responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getnotificationsequencedetails(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_NOTIFICATION_SEQUENCE_DETAILS(?,?,?,?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());
				callableStatement.setInt(3, chalanMasterRequestModel.getStart());
				callableStatement.setInt(4, chalanMasterRequestModel.getEnd());
				callableStatement.setString(5, chalanMasterRequestModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getnotificationsequencedetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getnotificationsequencedetailsexport(ChallanMasterReqModel chalanMasterRequestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_NOTIFICATION_SEQUENCE_DETAILS_EXPORT(?,?)}");
				callableStatement.setDate(1, chalanMasterRequestModel.getStartdate());
				callableStatement.setDate(2, chalanMasterRequestModel.getEnddate());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getnotificationsequencedetailsexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getgrommingstandardsdetails(SocietyDetailsReqModel societyDetailsReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_GROOMING_STANDARDS_DETAILS(?,?,?,?)}");

				callableStatement.setInt(1, societyDetailsReqModel.getStart());
				callableStatement.setInt(2, societyDetailsReqModel.getEnd());
				callableStatement.setString(3, societyDetailsReqModel.getStatus());
				callableStatement.setString(4, societyDetailsReqModel.getSearch());

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getgrommingstandardsdetails", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		} // log.info("responseModel--"+responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertupdategrommingstandards(GrommingstandardsReqModel grommingstandardsReqModel)
			throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall(
								"{call " + CommonConstants.USP_INSERT_UPDATE_GROOMING_STANDARDS + "(?,?,?,?,?,?,?,?)}");

				if (grommingstandardsReqModel.getFlag() != null) {
					callableStatement.setInt(1, grommingstandardsReqModel.getFlag());
				} else {
					callableStatement.setString(1, null);
				}
				if (grommingstandardsReqModel.getTitle() != null) {
					callableStatement.setString(2, grommingstandardsReqModel.getTitle());
				} else {
					callableStatement.setString(2, null);
				}

				callableStatement.setString(3, grommingstandardsReqModel.getUserid());

				if (grommingstandardsReqModel.getDiscription() != null) {
					callableStatement.setString(4, grommingstandardsReqModel.getDiscription());
				} else {
					callableStatement.setString(4, null);
				}

				callableStatement.setString(5, grommingstandardsReqModel.getGsflag());

				if (grommingstandardsReqModel.getGsid() != null) {
					callableStatement.setInt(6, grommingstandardsReqModel.getGsid());
				} else {
					callableStatement.setString(6, null);
				}
				if (grommingstandardsReqModel.getOrder() != null) {
					callableStatement.setLong(7, grommingstandardsReqModel.getOrder());
				} else {
					callableStatement.setString(7, null);
				}
				if (grommingstandardsReqModel.getImagepath() != null) {
					callableStatement.setString(8, grommingstandardsReqModel.getImagepath());
				} else {
					callableStatement.setString(8, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("insertupdategrommingstandards", l_lstResult);
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getChatUserList(ChatUserReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.usp_GetChatUserList + "(?,?)}");

				if (reqModel.getUser_id() != null) {
					callableStatement.setLong(1, reqModel.getUser_id());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getRole_id() != null) {
					callableStatement.setInt(2, reqModel.getRole_id());
				} else {
					callableStatement.setString(2, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getChatUserList", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getlastmesssage(ChatUserReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.usp_GetLastMessage + "(?,?)}");

				if (reqModel.getUser_id() != null) {
					callableStatement.setLong(1, reqModel.getUser_id());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getOrderid() != null) {
					callableStatement.setLong(2, reqModel.getOrderid());
				} else {
					callableStatement.setString(2, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getlastmesssage", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getmessageHistory(ChatUserReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.usp_GetMessageHistory + "(?,?,?,?)}");

				if (reqModel.getFrom_user_id() != null) {
					callableStatement.setLong(1, reqModel.getFrom_user_id());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getTo_user_id() != null) {
					callableStatement.setLong(2, reqModel.getTo_user_id());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getPage_number() != null) {
					callableStatement.setInt(3, reqModel.getPage_number());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getOrderid() != null) {
					callableStatement.setLong(4, reqModel.getOrderid());
				} else {
					callableStatement.setString(4, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getmessageHistory", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getupdateMessageStatus(ChatUserReqModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.usp_UpdateMessageStatus + "(?,?,?,?,?)}");

				if (reqModel.getFrom_user_id() != null) {
					callableStatement.setLong(1, reqModel.getFrom_user_id());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getTo_user_id() != null) {
					callableStatement.setLong(2, reqModel.getTo_user_id());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getReturnvalues() != null) {
					callableStatement.setLong(3, reqModel.getReturnvalues());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getOrderid() != null) {
					callableStatement.setLong(4, reqModel.getOrderid());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getInvoiceid() != null) {
					callableStatement.setLong(5, reqModel.getInvoiceid());
				} else {
					callableStatement.setString(5, null);
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getupdateMessageStatus", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertUpdateAppQRcodeDetails(OrderDetailsReqModel orderReqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();

		try {
			List prmtrsList = new ArrayList();

			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			SQLServerDataTable collectitemsdetails = new SQLServerDataTable();
			collectitemsdetails.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMCOUNT", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMPRICE", java.sql.Types.DOUBLE);
			collectitemsdetails.addColumnMetadata("STAINID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("DAMAGEID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("COLOURID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("NOTES", java.sql.Types.VARCHAR);

			SQLServerDataTable damageitemsdetails = new SQLServerDataTable();
			damageitemsdetails.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMCOUNT", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMPRICE", java.sql.Types.DOUBLE);
			damageitemsdetails.addColumnMetadata("STAINID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("DAMAGEID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("COLOURID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("NOTES", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("BRANDID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("IMAGEPATH", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("IMAGENAME", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("ITEMQTYID", java.sql.Types.INTEGER);

			for (CollectItemDetailsModel d : orderReqModel.getCollectitems()) {
				if (d.getDamagedetails().size() == 0) {
					if (d.getStaindetails().size() == 0) {
						if (d.getColordetails().size() == 0) {
							if (d.getBranddetails().size() == 0) {
								collectitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()),
										Utils.checkNullandEmpty(d.getNotes()));
							}

						}
					}

				}
			}

			for (CollectItemDetailsModel d : orderReqModel.getCollectitems()) {
				int itemqtyid = 0;
				if (d.getDamagedetails() != null && d.getDamagedetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getDamagedetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid);
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									null, Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid);
						}

					}

				}
				if (d.getStaindetails() != null && d.getStaindetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getStaindetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid);
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), null,
									Utils.checkNullandEmpty(d.getDamageid()), Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid);
						}

					}
				}
				if (d.getColordetails() != null && d.getColordetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getColordetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(object.getId()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid);
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									Utils.checkNullandEmpty(d.getDamageid()), null,
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid);
						}

					}

				}
				if (d.getBranddetails() != null && d.getBranddetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getBranddetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid);
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									Utils.checkNullandEmpty(d.getDamageid()), Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), null, null, null, itemqtyid);
						}

					}

				}
			}

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_APP_QRCODE_DETAILS
								+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					cs.setLong(1, orderReqModel.getOrderid());
					cs.setLong(2, orderReqModel.getCustomerid());
					cs.setStructured(3, "dbo.UTT_COLLECT_ITEMS_DETAILS", collectitemsdetails);
					cs.setString(4, Utils.checkNull(orderReqModel.getRemarks()));
					if (orderReqModel.getInvoiceamount() != null) {
						cs.setDouble(5, orderReqModel.getInvoiceamount());
					} else {
						cs.setString(5, null);
					}
					if (orderReqModel.getSubtotal() != null) {
						cs.setDouble(6, orderReqModel.getSubtotal());
					} else {
						cs.setString(6, null);
					}
					if (orderReqModel.getDiscount() != null) {
						cs.setDouble(7, orderReqModel.getDiscount());
					} else {
						cs.setString(7, null);
					}
					if (orderReqModel.getDeliveryfee() != null) {
						cs.setDouble(8, orderReqModel.getDeliveryfee());
					} else {
						cs.setString(8, null);
					}
					if (orderReqModel.getTotal() != null) {
						cs.setDouble(9, orderReqModel.getTotal());
					} else {
						cs.setString(9, null);
					}
					if (orderReqModel.getTax() != null) {
						cs.setDouble(10, orderReqModel.getTax());
					} else {
						cs.setString(10, null);
					}
					if (orderReqModel.getDeliverymode() != null) {
						cs.setLong(11, orderReqModel.getDeliverymode());
					} else {
						cs.setString(11, null);
					}
					if (orderReqModel.getIsnotification() != null) {
						cs.setLong(12, orderReqModel.getIsnotification());
					} else {
						cs.setString(12, null);
					}

					// cs.setInt(12,orderReqModel.getIsnotification());
					cs.setDouble(13, orderReqModel.getDiscountpercent());
					cs.setDouble(14, orderReqModel.getDeliverypercent());
					cs.setStructured(15, "dbo.UTT_ITEMS_DAMAGE_QTY_DETAILS_NEW", damageitemsdetails);
					if (orderReqModel.getUserid() != null) {
						cs.setLong(16, orderReqModel.getUserid());
					} else {
						cs.setString(16, null);
					}
					if (orderReqModel.getInvoiceid() != null) {
						cs.setLong(17, orderReqModel.getInvoiceid());
					} else {
						cs.setString(17, null);
					}
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());

			for (String key : set) {
				if (key.contains("result")) {
					List<NewOrderResModel> newOrderResModel = new ArrayList<>();
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);

					NewOrderResModel newOrderResModels = null;
					for (int i = 0; i < l_lstResult.size(); i++) {
						newOrderResModels = new NewOrderResModel();
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);

						responseModel.setStatusCode(Integer.valueOf(String.valueOf(l_hmColmnData.get("status"))));
						if (responseModel.getStatusCode() == 200) {
							responseModel.setMessage(String.valueOf(l_hmColmnData.get("message")));

							newOrderResModels.setItemid(Integer.valueOf(String.valueOf(l_hmColmnData.get("ITEMID"))));
							newOrderResModels
									.setItemcount(Integer.valueOf(String.valueOf(l_hmColmnData.get("ITEMCOUNT"))));
							newOrderResModels.setItemname(String.valueOf(l_hmColmnData.get("ITEMNAME")));
							newOrderResModels.setServicename(String.valueOf(l_hmColmnData.get("SERVICENAME")));
							newOrderResModels.setQrcode(String.valueOf(l_hmColmnData.get("QRCODE")));
							newOrderResModels.setCustomername(String.valueOf(l_hmColmnData.get("CUSTOMERNAME")));
							// newOrderResModels.setInvoiceid(Long.valueOf(String.valueOf(l_hmColmnData.get("invoiceid"))));
							// if (newOrderResModels.getInvoiceid() != null) {
							// newOrderResModels.setInvoiceid(Long.valueOf(String.valueOf(l_hmColmnData.get("invoiceid"))));
							// } else {
							// newOrderResModels.setInvoiceid(null);
							// }
							newOrderResModels.setSocietyname(String.valueOf(l_hmColmnData.get("SOCIETYNAME")));
							newOrderResModels.setFlatno(String.valueOf(l_hmColmnData.get("FLATNO")));
							newOrderResModels.setOrdercode(String.valueOf(l_hmColmnData.get("ORDERCODE")));
							newOrderResModels.setBrandname(String.valueOf(l_hmColmnData.get("BRANDNAME")));
							newOrderResModel.add(newOrderResModels);
						}

						else {
							responseModel.setMessage(String.valueOf(l_hmColmnData.get("message")));
						}
					}
					responseModel.setResponseObject(newOrderResModel);
				}
			}
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		System.out.println(responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertUpdateOrderSubmitDetails(OrderDetailsReqModel orderReqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();

		try {
			List prmtrsList = new ArrayList();

			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			SQLServerDataTable collectitemsdetails = new SQLServerDataTable();
			collectitemsdetails.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMCOUNT", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMPRICE", java.sql.Types.DOUBLE);
			collectitemsdetails.addColumnMetadata("STAINID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("DAMAGEID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("COLOURID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("NOTES", java.sql.Types.VARCHAR);

			SQLServerDataTable imagedetails = new SQLServerDataTable();
			imagedetails.addColumnMetadata("QRCODE", java.sql.Types.VARCHAR);
			imagedetails.addColumnMetadata("IMAGEPATH", java.sql.Types.VARCHAR);
			imagedetails.addColumnMetadata("IMAGENAME", java.sql.Types.VARCHAR);

			SQLServerDataTable damageitemsdetails = new SQLServerDataTable();
			damageitemsdetails.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMCOUNT", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMPRICE", java.sql.Types.DOUBLE);
			damageitemsdetails.addColumnMetadata("STAINID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("DAMAGEID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("COLOURID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("NOTES", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("BRANDID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("IMAGEPATH", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("IMAGENAME", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("ITEMQTYID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("CHECKAPPROVAL", java.sql.Types.INTEGER);

			for (CollectItemDetailsModel d : orderReqModel.getCollectitems()) {
				if (d.getDamagedetails().size() == 0) {
					if (d.getStaindetails().size() == 0) {
						if (d.getColordetails().size() == 0) {
							if (d.getBranddetails().size() == 0) {
								collectitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()),
										Utils.checkNullandEmpty(d.getNotes()));
							}

						}
					}

				}
			}

			for (CollectItemDetailsModel d : orderReqModel.getCollectitems()) {
				if (d.getImagedetails() != null && d.getImagedetails().size() > 0) {
					for (List<Imagedetails> objects : d.getImagedetails()) {
						if (objects.size() > 0) {
							for (Imagedetails object : objects) {
								imagedetails.addRow(Utils.checkNullandEmpty(object.getQrcode()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()));
							}
						}
					}
				}

			}
			for (CollectItemDetailsModel d : orderReqModel.getCollectitems()) {
				int itemqtyid = 0;
				if (d.getDamagedetails() != null && d.getDamagedetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getDamagedetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid,
										Utils.checkNullandEmpty(object.getFlag()));
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									null, Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid, null);
						}

					}

				}
				if (d.getStaindetails() != null && d.getStaindetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getStaindetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid,
										Utils.checkNullandEmpty(object.getFlag()));
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), null,
									Utils.checkNullandEmpty(d.getDamageid()), Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid, null);
						}

					}
				}
				if (d.getColordetails() != null && d.getColordetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getColordetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(object.getId()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid,
										Utils.checkNullandEmpty(object.getFlag()));
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									Utils.checkNullandEmpty(d.getDamageid()), null,
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid, null);
						}

					}

				}
				if (d.getBranddetails() != null && d.getBranddetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getBranddetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid,
										Utils.checkNullandEmpty(object.getFlag()));
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									Utils.checkNullandEmpty(d.getDamageid()), Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), null, null, null, itemqtyid, null);
						}

					}

				}
			}

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_ORDER_SUBMIT_DETAILS
								+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					cs.setLong(1, orderReqModel.getOrderid());
					cs.setLong(2, orderReqModel.getCustomerid());
					cs.setStructured(3, "dbo.UTT_COLLECT_ITEMS_DETAILS", collectitemsdetails);
					cs.setString(4, Utils.checkNull(orderReqModel.getRemarks()));
					if (orderReqModel.getInvoiceamount() != null) {
						cs.setDouble(5, orderReqModel.getInvoiceamount());
					} else {
						cs.setString(5, null);
					}
					if (orderReqModel.getSubtotal() != null) {
						cs.setDouble(6, orderReqModel.getSubtotal());
					} else {
						cs.setString(6, null);
					}
					if (orderReqModel.getDiscount() != null) {
						cs.setDouble(7, orderReqModel.getDiscount());
					} else {
						cs.setString(7, null);
					}
					if (orderReqModel.getDeliveryfee() != null) {
						cs.setDouble(8, orderReqModel.getDeliveryfee());
					} else {
						cs.setString(8, null);
					}
					if (orderReqModel.getTotal() != null) {
						cs.setDouble(9, orderReqModel.getTotal());
					} else {
						cs.setString(9, null);
					}
					if (orderReqModel.getTax() != null) {
						cs.setDouble(10, orderReqModel.getTax());
					} else {
						cs.setString(10, null);
					}
					// cs.setDouble(5,orderReqModel.getInvoiceamount());
					// cs.setDouble(6,orderReqModel.getSubtotal());
					// cs.setDouble(7,orderReqModel.getDiscount());
					// cs.setDouble(8,orderReqModel.getDeliveryfee());
					// cs.setDouble(9,orderReqModel.getTotal());
					// cs.setDouble(10,orderReqModel.getTax());
					if (orderReqModel.getDeliverymode() != null) {
						cs.setLong(11, orderReqModel.getDeliverymode());
					} else {
						cs.setString(11, null);
					}
					// cs.setInt(12,orderReqModel.getIsnotification());
					if (orderReqModel.getIsnotification() != null) {
						cs.setLong(12, orderReqModel.getIsnotification());
					} else {
						cs.setString(12, null);
					}
					cs.setDouble(13, orderReqModel.getDiscountpercent());
					cs.setDouble(14, orderReqModel.getDeliverypercent());
					cs.setStructured(15, "dbo.UTT_ITEMSDAMAGE_QTY_DETAILS", damageitemsdetails);
					cs.setStructured(16, "dbo.UTT_REFERENCE_IMAGE", imagedetails);
					if (orderReqModel.getUserid() != null) {
						cs.setLong(17, orderReqModel.getUserid());
					} else {
						cs.setString(17, null);
					}
					if (orderReqModel.getInvoiceid() != null) {
						cs.setLong(18, orderReqModel.getInvoiceid());
					} else {
						cs.setString(18, null);
					}
					if (orderReqModel.getOrderflag() != null) {
						cs.setLong(19, orderReqModel.getOrderflag());
					} else {
						cs.setString(19, null);
					}
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());

			for (String key : set) {
				if (key.contains("result")) {
					List<NewOrderResModel> newOrderResModel = new ArrayList<>();
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);

					NewOrderResModel newOrderResModels = null;
					for (int i = 0; i < l_lstResult.size(); i++) {
						newOrderResModels = new NewOrderResModel();
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);

						responseModel.setStatusCode(Integer.valueOf(String.valueOf(l_hmColmnData.get("status"))));
						if (responseModel.getStatusCode() == 200) {
							responseModel.setMessage(String.valueOf(l_hmColmnData.get("message")));

							newOrderResModels.setItemid(Integer.valueOf(String.valueOf(l_hmColmnData.get("ITEMID"))));
							newOrderResModels
									.setItemcount(Integer.valueOf(String.valueOf(l_hmColmnData.get("ITEMCOUNT"))));
							newOrderResModels.setItemname(String.valueOf(l_hmColmnData.get("ITEMNAME")));
							newOrderResModels.setServicename(String.valueOf(l_hmColmnData.get("SERVICENAME")));
							newOrderResModels.setQrcode(String.valueOf(l_hmColmnData.get("QRCODE")));
							newOrderResModels.setCustomername(String.valueOf(l_hmColmnData.get("CUSTOMERNAME")));
							// newOrderResModels.setInvoiceid(Long.valueOf(String.valueOf(l_hmColmnData.get("invoiceid"))));
							if (l_hmColmnData.get("invoiceid") != null) {
								newOrderResModels
										.setInvoiceid(Long.valueOf(String.valueOf(l_hmColmnData.get("invoiceid"))));
							} else {
								newOrderResModels.setInvoiceid(null);
							}
							newOrderResModels.setSocietyname(String.valueOf(l_hmColmnData.get("SOCIETYNAME")));
							newOrderResModels.setFlatno(String.valueOf(l_hmColmnData.get("FLATNO")));
							newOrderResModels.setOrdercode(String.valueOf(l_hmColmnData.get("ORDERCODE")));
							;
							newOrderResModels.setNotification(String.valueOf(l_hmColmnData.get("NOTIFICATION")));
							newOrderResModels.setMobile_id(String.valueOf(l_hmColmnData.get("mobile_id")));
							newOrderResModel.add(newOrderResModels);
						}

						else {
							responseModel.setMessage(String.valueOf(l_hmColmnData.get("message")));
						}
					}
					responseModel.setResponseObject(newOrderResModel);
					responseModel.setResponseObj(newOrderResModels);
				}
			}
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		System.out.println(responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getWcSocietyMaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_WC_SOCIETY_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getWcSocietyMaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertUpdateWebQrcodeDetails(OrderDetailsReqModel orderReqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();

		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			SQLServerDataTable collectitemsdetails = new SQLServerDataTable();
			collectitemsdetails.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMCOUNT", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMPRICE", java.sql.Types.DOUBLE);
			collectitemsdetails.addColumnMetadata("STAINID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("DAMAGEID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("COLOURID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("NOTES", java.sql.Types.VARCHAR);

			SQLServerDataTable damageitemsdetails = new SQLServerDataTable();
			damageitemsdetails.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMCOUNT", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMPRICE", java.sql.Types.DOUBLE);
			damageitemsdetails.addColumnMetadata("STAINID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("DAMAGEID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("COLOURID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("NOTES", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("BRANDID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("IMAGEPATH", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("IMAGENAME", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("ITEMQTYID", java.sql.Types.INTEGER);

			for (CollectItemDetailsModel d : orderReqModel.getCollectitems()) {
				if (d.getDamagedetails().size() == 0) {
					if (d.getStaindetails().size() == 0) {
						if (d.getColordetails().size() == 0) {
							if (d.getBranddetails().size() == 0) {

								collectitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()),
										Utils.checkNullandEmpty(d.getNotes()));
							}

						}
					}

				}
			}

			for (CollectItemDetailsModel d : orderReqModel.getCollectitems()) {
				int itemqtyid = 0;
				if (d.getDamagedetails() != null && d.getDamagedetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getDamagedetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid);
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									null, Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid);
						}

					}

				}
				if (d.getStaindetails() != null && d.getStaindetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getStaindetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid);
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), null,
									Utils.checkNullandEmpty(d.getDamageid()), Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid);
						}

					}
				}
				if (d.getColordetails() != null && d.getColordetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getColordetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(object.getId()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid);
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									Utils.checkNullandEmpty(d.getDamageid()), null,
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid);
						}

					}

				}
				if (d.getBranddetails() != null && d.getBranddetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getBranddetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid);
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									Utils.checkNullandEmpty(d.getDamageid()), Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), null, null, null, itemqtyid);
						}

					}

				}
			}

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_WEB_QRCODE_DETAILS
								+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					cs.setString(1, orderReqModel.getName());
					cs.setString(2, orderReqModel.getEmailid());
					cs.setString(3, orderReqModel.getMobileno());
					cs.setLong(4, orderReqModel.getTypeid());
					if (orderReqModel.getDob() != null) {
						cs.setDate(5, Utils.utilDateTojavaSqlDate(orderReqModel.getDob()));
					} else {
						cs.setString(5, null);
					}
					if (orderReqModel.getDoa() != null) {
						cs.setDate(6, Utils.utilDateTojavaSqlDate(orderReqModel.getDoa()));
					} else {
						cs.setString(6, null);
					}
					cs.setString(7, orderReqModel.getAddressline1());
					cs.setString(8, orderReqModel.getAddressline2());
					cs.setString(9, orderReqModel.getPincode());
					cs.setStructured(10, "dbo.UTT_COLLECT_ITEMS_DETAILS", collectitemsdetails);

					if (orderReqModel.getPickupdate() != null) {
						cs.setString(11, orderReqModel.getPickupdate());
					} else {
						cs.setString(11, null);
					}
					if (orderReqModel.getPickuptimeid() != null) {
						cs.setLong(12, orderReqModel.getPickuptimeid());
					} else {
						cs.setString(12, null);
					}
					if (orderReqModel.getDeliverymode() != null) {
						cs.setLong(13, orderReqModel.getDeliverymode());
					} else {
						cs.setString(13, null);
					}
					cs.setString(14, orderReqModel.getRemarks());

					if (orderReqModel.getInvoiceamount() != null) {
						cs.setDouble(15, orderReqModel.getInvoiceamount());
					} else {
						cs.setString(15, null);
					}

					if (orderReqModel.getSubtotal() != null) {
						cs.setDouble(16, orderReqModel.getSubtotal());
					} else {
						cs.setString(16, null);
					}
					if (orderReqModel.getDiscount() != null) {
						cs.setDouble(17, orderReqModel.getDiscount());
					} else {
						cs.setString(17, null);
					}
					if (orderReqModel.getDeliveryfee() != null) {
						cs.setDouble(18, orderReqModel.getDeliveryfee());
					} else {
						cs.setString(18, null);
					}
					if (orderReqModel.getTotal() != null) {
						cs.setDouble(19, orderReqModel.getTotal());
					} else {
						cs.setString(19, null);
					}
					if (orderReqModel.getTax() != null) {
						cs.setDouble(20, orderReqModel.getTax());
					} else {
						cs.setString(20, null);
					}

					if (orderReqModel.getIsnotification() != null) {
						cs.setLong(21, orderReqModel.getIsnotification());
					} else {
						cs.setString(21, null);
					}
					// cs.setInt(21,orderReqModel.getIsnotification());
					if (orderReqModel.getOrderid() != null) {
						cs.setLong(22, orderReqModel.getOrderid());
					} else {
						cs.setString(22, null);
					}

					if (orderReqModel.getCustomerid() != null) {
						cs.setLong(23, orderReqModel.getCustomerid());
					} else {
						cs.setString(23, null);
					}
					if (orderReqModel.getUserid() != null) {
						cs.setLong(24, orderReqModel.getUserid());
					} else {
						cs.setString(24, null);
					}
					if (orderReqModel.getInvoiceid() != null) {
						cs.setInt(25, orderReqModel.getInvoiceid());
					} else {
						cs.setString(25, null);
					}
					if (orderReqModel.getDiscountpercent() != null) {
						cs.setDouble(26, orderReqModel.getDiscountpercent());
					} else {
						cs.setString(26, null);
					}
					if (orderReqModel.getDeliverypercent() != null) {
						cs.setDouble(27, orderReqModel.getDeliverypercent());
					} else {
						cs.setString(27, null);
					}
					if (orderReqModel.getDeliverytypeid() != null) {
						cs.setInt(28, orderReqModel.getDeliverytypeid());
					} else {
						cs.setString(28, null);
					}
					if (orderReqModel.getQuckdeliveryid() != null) {
						cs.setInt(29, orderReqModel.getQuckdeliveryid());
					} else {
						cs.setString(29, null);
					}
					cs.setStructured(30, "dbo.UTT_ITEMS_DAMAGE_QTY_DETAILS_NEW", damageitemsdetails);

					if (orderReqModel.getDeliverydate() != null) {
						cs.setString(31, orderReqModel.getDeliverydate());
					} else {
						cs.setString(31, null);
					}

					if (orderReqModel.getOrdertype() != null) {
						cs.setInt(32, orderReqModel.getOrdertype());
					} else {
						cs.setString(32, null);
					}
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());

			for (String key : set) {
				if (key.contains("result")) {
					List<NewOrderResModel> newOrderResModel = new ArrayList<>();
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);

					NewOrderResModel newOrderResModels = null;
					for (int i = 0; i < l_lstResult.size(); i++) {
						newOrderResModels = new NewOrderResModel();
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);

						responseModel.setStatusCode(Integer.valueOf(String.valueOf(l_hmColmnData.get("status"))));
						if (responseModel.getStatusCode() == 200) {
							responseModel.setMessage(String.valueOf(l_hmColmnData.get("message")));
							responseModel.setOrderid(Long.valueOf(String.valueOf(l_hmColmnData.get("ORDERID"))));

							newOrderResModels.setItemid(Integer.valueOf(String.valueOf(l_hmColmnData.get("ITEMID"))));
							newOrderResModels
									.setItemcount(Integer.valueOf(String.valueOf(l_hmColmnData.get("ITEMCOUNT"))));
							newOrderResModels.setItemname(String.valueOf(l_hmColmnData.get("ITEMNAME")));
							newOrderResModels
									.setServicename(Utils.checkNull(String.valueOf(l_hmColmnData.get("SERVICENAME"))));
							newOrderResModels.setQrcode(String.valueOf(l_hmColmnData.get("QRCODE")));
							newOrderResModels.setCustomername(String.valueOf(l_hmColmnData.get("CUSTOMERNAME")));
							// newOrderResModels.setInvoiceid(Long.valueOf(String.valueOf(l_hmColmnData.get("invoiceid"))));
							newOrderResModels
									.setNewuserid(Long.valueOf(String.valueOf(l_hmColmnData.get("newuserid"))));
							newOrderResModels.setSocietyname(String.valueOf(l_hmColmnData.get("SOCIETYNAME")));
							newOrderResModels.setFlatno(String.valueOf(l_hmColmnData.get("FLATNO")));
							newOrderResModels.setOrdercode(String.valueOf(l_hmColmnData.get("ORDERCODE")));
							newOrderResModels.setBrandname(String.valueOf(l_hmColmnData.get("BRANDNAME")));

							newOrderResModel.add(newOrderResModels);
						}

						else {
							responseModel.setMessage(String.valueOf(l_hmColmnData.get("message")));
						}
					}
					responseModel.setResponseObject(newOrderResModel);
				}
			}
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		System.out.println(responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertUpdateWebSubmitDetails(OrderDetailsReqModel orderReqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();

		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.DOUBLE));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));

			SQLServerDataTable collectitemsdetails = new SQLServerDataTable();
			collectitemsdetails.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMCOUNT", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMPRICE", java.sql.Types.DOUBLE);
			collectitemsdetails.addColumnMetadata("STAINID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("DAMAGEID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("COLOURID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("NOTES", java.sql.Types.VARCHAR);

			SQLServerDataTable imagedetails = new SQLServerDataTable();
			imagedetails.addColumnMetadata("QRCODE", java.sql.Types.VARCHAR);
			imagedetails.addColumnMetadata("IMAGEPATH", java.sql.Types.VARCHAR);
			imagedetails.addColumnMetadata("IMAGENAME", java.sql.Types.VARCHAR);

			SQLServerDataTable damageitemsdetails = new SQLServerDataTable();
			damageitemsdetails.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMCOUNT", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMPRICE", java.sql.Types.DOUBLE);
			damageitemsdetails.addColumnMetadata("STAINID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("DAMAGEID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("COLOURID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("NOTES", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("BRANDID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("IMAGEPATH", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("IMAGENAME", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("ITEMQTYID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("CHECKAPPROVAL", java.sql.Types.INTEGER);

			for (CollectItemDetailsModel d : orderReqModel.getCollectitems()) {
				if (d.getDamagedetails().size() == 0) {
					if (d.getStaindetails().size() == 0) {
						if (d.getColordetails().size() == 0) {
							if (d.getBranddetails().size() == 0) {

								collectitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()),
										Utils.checkNullandEmpty(d.getNotes()));
							}

						}
					}

				}
			}

			for (CollectItemDetailsModel d : orderReqModel.getCollectitems()) {
				if (d.getImagedetails() != null && d.getImagedetails().size() > 0) {
					for (List<Imagedetails> objects : d.getImagedetails()) {
						if (objects.size() > 0) {
							for (Imagedetails object : objects) {
								imagedetails.addRow(Utils.checkNullandEmpty(object.getQrcode()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()));
							}
						}
					}
				}

			}

			for (CollectItemDetailsModel d : orderReqModel.getCollectitems()) {
				int itemqtyid = 0;
				if (d.getDamagedetails() != null && d.getDamagedetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getDamagedetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid,
										Utils.checkNullandEmpty(object.getFlag()));
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									null, Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid, null);
						}

					}

				}
				if (d.getStaindetails() != null && d.getStaindetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getStaindetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid,
										Utils.checkNullandEmpty(object.getFlag()));
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), null,
									Utils.checkNullandEmpty(d.getDamageid()), Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid, null);
						}

					}
				}
				if (d.getColordetails() != null && d.getColordetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getColordetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(object.getId()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(d.getBrandid()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid,
										Utils.checkNullandEmpty(object.getFlag()));
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									Utils.checkNullandEmpty(d.getDamageid()), null,
									Utils.checkNullandEmpty(d.getNotes()), Utils.checkNullandEmpty(d.getBrandid()),
									null, null, itemqtyid, null);
						}

					}

				}
				if (d.getBranddetails() != null && d.getBranddetails().size() > 0) {
					itemqtyid = 0;
					for (List<Damagedetails> objects : d.getBranddetails()) {
						itemqtyid++;
						if (objects.size() > 0) {
							for (Damagedetails object : objects) {
								damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemcount()),
										Utils.checkNullandEmpty(d.getItemprice()),
										Utils.checkNullandEmpty(d.getStainid()),
										Utils.checkNullandEmpty(d.getDamageid()),
										Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getNotes()),
										Utils.checkNullandEmpty(object.getId()),
										Utils.checkNullandEmpty(object.getImagepath()),
										Utils.checkNullandEmpty(object.getName()), itemqtyid,
										Utils.checkNullandEmpty(object.getFlag()));
							}
						} else {
							damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
									Utils.checkNullandEmpty(d.getItemid()), Utils.checkNullandEmpty(d.getItemcount()),
									Utils.checkNullandEmpty(d.getItemprice()), Utils.checkNullandEmpty(d.getStainid()),
									Utils.checkNullandEmpty(d.getDamageid()), Utils.checkNullandEmpty(d.getColourid()),
									Utils.checkNullandEmpty(d.getNotes()), null, null, null, itemqtyid, null);
						}

					}

				}
			}

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_WEB_SUBMIT_DETAILS
								+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					cs.setString(1, orderReqModel.getName());
					cs.setString(2, orderReqModel.getEmailid());
					cs.setString(3, orderReqModel.getMobileno());
					cs.setLong(4, orderReqModel.getTypeid());
					if (orderReqModel.getDob() != null) {
						cs.setDate(5, Utils.utilDateTojavaSqlDate(orderReqModel.getDob()));
					} else {
						cs.setString(5, null);
					}
					if (orderReqModel.getDoa() != null) {
						cs.setDate(6, Utils.utilDateTojavaSqlDate(orderReqModel.getDoa()));
					} else {
						cs.setString(6, null);
					}
					cs.setString(7, orderReqModel.getAddressline1());
					cs.setString(8, orderReqModel.getAddressline2());
					cs.setString(9, orderReqModel.getPincode());
					cs.setStructured(10, "dbo.UTT_COLLECT_ITEMS_DETAILS", collectitemsdetails);

					if (orderReqModel.getPickupdate() != null) {
						cs.setString(11, orderReqModel.getPickupdate());
					} else {
						cs.setString(11, null);
					}
					if (orderReqModel.getPickuptimeid() != null) {
						cs.setLong(12, orderReqModel.getPickuptimeid());
					} else {
						cs.setString(12, null);
					}
					if (orderReqModel.getDeliverymode() != null) {
						cs.setLong(13, orderReqModel.getDeliverymode());
					} else {
						cs.setString(13, null);
					}
					cs.setString(14, orderReqModel.getRemarks());

					if (orderReqModel.getInvoiceamount() != null) {
						cs.setDouble(15, orderReqModel.getInvoiceamount());
					} else {
						cs.setString(15, null);
					}

					if (orderReqModel.getSubtotal() != null) {
						cs.setDouble(16, orderReqModel.getSubtotal());
					} else {
						cs.setString(16, null);
					}
					if (orderReqModel.getDiscount() != null) {
						cs.setDouble(17, orderReqModel.getDiscount());
					} else {
						cs.setString(17, null);
					}
					if (orderReqModel.getDeliveryfee() != null) {
						cs.setDouble(18, orderReqModel.getDeliveryfee());
					} else {
						cs.setString(18, null);
					}
					if (orderReqModel.getTotal() != null) {
						cs.setDouble(19, orderReqModel.getTotal());
					} else {
						cs.setString(19, null);
					}
					if (orderReqModel.getTax() != null) {
						cs.setDouble(20, orderReqModel.getTax());
					} else {
						cs.setString(20, null);
					}
					// cs.setInt(21,orderReqModel.getIsnotification());

					if (orderReqModel.getIsnotification() != null) {
						cs.setLong(21, orderReqModel.getIsnotification());
					} else {
						cs.setString(21, null);
					}

					if (orderReqModel.getOrderid() != null) {
						cs.setLong(22, orderReqModel.getOrderid());
					} else {
						cs.setString(22, null);
					}

					if (orderReqModel.getCustomerid() != null) {
						cs.setLong(23, orderReqModel.getCustomerid());
					} else {
						cs.setString(23, null);
					}
					if (orderReqModel.getUserid() != null) {
						cs.setLong(24, orderReqModel.getUserid());
					} else {
						cs.setString(24, null);
					}
					if (orderReqModel.getInvoiceid() != null) {
						cs.setInt(25, orderReqModel.getInvoiceid());
					} else {
						cs.setString(25, null);
					}
					if (orderReqModel.getDiscountpercent() != null) {
						cs.setDouble(26, orderReqModel.getDiscountpercent());
					} else {
						cs.setString(26, null);
					}
					if (orderReqModel.getDeliverypercent() != null) {
						cs.setDouble(27, orderReqModel.getDeliverypercent());
					} else {
						cs.setString(27, null);
					}
					if (orderReqModel.getDeliverytypeid() != null) {
						cs.setInt(28, orderReqModel.getDeliverytypeid());
					} else {
						cs.setString(28, null);
					}
					if (orderReqModel.getQuckdeliveryid() != null) {
						cs.setInt(29, orderReqModel.getQuckdeliveryid());
					} else {
						cs.setString(29, null);
					}
					if (orderReqModel.getDeliverydate() != null) {
						cs.setString(30, orderReqModel.getDeliverydate());
					} else {
						cs.setString(30, null);
					}
					if (orderReqModel.getOrdertype() != null) {
						cs.setInt(31, orderReqModel.getOrdertype());
					} else {
						cs.setString(31, null);
					}
					cs.setStructured(32, "dbo.UTT_ITEMSDAMAGE_QTY_DETAILS", damageitemsdetails);
					cs.setStructured(33, "dbo.UTT_REFERENCE_IMAGE", imagedetails);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());

			for (String key : set) {
				if (key.contains("result")) {
					List<NewOrderResModel> newOrderResModel = new ArrayList<>();
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);

					NewOrderResModel newOrderResModels = null;
					for (int i = 0; i < l_lstResult.size(); i++) {
						newOrderResModels = new NewOrderResModel();
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);

						responseModel.setStatusCode(Integer.valueOf(String.valueOf(l_hmColmnData.get("status"))));
						if (responseModel.getStatusCode() == 200) {
							responseModel.setMessage(String.valueOf(l_hmColmnData.get("message")));
							responseModel.setOrderid(Long.valueOf(String.valueOf(l_hmColmnData.get("ORDERID"))));

							newOrderResModels.setItemid(Integer.valueOf(String.valueOf(l_hmColmnData.get("ITEMID"))));
							newOrderResModels
									.setItemcount(Integer.valueOf(String.valueOf(l_hmColmnData.get("ITEMCOUNT"))));
							newOrderResModels.setItemname(String.valueOf(l_hmColmnData.get("ITEMNAME")));
							newOrderResModels
									.setServicename(Utils.checkNull(String.valueOf(l_hmColmnData.get("SERVICENAME"))));
							newOrderResModels.setQrcode(String.valueOf(l_hmColmnData.get("QRCODE")));
							newOrderResModels.setCustomername(String.valueOf(l_hmColmnData.get("CUSTOMERNAME")));
							newOrderResModels
									.setInvoiceid(Long.valueOf(String.valueOf(l_hmColmnData.get("invoiceid"))));
							newOrderResModels
									.setNewuserid(Long.valueOf(String.valueOf(l_hmColmnData.get("newuserid"))));
							newOrderResModels.setSocietyname(String.valueOf(l_hmColmnData.get("SOCIETYNAME")));
							newOrderResModels.setFlatno(String.valueOf(l_hmColmnData.get("FLATNO")));
							newOrderResModels.setOrdercode(String.valueOf(l_hmColmnData.get("ORDERCODE")));
							newOrderResModel.add(newOrderResModels);
						}

						else {
							responseModel.setMessage(String.valueOf(l_hmColmnData.get("message")));
						}
					}
					responseModel.setResponseObject(newOrderResModel);
				}
			}
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		System.out.println(responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getWcServiceType() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_WC_SERVICE_TYPE + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getWcServiceType", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getrangemaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_AGE_RANGE_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getrangemaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getStepsMaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_STEPS_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getStepsMaster", l_lstResult);
			}
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getinsertupdatestepsmaster(StepsMasterNewRequestModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection.prepareCall(
						"{call " + CommonConstants.USP_GET_INSERT_UPDATE_STEPS_MASTER + "(?,?,?,?,?,?,?,?,?,?)}");
				if (reqModel.getFlag() != null) {
					callableStatement.setInt(1, reqModel.getFlag());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getProcessingsteps() != null) {
					callableStatement.setString(2, reqModel.getProcessingsteps());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getDescription() != null) {
					callableStatement.setString(3, reqModel.getDescription());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getImagepath() != null) {
					callableStatement.setString(4, reqModel.getImagepath());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getRemarks() != null) {
					callableStatement.setString(5, reqModel.getRemarks());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getFlag() != null) {
					callableStatement.setInt(6, reqModel.getFlag());
				} else {
					callableStatement.setString(6, null);
				}

				if (reqModel.getStId() != null) {
					callableStatement.setInt(7, reqModel.getStId());
				} else {
					callableStatement.setString(7, null);
				}
				if (reqModel.getStart() != null) {
					callableStatement.setInt(8, reqModel.getStart());
				} else {
					callableStatement.setString(8, null);
				}
				if (reqModel.getEnd() != null) {
					callableStatement.setInt(9, reqModel.getEnd());
				} else {
					callableStatement.setString(9, null);
				}
				if (reqModel.getSearch() != null) {
					callableStatement.setString(10, reqModel.getSearch());
				} else {
					callableStatement.setString(10, null);
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getinsertupdatestepsmaster", l_lstResult);
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertmessagedetails(MessagedetailsModel messagedetailsModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_MESSAGE_DETAILS + "(?,?,?,?)}");
				callableStatement.setLong(1, messagedetailsModel.getUserid());
				callableStatement.setLong(2, messagedetailsModel.getFromid());
				callableStatement.setLong(3, messagedetailsModel.getToid());
				callableStatement.setString(4, messagedetailsModel.getAudioUrl());

				/*
				 * if (reqModel.getUserid() != null) { callableStatement.setLong(1,
				 * reqModel.getUserid()); } else { callableStatement.setString(1, null); } if
				 * (reqModel.getFromid() != null) { callableStatement.setLong(2,
				 * reqModel.getFromid()); } else { callableStatement.setString(2, null); } if
				 * (reqModel.getToid() != null) { callableStatement.setLong(3,
				 * reqModel.getToid()); } else { callableStatement.setString(3, null); } if
				 * (reqModel.getAudioUrl() != null) { callableStatement.setString(4,
				 * reqModel.getAudioUrl()); } else { callableStatement.setString(3, null); } //
				 * cs.execute();
				 */
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("insertmessagedetails", l_lstResult);
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getServiceStepsMaster(ServiceStepsMapppingReqModel reqModel) throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_SERVICE_STEPS_MASTER + "(?,?,?,?,?,?,?,?,?,?)}");
				if (reqModel.getFlag() != null) {
					callableStatement.setInt(1, reqModel.getFlag());
				} else {
					callableStatement.setString(1, null);
				}
				if (reqModel.getServiceid() != null) {
					callableStatement.setInt(2, reqModel.getServiceid());
				} else {
					callableStatement.setString(2, null);
				}
				if (reqModel.getStepsid() != null) {
					callableStatement.setInt(3, reqModel.getStepsid());
				} else {
					callableStatement.setString(3, null);
				}
				if (reqModel.getUserid() != null) {
					callableStatement.setString(4, reqModel.getUserid());
				} else {
					callableStatement.setString(4, null);
				}
				if (reqModel.getDmflag() != null) {
					callableStatement.setInt(5, reqModel.getDmflag());
				} else {
					callableStatement.setString(5, null);
				}
				if (reqModel.getSsmid() != null) {
					callableStatement.setInt(6, reqModel.getSsmid());
				} else {
					callableStatement.setString(6, null);
				}
				if (reqModel.getStart() != null) {
					callableStatement.setInt(7, reqModel.getStart());
				} else {
					callableStatement.setString(7, null);
				}
				if (reqModel.getEnd() != null) {
					callableStatement.setInt(8, reqModel.getEnd());
				} else {
					callableStatement.setString(8, null);
				}
				if (reqModel.getSearch() != null) {
					callableStatement.setString(9, reqModel.getSearch());
				} else {
					callableStatement.setString(9, null);
				}
				if (reqModel.getRoleid() != null) {
					callableStatement.setInt(10, reqModel.getRoleid());
				} else {
					callableStatement.setString(10, null);
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getServiceStepsMaster", l_lstResult);
			}
			responseModel.setResponseObject(properties);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getstepmasterreport() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_STEP_MASTER_REPORT + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getstepmasterreport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getservicestepmappingexport() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_SERVICE_STEP_MAPPING_EXPORT + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getservicestepmappingexport", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel updateitemwiseimageupload(ItemwiseImageReqModel itemwiseImageReqModel)
			throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();

		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			SQLServerDataTable collectitemsdetails = new SQLServerDataTable();
			collectitemsdetails.addColumnMetadata("ORDERID", java.sql.Types.BIGINT);
			collectitemsdetails.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ORCODE", java.sql.Types.VARCHAR);
			collectitemsdetails.addColumnMetadata("IMAGEPATH", java.sql.Types.VARCHAR);

			for (NewItemwiseImageReqModel d : itemwiseImageReqModel.getCollectitems()) {

				collectitemsdetails.addRow(Utils.checkNullandEmpty(d.getOrderid()),
						Utils.checkNullandEmpty(d.getServiceid()), Utils.checkNullandEmpty(d.getItemid()),
						Utils.checkNullandEmpty(d.getQrcode()), Utils.checkNullandEmpty(d.getImagepath()));

			}

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_UPDATE_ITEMWISE_IMAGE_UPLOAD + "(?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");
					cs.setStructured(1, "dbo.UTT_ITEMWISE_IMAGE_UPLOAD", collectitemsdetails);

					if (itemwiseImageReqModel.getUserid() != null) {
						cs.setLong(2, itemwiseImageReqModel.getUserid());
					} else {
						cs.setString(2, null);
					}
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// log.info(set.toString());

			for (String key : set) {
				if (key.contains("result")) {
					List<NewItemwiseImageReqModel> newItemwiseImageReqModel = new ArrayList<>();
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);

					NewItemwiseImageReqModel newItemwiseImageReqModels = null;
					for (int i = 0; i < l_lstResult.size(); i++) {
						newItemwiseImageReqModels = new NewItemwiseImageReqModel();
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);

						responseModel.setStatusCode(Integer.valueOf(String.valueOf(l_hmColmnData.get("status"))));

						responseModel.setMessage(String.valueOf(l_hmColmnData.get("message")));
					}

					responseModel.setResponseObject(newItemwiseImageReqModel);
				}
			}
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		System.out.println(responseModel);
		return responseModel;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public ResponseModel getprocessStsConfig() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_PROCESS_STS_CONFIGURATION()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			ProcessStsConfigModel processStsConfigModel = new ProcessStsConfigModel();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				for (int i = 0; i < l_lstResult.size(); i++) {
					LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
					processStsConfigModel.setLC_CM_SMS_API(l_hmColmnData.get("WC_CM_SMS_API"));
					processStsConfigModel.setLC_CM_HOST(l_hmColmnData.get("WC_CM_HOST"));
					processStsConfigModel.setLC_CM_PORT(l_hmColmnData.get("WC_CM_PORT"));
					processStsConfigModel.setLC_CM_USERNAME(l_hmColmnData.get("WC_CM_USERNAME"));
					processStsConfigModel.setLC_CM_PASSWORD(l_hmColmnData.get("WC_CM_PASSWORD"));
					processStsConfigModel.setLC_CM_PURPOSE(l_hmColmnData.get("WC_CM_PURPOSE"));
					processStsConfigModel.setLC_CM_FLAG(String.valueOf(l_hmColmnData.get("WC_CM_FLAG")));
					processStsConfigModel.setLC_CM_DOMAIN(String.valueOf(l_hmColmnData.get("WC_CM_DOMAIN")));
				}
			}
			responseModel.setResponseObject(processStsConfigModel);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public ResponseModel getprocessrescheduleconfiguration() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_PROCESS_RESCHEDULE_CONFIGURATION()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			ProcessRescheduleConfiguration configurationModel = new ProcessRescheduleConfiguration();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				for (int i = 0; i < l_lstResult.size(); i++) {
					LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
					configurationModel.setLC_CM_SMS_API(l_hmColmnData.get("WC_CM_SMS_API"));
					configurationModel.setLC_CM_HOST(l_hmColmnData.get("WC_CM_HOST"));
					configurationModel.setLC_CM_PORT(l_hmColmnData.get("WC_CM_PORT"));
					configurationModel.setLC_CM_USERNAME(l_hmColmnData.get("WC_CM_USERNAME"));
					configurationModel.setLC_CM_PASSWORD(l_hmColmnData.get("WC_CM_PASSWORD"));
					configurationModel.setLC_CM_PURPOSE(l_hmColmnData.get("WC_CM_PURPOSE"));
					configurationModel.setLC_CM_FLAG(String.valueOf(l_hmColmnData.get("WC_CM_FLAG")));
					configurationModel.setLC_CM_DOMAIN(String.valueOf(l_hmColmnData.get("WC_CM_DOMAIN")));
				}
			}
			responseModel.setResponseObject(configurationModel);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public ResponseModel getprocessneedapprovalconfig() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_PROCESS_NEED_APPROVAL_CONFIGURATION()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			ProcessRescheduleConfiguration configurationModel = new ProcessRescheduleConfiguration();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				for (int i = 0; i < l_lstResult.size(); i++) {
					LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
					configurationModel.setLC_CM_SMS_API(l_hmColmnData.get("WC_CM_SMS_API"));
					configurationModel.setLC_CM_HOST(l_hmColmnData.get("WC_CM_HOST"));
					configurationModel.setLC_CM_PORT(l_hmColmnData.get("WC_CM_PORT"));
					configurationModel.setLC_CM_USERNAME(l_hmColmnData.get("WC_CM_USERNAME"));
					configurationModel.setLC_CM_PASSWORD(l_hmColmnData.get("WC_CM_PASSWORD"));
					configurationModel.setLC_CM_PURPOSE(l_hmColmnData.get("WC_CM_PURPOSE"));
					configurationModel.setLC_CM_FLAG(String.valueOf(l_hmColmnData.get("WC_CM_FLAG")));
					configurationModel.setLC_CM_DOMAIN(String.valueOf(l_hmColmnData.get("WC_CM_DOMAIN")));
				}
			}
			responseModel.setResponseObject(configurationModel);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertUpdateOrderApprovelsDetails(OrderDetailsReqModel orderReqModel)
			throws SQLServerException {
		ResponseModel responseModel = new ResponseModel();

		try {
			List prmtrsList = new ArrayList();

			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			SQLServerDataTable collectitemsdetails = new SQLServerDataTable();
			collectitemsdetails.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			collectitemsdetails.addColumnMetadata("SERVICENAME", java.sql.Types.VARCHAR);
			collectitemsdetails.addColumnMetadata("ITEMNAME", java.sql.Types.VARCHAR);
			collectitemsdetails.addColumnMetadata("QRCODE", java.sql.Types.VARCHAR);
			collectitemsdetails.addColumnMetadata("FLAG", java.sql.Types.INTEGER);

			SQLServerDataTable imagedetails = new SQLServerDataTable();
			imagedetails.addColumnMetadata("IMAGEPATH", java.sql.Types.VARCHAR);
			imagedetails.addColumnMetadata("IMAGENAME", java.sql.Types.VARCHAR);

			SQLServerDataTable damageitemsdetails = new SQLServerDataTable();
			damageitemsdetails.addColumnMetadata("SERVICEID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("ITEMID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("STAINID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("DAMAGEID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("COLOURID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("BRANDID", java.sql.Types.INTEGER);
			damageitemsdetails.addColumnMetadata("QRCODE", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("IMAGEPATH", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("IMAGENAME", java.sql.Types.VARCHAR);
			damageitemsdetails.addColumnMetadata("ITEMQTYID", java.sql.Types.INTEGER);

			for (CollectItemDetailsModelinsp d : orderReqModel.getCollectitemsinsp()) {
				if (d.getDamagedetails().size() == 0) {
					if (d.getStaindetails().size() == 0) {
						if (d.getColordetails().size() == 0) {
							if (d.getBranddetails().size() == 0) {
								collectitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
										Utils.checkNullandEmpty(d.getItemid()),
										Utils.checkNullandEmpty(d.getItemname()),
										Utils.checkNullandEmpty(d.getQrcode()),
										Utils.checkNullandEmpty(d.getServicename()),
										Utils.checkNullandEmpty(d.getFlag()));
							}

						}
					}

				}
			}

			for (CollectItemDetailsModelinsp d : orderReqModel.getCollectitemsinsp()) {
				if (d.getImagedetails() != null && d.getImagedetails().size() > 0) {
					for (Imagedetails object : d.getImagedetails()) {
						imagedetails.addRow(Utils.checkNullandEmpty(object.getImagepath()),
								Utils.checkNullandEmpty(object.getName()));
					}
				}
			}

			for (CollectItemDetailsModelinsp d : orderReqModel.getCollectitemsinsp()) {
				if (d.getDamagedetails() != null && d.getDamagedetails().size() > 0) {
					for (Damagedetails object : d.getDamagedetails()) {
						damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
								Utils.checkNullandEmpty(d.getItemid()),
								Utils.checkNullandEmpty(d.getStainid()), Utils.checkNullandEmpty(object.getId()),
								Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getBrandid()),
								Utils.checkNullandEmpty(d.getQrcode()),
								Utils.checkNullandEmpty(object.getImagepath()),
								Utils.checkNullandEmpty(object.getName()), Utils.checkNullandEmpty(d.getFlag()));

					}

				}
				if (d.getStaindetails() != null && d.getStaindetails().size() > 0) {
					for (Damagedetails object : d.getStaindetails()) {
						damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
								Utils.checkNullandEmpty(d.getItemid()),
								Utils.checkNullandEmpty(object.getId()), Utils.checkNullandEmpty(d.getDamageid()),
								Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(d.getBrandid()),
								Utils.checkNullandEmpty(d.getQrcode()),
								Utils.checkNullandEmpty(object.getImagepath()),
								Utils.checkNullandEmpty(object.getName()), Utils.checkNullandEmpty(d.getFlag()));

					}
				}
				if (d.getColordetails() != null && d.getColordetails().size() > 0) {
					for (Damagedetails object : d.getColordetails()) {
						damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
								Utils.checkNullandEmpty(d.getItemid()),
								Utils.checkNullandEmpty(d.getStainid()), Utils.checkNullandEmpty(d.getDamageid()),
								Utils.checkNullandEmpty(object.getId()), Utils.checkNullandEmpty(d.getBrandid()),
								Utils.checkNullandEmpty(d.getQrcode()),
								Utils.checkNullandEmpty(object.getImagepath()),
								Utils.checkNullandEmpty(object.getName()), Utils.checkNullandEmpty(d.getFlag()));
					}

				}
				if (d.getBranddetails() != null && d.getBranddetails().size() > 0) {
					for (Damagedetails object : d.getBranddetails()) {
						damageitemsdetails.addRow(Utils.checkNullandEmpty(d.getServiceid()),
								Utils.checkNullandEmpty(d.getItemid()),
								Utils.checkNullandEmpty(d.getStainid()), Utils.checkNullandEmpty(d.getDamageid()),
								Utils.checkNullandEmpty(d.getColourid()), Utils.checkNullandEmpty(object.getId()),
								Utils.checkNullandEmpty(d.getQrcode()),
								Utils.checkNullandEmpty(object.getImagepath()),
								Utils.checkNullandEmpty(object.getName()), Utils.checkNullandEmpty(d.getFlag()));
					}

				}
			}

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_INSERT_UPDATE_ORDER_APPROVALS_DETAILS
								+ "(?,?,?,?,?,?,?,?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");

					cs.setLong(1, orderReqModel.getOrderid());

					if (orderReqModel.getInvoiceid() != null) {
						cs.setLong(2, orderReqModel.getInvoiceid());
					} else {
						cs.setString(2, null);
					}

					cs.setLong(3, orderReqModel.getCustomerid());

					if (orderReqModel.getUserid() != null) {
						cs.setLong(4, orderReqModel.getUserid());
					} else {
						cs.setString(4, null);
					}

					if (orderReqModel.getIsnotification() != null) {
						cs.setLong(5, orderReqModel.getIsnotification());
					} else {
						cs.setString(5, null);
					}
					cs.setStructured(6, "dbo.UTT_COLLECT_ITEMS_DETAILS_INSP", collectitemsdetails);

					cs.setString(7, Utils.checkNull(orderReqModel.getRemarks()));

					cs.setStructured(8, "dbo.UTT_ITEMS_DAMAGE_QTY_DETAILS_INS", damageitemsdetails);

					cs.setStructured(9, "dbo.UTT_REFERENCE_IMAGE_INSP", imagedetails);

					if (orderReqModel.getOrderflag() != null) {
						cs.setLong(10, orderReqModel.getOrderflag());
					} else {
						cs.setString(10, null);
					}
				}

				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();

			ApprovalsDetResModel configurationModel = new ApprovalsDetResModel();
			for (String key : set) {

				if (key.contains("#result-set-1")) {

					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					for (int i = 0; i < l_lstResult.size(); i++) {
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
						configurationModel.setStatusCode(String.valueOf(l_hmColmnData.get("status")));
						configurationModel.setMessage(String.valueOf(l_hmColmnData.get("message")));
						configurationModel.setSms(String.valueOf(l_hmColmnData.get("sms")));

						responseModel.setResponseObject(configurationModel);

					}
				}
			}
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getCustomerMaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_CUSTOMER_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getCustomerMaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getOrderWiseMaster() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_ORDER_WISE_MASTER + "()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getOrderWiseMaster", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}

		return responseModel;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public ResponseModel getprocessOrderAckconfig() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_PROCESS_ORDER_ACKNOWLEDGEMENT_CONFIGURATION()}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			ProcessStsConfigModel configurationModel = new ProcessStsConfigModel();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				for (int i = 0; i < l_lstResult.size(); i++) {
					LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
					configurationModel.setLC_CM_SMS_API(l_hmColmnData.get("WC_CM_SMS_API"));
					configurationModel.setLC_CM_HOST(l_hmColmnData.get("WC_CM_HOST"));
					configurationModel.setLC_CM_PORT(l_hmColmnData.get("WC_CM_PORT"));
					configurationModel.setLC_CM_USERNAME(l_hmColmnData.get("WC_CM_USERNAME"));
					configurationModel.setLC_CM_PASSWORD(l_hmColmnData.get("WC_CM_PASSWORD"));
					configurationModel.setLC_CM_PURPOSE(l_hmColmnData.get("WC_CM_PURPOSE"));
					configurationModel.setLC_CM_FLAG(String.valueOf(l_hmColmnData.get("WC_CM_FLAG")));
					configurationModel.setLC_CM_DOMAIN(String.valueOf(l_hmColmnData.get("WC_CM_DOMAIN")));
				}
			}
			responseModel.setResponseObject(configurationModel);

			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				// log.debug(e.getMessage());
			}
		}
		return responseModel;
	}

}
