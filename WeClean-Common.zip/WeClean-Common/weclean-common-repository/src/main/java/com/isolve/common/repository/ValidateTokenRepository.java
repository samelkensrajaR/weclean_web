package com.isolve.common.repository;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.isolve.common.model.ResponseModel;
import com.isolve.common.utils.CommonConstants;

@Transactional
@Repository
public class ValidateTokenRepository implements IValidateTokenRepository {

	@Autowired
	private EntityManager entityManager;

	/**
	 * @author
	 * @Name validateToken - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: validateToken method using to validate the auth Token.
	 */
	@Override
	public ResponseModel validateToken(String jwtToken) {
		ResponseModel responseModel = new ResponseModel();
		try {
			// "login" this is the name of your procedure
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_VALIDATE_TOKEN);
			// Declare the parameters in the same order
			query.registerStoredProcedureParameter(CommonConstants.TOKEN, String.class, ParameterMode.IN);
			query.setParameter(CommonConstants.TOKEN, jwtToken);
			Object[] fromStoredProcedure = (Object[]) query.getSingleResult();
			responseModel.setStatusCode(Integer.valueOf((String) fromStoredProcedure[0]));
			responseModel.setMessage((String) fromStoredProcedure[1]);
		} finally {
			entityManager.close();
		}
		return responseModel;
	}

}
