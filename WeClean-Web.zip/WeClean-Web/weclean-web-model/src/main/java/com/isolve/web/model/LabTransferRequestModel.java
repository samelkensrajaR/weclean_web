package com.isolve.web.model;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LabTransferRequestModel implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -182730206071929566L;
	private Long paramedicid;
	private Date schstartdatetime;
	private Date schenddatetime;
    private String rpttype;
	private String orderorigination;
	private Integer sampletype;
	private Integer transfertype;
	private Integer lab;
}
