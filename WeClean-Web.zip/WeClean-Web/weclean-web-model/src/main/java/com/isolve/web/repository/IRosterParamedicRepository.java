package com.isolve.web.repository;

import com.isolve.web.model.DeleteRosterRequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RosterDetUserRequestModel;
import com.isolve.web.model.RosterDetUserWithDateRequestModel;
import com.isolve.web.model.RosterInsertUpdateRequestModel;

public interface IRosterParamedicRepository 
{
	public ResponseModel getRosterAgent();

	ResponseModel getRosterDetUser(RosterDetUserRequestModel rosterDetUserRequestModel);

	ResponseModel getRosterRider();

	ResponseModel getRosterType();

	ResponseModel getRosterInsertUpdate(RosterInsertUpdateRequestModel rosterInsertUpdateRequestModel);

	ResponseModel deleteRoster(DeleteRosterRequestModel deleteRosterRequestModel);

	ResponseModel getRosterDetUserWithDate(RosterDetUserWithDateRequestModel detUserWithDateRequestModel);

	
	
}
