package com.isolve.web.model;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CollectItemDetailsModelinsp implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8156769007193236350L;
	private Integer serviceid;
	private Integer itemid;
	
	private String servicename;
	private String itemname;
	private String qrcode;
	private Double itemprice;
	private Integer itemcount;
	private List<Damagedetails> staindetails;
	private List<Damagedetails> damagedetails;
	private List<Damagedetails> colordetails;
	private List<Damagedetails> branddetails;
	private List<Imagedetails> imagedetails;
	private List<DamageCommondetails> commondetails;
	private Integer stainid;
	private Integer damageid;
	private Integer colourid;
	private Integer brandid;
	private String notes;
	private int flag;

}
