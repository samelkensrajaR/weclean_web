package com.isolve.web.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.isolve.web.model.RepeatCollectionActionRequestModel;
import com.isolve.web.model.RepeatCollectionActionResponseModel;
import com.isolve.web.utils.CommonConstants;

@Transactional
@Repository
public class RepeatCollectionActionRespositoryImpl implements IRepeatCollectionActionRespository
{
	@Autowired
	private EntityManager entityManager;
	

	Logger log = LoggerFactory.getLogger(RepeatCollectionActionRespositoryImpl.class);

	@SuppressWarnings("unchecked")
	@Override
	public List<RepeatCollectionActionResponseModel> getRepeatCollectionAction
	(RepeatCollectionActionRequestModel actionRequestModel)
	{
		List<RepeatCollectionActionResponseModel> actionResponseModel = new ArrayList<RepeatCollectionActionResponseModel>();
		try {
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_REPEAT_COLLECTION_ACTION,RepeatCollectionActionResponseModel.class); 
			query.registerStoredProcedureParameter(CommonConstants.ORDERID, Long.class, ParameterMode.IN);
			query.setParameter(CommonConstants.ORDERID, actionRequestModel.getOrderid());
			actionResponseModel = query.getResultList();
		} finally {
			entityManager.close();
		}//log.info("RepeatCollectionActionResponseModel-------"+actionResponseModel);
		return actionResponseModel;
	}
}
