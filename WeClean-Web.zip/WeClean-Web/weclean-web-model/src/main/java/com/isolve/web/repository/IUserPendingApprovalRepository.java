package com.isolve.web.repository;

import java.util.List;

import com.isolve.web.model.UserPendingApprovalRequestModel;
import com.isolve.web.model.UserPendingApprovalResponseModel;

public interface IUserPendingApprovalRepository {
	
	public List<UserPendingApprovalResponseModel> userPendingApproval(UserPendingApprovalRequestModel userPendingApprovalRequestModel);
}
