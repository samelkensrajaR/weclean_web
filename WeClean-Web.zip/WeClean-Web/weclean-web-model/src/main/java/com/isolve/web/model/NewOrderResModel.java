package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewOrderResModel implements Serializable{/**
	 * 
	 */
	private static final long serialVersionUID = -142108461205089462L;
	private Integer itemid;
	private Integer itemcount;
	private  String itemname;
	private  String servicename;
	private String Qrcode;
	private String customername;
	private Long invoiceid;
	private Long newuserid;
	private String societyname;
	private String flatno;
	private String ordercode;
	private String brandname;
	private Long orderid;
	private String notification;
	private String mobile_id;
	private Integer status;
	private String message;
	
}
