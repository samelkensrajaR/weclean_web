package com.isolve.web.repository;

import java.sql.SQLException;

import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.UpdateBioReceiveRequestModel;

public interface IBioReceiveRepository 
{
	public ResponseModel updateBioReceive(UpdateBioReceiveRequestModel updateBioReceiveRequestModel) throws SQLException;
}
