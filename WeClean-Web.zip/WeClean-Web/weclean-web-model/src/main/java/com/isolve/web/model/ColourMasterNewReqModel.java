package com.isolve.web.model;

import java.io.Serializable;
import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ColourMasterNewReqModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer flag;
	private String colourname;
	private String categoryid;
	private String userid;
	private Integer dmflag;
	private String discription;
	private Integer cmid;
	private Integer start;
	private Integer end;
	private String search;
	private String colourcode;

}
