package com.isolve.web.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class LabTransferResponseModel 
{
	@Id
	private Long orderid;
	private String crmid;
	private String kit_box_id;
	private String patient_name;
	private String client_name;
	private String paramedic_name;
	private String pickup_type;
	private Date pickup_time;
	private Date received_time;
	private String client_type;
	private String sample_type;
	private Long total_samples;
	private String mode;
	private String status;
	private String source_lab;
}
