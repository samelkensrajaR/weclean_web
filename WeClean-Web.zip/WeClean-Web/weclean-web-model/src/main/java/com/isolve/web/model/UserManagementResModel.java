package com.isolve.web.model;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserManagementResModel implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2139975868786906252L;
	private Integer start;
	private Integer end;
	private String search;
	

}
