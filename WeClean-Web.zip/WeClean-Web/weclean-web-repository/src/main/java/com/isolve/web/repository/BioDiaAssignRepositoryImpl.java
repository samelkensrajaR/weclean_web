package com.isolve.web.repository;

import java.math.BigInteger;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.isolve.web.model.AssignParamedicRequestModel;
import com.isolve.web.model.CancelParamedicRequestModel;
import com.isolve.web.model.CancelReasonResponseModel;
import com.isolve.web.model.ParamedicResponseModel;
import com.isolve.web.model.ParamedicUserAvailabiltyRequestModel;
import com.isolve.web.model.ParamedicUserAvailabiltyResponseModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.UpdateBioDiaAssignRequestModel;
import com.isolve.web.model.UpdateBioDiaAssignResponseModel;
import com.isolve.web.model.UserPickUpScheduleRequestModel;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.MyObject;
import com.isolve.web.utils.Utils;
import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;

@Transactional
@Repository
public class BioDiaAssignRepositoryImpl implements IBioDiaAssignRepository
{
	@Autowired
	private EntityManager entityManager;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	Logger log = LoggerFactory.getLogger(BioDiaAssignRepositoryImpl.class);

	@SuppressWarnings("unchecked")
	@Override
	public List<UpdateBioDiaAssignResponseModel> updateBioDiaAssign(UpdateBioDiaAssignRequestModel requestModel) {

		List<UpdateBioDiaAssignResponseModel> responseModel = new ArrayList<>();
		try {
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_BIO_DIA_ASSIGN_DETAILS,UpdateBioDiaAssignResponseModel.class);
			query.registerStoredProcedureParameter(CommonConstants.TASKID, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.SCHSTARTDATETIME, Date.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.SCHENDDATETIME, Date.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.RPTTYPE, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.ORDERORIGINATION, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.CENTERID, Long.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.PICKUPID, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.CLIENTTYPEID, Integer.class, ParameterMode.IN);
			query.setParameter(CommonConstants.TASKID, requestModel.getTaskid());
			query.setParameter(CommonConstants.SCHSTARTDATETIME, Utils.utilDateToSqlDate(requestModel.getSchStartdatetime()));
			query.setParameter(CommonConstants.SCHENDDATETIME, Utils.utilDateToSqlDate(requestModel.getSchEnddatetime()));
			query.setParameter(CommonConstants.RPTTYPE, requestModel.getRpttype());
			query.setParameter(CommonConstants.ORDERORIGINATION, requestModel.getOrderorigination());
			query.setParameter(CommonConstants.CENTERID, requestModel.getCenterid());
			query.setParameter(CommonConstants.PICKUPID, requestModel.getPickupid());
			query.setParameter(CommonConstants.CLIENTTYPEID, requestModel.getClienttypeid());
			responseModel = query.getResultList();
			log.info("resp---"+responseModel);
		} finally {
			entityManager.close();
		}
		return responseModel;
	}


	@Override
	public ResponseModel getAssignParamedicUpdate(AssignParamedicRequestModel assignParamedicRequestModel)
	{
		ResponseModel responseModel = new ResponseModel();
		ParamedicResponseModel model = new ParamedicResponseModel();
		try 
		{
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_UPDATE_ASSIGN_PARAMEDIC); 
			query.registerStoredProcedureParameter(CommonConstants.PICKUPDATETIME, Timestamp.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.REMARKSS, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.PICKUPIDD, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.PARAMEDICIDD, Long.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.TYPE, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.ORDERIDD, Long.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USERIDD, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.LATTITUDE, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.LONGITUDE, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.ispickupedit, Boolean.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.isreassigned, Boolean.class, ParameterMode.IN);

			query.setParameter(CommonConstants.PICKUPDATETIME, Utils.LocalDateToTimeStamp1(assignParamedicRequestModel.getPickupdatetime()));
			query.setParameter(CommonConstants.REMARKSS, assignParamedicRequestModel.getRemarks());
			query.setParameter(CommonConstants.PICKUPIDD, assignParamedicRequestModel.getPickupid());
			query.setParameter(CommonConstants.PARAMEDICIDD, assignParamedicRequestModel.getParamedicid());
			query.setParameter(CommonConstants.TYPE, assignParamedicRequestModel.getType());
			query.setParameter(CommonConstants.ORDERIDD, assignParamedicRequestModel.getOrderid());
			query.setParameter(CommonConstants.USERIDD, assignParamedicRequestModel.getUserid());
			query.setParameter(CommonConstants.LATTITUDE, Utils.checkNullandEmpty(assignParamedicRequestModel.getLattitude()));
			query.setParameter(CommonConstants.LONGITUDE, Utils.checkNullandEmpty(assignParamedicRequestModel.getLongitude()));
			query.setParameter(CommonConstants.ispickupedit, assignParamedicRequestModel.getIspickupedit());
			query.setParameter(CommonConstants.isreassigned, assignParamedicRequestModel.getIsreassigned());

			Object[] object = (Object[]) query.getSingleResult();
			responseModel.setStatusCode((Integer)object[0]);
			responseModel.setMessage((String)object[1]);
			if (responseModel.getStatusCode()==200) {
				model.setOrderid(String.valueOf((BigInteger)object[2]));
				model.setParamedicid(String.valueOf((BigInteger)object[3]));
				model.setMobileno((String)object[4]);
				model.setScheduledatetime(String.valueOf((Timestamp)object[5]));
				responseModel.setResponseObject(model);
			}
		}
		finally 
		{
			entityManager.close();
		}
		return responseModel;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getUserPickupSchedule(UserPickUpScheduleRequestModel reqModel) throws SQLException
	{
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.DATE));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection.prepareCall("{call USP_GET_USER_PICKUP_SCHEDULE(?, ?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
		            cs.setLong(1, reqModel.getUserid());
		            cs.setDate(2, Utils.utilDateTojavaSqlDate(reqModel.getPickupdate()));
					cs.execute();
				}
				return callableStatement;
			}, prmtrsList);

			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				{
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put(CommonConstants.GET_USER_PICKUP_SCHEDULE_RESPONSE_MODEL, l_lstResult);
				}
			}
			
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
			log.info("object------"+object);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		//log.info("responseModel------"+responseModel);
		return responseModel;
	}

	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getParamedicUserAvailability(ParamedicUserAvailabiltyRequestModel paramedicUserAvailabiltyRequestModel) throws SQLException
	{
		ResponseModel responseModel = new ResponseModel();
		List<ParamedicUserAvailabiltyResponseModel> responseModels = new ArrayList<ParamedicUserAvailabiltyResponseModel>();
		ParamedicUserAvailabiltyResponseModel model;
		Connection connection = jdbcTemplate.getDataSource().getConnection();
		try {

			CallableStatement csstmt = connection
					.prepareCall("{call " + CommonConstants.USP_GET_RIDER_AVAILABILITY + "(?, ?)}");
			if (csstmt.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {

				SQLServerCallableStatement cs = csstmt
						.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
				cs.setResponseBuffering("adaptive");
				if (paramedicUserAvailabiltyRequestModel.getUserid() != null) {
					cs.setLong(1, paramedicUserAvailabiltyRequestModel.getUserid());
				} else {
					cs.setString(1, null);
				}
				cs.setDate(2, Utils.utilDateTojavaSqlDate(paramedicUserAvailabiltyRequestModel.getPickupdate()));

				boolean isResultSet = cs.execute();
				while (true) {
				    if (isResultSet) {
				        try (ResultSet rs = cs.getResultSet()) {
				        	while (rs.next()) {
				        		 model = new ParamedicUserAvailabiltyResponseModel();
				        		 model.setMSG_TIME(rs.getString(1));
				        		 model.setAVAILABLE(rs.getString(2));
				        		 responseModels.add(model);
							}
							rs.close();
				        }
				    } else {
				        int updateCount = cs.getUpdateCount();
				        if (updateCount == -1) {
							System.out.println("updateCount : " + updateCount);
				            break;
				        }
				    }
				    isResultSet = cs.getMoreResults();
				}
			}
			responseModel.setStatusCode(200);
			responseModel.setRespList(responseModels);
		} finally {
		connection.close();
		}
		return responseModel;
		
	}
	
	
	
	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel cancelParamedic(CancelParamedicRequestModel cancelParamedicRequestModel)
	{

		ResponseModel responseModel = new ResponseModel();
		try 
		{
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_CANCEL_PARAMEDIC); 
			query.registerStoredProcedureParameter(CommonConstants.ORDERIDD, Long.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.REASON, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.REMARKSS, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USERIDD, Long.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.LATTITUDE, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.LONGITUDE, String.class, ParameterMode.IN);

			query.setParameter(CommonConstants.ORDERIDD, cancelParamedicRequestModel.getOrderid());
			query.setParameter(CommonConstants.REASON, cancelParamedicRequestModel.getReason());
			query.setParameter(CommonConstants.REMARKSS, cancelParamedicRequestModel.getRemarks());
			query.setParameter(CommonConstants.USERIDD, cancelParamedicRequestModel.getUserid());
			query.setParameter(CommonConstants.LATTITUDE, Utils.checkNullandEmpty(cancelParamedicRequestModel.getLattitude()));
			query.setParameter(CommonConstants.LONGITUDE, Utils.checkNullandEmpty(cancelParamedicRequestModel.getLongitude()));

			Object[] object = (Object[]) query.getSingleResult();
			log.info("status: "+object[0]+" "+"message: "+object[1]);
			responseModel.setStatusCode((Integer)object[0]);
			responseModel.setMessage((String)object[1]);
		}
		finally 
		{
			entityManager.close();
		}
		return responseModel;
	}


	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getCancelReason()
	{
		List<CancelReasonResponseModel> reasonResponseModels = new ArrayList<CancelReasonResponseModel>();
		ResponseModel responseModel = new ResponseModel();
		try 
		{
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_CANCEL_REASON,CancelReasonResponseModel.class); 
			reasonResponseModels = query.getResultList();
			log.info("resp---"+reasonResponseModels);
			responseModel.setStatusCode(200);
			responseModel.setRespList(reasonResponseModels);		
		}
		finally 
		{
			entityManager.close();
		}
		return responseModel;
	}
	
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getParamedicUserAvailabilityDay(ParamedicUserAvailabiltyRequestModel reqModel) throws SQLException
	{
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.DATE));
			prmtrsList.add(new SqlParameter(Types.BIGINT));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection.prepareCall("{call USP_GET_PARAMEDIC_AVAILABILITY_Day(?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
		            cs.setDate(1, Utils.utilDateTojavaSqlDate(reqModel.getPickupdate()));
		            cs.setLong(2, reqModel.getCityid());
//					cs.execute();
				}
				return callableStatement;
			}, prmtrsList);

			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			int count=0;
			for (String key : set) {
				count++;
				if (count==2) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put(CommonConstants.PARAMEDIC_AVAILABILITY_DAY_RESPONSE, l_lstResult);
				}
			}
			
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		//log.info("responseModel------"+responseModel);
		return responseModel;
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel insertUpdateTrackSMSDetails(ParamedicResponseModel paramedicResponseModel, String shortenURL, String longURL) {

		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.TIMESTAMP));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = 
						connection.prepareCall("{call USP_INSERT_UPDATE_TRACK_URL_DETAILS(?,?,?,?,?,?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
		            cs.setLong(1, Long.parseLong(paramedicResponseModel.getOrderid()));
		            cs.setLong(2, Long.parseLong(paramedicResponseModel.getParamedicid()));
		            cs.setString(3, shortenURL);
		            cs.setString(4, longURL);
		            cs.setTimestamp(5, Utils.StringToTimeStamp(paramedicResponseModel.getScheduledatetime()));
		            cs.setInt(6, 0);
		            cs.setString(7, paramedicResponseModel.getMobileno());
		            cs.setString(8, "I");
				}
				return callableStatement;
			}, prmtrsList);

			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					properties.put("TrackSMSDetailsResponse", l_lstResult);
			}
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getTrackFullUrl(String shortenURL) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection.prepareCall("{call USP_GET_PARAMEDIC_TRACK_URL(?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
		            cs.setString(1, shortenURL);
				}
				return callableStatement;
			}, prmtrsList);

			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			for (String key : set) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					for (int i = 0; i < l_lstResult.size(); i++) {
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
						responseModel.setStatus(l_hmColmnData.get("LC_TUD_LONGURL"));
					}
			}
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return responseModel;
	}
	
	
}



