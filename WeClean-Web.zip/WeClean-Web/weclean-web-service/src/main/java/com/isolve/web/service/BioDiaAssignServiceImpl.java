package com.isolve.web.service;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isolve.web.model.AssignParamedicRequestModel;
import com.isolve.web.model.CancelParamedicRequestModel;
import com.isolve.web.model.LabTranReceiveReqModel;
import com.isolve.web.model.ParamedicResponseModel;
import com.isolve.web.model.ParamedicUserAvailabiltyRequestModel;
import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RoleActionForSpecificIDReqModel;
import com.isolve.web.model.RosterDetUserRequestModel;
import com.isolve.web.model.UpdateBioDiaAssignRequestModel;
import com.isolve.web.model.UpdateBioDiaAssignResponseModel;
import com.isolve.web.model.UserPickUpScheduleRequestModel;
import com.isolve.web.repository.IBioDiaAssignRepository;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@Service
public class BioDiaAssignServiceImpl implements IBioDiaAssignService{

	@Autowired
	private IBioDiaAssignRepository iUpdateBioDiaAssignRepository ;

	@Value("${encryptsecretkey}")
	private String encryptsecretkey;
	
	@Value("${domain}")
	private String domain;

	@Value("${trackdomain}")
	private String trackdomain;

	private ObjectMapper objectMapper = new ObjectMapper();

	Logger log = LoggerFactory.getLogger(BioDiaAssignServiceImpl.class);

	@Override
	public ResponseModel updateBioDiaAssign(RequestModel requestModel) {

		List<UpdateBioDiaAssignResponseModel>  responseModel = new ArrayList<UpdateBioDiaAssignResponseModel>();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY + encryptsecretkey);
		try {
			UpdateBioDiaAssignRequestModel updateBioDiaAssignRequestModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), UpdateBioDiaAssignRequestModel.class);
			log.info(CommonConstants.UPDATE_BIO_DIA_ASSIGN_REQUEST_MODEL + updateBioDiaAssignRequestModel);
			responseModel = iUpdateBioDiaAssignRepository.updateBioDiaAssign(updateBioDiaAssignRequestModel);
		} catch (Exception e) {			
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}		
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
		
	@Override
	public ResponseModel getAssignParamedicUpdate(RequestModel requestModel) {

		ResponseModel responseModel = new ResponseModel(); 
		ResponseModel model = new ResponseModel();
		ResponseModel response = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable());
			AssignParamedicRequestModel paramedicAvailabilityRequestModel = objectMapper.readValue(decrypt, AssignParamedicRequestModel.class);
			log.info(CommonConstants.GET_ASSIGN_PARAMEDIC_REQUEST_MODEL + paramedicAvailabilityRequestModel);
			responseModel = iUpdateBioDiaAssignRepository.getAssignParamedicUpdate(paramedicAvailabilityRequestModel);
			ParamedicResponseModel paramedicResponseModel = (ParamedicResponseModel) responseModel.getResponseObject();
			String randomChar = Utils.getRandomChars();
			String shortenURL = domain+randomChar;
			String longURL = trackdomain+"phlb="+Base64.getEncoder().encodeToString(String.valueOf(paramedicResponseModel.getParamedicid()).getBytes())+"&Bkn="+Base64.getEncoder().encodeToString(String.valueOf(paramedicResponseModel.getOrderid()).getBytes());
			response = iUpdateBioDiaAssignRepository.insertUpdateTrackSMSDetails(paramedicResponseModel, shortenURL, longURL);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
	
	
	
	@Override
	public ResponseModel getUserPickupSchedule(RequestModel requestModel) {

		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			UserPickUpScheduleRequestModel reqModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), UserPickUpScheduleRequestModel.class);
			log.info(CommonConstants.GET_USER_PICKUP_SCHEDULE_REQUEST_MODEL + reqModel );
			responseModel = iUpdateBioDiaAssignRepository.getUserPickupSchedule(reqModel);
		} catch (Exception e) {			
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}		
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
	
	
	
	@Override
	public ResponseModel getParamedicUserAvailability(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel(); 
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			ParamedicUserAvailabiltyRequestModel paramedicUserAvailabiltyRequestModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), ParamedicUserAvailabiltyRequestModel.class);
			log.info(CommonConstants.GET_USER_PARAMEDIC_AVAILABILITY_REQUEST_MODEL + paramedicUserAvailabiltyRequestModel);
			responseModel = iUpdateBioDiaAssignRepository.getParamedicUserAvailability(paramedicUserAvailabiltyRequestModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
	
	
	@Override
	public ResponseModel cancelParamedic(RequestModel requestModel) {

		ResponseModel responseModel = new ResponseModel(); 
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			CancelParamedicRequestModel cancelParamedicRequestModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), CancelParamedicRequestModel.class);
			log.info(CommonConstants.CANCEL_PARAMEDIC_REQUEST_MODEL + cancelParamedicRequestModel);
			responseModel = iUpdateBioDiaAssignRepository.cancelParamedic(cancelParamedicRequestModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
	
	
	@Override
	public ResponseModel getCancelReason() {

		ResponseModel responseModel = new ResponseModel(); 
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			responseModel = iUpdateBioDiaAssignRepository.getCancelReason();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
	
	@Override
	public ResponseModel getParamedicUserAvailabilityDay(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel(); 
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			ParamedicUserAvailabiltyRequestModel userAvailabiltyRequestModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), ParamedicUserAvailabiltyRequestModel.class);
			log.info(CommonConstants.PARAMEDIC_AVAILABILITY_DAY_REQUEST_MODEL + userAvailabiltyRequestModel);
			responseModel = iUpdateBioDiaAssignRepository.getParamedicUserAvailabilityDay(userAvailabiltyRequestModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	@Override
	public ResponseModel getTrackFullUrl(String shortenURL) {
		ResponseModel responseModel = new ResponseModel(); 
		ResponseModel model = new ResponseModel();
		try {
			responseModel = iUpdateBioDiaAssignRepository.getTrackFullUrl(shortenURL);
			model.setStatusCode(200);
			model.setStatus(responseModel.getStatus());
		} catch (Exception e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
}
