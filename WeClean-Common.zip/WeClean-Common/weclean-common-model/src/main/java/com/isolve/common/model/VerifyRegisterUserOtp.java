package com.isolve.common.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VerifyRegisterUserOtp implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 6017668426150362089L;
	private String mobile;
	private String email;
    private String otp;
    private Integer flag;
    private String deviceid;
    private String firebaseId;
}