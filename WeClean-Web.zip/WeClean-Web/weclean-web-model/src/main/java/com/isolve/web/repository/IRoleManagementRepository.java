package com.isolve.web.repository;

import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RoleActionForSpecificIDReqModel;
import com.isolve.web.model.RolePermissionReqModel;
import com.isolve.web.model.RoleTargetActionReqModel;
import com.microsoft.sqlserver.jdbc.SQLServerException;

public interface IRoleManagementRepository {

	ResponseModel getRoleTargets();

	ResponseModel getRoles();

	public ResponseModel saveTargetActionRole(RoleTargetActionReqModel reqModel) throws SQLServerException;

	ResponseModel getRoleActionForSpecificId(RoleActionForSpecificIDReqModel reqModel) throws SQLServerException;

	ResponseModel getUserRolePermission(RolePermissionReqModel response);

	ResponseModel getroleuseroleservicesteps(RolePermissionReqModel reqModel);
}
