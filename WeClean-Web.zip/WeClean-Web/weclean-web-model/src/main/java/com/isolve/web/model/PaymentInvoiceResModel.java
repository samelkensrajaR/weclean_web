package com.isolve.web.model;

import java.io.Serializable;
import java.util.List;

import com.isolve.web.model.PaymentInvoiceDetails;
import com.isolve.web.model.PaymentInvoiceResModel;
import com.isolve.web.model.PaymentRaiseCompliantModel;
import com.isolve.web.model.PaymentServiceDetailsResModel;
import com.isolve.web.model.PaymentSpecialInstructModel;
import com.isolve.web.model.WecleanInvoiceResModel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentInvoiceResModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3881991100975634679L;
	
	private PaymentInvoiceDetails PaymentUserDetails;
	private WecleanInvoiceResModel WecleanInvoice;
	private List<PaymentServiceDetailsResModel> servicename;
	private List<PaymentSpecialInstructModel> Specialinstruct;
	private List<PaymentRaiseCompliantModel> Raisecompliant;
	private String cgst;
	private String sgst;
	private String tax;

}
