package com.isolve.web.model;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class AssignParamedicRequestModel implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5984463234658388925L;
	
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm")
	@JsonSerialize(using=LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	private LocalDateTime pickupdatetime;
	private String remarks;
	private Integer pickupid;
	private Long paramedicid;
	private String type;
	private Long orderid;
	private Integer userid;
	private String lattitude;
	private String longitude;
	private Boolean ispickupedit;
	private Boolean isreassigned;
}
