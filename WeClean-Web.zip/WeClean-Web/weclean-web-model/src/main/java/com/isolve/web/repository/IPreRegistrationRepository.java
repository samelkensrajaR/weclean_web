package com.isolve.web.repository;

import com.isolve.web.model.PreRegistrationDetailsReqModel;
import com.isolve.web.model.PreRegistrationProcessRequestModel;
import com.isolve.web.model.PreRegistrationRequestModel;
import com.isolve.web.model.ResponseModel;
import com.microsoft.sqlserver.jdbc.SQLServerException;

public interface IPreRegistrationRepository{

	public ResponseModel getPreRegistrationDetails(PreRegistrationDetailsReqModel requestModel);

	public	ResponseModel submitPreRegistration(PreRegistrationRequestModel requestModel) throws SQLServerException;
	
	public	ResponseModel preRegistrationProcess(PreRegistrationProcessRequestModel requestModel);


}
