package com.isolve.common.service;

import com.isolve.common.model.ResponseModel;

public interface IValidateTokenService {

	ResponseModel validateToken(String jwtToken);

}
