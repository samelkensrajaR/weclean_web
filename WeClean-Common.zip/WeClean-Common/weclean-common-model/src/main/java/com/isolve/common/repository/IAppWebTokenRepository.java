package com.isolve.common.repository;

import java.sql.SQLException;

import com.isolve.common.model.AppWebTokenRequestModel;
import com.isolve.common.model.AppWebTokenResponseModel;
import com.isolve.common.model.GenerateOTPForgotPassReqModel;
import com.isolve.common.model.GenerateOTPForgotPassResModel;
import com.isolve.common.model.GenerateOTPPaymentReqModel;
import com.isolve.common.model.GenerateOTPResponseModel;
import com.isolve.common.model.GenerateOTPVendorReqModel;
import com.isolve.common.model.GenerateOtpForRescheduleRequestModel;
import com.isolve.common.model.GenerateOtpForRescheduleResponseModel;
import com.isolve.common.model.GenerateOtpRequestModel;
import com.isolve.common.model.ResetPinModel;
import com.isolve.common.model.ResponseModel;
import com.isolve.common.model.SignUpDetailsModel;
import com.isolve.common.model.TechDayStartTimeModel;
import com.isolve.common.model.ValidateEmailPhonenoModel;
import com.isolve.common.model.VerifyOTPModel;

public interface IAppWebTokenRepository {

	AppWebTokenResponseModel checkUsernameandPassword(AppWebTokenRequestModel voilaTokenRequestModel)
			throws SQLException;

	SignUpDetailsModel signUpDetails(SignUpDetailsModel signUpDetailsModel);

	GenerateOTPResponseModel generateOTP(GenerateOtpRequestModel otpRequestModel);

	ResponseModel appWebLogin(AppWebTokenRequestModel appWebTokenRequestModel);

	ResponseModel verifyOTP(VerifyOTPModel verifyOTPModel);

	ResponseModel resetPin(ResetPinModel resetPinModel);

	ResponseModel logout(AppWebTokenRequestModel appWebTokenRequestModel);

}
