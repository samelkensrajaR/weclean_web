package com.isolve.common.repository;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.isolve.common.model.AccountTypeModel;
import com.isolve.common.model.AddressTypeModel;
import com.isolve.common.model.CityMasterModel;
import com.isolve.common.model.LanguageMasterRequestModel;
import com.isolve.common.model.LanguageMasterResponseModel;
import com.isolve.common.model.PickupTypeModel;
import com.isolve.common.model.ResponseModel;
import com.isolve.common.model.RoleMasterModel;
import com.isolve.common.model.RoleReqModel;
import com.isolve.common.model.StateMasterReqModel;
import com.isolve.common.model.StateMasterResModel;
import com.isolve.common.model.TaskTypeModel;
import com.isolve.common.model.TaskTypeReqModel;
import com.isolve.common.model.UserTypeModel;
import com.isolve.common.model.UserTypeReqModel;
import com.isolve.common.utils.CommonConstants;
import com.isolve.common.utils.MyObject;

@Transactional
@Repository
public class MasterRepositoryImpl implements IMasterRepository {

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	/**
	 * @author
	 * @Name getStateMaster - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getStateMaster method using to get all state lists.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel getStateMaster(StateMasterReqModel stateMasterReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List<StateMasterResModel> stateMasterResModels = new ArrayList<StateMasterResModel>();
			// this is the name of your procedure
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_STATE_MASTER,
					StateMasterResModel.class);
			// Declare the parameters in the same order
			query.registerStoredProcedureParameter(CommonConstants.SEARCH, String.class, ParameterMode.IN);
			query.setParameter(CommonConstants.SEARCH, stateMasterReqModel.getSearch());
			stateMasterResModels = query.getResultList();
			responseModel.setRespList(stateMasterResModels);
			responseModel.setStatusCode(200);
		} finally {
			entityManager.close();
		}
		return responseModel;
	}

	/**
	 * @author
	 * @Name getCityMaster - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getCityMaster method using to get City list based on State.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel getCityMaster(StateMasterReqModel stateMasterReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List<CityMasterModel> cityMasterModels = new ArrayList<CityMasterModel>();
			// this is the name of your procedure
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_CITY_MASTER,
					CityMasterModel.class);
			// Declare the parameters in the same order
			query.registerStoredProcedureParameter(CommonConstants.STATEID, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.SEARCH, String.class, ParameterMode.IN);
			query.setParameter(CommonConstants.STATEID, stateMasterReqModel.getStateid());
			query.setParameter(CommonConstants.SEARCH, stateMasterReqModel.getSearch());
			cityMasterModels = query.getResultList();
			responseModel.setRespList(cityMasterModels);
			responseModel.setStatusCode(200);
		} finally {
			entityManager.close();
		}
		return responseModel;
	}

	/**
	 * @author
	 * @Name getAddressType - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getAddressType method using to get Address type master.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel getAddressType() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List<AddressTypeModel> addressTypeModels = new ArrayList<AddressTypeModel>();
			// "login" this is the name of your procedure
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_ADDRESS_TYPE,
					AddressTypeModel.class);
			addressTypeModels = query.getResultList();
			responseModel.setStatusCode(200);
			responseModel.setRespList(addressTypeModels);
		} finally {
			entityManager.close();
		}
		return responseModel;
	}

	/**
	 * @author
	 * @Name getPickupType - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getPickupType method using to get pickup type master.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel getPickupType() {
		ResponseModel responseModel = new ResponseModel();
		try {
			List<PickupTypeModel> pickupTypeModels = new ArrayList<PickupTypeModel>();
			// "login" this is the name of your procedure
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_PICKUP_TYPE,
					PickupTypeModel.class);
			pickupTypeModels = query.getResultList();
			responseModel.setStatusCode(200);
			responseModel.setRespList(pickupTypeModels);
		} finally {
			entityManager.close();
		}
		return responseModel;
	}

	/**
	 * @author
	 * @Name getAccountType - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getAccountType method using to get account type master.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel getAccountType(TaskTypeReqModel typeReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List<AccountTypeModel> accountTypeModels = new ArrayList<AccountTypeModel>();
			// "login" this is the name of your procedure
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_ACCOUNTTYPE,
					AccountTypeModel.class);
			// Declare the parameters in the same order
			query.registerStoredProcedureParameter(CommonConstants.FLAG, Integer.class, ParameterMode.IN);
			query.setParameter(CommonConstants.FLAG, typeReqModel.getFlag());
			accountTypeModels = query.getResultList();
			responseModel.setStatusCode(200);
			responseModel.setRespList(accountTypeModels);
		} finally {
			entityManager.close();
		}
		return responseModel;
	}

	/**
	 * @author
	 * @Name getTaskType - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getTaskType method using to get task type master.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel getTaskType(TaskTypeReqModel typeReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List<TaskTypeModel> taskTypeModels = new ArrayList<TaskTypeModel>();
			// this is the name of your procedure
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_TASK_TYPE,
					TaskTypeModel.class);
			// Declare the parameters in the same order
			query.registerStoredProcedureParameter(CommonConstants.TASKID, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.SEARCH, String.class, ParameterMode.IN);
			query.setParameter(CommonConstants.TASKID, typeReqModel.getTaskid());
			query.setParameter(CommonConstants.SEARCH, typeReqModel.getSearch());
			taskTypeModels = query.getResultList();
			responseModel.setRespList(taskTypeModels);
			responseModel.setStatusCode(200);
		} finally {
			entityManager.close();
		}
		return responseModel;
	}

	/**
	 * @author
	 * @Name getUserType - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getUserType method using to get User Type master.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel getUserType(UserTypeReqModel userTypeReqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List<UserTypeModel> userTypeModels = new ArrayList<UserTypeModel>();
			// this is the name of your procedure
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_USER_TYPE,
					UserTypeModel.class);
			// Declare the parameters in the same order
			query.registerStoredProcedureParameter(CommonConstants.fLAG, Integer.class, ParameterMode.IN);

			query.setParameter(CommonConstants.fLAG, userTypeReqModel.getFlag());

			userTypeModels = query.getResultList();
			responseModel.setRespList(userTypeModels);
			responseModel.setStatusCode(200);
		} finally {
			entityManager.close();
		}
		return responseModel;
	}

	/**
	 * @author
	 * @Name getRole - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getRole method using to get all roles list.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel getRole(RoleReqModel reoleReqmodel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List<RoleMasterModel> roleMasterModels = new ArrayList<RoleMasterModel>();
			// this is the name of your procedure
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_ROLE,
					RoleMasterModel.class);
			// Declare the parameters in the same order
			query.registerStoredProcedureParameter(CommonConstants.Flag, Integer.class, ParameterMode.IN);

			query.setParameter(CommonConstants.Flag, reoleReqmodel.getFlag());

			roleMasterModels = query.getResultList();
			responseModel.setRespList(roleMasterModels);
			responseModel.setStatusCode(200);
		} finally {
			entityManager.close();
		}
		return responseModel;
	}

	/**
	 * @author
	 * @Name getgenderDetails - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getgenderDetails method using to get gender list master.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel getGenderDetails() {
		ResponseModel responseModel = new ResponseModel();
		try {

			List prmtrsList = new ArrayList();

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_WC_GENDER + "}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("genderlist", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();

			}
		}
		return responseModel;

	}

	/**
	 * @author
	 * @Name getTitleMaster - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getTitleMaster method using to get Title MAster.
	 */
	@SuppressWarnings("unchecked")
	@Override

	public ResponseModel getTitleMaster() {
		ResponseModel responseModel = new ResponseModel();
		try {

			List prmtrsList = new ArrayList();
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_GET_LC_TITLE_MASTER + "}");
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();

			// Create properties
			Map<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("titlemasterlist", l_lstResult);
			}

			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();

			}
		}
		return responseModel;

	}

	/**
	 * @author
	 * @Name getLanguageMaster - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getLanguageMaster method using to get all language names.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<LanguageMasterResponseModel> getLanguageMaster(LanguageMasterRequestModel languageMasterResponseModel) {
		List<LanguageMasterResponseModel> languageMasterResponseModels = new ArrayList<LanguageMasterResponseModel>();
		try {
			// "login" this is the name of your procedure
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(
					CommonConstants.USP_GET_LANGUAGE_MASTER, LanguageMasterResponseModel.class);
			// Declare the parameters in the same order
			query.registerStoredProcedureParameter(CommonConstants.FROM_REGISTRATION_MASTER, Integer.class,
					ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.LANGID, Integer.class, ParameterMode.IN);

			query.setParameter(CommonConstants.FROM_REGISTRATION_MASTER,
					languageMasterResponseModel.getFromRegistrationMaster());
			query.setParameter(CommonConstants.LANGID, languageMasterResponseModel.getLangId());
			languageMasterResponseModels = query.getResultList();
		} finally {
			entityManager.close();
		}
		return languageMasterResponseModels;
	}
}
