package com.isolve.web.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DeleteRosterRequestModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7990216551825417161L;
	private Integer ra_id;
	private String Wc_ra_remarks;
	private Long userid;
}
