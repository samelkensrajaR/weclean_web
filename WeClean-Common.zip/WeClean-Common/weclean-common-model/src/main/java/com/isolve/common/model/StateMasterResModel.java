package com.isolve.common.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class StateMasterResModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7762460859527315217L;
	
	@Id
	private String WC_SM_ID;
	private String WC_SM_STATE_NAME;

}
