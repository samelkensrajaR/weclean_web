/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.isolve.common.utils;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

@Component
public class SendEmail {

    @Value("${host}")
    private String host;

    @Value("${flag}")
    private String flag;

    @Value("${mailusernames}")
    private String mailusernames;

    @Value("${mailpassword}")
    private String mailpassword;

    @Value("${mailport}")
    private String mailport;

    public void send(String errorMsg, String mailto) {
        String to = mailto;
        String[] toArray = to.split(",");
        String from = mailusernames;
        Session session;
        if (flag.equalsIgnoreCase("gmail")) {
            Properties props = new Properties();

            props.put("mail.smtp.host", host);
            props.put("mail.smtp.socketFactory.port", mailport);
            props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.port", mailport);

            // get Session
            session = Session.getDefaultInstance(props,
                    new javax.mail.Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(mailusernames, mailpassword);
                        }
                    });
        } else {
            // Get the session object
            Properties properties = System.getProperties();
            properties.setProperty("mail.smtp.host", host);
            properties.setProperty("mail.smtp.port", mailport);
            properties.setProperty("mail.smtp.starttls.enable", "false");
            properties.setProperty("mail.smtp.auth", "true");

            session = Session.getInstance(properties, new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(mailusernames, mailpassword);
                }
            });
        }

        // compose the message
        try {

            MimeMessage message = new MimeMessage(session);
            MimeMessageHelper helper = new MimeMessageHelper(message, "utf-8");
            helper.setFrom(new InternetAddress(from));
            helper.setTo(toArray);
            helper.setSubject("Lifecell");
            helper.setText(
                    "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n"
                            +
                            "<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-GB\">\n" +
                            "<head>\n" +
                            "    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n" +
                            "    <title>Lifecell</title>\n" +
                            "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"/>\n" +
                            "<style>\n" +
                            "\n" +
                            "div { \n" +
                            "  padding-top: 0px;\n" +
                            "  padding-right: 30px;\n" +
                            "  padding-bottom: 50px;\n" +
                            "  padding-left: 80px;\n" +
                            "}\n" +
                            "/* Style the footer */\n" +
                            "footer {\n" +
                            " padding-top: 0px;\n" +
                            "  padding-right: 30px;\n" +
                            "  padding-bottom: 50px;\n" +
                            "  padding-left: 80px;\n" +
                            "}\n" +
                            "</style>\n" +
                            "</head>\n" +
                            "<body style=\"margin: 0; padding: 0;\">\n" +
                            "\n" +
                            "  <h4>Hi,</h4>\n" +
                            "\n" +
                            "<div>" + errorMsg + "</div>\n" +
                            "<footer>\n" +
                            "  <p>Thanks,</p>\n" +
                            "  <p>Lifecell.</p>\n" +
                            "</footer>\n" +
                            "</body>\n" +
                            "</html>",
                    true);

            // Send message
            Transport.send(message);
        } catch (MessagingException mex) {
            mex.printStackTrace();
        }
    }

}
