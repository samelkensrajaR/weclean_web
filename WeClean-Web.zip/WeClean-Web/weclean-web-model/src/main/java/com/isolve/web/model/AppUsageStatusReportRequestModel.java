package com.isolve.web.model;


import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
public class AppUsageStatusReportRequestModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7156500768392226602L;
	private Date startdatetime;
	private Date enddatetime;
	private Long cityid;
	private Long centerid;
    private String type;
}
