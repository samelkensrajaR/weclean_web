package com.isolve.web.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class UserPendingApprovalResponseModel 
{
	@Id
	private Long userid;
	private Integer title;
	private String first_name;
	private String middle_name;
	private String last_name;
	private String user_name;
	private String phoneno;
	private String emailid;
	private Date dob;
	private String add1;
	private String add2;
	private String pincode;
	private String city_name;
	private String center;
	private String qualification;
	private String experience;
	private String type;
	private String rolename;
	private Long roleid;
	private Date request;
	private String age;
	private Integer city_id;
	private Integer center_id;
	private String empid;
	private Integer usertypeid;
	private Integer lc_sm_id;
	private String lc_sm_state_name;
}
