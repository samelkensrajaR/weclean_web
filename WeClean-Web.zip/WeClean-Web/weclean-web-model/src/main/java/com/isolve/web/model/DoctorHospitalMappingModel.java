package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class DoctorHospitalMappingModel implements Serializable {

	private static final long serialVersionUID = 7505423328522635451L;
	
	
	private Long dhmdoctorid;
	private Long dhmhospitalid;
	
}
