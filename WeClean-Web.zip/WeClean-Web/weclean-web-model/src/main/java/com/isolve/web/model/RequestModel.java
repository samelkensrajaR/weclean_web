/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.isolve.web.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestModel implements Serializable {        
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String payload;
	private String extraVariable;
	private Object reqObject;
	private List<?> reqList;	
	private String[] reqArray;
	
}