package com.isolve.web.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class SampleTypeResponseModel 
{
	@Id
	private Integer WC_OT_TYPE_ID;
	private String WC_OT_TYPE_NAME;
}
