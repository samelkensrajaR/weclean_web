package com.isolve.web.repository;

import com.isolve.web.model.AutomaticProcessReqModel;
import com.isolve.web.model.BrandMasterNewReqModel;
import com.isolve.web.model.CallHestoryReqModel;
import com.isolve.web.model.CenterMasterReqModel;
import com.isolve.web.model.ChallanMasterReqModel;
import com.isolve.web.model.ColourMasterNewReqModel;
import com.isolve.web.model.CompanyMasterNewReqModel;
import com.isolve.web.model.ComplaintsReqModel;
import com.isolve.web.model.ConfigurationModel;
import com.isolve.web.model.CustomerDetailsReqModel;
import com.isolve.web.model.DamageMasterNewReqModel;
import com.isolve.web.model.DeliveryModeReqModel;
import com.isolve.web.model.DispatchDetailsReqModel;
import com.isolve.web.model.DispatchDetailsRequestModel;
import com.isolve.web.model.ParamedicDetailsReqModel;
import com.isolve.web.model.PaymentStatusReqModel;
import com.isolve.web.model.PickupDetailsByItemsReqModel;
import com.isolve.web.model.PickupDetailsReqModel;
import com.isolve.web.model.PickupRescheduleReqModel;
import com.isolve.web.model.PinCodeMappingModel;
import com.isolve.web.model.PincodeMasterReqModel;
import com.isolve.web.model.ProcessStatusReqModel;
import com.isolve.web.model.ProcessStepsByServiceIdReqModel;
import com.isolve.web.model.QrcodeDetailsReqModel;
import com.isolve.web.model.ReceiveDtailsExportReqModel;
import com.isolve.web.model.ReceiveItemDetailsReqModel;
import com.isolve.web.model.ReceivedItemDetailsReqModel;
import com.isolve.web.model.RequestModel;
import com.isolve.web.model.RescheduleAndCancellationExportReqModel;
import com.isolve.web.model.RescheduleAndCancellationReqModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RiderCancilationReqModel;
import com.isolve.web.model.RiderDetailsReqModel;
import com.isolve.web.model.RiderTimeSlotAvailabilityReqModel;
import com.isolve.web.model.TestProductMappingReqModel;
import com.isolve.web.model.TrackRiderDetailsReqModel;
import com.isolve.web.model.UpdateSocietyReqModel;
import com.isolve.web.model.UpdateWalletConfigurationReqModel;
import com.isolve.web.model.VendorDetailsMasterReqModel;
import com.isolve.web.model.VendorVisitTimeMappingReqModel;
import com.isolve.web.model.VendorVisitTimeReqModel;
import com.isolve.web.model.VisitTimeReqModel;
import com.isolve.web.model.WalletConfigurationReqModel;
import com.isolve.web.model.WalletInvoiceResModel;
import com.isolve.web.model.WebDashBoardDetails;
import com.isolve.web.model.WebDelierySlotsModel;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import com.isolve.web.model.DoctorDetailsReqModel;
import com.isolve.web.model.DoctorHospitalMappingReqModel;
import com.isolve.web.model.GrommingstandardsReqModel;
import com.isolve.web.model.HospitalstatecityModel;
import com.isolve.web.model.InsertAutomaticProcessStepsReqModel;
import com.isolve.web.model.InsertComplaintsReqModel;
import com.isolve.web.model.InsertRefundReqModel;
import com.isolve.web.model.InsertSlotNewReqModel;
import com.isolve.web.model.ItemMasterNewReqModel;
import com.isolve.web.model.ItemMasterReqModel;
import com.isolve.web.model.OrderDetailsReqModel;
import com.isolve.web.model.OrderSummaryImageReqModel;
import com.isolve.web.model.OrdersummaryPdf;
import com.isolve.web.model.SalesHospitalMappingReqModel;
import com.isolve.web.model.SaleshospitalMappingModel;
import com.isolve.web.model.ServiceItemMappingReqModel;
import com.isolve.web.model.ServiceItemMasterNewReqModel;
import com.isolve.web.model.SlotReqModel;
import com.isolve.web.model.SocietyDetailsReqModel;
import com.isolve.web.model.SocietyReqModel;
import com.isolve.web.model.StainMasterNewReqModel;
import com.isolve.web.model.TemplateDetailsReqModel;

public interface IOrderRepository {

	ResponseModel getTrainingVideosDetails(GrommingstandardsReqModel societyDetailsReqModel);

	ResponseModel insertupdateTrainingVideos(GrommingstandardsReqModel grommingstandardsReqModel);

	ResponseModel getgrommingstandardsdetailsExports(GrommingstandardsReqModel societyDetailsReqModel);

	ResponseModel getTrainingVideosDetailsExports(GrommingstandardsReqModel societyDetailsReqModel);

	
}
