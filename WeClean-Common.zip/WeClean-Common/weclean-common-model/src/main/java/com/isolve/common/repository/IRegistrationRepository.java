package com.isolve.common.repository;

import java.util.List;

import com.isolve.common.model.DoctorListRequestModel;
import com.isolve.common.model.DoctorListResponseModel;
import com.isolve.common.model.GenerateOTPForgotPassResModel;
import com.isolve.common.model.LableMasterFinalResponseModel;
import com.isolve.common.model.LableMasterRequestModel;
import com.isolve.common.model.RegistrationDetailsReqModel;
import com.isolve.common.model.ResponseModel;
import com.isolve.common.model.VerifyRegisterUserOtp;


public interface IRegistrationRepository {


	ResponseModel registrationDetails(RegistrationDetailsReqModel reqModel);

	GenerateOTPForgotPassResModel registerUserGenerateOtp(VerifyRegisterUserOtp otpRequestModel);

	ResponseModel getConfiguration();

	ResponseModel verifyRegisterUserOtps(VerifyRegisterUserOtp otpRequestModel);

	LableMasterFinalResponseModel getLableMaster(LableMasterRequestModel lableMasterRequestModel);
	
	
	ResponseModel getRiderConfiguration();

	

	

}
