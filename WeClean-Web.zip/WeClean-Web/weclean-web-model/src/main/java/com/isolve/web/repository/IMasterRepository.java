package com.isolve.web.repository;

import com.isolve.web.model.AutomaticProcessReqModel;
import com.isolve.web.model.BrandMasterNewReqModel;
import com.isolve.web.model.CallHestoryReqModel;
import com.isolve.web.model.CenterMasterReqModel;
import com.isolve.web.model.ChallanMasterReqModel;
import com.isolve.web.model.ChatUserReqModel;
import com.isolve.web.model.ColourMasterNewReqModel;
import com.isolve.web.model.CompanyMasterNewReqModel;
import com.isolve.web.model.ComplaintsReqModel;
import com.isolve.web.model.ConfigurationModel;
import com.isolve.web.model.CustomerDetailsReqModel;
import com.isolve.web.model.DamageMasterNewReqModel;
import com.isolve.web.model.DeliveryModeReqModel;
import com.isolve.web.model.DispatchDetailsReqModel;
import com.isolve.web.model.DispatchDetailsRequestModel;
import com.isolve.web.model.ParamedicDetailsReqModel;
import com.isolve.web.model.PaymentStatusReqModel;
import com.isolve.web.model.PickupDetailsByItemsReqModel;
import com.isolve.web.model.PickupDetailsReqModel;
import com.isolve.web.model.PickupRescheduleReqModel;
import com.isolve.web.model.PinCodeMappingModel;
import com.isolve.web.model.PincodeMasterReqModel;
import com.isolve.web.model.ProcessStatusReqModel;
import com.isolve.web.model.ProcessStepsByServiceIdReqModel;
import com.isolve.web.model.QrcodeDetailsReqModel;
import com.isolve.web.model.ReceiveDtailsExportReqModel;
import com.isolve.web.model.ReceiveItemDetailsReqModel;
import com.isolve.web.model.ReceivedItemDetailsReqModel;
import com.isolve.web.model.RequestModel;
import com.isolve.web.model.RescheduleAndCancellationExportReqModel;
import com.isolve.web.model.RescheduleAndCancellationReqModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RiderCancilationReqModel;
import com.isolve.web.model.RiderDetailsReqModel;
import com.isolve.web.model.RiderTimeSlotAvailabilityReqModel;
import com.isolve.web.model.TestProductMappingReqModel;
import com.isolve.web.model.TrackRiderDetailsReqModel;
import com.isolve.web.model.UpdateSocietyReqModel;
import com.isolve.web.model.UpdateWalletConfigurationReqModel;
import com.isolve.web.model.VendorDetailsMasterReqModel;
import com.isolve.web.model.VendorVisitTimeMappingReqModel;
import com.isolve.web.model.VendorVisitTimeReqModel;
import com.isolve.web.model.VisitTimeReqModel;
import com.isolve.web.model.WalletConfigurationReqModel;
import com.isolve.web.model.WebDashBoardDetails;
import com.isolve.web.model.WebDelierySlotsModel;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import com.isolve.web.model.DoctorDetailsReqModel;
import com.isolve.web.model.DoctorHospitalMappingReqModel;
import com.isolve.web.model.GrommingstandardsReqModel;
import com.isolve.web.model.HospitalstatecityModel;
import com.isolve.web.model.InsertAutomaticProcessStepsReqModel;
import com.isolve.web.model.InsertComplaintsReqModel;
import com.isolve.web.model.InsertRefundReqModel;
import com.isolve.web.model.InsertSlotNewReqModel;
import com.isolve.web.model.ItemMasterNewReqModel;
import com.isolve.web.model.ItemMasterReqModel;
import com.isolve.web.model.ItemwiseImageReqModel;
import com.isolve.web.model.MessagedetailsModel;
import com.isolve.web.model.OrderDetailsReqModel;
import com.isolve.web.model.OrderSummaryImageReqModel;
import com.isolve.web.model.OrdersummaryPdf;
import com.isolve.web.model.SalesHospitalMappingReqModel;
import com.isolve.web.model.SaleshospitalMappingModel;
import com.isolve.web.model.ServiceItemMappingReqModel;
import com.isolve.web.model.ServiceItemMasterNewReqModel;
import com.isolve.web.model.ServiceStepsMapppingReqModel;
import com.isolve.web.model.SlotReqModel;
import com.isolve.web.model.SocietyDetailsReqModel;
import com.isolve.web.model.SocietyReqModel;
import com.isolve.web.model.StainMasterNewReqModel;
import com.isolve.web.model.StepsMasterNewRequestModel;
import com.isolve.web.model.TemplateDetailsReqModel;

public interface IMasterRepository {

	ResponseModel insertupdatepincodemapping(PinCodeMappingModel reqModel) throws SQLServerException;

	ResponseModel getPinCodeMaster(PincodeMasterReqModel requestModel);

	ResponseModel insertupdatevendorvisittimemapping(VendorVisitTimeMappingReqModel vendorVisitTimeMappingReqModel)
			throws SQLServerException;

	ResponseModel getVendorVisitTime(VendorVisitTimeReqModel vendorVisitTimeReqModel);

	ResponseModel getParamedicDetails(ParamedicDetailsReqModel reqModel);

	ResponseModel vendorDetailsMaster(VendorDetailsMasterReqModel reqModel);

	ResponseModel getcitystatecenterbyuserid(PinCodeMappingModel reqModel);

	ResponseModel insertUpdateCenterMaster(CenterMasterReqModel reqModel);

	ResponseModel insertUpdateVisitTimeMaster(VisitTimeReqModel reqModel);

	ResponseModel getApproveStatus();

	ResponseModel getRegion();

	ResponseModel getManagement();

	ResponseModel insertUpdateTestProductMapping(TestProductMappingReqModel reqmodel);

	ResponseModel getPreconditionMaster();

	ResponseModel getPaymentStatus(PaymentStatusReqModel reqModel);

	ResponseModel getallclientmaster();

	ResponseModel getallstatusmaster();

	ResponseModel getallinvoicetracking(PaymentStatusReqModel reqModel);

	ResponseModel getapprovedstatusmaster();

	ResponseModel getaccounttypemaster();

	ResponseModel getQuotationdetails(PaymentStatusReqModel reqModel);

	ResponseModel getInvoiceStatusMaster();

	ResponseModel getWebDashBoardDetails(WebDashBoardDetails reqModel);

	ResponseModel getsalesWebDashBoardDetails(WebDashBoardDetails reqModel);

	ResponseModel getsalesusers(WebDashBoardDetails reqModel);

	ResponseModel insertupdatedoctordetails(DoctorDetailsReqModel reqModel) throws SQLServerException;

	ResponseModel insertupdatedoctorhospitalmapping(DoctorHospitalMappingReqModel reqModel) throws SQLServerException;

	ResponseModel insertupdatesaleshospitalmapping(SalesHospitalMappingReqModel SalesHospitalMappingReqModel)
			throws SQLServerException;

	ResponseModel gethospitalwisestatecity(HospitalstatecityModel reqModel);

	ResponseModel getProductForWeb();

	
	ResponseModel getallcleaningcategory();

	
	ResponseModel getallservicemaster();
	
	ResponseModel getcolourmaster();
	
	ResponseModel getdamagemaster();

	ResponseModel getstainmaster();

	ResponseModel getusermaster();

	ResponseModel getallitemmaster(ItemMasterReqModel requestModel) throws SQLServerException;

	ResponseModel getriderslotavailability(RiderTimeSlotAvailabilityReqModel riderTimeSlotAvailabilityrReqModel);

	ResponseModel getPickupDetails(PickupDetailsReqModel reqModel);

	ResponseModel insertUpdateOrderDetails(OrderDetailsReqModel reqModel) throws SQLServerException;

	ResponseModel insertWebNewOrderDetails(OrderDetailsReqModel reqModel) throws SQLServerException;

	ResponseModel getchallantypemaster();

	ResponseModel getchallanmaster(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getpickupdetailsbyitems(PickupDetailsByItemsReqModel reqModel);

	ResponseModel getchallanmasterexport(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getprocessingmaster(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getprocessdetailsbyitems(PickupDetailsByItemsReqModel reqModel);

	ResponseModel getprocessstepsbyserviceid(ProcessStepsByServiceIdReqModel reqModel);

	ResponseModel insertupdateprocessingstatus(ProcessStatusReqModel reqModel) throws SQLServerException;

	

	ResponseModel getdispatchdetailss(DispatchDetailsReqModel reqModel);

	ResponseModel insertupdatedispatchdetails(DispatchDetailsRequestModel reqModel) throws SQLServerException;

	ResponseModel getstatusdetails(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getprocessingmasterexport(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getpickupdetailsfilter();

	ResponseModel getdetailsbyqrcode(PickupDetailsByItemsReqModel reqModel);

	ResponseModel getdeliverychallandetails(PickupDetailsByItemsReqModel reqModel);

	ResponseModel getstatusdetailsexport(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getreceiveddetails(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getreceiveitemdetails(ReceiveItemDetailsReqModel reciveItemDetailsReqModel);

	ResponseModel updatereceiveitemdetails(ReceivedItemDetailsReqModel reqModel) throws SQLServerException;

	ResponseModel insertupdatesocity(SocietyReqModel socityReqModel)throws SQLServerException;

	ResponseModel getsocietydetails(SocietyDetailsReqModel societyDetailsReqModel);

	ResponseModel updatesocietydetails(UpdateSocietyReqModel reqModel);

	ResponseModel getsocietydetailsexport(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getreceiveddetailsexport(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getreceivedetailsexport(ReceiveDtailsExportReqModel receivedDetailsExportReqModel);

	ResponseModel getmanageinovice(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getmanageinvoiceexport(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getpaymentstatus(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel updatecashreceivedetails(ReceivedItemDetailsReqModel reqModel) throws SQLServerException;

	ResponseModel getcashreceiveddetails(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getcashreceivedetails(ReceiveItemDetailsReqModel reciveItemDetailsReqModel);

	ResponseModel getpaymentstatusdetailsexport(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getcashreceivedetailsexport(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getcashreceiveddetailsexport(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel insertupdatewalletconfiguration(WalletConfigurationReqModel reqModel);

	ResponseModel getwalletconfiguration(SocietyDetailsReqModel societyDetailsReqModel);

	ResponseModel updatewalletconfiguration(UpdateWalletConfigurationReqModel reqModel);

	ResponseModel getwalletconfigurationexport(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getwalletDetailsList(SocietyDetailsReqModel societyDetailsReqModel);

	ResponseModel getwalletDetailsListExport();

	ResponseModel insertupdateCustInfo(CustomerDetailsReqModel reqModel) throws SQLServerException;

	ResponseModel getautomaticprocessdetails(AutomaticProcessReqModel automaticProcessReqModel);

	ResponseModel insertupdateautomaticprocessingstatus(InsertAutomaticProcessStepsReqModel reqModel) throws SQLServerException;

	ResponseModel getcustInfoDetailsExport();

	ResponseModel getstainmasternew(StainMasterNewReqModel reqModel)throws SQLServerException;

	ResponseModel getdamagemasternew(DamageMasterNewReqModel reqModel)throws SQLServerException;

	ResponseModel getcomplaintsdetails(ComplaintsReqModel complaintsReqModel);

	ResponseModel getrefunddetails(ComplaintsReqModel complaintsReqModel);

	ResponseModel insertupdateRiderInfo(RiderDetailsReqModel reqModel) throws SQLServerException;

	ResponseModel getRiderinfoExport(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getcallhestorydetails(CallHestoryReqModel callHestoryReqModel);

	ResponseModel insercomplaintsdetails(InsertComplaintsReqModel reqModel)throws SQLServerException;

	ResponseModel getclosedcomplaintsdetails(ComplaintsReqModel complaintsReqModel);

	ResponseModel insertrefund(InsertRefundReqModel reqModel)throws SQLServerException;

	ResponseModel getdetailstorefund(CallHestoryReqModel callHestoryReqModel);

	ResponseModel getrefundmaster();

	ResponseModel getrefunddetailsexport(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getclosedcomplaintsdetailsexport(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getcomplaintsdetailsexport(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getrefundeddetails(ComplaintsReqModel complaintsReqModel);

	ResponseModel getrefundeddetailsexport(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel gettrackriderdetails(TrackRiderDetailsReqModel trackRiderDetailsReqModel);

	ResponseModel getapporveldetails(TrackRiderDetailsReqModel trackRiderDetailsReqModel);

	ResponseModel getapporvelsaction(CallHestoryReqModel callHestoryReqModel);

	ResponseModel gettrackriderexport(TrackRiderDetailsReqModel trackRiderDetailsReqModel);

	ResponseModel getdeliverymode(DeliveryModeReqModel reqModel);

	ResponseModel getwebdeliveryslots(WebDelierySlotsModel webDelierySlotsModel);

	ResponseModel updateOrderSummaryImagePath(OrderSummaryImageReqModel reqModel);

	ResponseModel getOrderSummaryPdf(OrdersummaryPdf reqModel);

	ResponseModel getqrcodedetails(QrcodeDetailsReqModel qrcodeDetailsReqModel);

	ResponseModel getapporveldetailsexport(ChallanMasterReqModel chalanMasterRequestModel);

	ResponseModel getcolourmasternew(ColourMasterNewReqModel reqModel) throws SQLServerException;

	ResponseModel getbrandmasternew(BrandMasterNewReqModel reqModel) throws SQLServerException;

	ResponseModel getcompanymasternew(CompanyMasterNewReqModel reqModel) throws SQLServerException;

	ResponseModel getdaymaster();

	ResponseModel getitemmasternew(ItemMasterNewReqModel itemMasterNewReqModel) throws SQLServerException;

	ResponseModel getitemmaster();

	ResponseModel getserviceitemmapping(ServiceItemMappingReqModel reqModel) throws SQLServerException;

	ResponseModel getcountrymaster();

	ResponseModel getservicemasternew(ServiceItemMasterNewReqModel reqModel) throws SQLServerException;

	ResponseModel getrescheduleandcancellationdetails(RescheduleAndCancellationReqModel rescheduleAndCancellationReqModel);

	ResponseModel insertupdatepickuprescheduledetails(PickupRescheduleReqModel reqModel) throws SQLServerException;

	ResponseModel insertupdatedeliveryrescheduledetails(PickupRescheduleReqModel reqModel) throws SQLServerException;

	ResponseModel getrescheduledetailsbyorderid(PickupDetailsByItemsReqModel reqModel);

	ResponseModel insertUpdateAssignDetails(PickupRescheduleReqModel reqModel) throws SQLServerException;

	ResponseModel getManualAssignDetails(RescheduleAndCancellationReqModel rescheduleAndCancellationReqModel);

	ResponseModel insertslot(SlotReqModel reqModel) throws SQLServerException;

	ResponseModel getcancilationmaster();

	ResponseModel insertupdateridercancilation(RiderCancilationReqModel reqModel) throws SQLServerException;

	ResponseModel getstainmasterexport();

	ResponseModel getservicemasterexport();

	ResponseModel getserviceitemmappingmasterexport();

	ResponseModel getitemmasterexport();

	ResponseModel getdamagemasterexport();

	ResponseModel getcolourmasterexport();

	ResponseModel getbrandmasterexport();

	ResponseModel getmanualassignexport(RescheduleAndCancellationExportReqModel reqModel) throws SQLServerException;

	ResponseModel getdurationmaster();

	ResponseModel insertupdateslotmasternew(InsertSlotNewReqModel reqModel) throws SQLServerException;

	ResponseModel getslotmasterexport();

	ResponseModel getrescheduleandcanncellationexport(RescheduleAndCancellationExportReqModel reqModel) throws SQLServerException;

	ResponseModel getslotcountt();

	ResponseModel getbrandmaster();

	ResponseModel getemailpromotionaltemplatemaster();

	ResponseModel getemailtransactionaltemplatemaster();

	ResponseModel insertemailtemplatedetailstransactional(TemplateDetailsReqModel reqModel)throws SQLServerException;

	ResponseModel insertemailtemplatedetailspromotional(TemplateDetailsReqModel reqModel)throws SQLServerException;

	ResponseModel getemailcategorymaster();

	ResponseModel getemailcategorydetails(TemplateDetailsReqModel reqModel)throws SQLServerException;

	ResponseModel getemailtempaltedetails(TemplateDetailsReqModel reqModel)throws SQLServerException;

	ResponseModel insertupdateemailtempaltedetails(TemplateDetailsReqModel reqModel)throws SQLServerException;

	ResponseModel getConfiguration(ConfigurationModel configurationModel);

	ResponseModel getbirthdaydetails();

	ResponseModel getanniversarydetails();

	ResponseModel getnotificationsequencedetails(ChallanMasterReqModel chalanMasterRequestModel)throws SQLServerException;

	ResponseModel getnotificationsequencedetailsexport(ChallanMasterReqModel chalanMasterRequestModel)throws SQLServerException;

	ResponseModel getgrommingstandardsdetails(SocietyDetailsReqModel societyDetailsReqModel);

	ResponseModel insertupdategrommingstandards(GrommingstandardsReqModel grommingstandardsReqModel)throws SQLServerException;

	ResponseModel getChatUserList(ChatUserReqModel reqModel);

	ResponseModel getlastmesssage(ChatUserReqModel reqModel);

	ResponseModel getmessageHistory(ChatUserReqModel reqModel);

	ResponseModel getupdateMessageStatus(ChatUserReqModel reqModel);

	ResponseModel insertUpdateAppQRcodeDetails(OrderDetailsReqModel reqModel) throws SQLServerException;

	ResponseModel insertUpdateOrderSubmitDetails(OrderDetailsReqModel reqModel) throws SQLServerException;

	ResponseModel getWcSocietyMaster();

	ResponseModel insertUpdateWebQrcodeDetails(OrderDetailsReqModel reqModel) throws SQLServerException;

	ResponseModel insertUpdateWebSubmitDetails(OrderDetailsReqModel reqModel) throws SQLServerException;

	ResponseModel getWcServiceType();

	ResponseModel getrangemaster();
	
	ResponseModel getStepsMaster();


	ResponseModel getinsertupdatestepsmaster(StepsMasterNewRequestModel reqModel) throws SQLServerException;

	ResponseModel insertmessagedetails(MessagedetailsModel messagedetailsModel) throws SQLServerException;

	ResponseModel getServiceStepsMaster(ServiceStepsMapppingReqModel reqModel) throws SQLServerException;

	ResponseModel getstepmasterreport();

	ResponseModel getservicestepmappingexport();

	ResponseModel updateitemwiseimageupload(ItemwiseImageReqModel reqModel) throws SQLServerException;

	ResponseModel getprocessStsConfig();

	

	ResponseModel getprocessrescheduleconfiguration();

	ResponseModel getprocessneedapprovalconfig();

	ResponseModel insertUpdateOrderApprovelsDetails(OrderDetailsReqModel orderReqModel) throws SQLServerException;

	ResponseModel getCustomerMaster();

	ResponseModel getOrderWiseMaster();

	ResponseModel getprocessOrderAckconfig();

	
	

	

	





	
	
}
