package com.isolve.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.service.IRepeatCollectionActionService;
import com.isolve.web.service.IRepeatCollectionService;
import com.isolve.web.service.IRepeatSampleInitiateService;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
public class RepeatCollectionController 
{
	@Autowired
	private IRepeatCollectionService repeatCollectionService;
	
	@Autowired
	private IRepeatCollectionActionService repeatCollectionActionService;
	
	@Autowired
	private IRepeatSampleInitiateService iRepeatSampleService;
	
	@RequestMapping(value = "/"+CommonConstants.GETREPEATCOLLECTION, method = RequestMethod.POST)
	public ResponseEntity<?> getRepeatCollection(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = repeatCollectionService.getRepeatCollection(requestModel);
			System.out.println(responseModel+" "+hexIV);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@RequestMapping(value = "/"+CommonConstants.GETREPEATCOLLECTIONACTION, method = RequestMethod.POST)
	public ResponseEntity<?> getRepeatCollectionAction(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = repeatCollectionActionService.getRepeatCollectionAction(requestModel);
			System.out.println(responseModel+" "+hexIV);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.REPEATSAMPLEINITIATE, method = RequestMethod.POST)
	public ResponseEntity<?> updateRepeatSample(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iRepeatSampleService.updateRepeatSample(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	
			}
}
