package com.isolve.web.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class TransferTypeResponseModel implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4680419470914839735L;
	@Id
	private Integer lc_tra_id;
	private String lc_tra_code;
	private String lc_tra_name;
}
