package com.isolve.web.service;

import com.isolve.web.model.ReportsReqModel;
import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;

public interface IReportService {

	ResponseModel getAppUsageStatusReport(RequestModel requestModel);

	ResponseModel getCashCollectionTrackReport(RequestModel requestModel);

	ResponseModel getCenterwiseSampleCollectionStatusReport(RequestModel requestModel);

	ResponseModel getParamedicTatReport(RequestModel requestModel);

	ResponseModel getBeatvsVisitComplianceTrackerReport(RequestModel requestModel);

	ResponseModel viewReports(RequestModel requestModel);


	ResponseModel getOrderHandOverType();

	ResponseModel getPendingReports();
	
	ResponseModel getRepositoryReports(RequestModel requestModel);
	
	ResponseModel getReportMaster(RequestModel requestModel);

}
