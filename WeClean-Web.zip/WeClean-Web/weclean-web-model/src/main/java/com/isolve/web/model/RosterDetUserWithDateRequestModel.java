package com.isolve.web.model;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RosterDetUserWithDateRequestModel implements Serializable 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3820859337904189954L;
	private Long userid;
	private Date startdate;
	private Date enddate;
}
