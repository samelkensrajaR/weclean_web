package com.isolve.web.model;

import java.io.Serializable;
import java.util.List;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SocietyReqModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer societyid;
	private String societyname;
	private String societyaddress;
	private Long pincode;
	private String boundry;
	private String latitude;
	private String longitude;
	private Integer status;
	private String remarks;
	private String imagepath;
	private String filename;
	private Long userid;
	private List<RiderInstructionReqModel> riderids;

}
