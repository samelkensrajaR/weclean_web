package com.isolve.web.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AppovalActionStausResModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8714622194718411237L;


	private String damagedetails;
	
	private String WC_OR_ORDERCODE;	 
	
	private Long WC_OR_ORDERID;
	
	private String WC_IM_ITEM_NAME;
	private String WC_SM_SERVICE_NAME;
	private String status;
	private Long invoice_id;
	private Long Item_id;
	private String qrcode;
//	private String image;
//	private String name;
	private Long flag;
	
	private Long rejectedflag;
	private Long approvedflag;
	
	private String approvedby;
	private List<ApprovalActionImagePathResModel> imagepath;
	
}
