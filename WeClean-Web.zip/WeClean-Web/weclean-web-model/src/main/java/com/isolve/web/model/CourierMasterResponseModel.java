package com.isolve.web.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class CourierMasterResponseModel 
{
	@Id
	private Integer id;
	private String courier_name;
}
