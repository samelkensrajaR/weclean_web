package com.isolve.web.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RepeatCollectionRequestModel 
{
	private Long paramedicID;
	private Date schStartdatetime;
	private Date schEnddatetime;
	private Long clientID;
	private String rptType;
}
