package com.isolve.web.repository;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.isolve.web.model.CourierMasterRequestModel;
import com.isolve.web.model.CourierMasterResponseModel;
import com.isolve.web.model.LabMasterRequestModel;
import com.isolve.web.model.LabMasterResponseModel;
import com.isolve.web.model.LabTranReceiveReqModel;
import com.isolve.web.model.LabTransferInitiativeRequestModel;
import com.isolve.web.model.LabTransferInitiativeUserModel;
import com.isolve.web.model.LabTransferRequestModel;
import com.isolve.web.model.LabTransferResponseModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RosterDetUserRequestModel;
import com.isolve.web.model.RosterDetUserResponseModel;
import com.isolve.web.model.RosterTypeResponseModel;
import com.isolve.web.model.SampleTypeResponseModel;
import com.isolve.web.model.TransferTypeResponseModel;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.MyObject;
import com.isolve.web.utils.Utils;
import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;

@Transactional
@Repository
public class LabTransferRepositoryImpl implements ILabTransferRepository
{

	@Autowired
	private EntityManager entityManager;

	Logger log = org.slf4j.LoggerFactory.getLogger(LabTransferRepositoryImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getLabTransfer(LabTransferRequestModel labTransferRequestModel)
	{
		ResponseModel responseModel = new ResponseModel();
		List<LabTransferResponseModel> transferResponseModels = new ArrayList<LabTransferResponseModel>();
		try 
		{	
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_LAB_TRANSFER,LabTransferResponseModel.class);
			query.registerStoredProcedureParameter(CommonConstants.PARAMEDICID, Long.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.SCHSTARTDATETIME, Date.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.SCHENDDATETIME, Date.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.RPTTYPE, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.ORDERORIGINATION, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.SAMPLETYPE, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.TRANSFERTYPE, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.LAB, Integer.class, ParameterMode.IN);


			query.setParameter(CommonConstants.PARAMEDICID, labTransferRequestModel.getParamedicid());
			query.setParameter(CommonConstants.SCHSTARTDATETIME, Utils.utilDateToSqlDate(labTransferRequestModel.getSchstartdatetime()));
			query.setParameter(CommonConstants.SCHENDDATETIME, Utils.utilDateToSqlDate(labTransferRequestModel.getSchenddatetime()));
			query.setParameter(CommonConstants.RPTTYPE, labTransferRequestModel.getRpttype());
			query.setParameter(CommonConstants.ORDERORIGINATION, labTransferRequestModel.getOrderorigination());	
			query.setParameter(CommonConstants.SAMPLETYPE, labTransferRequestModel.getSampletype());	
			query.setParameter(CommonConstants.TRANSFERTYPE, labTransferRequestModel.getTransfertype());	
			query.setParameter(CommonConstants.LAB, labTransferRequestModel.getLab());	


			transferResponseModels = query.getResultList();
			log.info("response----"+transferResponseModels);
			responseModel.setStatusCode(200);
			responseModel.setRespList(transferResponseModels);
		}
		finally 
		{
			entityManager.close();
		}
		return responseModel;
	}

	@Override
	public ResponseModel updateLabTransferInitiative(LabTransferInitiativeRequestModel labTransferInitiativeRequestModel) throws SQLException
	{
		ResponseModel responseModel = new ResponseModel();
		Connection connection = jdbcTemplate.getDataSource().getConnection();
		try 
		{	
			SQLServerDataTable utt_lab_tran_orderid = new SQLServerDataTable();
			utt_lab_tran_orderid.addColumnMetadata("orderid", java.sql.Types.BIGINT);
			utt_lab_tran_orderid.addColumnMetadata("crmid", java.sql.Types.VARCHAR);
			for(LabTransferInitiativeUserModel userModel : labTransferInitiativeRequestModel.getUttlabtranorderid())
			{
				utt_lab_tran_orderid.addRow(userModel.getOrderid(),userModel.getCrmid());
			}
			CallableStatement csstmt = connection.prepareCall("{call USP_UPDATE_LAB_TRAN_INITIATE(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
			if (csstmt.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
				// The CallableStatement object can unwrap to
				// SQLServerCallableStatement.
				SQLServerCallableStatement cs = csstmt.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
				cs.setResponseBuffering("adaptive");
				cs.setInt(1, labTransferInitiativeRequestModel.getSourcelab_id());
				cs.setInt(2, labTransferInitiativeRequestModel.getDestlab_id());
				cs.setStructured(3, "dbo.UTT_LAB_TRAN_ORDERID", utt_lab_tran_orderid);
				cs.setInt(4, labTransferInitiativeRequestModel.getTrantypeid());
				cs.setInt(5, labTransferInitiativeRequestModel.getParamedicid());
				cs.setTimestamp(6, Utils.LocalDateToTimeStamp1(labTransferInitiativeRequestModel.getTransferdate()));
				cs.setString(7, labTransferInitiativeRequestModel.getRemarks());
				cs.setInt(8, labTransferInitiativeRequestModel.getCourier_id());
				cs.setString(9, labTransferInitiativeRequestModel.getPodnumber());
				cs.setTimestamp(10, Utils.LocalDateToTimeStamp1(labTransferInitiativeRequestModel.getCourierdate()));
				cs.setInt(11, labTransferInitiativeRequestModel.getUserid());
				cs.setString(12, labTransferInitiativeRequestModel.getLattitude());
				cs.setString(13, labTransferInitiativeRequestModel.getLongitude());

				boolean resultSetReturned = cs.execute();
				if (resultSetReturned) {
					try (ResultSet rs = cs.getResultSet()) {
						rs.next();
						responseModel.setStatusCode(rs.getInt(1));
						responseModel.setMessage(rs.getString(2));
						log.info("code: "+rs.getInt(1)+" , "+"message: "+rs.getString(2));

					}
				}
			}
		} finally {
			connection.close();
		}
		return responseModel;
	}


	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getSampleType() 
	{
		List<SampleTypeResponseModel> response = new ArrayList<SampleTypeResponseModel>();
		ResponseModel responseModel = new ResponseModel();
		try {
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_ORDER_TYPE,SampleTypeResponseModel.class);
			response = query.getResultList();
			log.info("resp--- "+response);
			responseModel.setStatusCode(200);
			responseModel.setRespList(response);
		}
		finally 
		{
			entityManager.close();
		}
		return responseModel;
	}	


	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getLabMaster(LabMasterRequestModel labMasterRequestModel)
	{
		List<LabMasterResponseModel> labMasterResponseModel = new ArrayList<LabMasterResponseModel>();
		ResponseModel responseModel = new ResponseModel();
		try 
		{
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_LAB_MASTER,LabMasterResponseModel.class); 
			query.registerStoredProcedureParameter(CommonConstants.LANG_ID, Integer.class, ParameterMode.IN);
			query.setParameter(CommonConstants.LANG_ID,labMasterRequestModel.getLang_id());
			labMasterResponseModel = query.getResultList();
			log.info("resp-----"+labMasterResponseModel);
			responseModel.setStatusCode(200);
			responseModel.setRespList(labMasterResponseModel);
		}
		finally 
		{
			entityManager.close();
		}
		return responseModel;
	}



	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getCourierMaster(CourierMasterRequestModel courierMasterRequestModel)
	{
		List<CourierMasterResponseModel> labMasterResponseModel = new ArrayList<CourierMasterResponseModel>();
		ResponseModel responseModel = new ResponseModel();
		try 
		{
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_COURIER_MASTER,CourierMasterResponseModel.class); 
			query.registerStoredProcedureParameter(CommonConstants.LANG_ID, Integer.class, ParameterMode.IN);
			query.setParameter(CommonConstants.LANG_ID,courierMasterRequestModel.getLang_id());
			labMasterResponseModel = query.getResultList();
			log.info("resp-----"+labMasterResponseModel);
			responseModel.setStatusCode(200);
			responseModel.setRespList(labMasterResponseModel);
		}
		finally 
		{
			entityManager.close();
		}
		return responseModel;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel getTransferType()
	{
		List<TransferTypeResponseModel> typeResponseModels  = new ArrayList<TransferTypeResponseModel>();
		ResponseModel responseModel = new ResponseModel();
		try 
		{
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_TRANSFER_TYPE,TransferTypeResponseModel.class); 
			typeResponseModels = query.getResultList();
			log.info("resp-----"+typeResponseModels);
			responseModel.setStatusCode(200);
			responseModel.setRespList(typeResponseModels);
		}
		finally 
		{
			entityManager.close();
		}
		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel updateLabTranReceive(LabTranReceiveReqModel reqModel) throws SQLException
	{
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			SQLServerDataTable orderdetails = new SQLServerDataTable();
			orderdetails.addColumnMetadata("ORDERID", java.sql.Types.BIGINT);
			orderdetails.addColumnMetadata("CRMID", java.sql.Types.VARCHAR);
			for(LabTransferInitiativeUserModel userModel : reqModel.getOrderdetails())
			{
				orderdetails.addRow(userModel.getOrderid(),userModel.getCrmid());

			}

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection.prepareCall("{call USP_UPDATE_LAB_TRAN_RECEIVE(?,?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");			
		            cs.setStructured(1, "dbo.UTT_LAB_TRAN_ORDERID", orderdetails);
		            cs.setInt(2, reqModel.getUserid());
		            cs.setString(3, reqModel.getLattitude());
		            cs.setString(4, reqModel.getLongitude());
//					cs.execute();
				}
				return callableStatement;
			}, prmtrsList);

			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put(CommonConstants.UPDATE_LAB_TRAN_RECEIVE_RESPONSE, l_lstResult);
			}
			
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		//log.info("responseModel------"+responseModel);
		return responseModel;
	}
}
