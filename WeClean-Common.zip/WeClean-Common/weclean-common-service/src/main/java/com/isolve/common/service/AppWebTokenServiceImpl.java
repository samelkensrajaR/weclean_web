package com.isolve.common.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isolve.common.model.AppWebTokenRequestModel;
import com.isolve.common.model.AppWebTokenResponseModel;
import com.isolve.common.model.GenerateOTPResponseModel;
import com.isolve.common.model.GenerateOtpRequestModel;
import com.isolve.common.model.RequestModel;
import com.isolve.common.model.ResponseModel;
import com.isolve.common.model.SignUpDetailsModel;
import com.isolve.common.model.VerifyOTPModel;
import com.isolve.common.repository.IAppWebTokenRepository;
import com.isolve.common.utils.SendEmail;
import com.isolve.common.utils.Utils;

@Service
public class AppWebTokenServiceImpl implements IAppWebTokenService {

	@Autowired
	private IAppWebTokenRepository iAppWebTokenRepository;

	private ObjectMapper objectMapper = new ObjectMapper();

	@Value("${encryptsecretkey}")
	private String encryptsecretkey;

	@Value("${method}")
	private String method;

	@Value("${msg_type}")
	private String msg_type;

	@Value("${userid}")
	private String userid;

	@Value("${auth_scheme}")
	private String auth_scheme;

	@Value("${password}")
	private String password;

	@Value("${v}")
	private String v;

	@Value("${format}")
	private String format;

	@Value("${msgurl}")
	private String msgurl;

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	SendEmail sendEmail;

	/**
	 * @author
	 * @Name createAuthenticationToken - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: createAuthenticationToken method using to validate the auth Token.
	 */
	@Override
	public ResponseModel createAuthenticationToken(RequestModel requestModel) {
		AppWebTokenResponseModel responseModel = new AppWebTokenResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			AppWebTokenRequestModel appWebTokenRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					AppWebTokenRequestModel.class);
			responseModel = iAppWebTokenRepository.checkUsernameandPassword(appWebTokenRequestModel);
		} catch (Exception e) {
			e.printStackTrace();

			responseModel.setStatus(400);
			responseModel.setMessage(e.getMessage());
		}

		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	/**
	 * @author
	 * @Name signUpDetails - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: signUpDetails method using to insert sign up web page.
	 */
	@Override
	public ResponseModel signUpDetails(RequestModel requestModel) {
		SignUpDetailsModel responseModel = new SignUpDetailsModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			SignUpDetailsModel signUpDetailsModel = objectMapper.readValue(decrypt, SignUpDetailsModel.class);
			responseModel = iAppWebTokenRepository.signUpDetails(signUpDetailsModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	/**
	 * @author
	 * @Name generateOTP - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: generateOTP method using to generate OTP for mobile.
	 */
	@Override
	public ResponseModel generateOTP(RequestModel requestModel) {

		ResponseModel responseModel = new ResponseModel();
		GenerateOTPResponseModel otpResponseModel = new GenerateOTPResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			GenerateOtpRequestModel otpRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					GenerateOtpRequestModel.class);
			otpResponseModel = iAppWebTokenRepository.generateOTP(otpRequestModel);

			// String finalurl =
			// msgurl+"method="+method+"&send_to=91"+otpResponseModel.getMobileNumber()+"&msg="+URLEncoder.encode(otpResponseModel.getOTPNo(),
			// StandardCharsets.UTF_8.toString())+"&msg_type="+msg_type+"&userid="+userid+"&auth_scheme="+auth_scheme+"&password="+password+"&v="+v+"&format="+format;
			String finalurl = msgurl + "method=" + method + "&send_to=91" + otpResponseModel.getMobileNumber() + "&msg="
					+ otpResponseModel.getOTPNo() + "&msg_type=" + msg_type + "&userid=" + userid + "&auth_scheme="
					+ auth_scheme + "&password=" + password + "&v=" + v + "&format=" + format;
			ResponseEntity<String> responseEntity;
			responseEntity = restTemplate.getForEntity(finalurl, String.class);
			String responseJsonString = responseEntity.getBody();
			String[] stringArray = responseJsonString.split(" ");
			if (otpResponseModel.getEmail() != null) {
				sendEmail.send(otpResponseModel.getOTPNo(), otpResponseModel.getEmail());
			}
			if (stringArray[0].equalsIgnoreCase("success")) {
				otpResponseModel.setOTPNo(null);
			}

		} catch (Exception e) {
			e.printStackTrace();

			responseModel.setStatusCode(400);
			responseModel.setMessage(e.getMessage());
		}

		try {
			String iv = Utils.randomKey(16);
			responseModel.setResponseData(
					Utils.encrypt(objectMapper.writeValueAsString(otpResponseModel), encryptsecretkey, iv));
			responseModel.setStatusCode(200);
			responseModel.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			responseModel.setStatusCode(400);
			responseModel.setMessage(e.getMessage());
		}
		return responseModel;

	}

	/**
	 * @author
	 * @Name appWebLogin - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: appWebLogin method using to login Web.
	 */
	@Override
	public ResponseModel appWebLogin(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decryptStr = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			AppWebTokenRequestModel appWebTokenRequestModel = objectMapper.readValue(decryptStr,
					AppWebTokenRequestModel.class);
			responseModel = iAppWebTokenRepository.appWebLogin(appWebTokenRequestModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	/**
	 * @author
	 * @Name verifyOTP - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: verifyOTP method using to verify generated OTP.
	 */
	@Override
	public ResponseModel verifyOTP(RequestModel requestModel) {
		ResponseModel model = new ResponseModel();
		ResponseModel responseModel = new ResponseModel();

		try {
			VerifyOTPModel verifyOTPModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					VerifyOTPModel.class);
			responseModel = iAppWebTokenRepository.verifyOTP(verifyOTPModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}

		return model;
	}

	/**
	 * @author
	 * @Name appLogout - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: appLogout method using to logout the WEB page.
	 */
	@Override
	public ResponseModel logout(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			String decryptStr = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			AppWebTokenRequestModel appWebTokenRequestModel = objectMapper.readValue(decryptStr,
					AppWebTokenRequestModel.class);
			responseModel = iAppWebTokenRepository.logout(appWebTokenRequestModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

}
