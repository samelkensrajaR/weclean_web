package com.isolve.common.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.isolve.common.model.LableMasterRequestModel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties
public class LableMasterRequestModel implements Serializable{/**
	 * 
	 */
	private static final long serialVersionUID = 5374362887440636433L;
	
	private Integer langId;
	private Integer controllerId;
	private Integer userType;
	private Integer pageId;
	private Integer appID;
	private Integer roleId;
	


}
