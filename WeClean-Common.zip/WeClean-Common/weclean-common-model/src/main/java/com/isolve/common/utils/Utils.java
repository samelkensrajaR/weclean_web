package com.isolve.common.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Date;
import java.util.Properties;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.mail.Authenticator;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.codec.Hex;

import com.isolve.common.model.ConfigurationModel;
import com.isolve.common.model.GenerateOTPForgotPassResModel;

public class Utils {

	private static final String CIPHER_ALGORITHM = "AES/CBC/PKCS5Padding";
	public static final String HMAC_SHA_256 = "HmacSHA256";
	private static final String KEY_ALGORITHM = "AES";

	/**
	 * @return
	 */
	public static String getCurrentDateTime() {
		String dateTimeFormat = "yyyy-MM-dd HH:mm:ss";
		final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
		SimpleDateFormat sdf = new SimpleDateFormat(dateTimeFormat);
		Date currentDate = new Date();
		String date = sdf.format(currentDate);
		LocalDateTime ldt = LocalDateTime.parse(date, DateTimeFormatter.ofPattern(dateTimeFormat));
		// LocalDateTime ldt = LocalDateTime.parse("2018-07-06 08:15:05",
		// DateTimeFormatter.ofPattern(dateTimeFormat));
		final String lexicalDate = ldt.format(dateTimeFormatter);
		return lexicalDate;
	}

	public static Integer checkNullInteger(String integer) {
		if (integer != null && !integer.equalsIgnoreCase("null")) {
			return Integer.valueOf(integer);
		}
		return null;
	}

	/**
	 * @return
	 * @throws ParseException
	 */
	public static Date getCurDateTime() throws ParseException {
		String dateTimeFormat = "yyyy-MM-dd HH:mm:ss";
		SimpleDateFormat sdf = new SimpleDateFormat(dateTimeFormat);
		Date currentDate = new Date();
		String date = sdf.format(currentDate);
		Date date1 = null;
		date1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(date);
		return date1;
	}

	/**
	 * @return
	 * @throws ParseException
	 */
	public static java.sql.Timestamp getSQLDateTime() throws ParseException {
		Date date = new Date();
		java.sql.Timestamp timestamp = new java.sql.Timestamp(date.getTime());
		return timestamp;
	}

	/**
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	public static Date StringToDateTime(String date) throws ParseException {
		String dateTimeFormat = "yyyy-MM-dd HH:mm:ss";
		Date date1 = new SimpleDateFormat(dateTimeFormat).parse(date);
		return date1;
	}

	/**
	 * @return
	 */
	public static String getCurrentDate() {
		String dateTimeFormat = "yyyy-MM-dd";
		SimpleDateFormat sdf = new SimpleDateFormat(dateTimeFormat);
		Date currentDate = new Date();
		String date = sdf.format(currentDate);

		return date;
	}

	/**
	 * @return
	 */
	public static String dateToString(Date date) {
		String dateTimeFormat = "yyyy-MM-dd";
		SimpleDateFormat sdf = new SimpleDateFormat(dateTimeFormat);
		String dateStr = sdf.format(date);
		return dateStr;
	}

	/**
	 * @param str
	 * @param length
	 * @return
	 */
	public static String lengthValidation(String str, Integer length) {
		String trimStr;
		if (str.length() > length) {
			trimStr = str.substring(0, length);
		} else {
			trimStr = str;
		}
		return trimStr;
	}

	public static Integer checkInteger(Integer integer) {
		if (integer != null) {
			return integer;
		}
		return 0;
	}

	/**
	 * @param string
	 * @return
	 */
	public static boolean isNotNullCheck(String string) {
		if (string != null) {
			return true;
		}
		return false;
	}

	/**
	 * @param string
	 * @return
	 */
	public static String checkString(String string) {
		if (string != null) {
			return string;
		}
		return "";
	}

	/**
	 * @param string
	 * @return
	 */
	public static boolean isEmptyCheck(String string) {
		if (string != "") {
			return true;
		}
		return false;
	}

	final static IvParameterSpec emptyIvSpec = new IvParameterSpec(new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
			0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 });

	/**
	 * @param Data
	 * @param secret
	 * @return
	 * @throws Exception
	 */
	public static String encrypt(String Data, String secret) throws Exception {
		Key key = generateKey(secret);
		Cipher c = Cipher.getInstance(KEY_ALGORITHM);
		c.init(Cipher.ENCRYPT_MODE, key);
		byte[] encVal = c.doFinal(Data.getBytes());
		String encryptedValue = Base64.getEncoder().encodeToString(encVal);
		return encryptedValue;
	}

	/**
	 * @param strToDecrypt
	 * @param secret
	 * @return
	 */
	public static String decrypt(String strToDecrypt, String secret) {
		try {
			Key key = generateKey(secret);
			Cipher cipher = Cipher.getInstance(KEY_ALGORITHM);
			cipher.init(Cipher.DECRYPT_MODE, key);
			return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
		} catch (Exception e) {
			System.out.println("Error while decrypting: " + e.toString());
		}
		return null;
	}

	/**
	 * @param text
	 * @param hexKey
	 * @param hexIv
	 * @return
	 * @throws Exception
	 */
	public static String encrypt(String text, String hexKey, String hexIv) throws Exception {
		if (text == null || text.length() == 0) {
			return null;
		}
		byte[] key = Hex.decode(hexKey);
		SecretKey secretKey = new SecretKeySpec(key, KEY_ALGORITHM);
		Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
		cipher.init(Cipher.ENCRYPT_MODE, secretKey,
				hexIv == null ? emptyIvSpec : new IvParameterSpec(Hex.decode(hexIv)));
		byte[] encrypted = cipher.doFinal(text.getBytes("UTF-8"));
		return Base64.getEncoder().encodeToString(cipher.doFinal(text.getBytes(StandardCharsets.UTF_8)));
	}

	/**
	 * @param ciphertext
	 * @param hexKey
	 * @param hexIv
	 * @return
	 * @throws Exception
	 */
	public static String decrypt(String ciphertext, String hexKey, String hexIv) throws Exception {
		if (ciphertext == null || ciphertext.length() == 0) {
			return null;
		}
		byte[] key = Hex.decode(hexKey);
		SecretKey secretKey = new SecretKeySpec(key, KEY_ALGORITHM);
		Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
		cipher.init(Cipher.DECRYPT_MODE, secretKey,
				hexIv == null ? emptyIvSpec : new IvParameterSpec(Hex.decode(hexIv)));
		byte[] decrypted = cipher.doFinal(Base64.getDecoder().decode(ciphertext.getBytes("UTF-8")));
		return new String(decrypted, "UTF-8");
	}

	/**
	 * @param length
	 * @return
	 */
	public static String randomKey(Integer length) {
		String keyHex = null;
		try {
			byte[] key = new byte[length];
			SecureRandom rand = new SecureRandom();
			rand.nextBytes(key);
			keyHex = bytesToHex(key);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return keyHex;
	}

	/**
	 * @param bytes
	 * @return
	 */
	public static String bytesToHex(byte[] bytes) {
		final char[] hexArray = "0123456789abcdef".toCharArray();
		char[] hexChars = new char[bytes.length * 2];
		for (int j = 0; j < bytes.length; j++) {
			int v = bytes[j] & 0xFF;
			hexChars[j * 2] = hexArray[v >>> 4];
			hexChars[j * 2 + 1] = hexArray[v & 0x0F];
		}
		return new String(hexChars);
	}

	public static Timestamp checkNullandEmpty(Timestamp localDateToTimeStamp) {
		if (localDateToTimeStamp != null) {
			return localDateToTimeStamp;
		}
		return null;
	}

	public static String checkNullandEmpty(String string) {
		if (string != null && !string.trim().isEmpty()) {
			return string;
		}
		return null;
	}

	public static Integer checkNullandEmpty(Integer integer) {
		if (integer != null) {
			return integer;
		}
		return null;
	}

	public static Long checkNullandEmpty(Long londg) {
		if (londg != null) {
			return londg;
		}
		return null;
	}

	public static Double checkNullandEmpty(Double londg) {
		if (londg != null) {
			return londg;
		}
		return null;
	}

	/**
	 * @param secret
	 * @return
	 * @throws Exception
	 */
	private static Key generateKey(String secret) throws Exception {
		byte[] decoded = Base64.getDecoder().decode(secret.getBytes());
		Key key = new SecretKeySpec(decoded, KEY_ALGORITHM);
		return key;
	}

	/**
	 * @param str
	 * @return
	 */
	public static String decodeKey(String str) {
		byte[] decoded = Base64.getDecoder().decode(str.getBytes());
		return new String(decoded);
	}

	/**
	 * @param str
	 * @return
	 */
	public static String encodeKey(String str) {
		byte[] encoded = Base64.getEncoder().encode(str.getBytes());
		return new String(encoded);
	}

	/**
	 * @param keySize
	 * @return
	 */
	public static byte[] generateKey(int keySize) {
		SecureRandom secureRandom = new SecureRandom();
		byte[] array = new byte[keySize];
		secureRandom.nextBytes(array);
		return array;
	}

	/**
	 * @return
	 */
	private static String generateKeyStr() {
		final SecureRandom prng = new SecureRandom();
		final byte[] aes128KeyData = new byte[128 / Byte.SIZE];
		prng.nextBytes(aes128KeyData);
		final SecretKey aesKey = new SecretKeySpec(aes128KeyData, "AES");
		final byte[] data = aesKey.getEncoded();
		final StringBuilder sb = new StringBuilder(data.length * 2);
		for (final byte b : data) {
			sb.append(String.format("%02X", b));
		}
		return sb.toString();
	}

	public static Timestamp LocalDateToTimeStamp(LocalDateTime invoiceDate) {
		Timestamp ts = Timestamp.valueOf(invoiceDate);
		return ts;
	}

	public static Timestamp DateToTimeStamp(Date date) {
		Timestamp ts = new Timestamp(date.getTime());
		return ts;
	}

	/**
	 * @param date
	 * @return
	 */
	public static Date utilDateToSqlDate(Date date) {
		java.sql.Date sqlStartDate = new java.sql.Date(date.getTime());
		return sqlStartDate;
	}

	public static java.sql.Date utilDateToJavaSqlDate(Date date) {
		java.sql.Date sqlStartDate = new java.sql.Date(date.getTime());
		return sqlStartDate;
	}

	public static String sendSMS(String msgurl, String method, GenerateOTPForgotPassResModel otpResponseModel,
			String msg_type, String userid, String auth_scheme, String password, String v, String format) {
		StringBuffer buffer = new StringBuffer();
		try {
			String data = "";
			data += "method=" + method;
			data += "&userid=" + userid; // your loginId
			data += "&password=" + URLEncoder.encode(password, "UTF-8");
			// // your password
			data += "&msg=" + URLEncoder.encode(otpResponseModel.getOTPNo(), "UTF-8");
			data += "&send_to=" + URLEncoder.encode(otpResponseModel.getMobileNumber(), "UTF-8");
			// a valid 10 digit phone no.
			data += "&v=" + v;
			data += "&msg_type=" + msg_type; // Can by "FLASH" or
			// "UNICODE_TEXT" or “BINARY”
			data += "&auth_scheme=" + auth_scheme;
			URL url = new URL(msgurl + data);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setUseCaches(false);
			conn.connect();
			BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;

			while ((line = rd.readLine()) != null) {
				buffer.append(line).append("\n");
			}
			rd.close();
			conn.disconnect();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return buffer.toString();
	}

	public static void sendMail(ConfigurationModel configurationModel, String mailTo) throws MessagingException {

		String to = mailTo;
		String[] toArray = to.split(",");
		String from = configurationModel.getLC_CM_USERNAME();
		String password = configurationModel.getLC_CM_PASSWORD();
		String host = configurationModel.getLC_CM_HOST();// or IP address
		String flag = configurationModel.getLC_CM_DOMAIN();// or IP address
		Session session;
		if (flag.equalsIgnoreCase("gmail")) {
			Properties props = new Properties();
			props.put("mail.smtp.host", host);
			props.put("mail.smtp.socketFactory.port", configurationModel.getLC_CM_PORT());
			props.put("mail.smtp.socketFactory.class",
					"javax.net.ssl.SSLSocketFactory");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.port", configurationModel.getLC_CM_PORT());

			// get Session
			session = Session.getDefaultInstance(props,
					new javax.mail.Authenticator() {
						protected PasswordAuthentication getPasswordAuthentication() {
							return new PasswordAuthentication(from, password);
						}
					});
		} else {
			Properties properties = new Properties();
			properties.put("mail.smtp.host", host);
			properties.put("mail.smtp.port", configurationModel.getLC_CM_PORT());
			properties.put("mail.smtp.starttls.enable", "true");
			properties.put("mail.smtp.auth", "true");

			// Authenticating
			Authenticator auth = new Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(from, password);
				}
			};
			// creating session
			session = Session.getInstance(properties, auth);
		}

		// compose the message
		MimeMessage message = new MimeMessage(session);
		MimeMessageHelper helper = new MimeMessageHelper(message, "utf-8");
		helper.setFrom(new InternetAddress(from));
		helper.setTo(toArray);
		helper.setSubject("Registration OTP");
		helper.setText(configurationModel.getLC_CM_PURPOSE(), true);

		// Send message
		Transport.send(message);

	}

}
