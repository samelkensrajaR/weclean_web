package com.isolve.web.model;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ParamedicUserAvailabiltyRequestModel implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2511470238500734000L;
	private Long userid;
	private Date pickupdate;
	private Long cityid;
}
