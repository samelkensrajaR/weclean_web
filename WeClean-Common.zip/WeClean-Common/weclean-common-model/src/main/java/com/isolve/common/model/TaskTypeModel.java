package com.isolve.common.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class TaskTypeModel implements Serializable{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -786261365659922175L;
	@Id
	private String LC_PT_ID;
	private String LC_PT_NAME;

}
