package com.isolve.web.model;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RoleTargetActionReqModel implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7600729670345623282L;
	private List<MenuUserRights> menuUserRights;
	private Integer actionstatus;
	private String rolename;
	private String rolediscription;
	private Integer rolestatus;

}
