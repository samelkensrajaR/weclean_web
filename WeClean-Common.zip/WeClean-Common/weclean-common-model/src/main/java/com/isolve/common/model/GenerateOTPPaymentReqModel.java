package com.isolve.common.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GenerateOTPPaymentReqModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7102969539934258682L;
	
	private String 	patient_id;
	private String 	sms_validtimelimit;
	private Integer lang_id;
	private String paymenttype;
	private String invoiceamount;
	
	
}
