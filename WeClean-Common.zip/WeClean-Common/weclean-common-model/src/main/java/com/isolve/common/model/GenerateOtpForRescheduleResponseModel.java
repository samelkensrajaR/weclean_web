package com.isolve.common.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class GenerateOtpForRescheduleResponseModel 
{
	@Id
	private String status;
	private String message;
	private String OTPNo;
	private String MobileNumber;
	private String MINS;
	private String Email_or_Mobile;
	private String SENDER_ID;
}
