package com.isolve.web.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.repository.ILabTransferRepository;
import com.isolve.web.service.IBioDiaAssignService;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
public class AssignParamedicBioDiaController 
{

	@Autowired
	private IBioDiaAssignService iUpdateBioDiaAssignService;
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.UPDATEBIODIAASSIGN, method = RequestMethod.POST)
	public ResponseEntity<?> updateBioDiaAssign(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iUpdateBioDiaAssignService.updateBioDiaAssign(requestModel);
			System.out.println(responseModel+" "+hexIV);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.UPDATEASSIGNPARAMEDIC, method = RequestMethod.POST)
	public ResponseEntity<?> getAssignParamedicUpdate(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iUpdateBioDiaAssignService.getAssignParamedicUpdate(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GETUSERPICKUPSCHEDULE, method = RequestMethod.POST)
	public ResponseEntity<?> getUserPickupSchedule(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iUpdateBioDiaAssignService.getUserPickupSchedule(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GETPARAMEDICUSERAVAILABILITY, method = RequestMethod.POST)
	public ResponseEntity<?> getParamedicUserAvailability(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iUpdateBioDiaAssignService.getParamedicUserAvailability(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.CANCELPARAMEDIC, method = RequestMethod.POST)
	public ResponseEntity<?> cancelParamedic(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iUpdateBioDiaAssignService.cancelParamedic(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@RequestMapping(value = "/"+CommonConstants.GETCANCELREASON, method = RequestMethod.GET)
	public ResponseEntity<?> getTransferType() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iUpdateBioDiaAssignService.getCancelReason();	
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_PARAMEDIC_AVAILABILITY_DAY, method = RequestMethod.POST)
	public ResponseEntity<?> getParamedicUserAvailabilityDay(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iUpdateBioDiaAssignService.getParamedicUserAvailabilityDay(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	
	@RequestMapping(value="/track/{randomstring}", method=RequestMethod.GET)
	public void getTrackFullUrl(HttpServletRequest request, HttpServletResponse response, @PathVariable("randomstring") String randomString) throws IOException {
		ResponseModel responseModel = new ResponseModel();
		StringBuffer buffer = request.getRequestURL();
		responseModel = iUpdateBioDiaAssignService.getTrackFullUrl(buffer.toString());	
		response.sendRedirect(responseModel.getStatus());
	}
	
}
