package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class WebDelierySlotsModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
 
	private String date;
	private String pincode;
	private Long type;
	
	private Long orderid;
	private Long invoiceid;
}
