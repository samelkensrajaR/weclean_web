package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ServiceItemMasterNewReqModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer flag;
	private String servicename;
	private String servicecode;
	private String userid;
	private Integer smflag;
	private String discription;
	private Integer smid;
	private Integer start;
	private Integer end;
	private String search;

}
