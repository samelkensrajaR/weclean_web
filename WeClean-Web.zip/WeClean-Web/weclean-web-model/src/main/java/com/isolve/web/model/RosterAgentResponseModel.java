package com.isolve.web.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class RosterAgentResponseModel 
{

	@Id
	private long user_id;
	private String employee_name;
	private String mobile_no;
	private String city;
	private String center;
	private String type;
	private String employee_id;
	private String currentstatus;
}
