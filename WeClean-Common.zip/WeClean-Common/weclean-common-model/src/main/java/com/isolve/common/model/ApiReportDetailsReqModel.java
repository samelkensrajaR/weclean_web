package com.isolve.common.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApiReportDetailsReqModel implements Serializable
{/**
	 * 
	 */
	private static final long serialVersionUID = 4745779282579992015L;
	private String type;
}
