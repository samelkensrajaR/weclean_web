package com.isolve.web.service;

import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;

public interface IUserApproveRejectService {

	public ResponseModel userApproveReject(RequestModel requestModel);

}
