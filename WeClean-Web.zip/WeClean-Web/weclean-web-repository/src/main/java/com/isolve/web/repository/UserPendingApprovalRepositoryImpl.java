package com.isolve.web.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.isolve.web.model.UserPendingApprovalRequestModel;
import com.isolve.web.model.UserPendingApprovalResponseModel;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@Transactional
@Repository
public class UserPendingApprovalRepositoryImpl implements IUserPendingApprovalRepository
{

	@Autowired
	private EntityManager entityManager;
	
	Logger log = LoggerFactory.getLogger(UserPendingApprovalRepositoryImpl.class);

	@SuppressWarnings("unchecked")
	@Override
	public List<UserPendingApprovalResponseModel> userPendingApproval(UserPendingApprovalRequestModel userPendingApprovalRequestModel)
	{
		List<UserPendingApprovalResponseModel> responseModel = new ArrayList<UserPendingApprovalResponseModel>();
		try {
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_USER_PENDING_APPROVAL,UserPendingApprovalResponseModel.class);
			query.registerStoredProcedureParameter(CommonConstants.USERTYPE,Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.CITY, Integer.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(CommonConstants.CRESTARTDATETIME,Date.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(CommonConstants.CREENDDATETIME,Date.class, ParameterMode.IN);
			query.setParameter(CommonConstants.USERTYPE, userPendingApprovalRequestModel.getUsertype());
			query.setParameter(CommonConstants.CITY, userPendingApprovalRequestModel.getCity());
//			query.setParameter(CommonConstants.CRESTARTDATETIME, Utils.utilDateToSqlDate(userPendingApprovalRequestModel.getCrestartdatetime()));
//			query.setParameter(CommonConstants.CREENDDATETIME, Utils.utilDateToSqlDate(userPendingApprovalRequestModel.getCreenddatetime()));
			responseModel = query.getResultList();
		} finally {
			entityManager.close();
		}
		return responseModel;
	}
}
