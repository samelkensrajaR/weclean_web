package com.isolve.web.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.UpdateUserApproveRejectRequestModel;
import com.isolve.web.repository.IUserApproveRejectRepository;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@Service
public class UserApproveRejectServiceImpl implements IUserApproveRejectService
{
	@Autowired
	private IUserApproveRejectRepository iApproveRejectRepository;

	@Value("${encryptsecretkey}")
	private String encryptsecretkey;

	private ObjectMapper objectMapper = new ObjectMapper();

	Logger log = LoggerFactory.getLogger(UserApproveRejectServiceImpl.class);

	@Override
	public ResponseModel userApproveReject(RequestModel requestModel) 
	{
		
		ResponseModel responsemodel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			UpdateUserApproveRejectRequestModel approveRejectRequestModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), UpdateUserApproveRejectRequestModel.class);
			log.info(CommonConstants.UPDATE_USER_APPROVE_REJECT_REQUESTMODEL+ approveRejectRequestModel);
			responsemodel = iApproveRejectRepository.updateUserApproveReject(approveRejectRequestModel);
		} catch (Exception e) {			
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}		
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
	
	
	
	
	
}
