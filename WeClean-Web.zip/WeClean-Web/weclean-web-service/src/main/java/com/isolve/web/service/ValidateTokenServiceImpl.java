package com.isolve.web.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isolve.web.model.ResponseModel;
import com.isolve.web.repository.IValidateTokenRepository;

@Service
public class ValidateTokenServiceImpl implements IValidateTokenService{

	@Autowired
	private IValidateTokenRepository iValidateTokenRepository; 	
	
	Logger log = LoggerFactory.getLogger(ValidateTokenServiceImpl.class);
	
	@Override
	public ResponseModel validateToken(String jwtToken) {
		ResponseModel responseModel = new ResponseModel();
		try {
			responseModel = iValidateTokenRepository.validateToken(jwtToken);
		} catch (Exception e) {
			responseModel.setStatusCode(400);
			responseModel.setMessage(e.getMessage());
			log.debug(e.getMessage());
		}
		return responseModel;
	}

}
