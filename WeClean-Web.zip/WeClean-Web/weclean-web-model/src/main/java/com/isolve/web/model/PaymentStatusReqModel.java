package com.isolve.web.model;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentStatusReqModel implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7373608550742005618L;
    private Long allstatus;
    private Long allclient;
    private Date startdate;
    private Date enddate;
    private Long alltype;
    private String allpaymentstatus;
	
	
    }
