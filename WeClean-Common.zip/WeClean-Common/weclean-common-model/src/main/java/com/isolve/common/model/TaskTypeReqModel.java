package com.isolve.common.model;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaskTypeReqModel implements Serializable{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -786261365659922175L;
	private Integer taskid;
	private Integer bankid;
	private Date pickupdate;
	private String search;
	private Integer flag;

}
