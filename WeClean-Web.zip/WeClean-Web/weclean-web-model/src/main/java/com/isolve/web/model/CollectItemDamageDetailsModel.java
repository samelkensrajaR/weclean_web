package com.isolve.web.model;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CollectItemDamageDetailsModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8156769007193236350L;
	private Integer serviceid;
	private Integer itemid;

	private String servicename;
	private String itemname;

	private Double itemprice;
	private Integer itemcount;
	private List<List<Staindetails>> staindetails;
	private List<List<DamagedetailsModel>> damagedetails;
	private List<List<Colordetails>> colordetails;
	private List<List<Branddetails>> branddetails;
	private List<List<ImagedetailsModel>> imagedetails;
	private List<List<DamageCommondetails>> commondetails;
	private Integer stainid;
	private Integer damageid;
	private Integer colourid;
	private Integer brandid;
	private String notes;
	private Integer is_curtain;

}
