package com.isolve.web.model;

import java.io.Serializable;
import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmailResponseModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7856679371361379734L;

	private Long userid;
	private String doa; 
	private String dob;
	private Long emailsent;
	
}
