package com.isolve.web.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RosterInsertUpdateRequestModel
{
	 private Long ra_id;
	 private Long wc_ra_rider_id;
	 private Long wc_ra_rider_type_id;
	 private String wc_ra_remarks;
	 private String wc_ra_start_date;
	 private String wc_ra_end_date;
	 private String wc_ra_day;
	 private Integer wc_ra_status;
	 private Long wc_ra_created_by;
}
