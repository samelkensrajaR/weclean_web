package com.isolve.web.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderDetailsReqModel implements Serializable{/**
	 * 
	 */
	private static final long serialVersionUID = -3653603813660249655L;
	private  Long orderid;
	private Long customerid;
	private String name;
	private String emailid;
	private String mobileno;
	private Long typeid;
	private Date dob;
	private Date doa;
	private String addressline1;
	private String addressline2;
	private String pincode;
	private List<CollectItemDetailsModel> collectitems;
	private List<CollectItemDetailsModelinsp> collectitemsinsp;
	private String pickupdate;
	private Long pickuptimeid;
	private String remarks;
	private Double invoiceamount;
	private Double subtotal;
	private Double discount;
	private Double deliveryfee;
	private Double tax;
	private Double total;
	private Long deliverymode;
	private Integer isnotification;
	private Long userid;
	private Integer invoiceid;
	private Double discountpercent;
	private Double deliverypercent;
	private Integer deliverytypeid;
	private Integer quckdeliveryid;
	private String deliverydate;
	private Integer ordertype;
	private Long orderflag;
}
