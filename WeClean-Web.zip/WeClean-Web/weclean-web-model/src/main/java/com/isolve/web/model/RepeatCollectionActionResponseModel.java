package com.isolve.web.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class RepeatCollectionActionResponseModel 
{
	@Id
	private String sampleid;
	private String orderid;
	private String crm_id;
	private String test_name;
	private String kit_box_id;
	private String patient_name;
	private String age;
	private String client_name;
	private String paramedic_name;
	private String pickup_type;
	private String pickup_time;
	private String lab_received;
}
