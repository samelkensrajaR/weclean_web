package com.isolve.web.model;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CenterMasterReqModel implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7373608550742005618L;

     private Long centerid;
     private Integer langid;
     private String centercode;
     private String centername;
     private String descriptionname;
     private Integer cityid;
     private Integer stateid;
     private String address;
     private String pincode;
     private String mgmt;
     private String centerheadname;
     private String email;
     private String contactno;
     private String regionalheadcontactno;
     private String regionalheademailid;
     private Long regionid;
     private String regionalheadname;
     private String city;
     private String state;
     private String regionname;
     private String latitude;
     private String longitude;
     private Long userid;
     private Integer flag;
}
