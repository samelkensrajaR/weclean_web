package com.isolve.web.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class RolesResponseModel implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7023526572319932838L;
	@Id
	private Integer roleid;
	private String name;	
	private String description;	
	private String listofrights;
	private String status;
}
