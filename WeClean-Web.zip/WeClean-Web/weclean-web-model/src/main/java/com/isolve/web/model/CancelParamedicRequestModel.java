package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CancelParamedicRequestModel implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1253361597399949516L;
	private Long orderid;
	private Integer reason;
	private String remarks;
	private Long userid;
	private String lattitude;
	private String longitude;
	
}
