package com.isolve.common.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GenerateOTPForgotPassResModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7102969539934258682L;
	
	private String statusCode;
	private String message;
	private String OTPNo;
	private String MobileNumber;
	private String MINS;
	private String Email_or_Mobile;
	private String SENDER_ID;
	private Integer isNewUser;

	
	
}
