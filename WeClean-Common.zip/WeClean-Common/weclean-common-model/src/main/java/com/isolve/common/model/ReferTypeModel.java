package com.isolve.common.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class ReferTypeModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -951818482030299018L;
	@Id
	private String LC_RT_REFER_TYPE_ID;
	private String LC_RT_REFER_TYPE_NAME;



}
