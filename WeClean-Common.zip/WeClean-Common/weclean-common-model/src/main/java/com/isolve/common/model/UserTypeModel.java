package com.isolve.common.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class UserTypeModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7428092750543335915L;
	@Id
	private String WC_UTE_TYPEID;
	private String WC_UTE_TYPENAME;
	private String WC_UTE_STATUS;
	

}
