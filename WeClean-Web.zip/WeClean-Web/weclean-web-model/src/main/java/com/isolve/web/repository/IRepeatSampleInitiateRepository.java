package com.isolve.web.repository;

import java.sql.SQLException;

import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RepeatSampleInitiateRequestModel;
import com.microsoft.sqlserver.jdbc.SQLServerException;

public interface IRepeatSampleInitiateRepository 
{
	public ResponseModel updateRepeatSample(RepeatSampleInitiateRequestModel updateRepeatSampleRequestModel) throws SQLServerException, SQLException;
}
