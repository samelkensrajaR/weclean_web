package com.isolve.web.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.UpdateBioReceiveRequestModel;
import com.isolve.web.repository.IBioReceiveRepository;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@Service
public class BioReceiveServiceImpl implements IBioReceiveService
{
	@Autowired
	private IBioReceiveRepository iBioReceiveRepository;

	@Value("${encryptsecretkey}")
	private String encryptsecretkey;

	private ObjectMapper objectMapper = new ObjectMapper();

	Logger log = LoggerFactory.getLogger(BioReceiveServiceImpl.class);


	@Override
	public ResponseModel updateBioReceive(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			UpdateBioReceiveRequestModel updateBioReceiveRequestModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), UpdateBioReceiveRequestModel.class);
			log.info(CommonConstants.UPDATEBIO_RECEIVE_REQUEST_MODEL + updateBioReceiveRequestModel);
			responsemodel = iBioReceiveRepository.updateBioReceive(updateBioReceiveRequestModel);
		} catch (Exception e) {			
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}		
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			//log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
}
}
