package com.isolve.web.repository;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.UserManagementResModel;
import com.isolve.web.utils.MyObject;
@Transactional
@Repository
public class UserManagementRepositoryImpl implements IUserManagementRepository 
{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	Logger log = LoggerFactory.getLogger(UserManagementRepositoryImpl.class);

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getusermanagement(UserManagementResModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_USER_MGMT(?,?,?)}");
				callableStatement.setInt(1, reqModel.getStart());
				callableStatement.setInt(2, reqModel.getEnd());
				callableStatement.setString(3, reqModel.getSearch());
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getusermanagement", l_lstResult);
			}
			
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}//log.info("responseModel--"+responseModel);
		return responseModel;
	}


}
