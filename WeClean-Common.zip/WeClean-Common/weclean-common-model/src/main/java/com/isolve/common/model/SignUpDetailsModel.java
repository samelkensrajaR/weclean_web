package com.isolve.common.model;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SignUpDetailsModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1201353072483395800L;

	private Integer 	user_title_id;
	private String 	user_first_name;	
	private String 	user_last_name;
	private String 	user_phoneno;
	private String 	user_emailid;
	private Date 	user_dob;
	private Date 	user_doj;
	private Integer 	user_gen_id;
	private String 	user_address_line1;
	private String 	user_address_line2;
	private String 	user_status;
	private String 	user_photo;
	private Integer 	branch_id;
	private Integer 	region_id;
	private String 	user_name;
	private String 	user_imei_number;
	private String 	user_udid_number;
	private String 	user_phone_code;
	private Integer 	user_type_id;
	private Integer 	user_designation_id;
	private Integer 	user_roleid;
	private String 	user_password;
	private String 	user_pin;	
	private String 	qualification;
	private Integer 	exp_in_years;
	private Integer 	pincode;
	private Integer 	cityid;
	private Integer 	stateid;
	private Long 	userid;
	private Long 	loginid;
	private Long roleid;
	private String 	employeeid;
	private Integer 	status;
	private String 	message;
	private Date 	user_doa;

 
	
}
