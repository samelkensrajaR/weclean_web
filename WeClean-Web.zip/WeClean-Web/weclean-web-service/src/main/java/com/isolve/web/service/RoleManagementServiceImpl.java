package com.isolve.web.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RoleActionForSpecificIDReqModel;
import com.isolve.web.model.RolePermissionReqModel;
import com.isolve.web.model.RoleTargetActionReqModel;
import com.isolve.web.repository.IRoleManagementRepository;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@Service
public class RoleManagementServiceImpl implements IRoleManagementService
{
	
	@Autowired
	IRoleManagementRepository iRoleManagementRepository;
	
	
	@Value("${encryptsecretkey}")
	private String encryptsecretkey;

	private ObjectMapper objectMapper = new ObjectMapper();

	Logger log = LoggerFactory.getLogger(RepeatCollectionActionServiceImpl.class);
	
	@Override
	public ResponseModel getRoleTargets()
	{
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try 
		{
			responseModel = iRoleManagementRepository.getRoleTargets();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
	
	
	@Override
	public ResponseModel getRoles()
	{
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try 
		{
			responseModel = iRoleManagementRepository.getRoles();
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
	
	@Override
	public ResponseModel saveTargetActionRole(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,requestModel.getExtraVariable());
			RoleTargetActionReqModel reqModel = objectMapper.readValue(decrypt, RoleTargetActionReqModel.class);
			log.info(CommonConstants.SAVE_TARGET_ACTION_ROLE_REQ_MODEL+" "+ reqModel);
			responseModel = iRoleManagementRepository.saveTargetActionRole(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {			
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}			
		return model;
	}
	
	@Override
	public ResponseModel getRoleActionForSpecificId(RequestModel requestModel) {

		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			RoleActionForSpecificIDReqModel reqModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), RoleActionForSpecificIDReqModel.class);
			log.info(CommonConstants.GET_ROLE_ACTIONSFORSPECIFICTARGETID_REQ_MODEL + reqModel );
			responseModel = iRoleManagementRepository.getRoleActionForSpecificId(reqModel);
		} catch (Exception e) {			
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}		
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
	
	@Override
	public ResponseModel getUserRolePermission(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,requestModel.getExtraVariable());
			RolePermissionReqModel reqModel = objectMapper.readValue(decrypt, RolePermissionReqModel.class);
			log.info(CommonConstants.USERROLE_PERMISSION_REQ_MODEL+" "+ reqModel);
			responseModel = iRoleManagementRepository.getUserRolePermission(reqModel);	
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {			
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}			
		return model;
	}
	
	@Override
	public ResponseModel getroleuseroleservicesteps(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,requestModel.getExtraVariable());
			RolePermissionReqModel reqModel = objectMapper.readValue(decrypt, RolePermissionReqModel.class);
			log.info(CommonConstants.USERROLE_PERMISSION_REQ_MODEL+" "+ reqModel);
			responseModel = iRoleManagementRepository.getroleuseroleservicesteps(reqModel);	
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {			
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}			
		return model;
	}
}
