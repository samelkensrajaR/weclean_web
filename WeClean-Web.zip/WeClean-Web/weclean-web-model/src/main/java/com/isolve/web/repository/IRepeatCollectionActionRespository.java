package com.isolve.web.repository;

import java.util.List;

import com.isolve.web.model.RepeatCollectionActionRequestModel;
import com.isolve.web.model.RepeatCollectionActionResponseModel;

public interface IRepeatCollectionActionRespository {
	public List<RepeatCollectionActionResponseModel> getRepeatCollectionAction
	(RepeatCollectionActionRequestModel actionRequestModel);
}
