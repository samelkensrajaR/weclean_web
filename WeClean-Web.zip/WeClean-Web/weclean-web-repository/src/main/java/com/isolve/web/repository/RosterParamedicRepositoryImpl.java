package com.isolve.web.repository;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.isolve.web.model.DeleteRosterRequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RosterAgentResponseModel;
import com.isolve.web.model.RosterDetUserRequestModel;
import com.isolve.web.model.RosterDetUserResponseModel;
import com.isolve.web.model.RosterDetUserWithDateRequestModel;
import com.isolve.web.model.RosterDetUserWithDateResponseModel;
import com.isolve.web.model.RosterInsertUpdateRequestModel;
import com.isolve.web.model.RosterRosterResponseModel;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;
import org.springframework.jdbc.core.JdbcTemplate;
import com.isolve.web.utils.MyObject;
import java.util.HashMap;
import java.util.HashSet;

@Transactional
@Repository
public class RosterParamedicRepositoryImpl implements IRosterParamedicRepository 
{	
	@Autowired
	private EntityManager entityManager;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	Logger log = LoggerFactory.getLogger(RosterParamedicRepositoryImpl.class);

	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel getRosterAgent() 
	{
		List<RosterAgentResponseModel> response = new ArrayList<RosterAgentResponseModel>();
		ResponseModel responseModel = new ResponseModel();
		try {
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(com.isolve.web.utils.CommonConstants.USP_GET_AGENT_ROSTER,RosterAgentResponseModel.class);
			response = query.getResultList();
			log.info("resp--- "+response);
			responseModel.setStatusCode(200);
			responseModel.setRespList(response);
		}
		finally 
		{
			entityManager.close();
		}
		return responseModel;
	}


	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getRosterDetUser(RosterDetUserRequestModel rosterDetUserRequestModel)
	{
		List<RosterDetUserResponseModel> userResponseModel = new ArrayList<RosterDetUserResponseModel>();
		ResponseModel responseModel = new ResponseModel();
		try 
		{
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_ROSTER_DET_USER,RosterDetUserResponseModel.class); 
			query.registerStoredProcedureParameter(CommonConstants.USERIDD, Long.class, ParameterMode.IN);
			query.setParameter(CommonConstants.USERIDD, rosterDetUserRequestModel.getUserid());
			userResponseModel = query.getResultList();
			log.info("resp-----"+userResponseModel);
			responseModel.setStatusCode(200);
			responseModel.setRespList(userResponseModel);
		}
		finally 
		{
			entityManager.close();
		}
		return responseModel;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getRosterRider() 
	{
		List<RosterRosterResponseModel> response = new ArrayList<RosterRosterResponseModel>();
		ResponseModel responseModel = new ResponseModel();
		try {
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(com.isolve.web.utils.CommonConstants.USP_GETROSTERRIDER,RosterRosterResponseModel.class);
			response = query.getResultList();
			log.info("resp--- "+response);
			responseModel.setStatusCode(200);
			responseModel.setRespList(response);
		}
		finally 
		{
			entityManager.close();
		}
		return responseModel;
	}
	

	@Override
    @SuppressWarnings("unchecked")
    public ResponseModel getRosterType()
    {
    ResponseModel responseModel = new ResponseModel();
    try {
        List prmtrsList = new ArrayList();

        Map<String, Object> resultData = jdbcTemplate.call(connection -> {
            CallableStatement callableStatement = connection
                    .prepareCall("{call "+CommonConstants.usp_Get_ROSTERTYPE+"()}");  
            return callableStatement;
        }, prmtrsList);
        Set<String> set = new HashSet<>();
        set = resultData.keySet();
        // Create properties
        Map<String, Object> properties = new HashMap<>();
        for (String key : set) {
            List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
                    .get(key);
            properties.put("getrostertype", l_lstResult);
        }

            MyObject object = new MyObject(properties);
            responseModel.setResponseObject(object);

        responseModel.setStatusCode(200);
    } finally {
        try {
            jdbcTemplate.getDataSource().getConnection().close();
        } catch (SQLException e) {
            e.printStackTrace();
            log.debug(e.getMessage());
        }
    }
    return responseModel;
}
	
	
	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getRosterInsertUpdate(RosterInsertUpdateRequestModel rosterInsertUpdateRequestModel)
	{
		
		ResponseModel responseModel = new ResponseModel();
		try 
		{	
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_INSERTUPDATEROSTER); 
			query.registerStoredProcedureParameter(CommonConstants.RA_ID, Long.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.WC_RA_RIDER_ID, Long.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.WC_RA_RIDER_TYPE_ID, Long.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.WC_RA_REMARKS, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.WC_RA_START_DATE, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.WC_RA_END_DATE, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.WC_RA_DAY, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.WC_RA_STATUS, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.WC_RA_CREATED_BY, Long.class, ParameterMode.IN);
			
			query.setParameter(CommonConstants.RA_ID, rosterInsertUpdateRequestModel.getRa_id());
			query.setParameter(CommonConstants.WC_RA_RIDER_ID, rosterInsertUpdateRequestModel.getWc_ra_rider_id());
			query.setParameter(CommonConstants.WC_RA_RIDER_TYPE_ID, rosterInsertUpdateRequestModel.getWc_ra_rider_type_id());
			query.setParameter(CommonConstants.WC_RA_REMARKS, rosterInsertUpdateRequestModel.getWc_ra_remarks());
			query.setParameter(CommonConstants.WC_RA_START_DATE, rosterInsertUpdateRequestModel.getWc_ra_start_date());
			query.setParameter(CommonConstants.WC_RA_END_DATE, rosterInsertUpdateRequestModel.getWc_ra_end_date());
			query.setParameter(CommonConstants.WC_RA_DAY, rosterInsertUpdateRequestModel.getWc_ra_day());
			query.setParameter(CommonConstants.WC_RA_STATUS, rosterInsertUpdateRequestModel.getWc_ra_status());
			query.setParameter(CommonConstants.WC_RA_CREATED_BY, rosterInsertUpdateRequestModel.getWc_ra_created_by());
			
			Object[] object = (Object[]) query.getSingleResult();
			for(Object object1:object)
			{
				log.info("resp---"+object1);
			}
			
			responseModel.setStatusCode((Integer)object[0]);
			responseModel.setMessage((String)object[1]);	
		}
		finally 	
		{
			entityManager.close();
		}
		return responseModel;
	}
	
	
	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel deleteRoster(DeleteRosterRequestModel deleteRosterRequestModel)
	{
		ResponseModel responseModel = new ResponseModel();
		try 
		{	
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_DELETE_ROSTER); 
			query.registerStoredProcedureParameter(CommonConstants.RA_ID, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.WC_RA_REMARKS, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USERIDD, Long.class, ParameterMode.IN);
			
			query.setParameter(CommonConstants.RA_ID, deleteRosterRequestModel.getRa_id());
			query.setParameter(CommonConstants.WC_RA_REMARKS, deleteRosterRequestModel.getWc_ra_remarks());
			query.setParameter(CommonConstants.USERIDD, deleteRosterRequestModel.getUserid());
			
			Object[] object = (Object[]) query.getSingleResult();
			for(Object object1:object)
			{
				log.info("resp---"+object1);
			}
			
			responseModel.setStatusCode((Integer)object[0]);
			responseModel.setMessage((String)object[1]);	
		}
		finally 	
		{
			entityManager.close();
		}
		return responseModel;
	}
	
	
	@Override
	@SuppressWarnings("unchecked")
	public ResponseModel getRosterDetUserWithDate(RosterDetUserWithDateRequestModel detUserWithDateRequestModel)
	{
		List<RosterDetUserWithDateResponseModel> detUserWithDateResponseModel = new ArrayList<RosterDetUserWithDateResponseModel>();
		ResponseModel responseModel = new ResponseModel();
		try 
		{
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_GET_ROSTER_DET_USER_WITHDATE,RosterDetUserWithDateResponseModel.class); 
			query.registerStoredProcedureParameter(CommonConstants.USERIDD, Long.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.STARTDATE, Date.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.ENDDATE, Date.class, ParameterMode.IN);
			
			query.setParameter(CommonConstants.USERIDD, detUserWithDateRequestModel.getUserid());
			query.setParameter(CommonConstants.STARTDATE, Utils.utilDateToSqlDate(detUserWithDateRequestModel.getStartdate()));
			query.setParameter(CommonConstants.ENDDATE, Utils.utilDateToSqlDate(detUserWithDateRequestModel.getEnddate()));
			
			detUserWithDateResponseModel = query.getResultList();
			log.info("resp-----"+detUserWithDateResponseModel);
			responseModel.setStatusCode(200);
			responseModel.setRespList(detUserWithDateResponseModel);
		}
		finally 
		{
			entityManager.close();
		}
		return responseModel;
	}
	
}


