package com.isolve.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RiderTimeSlotAvailabilityReqModel;
import com.isolve.web.service.IMasterSevice;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;


@RestController
@CrossOrigin(value = "*",maxAge = 3600)
public class MasterController {
	
	@Autowired
	private IMasterSevice iMasterService;
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERTUPDATEPINCODEMAPPING, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdatepincodemapping(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdatepincodemapping(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_PINCODE_MASTER, method = RequestMethod.POST)
	public ResponseEntity<?> getPinCodeMaster(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getPinCodeMaster(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_VENDOR_VISITTIME_MAPPING, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdatevendorvisittimemapping(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdatevendorvisittimemapping(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_VENDOR_VISIT_TIME, method = RequestMethod.POST)
	public ResponseEntity<?> getVendorVisitTime(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getVendorVisitTime(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_PARAMEDIC_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getParamedicDetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getParamedicDetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_CITY_STATE_CENTER_BY_USERID, method = RequestMethod.POST)
	public ResponseEntity<?> getcitystatecenterbyuserid(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getcitystatecenterbyuserid(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.VENDOR_DETAILS_MASTER, method = RequestMethod.POST)
	public ResponseEntity<?> vendorDetailsMaster(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.vendorDetailsMaster(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_CENTER_MASTER, method = RequestMethod.POST)
	public ResponseEntity<?> insertUpdateCenterMaster(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertUpdateCenterMaster(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_VISIT_TIME_MASTER, method = RequestMethod.POST)
	public ResponseEntity<?> insertUpdateVisitTimeMaster(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertUpdateVisitTimeMaster(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@RequestMapping(value = "/" + CommonConstants.GET_LC_APPROVE_STATUS, method = RequestMethod.GET)
	public ResponseEntity<?> getApproveStatus() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getApproveStatus();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@RequestMapping(value = "/" + CommonConstants.GET_REGION, method = RequestMethod.GET)
	public ResponseEntity<?> getRegion() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getRegion();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@RequestMapping(value = "/" + CommonConstants.GET_MANAGEMENT, method = RequestMethod.GET)
	public ResponseEntity<?> getManagement() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getManagement();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_TEST_PRODUCT_MAPPING, method = RequestMethod.POST)
	public ResponseEntity<?> insertUpdateTestProductMapping(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertUpdateTestProductMapping(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@RequestMapping(value = "/" + CommonConstants.GET_PRECONDITION_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getPreconditionMaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getPreconditionMaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_PAYMENTSTATUS, method = RequestMethod.POST)
	public ResponseEntity<?> getPayamentStatus(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getPaymentStatus(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@RequestMapping(value = "/" + CommonConstants.GET_ALLCLIENT_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getallclientmaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getallclientmaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@RequestMapping(value = "/" + CommonConstants.GET_ALLSTATUS_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getallstatusmaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getallstatusmaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_ALLINVOICETRACKING, method = RequestMethod.POST)
	public ResponseEntity<?> getallinvoicetracking(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getallinvoicetracking(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_QUOTATION_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getQuotationdetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getQuotationdetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@RequestMapping(value = "/" + CommonConstants.GET_APPROVEDSTATUS_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getapprovedstatusmaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getapprovedstatusmaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@RequestMapping(value = "/" + CommonConstants.GET_ACCOUNT_TYPE_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getaccounttypemaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getaccounttypemaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	
	@RequestMapping(value = "/" + CommonConstants.GET_ALLINVOICESTATUS_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getInvoiceStatusMaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getInvoiceStatusMaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_WEB_DASHBOARD_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?>  getWebDashBoardDetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.getWebDashBoardDetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_SALES_WEB_DASHBOARD_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?>  getsalesWebDashBoardDetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.getsalesWebDashBoardDetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_SALES_HOSPITAL_MAPPING, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdatesaleshospitalmapping(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdatesaleshospitalmapping(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_SALES_USERS, method = RequestMethod.POST)
	public ResponseEntity<?>  getsalesusers(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.getsalesusers(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_DOCTOR_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdatedoctordetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdatedoctordetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_DOCTOR_HOSPITAL_MAPPING, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdatedoctorhospitalmapping(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdatedoctorhospitalmapping(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_HOSPITAL_WISE_STATE_CITY, method = RequestMethod.POST)
	public ResponseEntity<?>  gethospitalwisestatecity(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.gethospitalwisestatecity(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	@RequestMapping(value = "/"+CommonConstants.GET_PRODUCT_FOR_WEB,method = RequestMethod.GET)
	public ResponseEntity<?> getProduct()
	{
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getProductForWeb();
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);		
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
		
	}
	@RequestMapping(value = "/"+CommonConstants.GET_ALL_CLEANING_CATEGORY, method = RequestMethod.GET)
	public ResponseEntity<?> getallcleaningcategory() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getallcleaningcategory();
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_ALL_ITEM_MASTER, method = RequestMethod.POST)
	public ResponseEntity<?>  getallitemmaster(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.getallitemmaster(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@RequestMapping(value = "/"+CommonConstants.GET_ALL_SERVICE_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getallservicemaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getallservicemaster();
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@RequestMapping(value = "/"+CommonConstants.GET_COLOUR_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getcolourmaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getcolourmaster();
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@RequestMapping(value = "/"+CommonConstants.GET_DAMAGE_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getdamagemaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getdamagemaster();
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@RequestMapping(value = "/"+CommonConstants.GET_STAIN_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getstainmaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getstainmaster();
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@RequestMapping(value = "/" + CommonConstants.GET_USER_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getusermaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getusermaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_DELIVERY_MODE, method = RequestMethod.POST)
	public ResponseEntity<?>  getdeliverymode(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.getdeliverymode(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_RIDER_SLOT_AVAILABILITY, method = RequestMethod.POST)
	public ResponseEntity<?>  getriderslotavailability(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.getriderslotavailability(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_PICKUP_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?>  getPickupDetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.getPickupDetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_ORDER_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?>  insertUpdateOrderDetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.insertUpdateOrderDetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_WEB_NEW_ORDER_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> insertWebNewOrderDetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.insertWebNewOrderDetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@RequestMapping(value = "/" + CommonConstants.GET_CHALLAN_TYPE_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getchallantypemaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getchallantypemaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_CHALLAN_MASTER, method = RequestMethod.POST)
	public ResponseEntity<?> getchallanmaster(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getchallanmaster(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_PICKUP_DETAILS_BY_ITEMS, method = RequestMethod.POST)
	public ResponseEntity<?>  getpickupdetailsbyitems(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.getpickupdetailsbyitems(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_CHALLAN_MASTER_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getchallanmasterexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getchallanmasterexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_PROCESSING_MASTER, method = RequestMethod.POST)
	public ResponseEntity<?> getprocessingmaster(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getprocessingmaster(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_PROCESS_DETAILS_BY_ITEMS, method = RequestMethod.POST)
	public ResponseEntity<?>  getprocessdetailsbyitems(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.getprocessdetailsbyitems(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_PROCESS_STEPS_BY_SERVICEID, method = RequestMethod.POST)
	public ResponseEntity<?>  getprocessstepsbyserviceid(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.getprocessstepsbyserviceid(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_PROCESS_STATUS, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdateprocessingstatus(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdateprocessingstatus(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	

	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_DISPATCH_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?>  getdispatchdetailss(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.getdispatchdetailss(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_DISPATCH_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdatedispatchdetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdatedispatchdetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_STATUS_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getstatusdetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getstatusdetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_PROCESSING_MASTER_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getprocessingmasterexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getprocessingmasterexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@RequestMapping(value = "/" + CommonConstants.GET_PICKUP_DETAILS_FILTER, method = RequestMethod.GET)
	public ResponseEntity<?> getpickupdetailsfilter() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getpickupdetailsfilter();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_DETAILS_BY_QRCODE, method = RequestMethod.POST)
	public ResponseEntity<?>  getdetailsbyqrcode(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.getdetailsbyqrcode(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_DELIVERY_CHALLAN_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?>  getdeliverychallandetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.getdeliverychallandetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_STATUS_DETAILS_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getstatusdetailsexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getstatusdetailsexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_RECEIVED_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getreceiveddetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getreceiveddetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_RECEIVE_ITEM_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getreceiveitemdetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getreceiveitemdetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.UPDATE_RECEIVE_ITEM_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> updatereceiveitemdetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.updatereceiveitemdetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_SOCITY, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdatesocity(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdatesocity(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_SOCIETY_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getsocietydetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getsocietydetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.UPDATE_SOCIETY_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> updatesocietydetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.updatesocietydetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_SOCIETY_DETAILS_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getsocietydetailsexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getsocietydetailsexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_RECEIVED_DETAILS_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getreceiveddetailsexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getreceiveddetailsexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_RECEIVE_DETAILS_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getreceivedetailsexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getreceivedetailsexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_MANAGE_INVOICE, method = RequestMethod.POST)
	public ResponseEntity<?> getmanageinovice(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getmanageinovice(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_MANAGE_INVOICE_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getmanageinvoiceexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getmanageinvoiceexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_PAYMENT_STATUS, method = RequestMethod.POST)
	public ResponseEntity<?> getpaymentstatus(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getpaymentstatus(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.UPDATE_CASH_RECEIVE_ITEM_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> updatecashreceivedetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.updatecashreceivedetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_CASH_RECEIVED_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getcashreceiveddetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getcashreceiveddetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_CASH_RECEIVE_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getcashreceivedetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getcashreceivedetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_PAYMENT_STATUS_DETAILS_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getpaymentstatusdetailsexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getpaymentstatusdetailsexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_CASH_RECEIVE_DETAILS_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getcashreceivedetailsexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getcashreceivedetailsexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_CASH_RECEIVED_DETAILS_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getcashreceiveddetailsexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getcashreceiveddetailsexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_WALLET_CONFIGURATION, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdatewalletconfiguration(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdatewalletconfiguration(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_WALLET_CONFIGURATION, method = RequestMethod.POST)
	public ResponseEntity<?> getwalletconfiguration(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getwalletconfiguration(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.UPDATE_WALLET_CONFIGURATION, method = RequestMethod.POST)
	public ResponseEntity<?> updatewalletconfiguration(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.updatewalletconfiguration(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_WALLET_CONFIGURATION_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getwalletconfigurationexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getwalletconfigurationexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_WALLET_DETAILS_LIST, method = RequestMethod.POST)
	public ResponseEntity<?> getwalletDetailsList(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getwalletDetailsList(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	

	@RequestMapping(value = "/" + CommonConstants.GET_WALLET_DETAILS_LIST_EXPORT, method = RequestMethod.GET)
	public ResponseEntity<?> getwalletDetailsListExport() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getwalletDetailsListExport();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_CUST_INFO, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdateCustInfo(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdateCustInfo(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_AUTOMATIC_PROCESS_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getautomaticprocessdetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getautomaticprocessdetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_AUTOMATIC_PROCESS_STATUS, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdateautomaticprocessingstatus(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdateautomaticprocessingstatus(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@RequestMapping(value = "/" + CommonConstants.GET_CUST_INFO_DETAILS_EXPORT, method = RequestMethod.GET)
	public ResponseEntity<?> getcustInfoDetailsExport() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getcustInfoDetailsExport();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_STAIN_MASTERS_NEW, method = RequestMethod.POST)
	public ResponseEntity<?> getstainmasternew(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getstainmasternew(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_DAMAGE_MASTERS_NEW, method = RequestMethod.POST)
	public ResponseEntity<?> getdamagemasternew(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getdamagemasternew(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_COMPLAINTS_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getcomplaintsdetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getcomplaintsdetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_REFUND_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getrefunddetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getrefunddetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_RIDER_INFO, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdateRiderInfo(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdateRiderInfo(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_RIDER_INFO_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getRiderinfoExport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getRiderinfoExport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_CALL_HESTORY_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getcallhestorydetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getcallhestorydetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_COMPLAINTS_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> insercomplaintsdetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insercomplaintsdetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_CLOSED_COMPLAINTS_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getclosedcomplaintsdetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getclosedcomplaintsdetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_REFUND, method = RequestMethod.POST)
	public ResponseEntity<?> insertrefund(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertrefund(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	

	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_DETAILS_TO_REFUND, method = RequestMethod.POST)
	public ResponseEntity<?> getdetailstorefund(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getdetailstorefund(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@RequestMapping(value = "/" + CommonConstants.GET_REFUND_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getrefundmaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getrefundmaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_REFUND_DETAILS_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getrefunddetailsexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getrefunddetailsexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_CLOSED_COMPLAINTS_DETAILS_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getclosedcomplaintsdetailsexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getclosedcomplaintsdetailsexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_COMPLAINTS_DETAILS_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getcomplaintsdetailsexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getcomplaintsdetailsexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}

	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_REFUNDED_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getrefundeddetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getrefundeddetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_REFUNDED_DETAILS_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getrefundeddetailsexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getrefundeddetailsexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_TRACK_RIDERS_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> gettrackriderdetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.gettrackriderdetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_APPORVEL_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getapporveldetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getapporveldetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_APPORVEL_ACTION, method = RequestMethod.POST)
	public ResponseEntity<?> getapporvelsaction(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getapporvelsaction(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_TRACK_RIDERS_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> gettrackriderexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.gettrackriderexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_WEB_DELIVERY_SLOTS, method = RequestMethod.POST)
	public ResponseEntity<?> getwebdeliveryslots(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getwebdeliveryslots(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_QRCODE_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getqrcodedetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getqrcodedetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.IMAGE_UPLOAD, method = RequestMethod.POST)
	public ResponseEntity<?> imageupload(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.imageupload(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_APPORVEL_DETAILS_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getapporveldetailsexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getapporveldetailsexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_INSERT_UPDATE_BRAND_MASTER, method = RequestMethod.POST)
	public ResponseEntity<?> getbrandmasternew(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getbrandmasternew(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_COLOUR_MASTER_NEW, method = RequestMethod.POST)
	public ResponseEntity<?> getcolourmasternew(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getcolourmasternew(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_INSERT_UPDATE_COMPANY_MASTER, method = RequestMethod.POST)
	public ResponseEntity<?> getcompanymasternew(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getcompanymasternew(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@RequestMapping(value = "/" + CommonConstants.GET_DAY_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getdaymaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getdaymaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_INSERT_UPDATE_ITEM_MASTER, method = RequestMethod.POST)
	public ResponseEntity<?> getitemmasternew(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getitemmasternew(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@RequestMapping(value = "/" + CommonConstants.GET_ITEM_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getitemmaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getitemmaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_SERVICE_ITEM_MAPPING_NEW, method = RequestMethod.POST)
	public ResponseEntity<?> getserviceitemmapping(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getserviceitemmapping(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@RequestMapping(value = "/" + CommonConstants.GET_COUNTRY_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getcountrymaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getcountrymaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_INSERT_UPDATE_SERVICE_MASTER, method = RequestMethod.POST)
	public ResponseEntity<?> getservicemasternew(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getservicemasternew(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_RESCHEDULE_AND_CANNCELLATION_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getrescheduleandcancellationdetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getrescheduleandcancellationdetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_PICKUP_RESCHEDLUE_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdatepickuprescheduledetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdatepickuprescheduledetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_DELIVERY_RESCHEDLUE_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdatedeliveryrescheduledetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdatedeliveryrescheduledetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_RESCHEDULE_DETAILS_BY_ORDERID, method = RequestMethod.POST)
	public ResponseEntity<?>  getrescheduledetailsbyorderid(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.getrescheduledetailsbyorderid(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_ASSIGN_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> insertUpdateAssignDetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertUpdateAssignDetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_MANUAL_ASSIGN_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getManualAssignDetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getManualAssignDetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_SLOT, method = RequestMethod.POST)
	public ResponseEntity<?> insertslot(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertslot(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@RequestMapping(value = "/" + CommonConstants.GET_ALL_CANCILATION_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getcancilationmaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getcancilationmaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_RIDER_CANCILLATION, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdateridercancilation(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdateridercancilation(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@RequestMapping(value = "/" + CommonConstants.GET_STAIN_MASTER_EXPORT, method = RequestMethod.GET)
	public ResponseEntity<?> getstainmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getstainmasterexport();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@RequestMapping(value = "/" + CommonConstants.GET_SERVICE_MASTER_EXPORT, method = RequestMethod.GET)
	public ResponseEntity<?> getservicemasterexport() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getservicemasterexport();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@RequestMapping(value = "/" + CommonConstants.GET_SERVICE_ITEM_MAPPING_EXPORT, method = RequestMethod.GET)
	public ResponseEntity<?> getserviceitemmappingmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getserviceitemmappingmasterexport();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@RequestMapping(value = "/" + CommonConstants.GET_ITEM_MASTER_EXPORT, method = RequestMethod.GET)
	public ResponseEntity<?> getitemmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getitemmasterexport();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@RequestMapping(value = "/" + CommonConstants.GET_DAMAGE_MASTER_EXPORT, method = RequestMethod.GET)
	public ResponseEntity<?> getdamagemasterexport() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getdamagemasterexport();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@RequestMapping(value = "/" + CommonConstants.GET_COLOUR_MASTER_EXPORT, method = RequestMethod.GET)
	public ResponseEntity<?> getcolourmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getcolourmasterexport();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@RequestMapping(value = "/" + CommonConstants.GET_BRAND_MASTER_EXPORT, method = RequestMethod.GET)
	public ResponseEntity<?> getbrandmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getbrandmasterexport();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
//	@RequestMapping(value = "/" + CommonConstants.GET_MANUAL_ASSIGN_EXPORT, method = RequestMethod.GET)
//	public ResponseEntity<?> getmanualassignexport() {
//		ResponseModel responseModel = new ResponseModel();
//		responseModel = iMasterService.getmanualassignexport();
//		
//		String iv = responseModel.getStatus();
//		responseModel.setStatus(null);
//		
//	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
//}
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_MANUAL_ASSIGN_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getmanualassignexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getmanualassignexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	@RequestMapping(value = "/" + CommonConstants.GET_WC_DURATION_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getdurationmaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getdurationmaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_SLOT_MASTER_NEW, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdateslotmasternew(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdateslotmasternew(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@RequestMapping(value = "/" + CommonConstants.GET_SLOT_MASTER_EXPORT, method = RequestMethod.GET)
	public ResponseEntity<?> getslotmasterexport() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getslotmasterexport();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_RESCHEDULE_AND_CANNCELLATION_DETAILS_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getrescheduleandcanncellationexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getrescheduleandcanncellationexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@RequestMapping(value = "/" + CommonConstants.GET_SLOT_COUNT, method = RequestMethod.GET)
	public ResponseEntity<?> getslotcountt() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getslotcountt();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@RequestMapping(value = "/" + CommonConstants.GET_BRAND_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getbrandmaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getbrandmaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@RequestMapping(value = "/" + CommonConstants.GET_EMAIL_PEOMOTIONAL_TEMPLATE_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getemailpromotionaltemplatemaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getemailpromotionaltemplatemaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@RequestMapping(value = "/" + CommonConstants.GET_EMAIL_TRANSACTIONAL_TEMPLATE_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getemailtransactionaltemplatemaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getemailtransactionaltemplatemaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_EMAIL_TEMPLATE_DETAILS_TRANSACTIONAL, method = RequestMethod.POST)
	public ResponseEntity<?> insertemailtemplatedetailstransactional(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertemailtemplatedetailstransactional(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_EMAIL_TEMPLATE_DETAILS_PEOMOTIONAL, method = RequestMethod.POST)
	public ResponseEntity<?> insertemailtemplatedetailspromotional(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertemailtemplatedetailspromotional(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@RequestMapping(value = "/" + CommonConstants.GET_EMAIL_CATEGORY_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getemailcategorymaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getemailcategorymaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_EMAIL_CATEGORY_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getemailcategorydetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getemailcategorydetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_EMAIL_TEMPLATE_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getemailtempaltedetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getemailtempaltedetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_EMAIL_TEMPLATE_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdateemailtempaltedetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdateemailtempaltedetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	@RequestMapping(value = "/" + CommonConstants.GET_BIRTHDAY_DETAILS, method = RequestMethod.GET)
	public ResponseEntity<?> getbirthdaydetails() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getbirthdaydetails();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@RequestMapping(value = "/" + CommonConstants.GET_ANNIVERSARY_DETAILS, method = RequestMethod.GET)
	public ResponseEntity<?> getanniversarydetails() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getanniversarydetails();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_NOTIFICATION_SEQUENCE_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getnotificationsequencedetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getnotificationsequencedetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_NOTIFICATION_SEQUENCE_DETAILS_EXPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getnotificationsequencedetailsexport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getnotificationsequencedetailsexport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_GROOMING_STANDARDS_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getgrommingstandardsdetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getgrommingstandardsdetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
			}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_GROOMING_STANDARDS, method = RequestMethod.POST)
	public ResponseEntity<?> insertupdategrommingstandards(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertupdategrommingstandards(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GetChatUserList, method = RequestMethod.POST)
	public ResponseEntity<?> getChatUserList(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getChatUserList(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GetLastMessage, method = RequestMethod.POST)
	public ResponseEntity<?> getlastmesssage(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getlastmesssage(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GetMessageHistory, method = RequestMethod.POST)
	public ResponseEntity<?> getmessageHistory(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getmessageHistory(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.UpdateMessageStatus, method = RequestMethod.POST)
	public ResponseEntity<?> getupdateMessageStatus(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getupdateMessageStatus(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_APP_QRCODE_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?>  insertUpdateAppQRcodeDetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.insertUpdateAppQRcodeDetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_ORDER_SUBMIT_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?>  insertUpdateOrderSubmitDetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.insertUpdateOrderSubmitDetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@RequestMapping(value = "/" + CommonConstants.GET_WC_SOCIETY_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getWcSocietyMaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getWcSocietyMaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_WEB_QRCODE_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> insertUpdateWebQrcodeDetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.insertUpdateWebQrcodeDetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_WEB_SUBMIT_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> insertUpdateWebSubmitDetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.insertUpdateWebSubmitDetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/" + CommonConstants.GET_WC_SERVICE_TYPE, method = RequestMethod.GET)
	public ResponseEntity<?> getWcServiceType() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getWcServiceType();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/" + CommonConstants.GET_AGE_RANGE_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getrangemaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getrangemaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/" + CommonConstants.GET_STEPS_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getStepsMaster() 
	{
	ResponseModel responseModel = new ResponseModel();
	responseModel = iMasterService.getStepsMaster();

		  String iv = responseModel.getStatus();
	responseModel.setStatus(null);
	
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	
}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_INSERT_UPDATE_STEPS_MASTER, method = RequestMethod.POST)
	public ResponseEntity<?> getinsertupdatestepsmaster(HttpServletRequest request, HttpServletResponse response,
	@RequestBody RequestModel requestModel)
	{
	     ResponseModel responseModel = new ResponseModel();
	    final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
	if (Utils.isNotNullCheck(hexIV)) {
	    requestModel.setExtraVariable(hexIV);
	    responseModel = iMasterService.getinsertupdatestepsmaster(requestModel);
	   } else {
	 responseModel.setStatusCode(response.SC_BAD_REQUEST);
	 responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
	}
	String iv = responseModel.getStatus();
	 responseModel.setStatus(null);
	 return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	 
	 
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_MESSAGE_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> insertmessagedetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.insertmessagedetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.SERVICE_STEPS_MASTER, method = RequestMethod.POST)
	public ResponseEntity<?> getServiceStepsMaster(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getServiceStepsMaster(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@RequestMapping(value = "/" + CommonConstants.GET_STEP_MASTER_REPORT, method = RequestMethod.GET)
	public ResponseEntity<?> getstepmasterreport() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getstepmasterreport();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}

	@RequestMapping(value = "/" + CommonConstants.GET_SERVICE_STEP_MAPPING_EXPORT, method = RequestMethod.GET)
	public ResponseEntity<?> getservicestepmappingexport() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getservicestepmappingexport();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.UPDATE_ITEMWISE_IMAGE_UPLOAD, method = RequestMethod.POST)
	public ResponseEntity<?> updateitemwiseimageupload(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.updateitemwiseimageupload(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.INSERT_UPDATE_ORDER_APPROVALS_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> insertUpdateOrderApprovelsDetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel =iMasterService.insertUpdateOrderApprovelsDetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@RequestMapping(value = "/" + CommonConstants.GET_CUSTOMER_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getCustomerMaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getCustomerMaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
	@RequestMapping(value = "/" + CommonConstants.GET_ORDER_WISE_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getOrderWiseMaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getOrderWiseMaster();
		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}	
}


	

	
