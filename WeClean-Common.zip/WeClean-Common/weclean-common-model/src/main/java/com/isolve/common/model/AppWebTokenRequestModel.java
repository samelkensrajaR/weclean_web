package com.isolve.common.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AppWebTokenRequestModel implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 6017668426150362089L;
	private String loginUser;
	private String password;
	private String loginType;
	private String loginMode;
	private String langId;	
	private String wcUsdLatitude;
	private String wcUsdLongitude;
	private String imei;
	private String firebaseId;
	private String androidIOSWeb;

			 
}