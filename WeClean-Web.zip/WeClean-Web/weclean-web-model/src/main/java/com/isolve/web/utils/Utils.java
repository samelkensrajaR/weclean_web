package com.isolve.web.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.activation.DataSource;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.util.ByteArrayDataSource;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.codec.CharEncoding;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.codec.Hex;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.isolve.web.model.ConfigurationResponseModel;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;
import com.opencsv.CSVWriter;

public class Utils {
	

	 private static final String CIPHER_ALGORITHM = "AES/CBC/PKCS5Padding";
	 public static final String HMAC_SHA_256 = "HmacSHA256";
	 private static final String KEY_ALGORITHM = "AES";

	/**
	 * @return
	 */
	public static String getCurrentDateTime() {
		String dateTimeFormat = "yyyy-MM-dd HH:mm:ss";
		final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
		SimpleDateFormat sdf = new SimpleDateFormat(dateTimeFormat);
		Date currentDate = new Date();
//		  System.out.println("dateTime : "+sdf.format(currentDate));			 
		String date = sdf.format(currentDate);
		LocalDateTime ldt = LocalDateTime.parse(date, DateTimeFormatter.ofPattern(dateTimeFormat));
//		LocalDateTime ldt = LocalDateTime.parse("2018-07-06 08:15:05", DateTimeFormatter.ofPattern(dateTimeFormat));
		final String lexicalDate = ldt.format(dateTimeFormatter);
		return lexicalDate;
	}
	 
	
	public static String getCurrentDateTimeMillisec() {
		String dateTimeFormat = "yyyy-MM-dd HH:mm:ssSSS";
		final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssSSS");
		SimpleDateFormat sdf = new SimpleDateFormat(dateTimeFormat);
		Date currentDate = new Date();
//		  System.out.println("dateTime : "+sdf.format(currentDate));			 
		String date = sdf.format(currentDate);
		LocalDateTime ldt = LocalDateTime.parse(date, DateTimeFormatter.ofPattern(dateTimeFormat));
//		LocalDateTime ldt = LocalDateTime.parse("2018-07-06 08:15:05", DateTimeFormatter.ofPattern(dateTimeFormat));
		final String lexicalDate = ldt.format(dateTimeFormatter);
		return lexicalDate;
	}

	/**
	 * @return
	 * @throws ParseException
	 */
	public static Date getCurDateTime() throws ParseException {
		String dateTimeFormat = "yyyy-MM-dd HH:mm:ss";
		SimpleDateFormat sdf = new SimpleDateFormat(dateTimeFormat);
		Date currentDate = new Date();
//		  System.out.println("dateTime : "+sdf.format(currentDate));			 
		String date = sdf.format(currentDate);
		Date date1 = null;
		date1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(date);
//		  System.out.println("zonedDateTime : "+date1); 
		return date1;
	}
	
	/**
	 * @return
	 * @throws ParseException
	 */
	public static java.sql.Timestamp getSQLDateTime() throws ParseException {
		Date date = new Date();
		java.sql.Timestamp timestamp = new java.sql.Timestamp(date.getTime());
		System.out.println("timestamp : "+timestamp);
		return timestamp;
	}

	
	/**
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	public static Date utilDateToSqlDate(Date date) {
		 java.sql.Date sqlStartDate = new java.sql.Date(date.getTime());
		 System.out.println("sqlStartDate----"+sqlStartDate);
		return sqlStartDate;
		
	}
	
	/**
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	public static  java.sql.Date utilDateTojavaSqlDate(Date date) {
		 java.sql.Date sqlStartDate = new java.sql.Date(date.getTime());
		 System.out.println("sqlStartDate----"+sqlStartDate);
		return sqlStartDate;
	}
	
	/**
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	public static Date StringToDateTime(String date) {
		String dateTimeFormat = "yyyy-MM-dd HH:mm:ss.sss";
		Date date1 = null;
		try {
			date1 = new SimpleDateFormat(dateTimeFormat).parse(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(date1 + "\t" + date1);
		return date1;
	}

	/**
	 * @return
	 */
	public static String getCurrentDate() {
		String dateTimeFormat = "yyyy-MM-dd";
		SimpleDateFormat sdf = new SimpleDateFormat(dateTimeFormat);
		Date currentDate = new Date();
//		  System.out.println("dateTime : "+sdf.format(currentDate));			 
		String date = sdf.format(currentDate);

		return date;
	}
	
	/**
	 * @return
	 */
	public static String dateToString(Date date) {
		String dateTimeFormat = "yyyy-MM-dd";
		SimpleDateFormat sdf = new SimpleDateFormat(dateTimeFormat);
		String dateStr = sdf.format(date);
		return dateStr;
	}	

	/**
	 * @param str
	 * @param length
	 * @return
	 */
	public static String lengthValidation(String str,Integer length) {
		String trimStr;
		if (str.length() > length) {
			trimStr = str.substring(0,length);
		} else {
			trimStr = str;
		}
		return trimStr;
	}

	/**
	 * @param string
	 * @return
	 */
	public static boolean isNotNullCheck(String string) {
		if (string != null) {
			return true;	
		}
		return false;
	}
	
	/**
	 * @param string
	 * @return
	 */
	public static boolean isEmptyCheck(String string) {
		if (string != "") {
			return true;	
		}
		return false;
	}

	
	/**
	 * @param string
	 * @return
	 */
	public static String setEmptyString(String string) {
		if (string != null) {
			return string;	
		}
		return "";
	}
	
	/**
	 * @param string
	 * @return
	 */
	public static Long setEmptyLong(Long long1) {
		if (long1 != null) {
			return long1;	
		}
		return null;
	}
	
	final static IvParameterSpec emptyIvSpec = new IvParameterSpec(new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
			0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 });
	
	
	 /**
     * @param text
     * @param hexKey
     * @param hexIv
     * @return
     * @throws Exception
     */
    public static String encrypt(String text, String hexKey, String hexIv) throws Exception {
		if (text == null || text.length() == 0) {
			return null;
		}
		byte[] key = Hex.decode(hexKey);
		SecretKey secretKey = new SecretKeySpec(key, KEY_ALGORITHM);
		Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
		cipher.init(Cipher.ENCRYPT_MODE, secretKey,
				hexIv == null ? emptyIvSpec : new IvParameterSpec(Hex.decode(hexIv)));
		byte[] encrypted = cipher.doFinal(text.getBytes("UTF-8"));
		return Base64.getEncoder().encodeToString(cipher.doFinal(text.getBytes(StandardCharsets.UTF_8)));
	}
    
    /**
     * @param ciphertext
     * @param hexKey
     * @param hexIv
     * @return
     * @throws Exception
     */
    public static String decrypt(String ciphertext, String hexKey, String hexIv) throws Exception {
		if (ciphertext == null || ciphertext.length() == 0) {
			return null;
		}
		byte[] key = Hex.decode(hexKey);
		SecretKey secretKey = new SecretKeySpec(key, KEY_ALGORITHM);
		Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
		cipher.init(Cipher.DECRYPT_MODE, secretKey,
				hexIv == null ? emptyIvSpec : new IvParameterSpec(Hex.decode(hexIv)));
		byte[] decrypted = cipher.doFinal(Base64.getDecoder().decode(ciphertext.getBytes("UTF-8")));
		return new String(decrypted, "UTF-8");
	}
    /**
     * @param length
     * @return
     */
    public static String randomKey(Integer length) {
		String keyHex = null;
		try {
			byte[] key = new byte[length];
			SecureRandom rand = new SecureRandom();
			rand.nextBytes(key);
			keyHex = bytesToHex(key);
			} catch (Exception e) {
			e.printStackTrace();
			}
		return keyHex;
	}

    /**
     * @return
     */
    public static String getRandomChars() {
		String randomStr = "";
		String possibleChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		for (int i = 0; i < 5; i++)
			randomStr += possibleChars.charAt((int) Math.floor(Math.random() * possibleChars.length()));
		return randomStr;
	}
    
    /**
     * @param bytes
     * @return
     */
    public static String bytesToHex(byte[] bytes) {
		final char[] hexArray = "0123456789abcdef".toCharArray();
		char[] hexChars = new char[bytes.length * 2];
		for (int j = 0; j < bytes.length; j++) {
			int v = bytes[j] & 0xFF;
			hexChars[j * 2] = hexArray[v >>> 4];
			hexChars[j * 2 + 1] = hexArray[v & 0x0F];
		}
		return new String(hexChars);
	}
    
	public static String encrypt(String Data, String secret) throws Exception {
        Key key = generateKey(secret);
        Cipher c = Cipher.getInstance(KEY_ALGORITHM);
        c.init(Cipher.ENCRYPT_MODE, key);
        byte[] encVal = c.doFinal(Data.getBytes());
        String encryptedValue = Base64.getEncoder().encodeToString(encVal);
        return encryptedValue;
    }

    public static String decrypt(String strToDecrypt, String secret) {

        try {
            Key key = generateKey(secret);
            Cipher cipher = Cipher.getInstance(KEY_ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, key);
            return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
        } catch (Exception e) {
            System.out.println("Error while decrypting: " + e.toString());
        }
        return null;
    }

    private static Key generateKey(String secret) throws Exception {
        byte[] decoded = Base64.getDecoder().decode(secret.getBytes());
        Key key = new SecretKeySpec(decoded, KEY_ALGORITHM);
        return key;
    }

    public static String decodeKey(String str) {
        byte[] decoded = Base64.getDecoder().decode(str.getBytes());
        return new String(decoded);
    }

    public static String encodeKey(String str) {
        byte[] encoded = Base64.getEncoder().encode(str.getBytes());
        return new String(encoded);
    }
    public static byte[] generateKey(int keySize) {
		SecureRandom secureRandom = new SecureRandom();
		byte[] array = new byte[keySize];
		secureRandom.nextBytes(array);
		return array;
	}
    private static String generateKeyStr() {
    	 final SecureRandom prng = new SecureRandom();
 	    final byte[] aes128KeyData  = new byte[128 / Byte.SIZE];
 	    prng.nextBytes(aes128KeyData);
 	    final SecretKey aesKey = new SecretKeySpec(aes128KeyData, "AES");
 	   final byte[] data = aesKey.getEncoded();
        final StringBuilder sb = new StringBuilder(data.length * 2);
        for (final byte b : data) {
            sb.append(String.format("%02X", b));
        }
        return sb.toString();
    }
    
    /**
    * @param invoiceDate
    * @return
    */
    public static Timestamp LocalDateToTimeStamp(LocalDateTime invoiceDate) {
    Timestamp ts = null;
    if (invoiceDate ==null) {
    return ts;
    } else {
    ts = Timestamp.valueOf(invoiceDate);
    System.out.println("ts"+ts);
    }
    return ts;
    }
    
    /**
     * @param labTransferInitiativeRequestModel
     * @return
     */
	public static Timestamp LocalDateToTimeStamp1(LocalDateTime localDateTime) {
		Timestamp ts = null;
		if (localDateTime == null) {
			return ts;
		} else {
			ts = Timestamp.valueOf(localDateTime);
			System.out.println("ts  " + ts);
		}
		return ts;
	}

		/**
		 * @param date
		 * @return
		 */
		public static Timestamp StringToTimeStamp(String date) {
			Timestamp timestamp = null;
			if (date == null) {
				return timestamp;
			} else {
				try {
					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
					Date parsedDate = dateFormat.parse(date);
					timestamp = new java.sql.Timestamp(parsedDate.getTime());
				} catch (Exception e) {

				}
			}
			return timestamp;
		}
    



    public static Timestamp checkNullandEmpty(Timestamp localDateToTimeStamp) {
    if (localDateToTimeStamp != null) {
    return localDateToTimeStamp;
    }
    return null;
    }

    public static String checkNullandEmpty(String string) {
    if (string != null && !string.trim().isEmpty()) {
    return string;
    }
    return null;
    }
    public static Integer checkNullandEmpty(Integer integer) {
    if (integer != null) {
    return integer;
    }
    return null;
    }
    
   
	public static Integer checkNullInteger(String integer) {
		if (integer != null && !integer.equalsIgnoreCase("null")) {
			return Integer.valueOf(integer);	
		}
		return null;
	}
	public static String checkNull(String string) {
		if (string != null) {
			return String.valueOf(string);	
		}
		return null;
	}
	

    public static Long checkNullandEmpty(Long londg) {
    if (londg != null) {
    return londg;
    }
    return null;
    }

    public static Double checkNullandEmpty(Double londg) {
    if (londg != null) {
    return londg;
    }
    return null;
    }

	
	public static String saveFile(List<String[]> list, String azureconnectionstring, String[] strings, String name, String date, Long reportId,
			InputStream is2) throws IOException {
		InputStream is = null;
		 if (name != null) {
	        	name =Base64.getEncoder().encodeToString(name.getBytes());
			}
		 if (date != null) {
			 date =Base64.getEncoder().encodeToString(date.getBytes());
			}
		 BlobContainerClient containerClient = null;
		 String connectStr = azureconnectionstring;
		 BlobServiceClient blobServiceClient = new BlobServiceClientBuilder().connectionString(connectStr).buildClient();
		 containerClient = blobServiceClient.getBlobContainerClient("reports");
		 BlobClient blobClient;
		 int length;	
		 if (reportId != null && reportId == 6) {
			 is = is2;
			 length = is2.available();	
			 blobClient = containerClient.getBlobClient(name+"\\"+date+"\\"+Utils.getCurrentDateTime()+".xlsx");
		} else {
			  ByteArrayOutputStream stream = new ByteArrayOutputStream();
		        OutputStreamWriter streamWriter = new OutputStreamWriter(stream);
		        CSVWriter writer = new CSVWriter(streamWriter);
		    	String[] headerRecord = {"", "", strings[1], ""};
		    	writer.writeNext(headerRecord,true);
		    	writer.writeAll(list);
				 streamWriter.flush();
				 byte[] ee = stream.toByteArray();
				 is = new ByteArrayInputStream(stream.toByteArray());
				 length = is.available();	
				 blobClient = containerClient.getBlobClient(name+"\\"+date+"\\"+Utils.getCurrentDateTime()+".csv");
		}
				
	    	blobClient.upload(is, length);	    	
	    	String path = blobClient.getBlobUrl();
		System.out.println(path);
		return path;
	}


	@SuppressWarnings({ "unchecked", "resource" })
	public static InputStream getInputStream(List<?> respList) throws IOException {
		Workbook workbook = new XSSFWorkbook();
		ByteArrayOutputStream out = new ByteArrayOutputStream();
			String SHEET = null;
			
			int n=0;
		      // Header
		      for (Object iterable_element : respList) {
		    	  int row=0;
					List<String[]> list = (List<String[]>) iterable_element;
					n++;
					if (n == 1) {
						SHEET = CommonConstants.PARAMEDICWISE_TAT_REPORT;
					} else if (n == 2) {
						SHEET = CommonConstants.HOSPITALWISE_TAT_REPORT;
					} else {
						SHEET = CommonConstants.OVERALL_TAT_REPORT;
					}
					Sheet sheet = workbook.createSheet(SHEET);
					for (String[] array : list) {						
						Row headerRow = sheet.createRow(row);
						row++;
							for (int col = 0; col < array.length; col++) {
								Cell cell = headerRow.createCell(col);
								cell.setCellValue(array[col]);
							}
					}
					
		      }
		      workbook.write(out);
		      return new ByteArrayInputStream(out.toByteArray());
	}

	
	
	public static String saveVideo(String videobase64, String videofilename,
			String azureconnectionstring) 
					throws URISyntaxException, IOException, DocumentException {
		  System.out.println("start : "+java.time.LocalDateTime.now());
		 String base64String = videobase64;
		 InputStream is = null;
		  byte[] data = null;
		  BlobContainerClient containerClient = null;
		 String connectStr = azureconnectionstring;
	    	BlobServiceClient blobServiceClient = new BlobServiceClientBuilder().connectionString(connectStr).buildClient();
	        String extension = null;
	        
	         containerClient = blobServiceClient.getBlobContainerClient("videos");
	                
	        System.out.println("start dy : "+java.time.LocalDateTime.now());
	     
	        byte[] decoded = Base64.getDecoder().decode(base64String);
	        String name =Base64.getEncoder().encodeToString(videofilename.getBytes());
	        System.out.println("end dy : "+java.time.LocalDateTime.now());
	     
	         is = new ByteArrayInputStream(decoded);

	        int length = is.available(); 
	        BlobClient blobClient;
	         blobClient = containerClient.getBlobClient(name+".mp4");
	        System.out.println("upload start : "+java.time.LocalDateTime.now());
//	    	blobClient.upload(is, length);	   
	    	blobClient.upload(is, length, true);
	    	System.out.println("upload end : "+java.time.LocalDateTime.now());
	    	String path = blobClient.getBlobUrl(); 
	    	System.out.println("\nUploading to Blob storage as blob:\n\t" + path);			
		return path;
	}
    
	
	public static String saveImage(String image, String imagefilename, String imagesavepath,
			String azureconnectionstring, String string, String id,String date,String name, String flag, String html) 
					throws URISyntaxException, IOException, DocumentException {
		  System.out.println("start : "+java.time.LocalDateTime.now());
		 String base64String = image;
		 InputStream is = null;
		  byte[] data = null;
		  BlobContainerClient containerClient = null;
		 String connectStr = azureconnectionstring;
	    	BlobServiceClient blobServiceClient = new BlobServiceClientBuilder().connectionString(connectStr).buildClient();
	        String extension = null;
	        if (flag.equalsIgnoreCase("static")) {
	        	String[] strings = base64String.split(",");
		        switch (strings[0]) {//check image's extension
		            case "data:image/jpeg;base64":
		                extension = "jpeg";
		                break;
		            case "data:image/png;base64":
		                extension = "png";
		                break;
		            default://should write cases for more images types
		                extension = "jpg";
		                break;
		        }
		      
		        if (imagefilename.contains("pdf")) {
					data = Base64.getDecoder().decode(strings[0]);
					containerClient = blobServiceClient.getBlobContainerClient("pdf");
					extension = "pdf";
				} else {
					data = DatatypeConverter.parseBase64Binary(strings[1]);
					containerClient = blobServiceClient.getBlobContainerClient("images");
					//extension = "png";
				}
			} else if (flag.equalsIgnoreCase("dynamic")){
				 containerClient = blobServiceClient.getBlobContainerClient("pdf");
	        	 extension = "pdf";
			}
	                
	        System.out.println("start dy : "+java.time.LocalDateTime.now());
	        if (flag.equalsIgnoreCase("dynamic")) {
	        	
	    	    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	    	    Document document = new Document(PageSize.LETTER, 72f, 72f, 108f, 90f);
	    	    PdfWriter writer = PdfWriter.getInstance(document,
	    	    		outputStream);
	    	    
//	    	    HtmlPipelineContext htmlContext = new HtmlPipelineContext(null);
//	    	    htmlContext.setTagFactory(Tags.getHtmlTagProcessorFactory());
//	    	    CSSResolver cssResolver = XMLWorkerHelper.getInstance().getDefaultCssResolver(true);
//	    	    Pipeline pipeline = new CssResolverPipeline(cssResolver, new HtmlPipeline(htmlContext, new PdfWriterPipeline(document, writer)));
//
//	    	    XMLWorker worker = new XMLWorker(pipeline, true);
//	    	    XMLParser xmlParse = new XMLParser(true, worker);
	    	    document.open();
	    	    XMLWorkerHelper.getInstance().parseXHtml(writer, document,new ByteArrayInputStream(html.getBytes("UTF-8")));
//	    	    xmlParse.parse(new ByteArrayInputStream(html.getBytes("UTF-8")));
	    	    
	    	    document.close();  
	    	    is = new ByteArrayInputStream(outputStream.toByteArray());
//	    	    try (OutputStream os = ((WritableResource) blobFile).getOutputStream()) {
//		            os.write(outputStream.toByteArray());
//		        }
			} else if(flag.equalsIgnoreCase("static")) {				
				is = new ByteArrayInputStream(data);    	
//				try (OutputStream os = ((WritableResource) blobFile).getOutputStream()) {
//		            os.write(data);
//		        }
			}
	        int length = is.available();	
	        if (id != null) {
	        	id =Base64.getEncoder().encodeToString(id.getBytes());
			}
	        if (name != null) {
	        	name =Base64.getEncoder().encodeToString(name.getBytes());
			}
	        System.out.println("end dy : "+java.time.LocalDateTime.now());
//	        for (BlobItem blobItem : containerClient.listBlobs()) {
////	            System.out.println("\t" + blobItem.getName());
//	            if (string.equalsIgnoreCase("order") || string.equalsIgnoreCase("vendor")) {
//	            	  if (blobItem.getName().equalsIgnoreCase(date+"/"+string+"/"+id+"/"+date+id+name+"."+extension)) {
//	  	            	containerClient.getBlobClient(date+"/"+string+"/"+id+"/"+date+id+name+"."+extension).delete();
//	  		            break;
//	  					}	        	
//				} else {
//					 if (blobItem.getName().equalsIgnoreCase(date+"/"+date+name+"."+extension)) {
//		  	            	containerClient.getBlobClient(date+"/"+date+name+"."+extension).delete();
//		  		            break;
//  					 }
//				}
//	        }
	        
	        BlobClient blobClient;
	        if (string.equalsIgnoreCase("order") || string.equalsIgnoreCase("vendor") ||  string.equalsIgnoreCase("invoice")) {
	        	blobClient = containerClient.getBlobClient(date+"\\"+string+"\\"+id+"\\"+date+id+name+"."+extension);	        	
			} else {
				blobClient = containerClient.getBlobClient(date+"\\"+date+name+"."+extension);
			}
	        System.out.println("upload start : "+java.time.LocalDateTime.now());
//	    	blobClient.upload(is, length);	   
	    	blobClient.upload(is, length, true);
	    	System.out.println("upload end : "+java.time.LocalDateTime.now());
	    	String path = blobClient.getBlobUrl(); 
	    	System.out.println("\nUploading to Blob storage as blob:\n\t" + path);			
		return path;
	}

	public static  java.sql.Date utilDateToJavaSqlDate(Date date) {
		 java.sql.Date sqlStartDate = new java.sql.Date(date.getTime());
		return sqlStartDate;
	
	}

	public static void sendMail(ConfigurationResponseModel configurationResponseModel, String imagePath, String fileName) {

        try {
 
        	
        	  String to = configurationResponseModel.getToaddress();
              String[] toArray = to.split(",");
              String from = configurationResponseModel.getUsername();
              String password = configurationResponseModel.getPassword();
              String host = configurationResponseModel.getHost();//or IP address
              String flag = "gmail";//or IP address
              Session session;
              if (flag.equalsIgnoreCase("gmail")) {
                  Properties props = new Properties();  
                  props.put("mail.smtp.host", host);    
                  props.put("mail.smtp.socketFactory.port", configurationResponseModel.getPort());    
                  props.put("mail.smtp.socketFactory.class",    
                            "javax.net.ssl.SSLSocketFactory");    
                  props.put("mail.smtp.auth", "true");    
                  props.put("mail.smtp.port", configurationResponseModel.getPort());  
                  
                  //get Session   
                  session = Session.getDefaultInstance(props,    
                   new javax.mail.Authenticator() {    
                   protected PasswordAuthentication getPasswordAuthentication() {    
                   return new PasswordAuthentication(from, password);  
                   }    
                  });
//                   session = Session.getInstance(props, new GMailAuthenticator(from, password));
                  
      		} else {
      		       Properties properties =  new Properties();		        
      		        properties.put("mail.smtp.host", host);
      	            properties.put("mail.smtp.port", configurationResponseModel.getPort());
      	            properties.put("mail.smtp.starttls.enable", "true");
      	            properties.put("mail.smtp.auth", "true");

      	            // Authenticating
      	            Authenticator auth = new Authenticator() {
      	                protected PasswordAuthentication getPasswordAuthentication() {
      	                    return new PasswordAuthentication(from, password);
      	                }
      	            };
      	            // creating session
      	            session = Session.getInstance(properties, auth);
      		}

              if(imagePath != null) {
            	  URL imageUrl = new URL(imagePath);
		  	        URLConnection ucon = imageUrl.openConnection();
		  	        InputStream is = ucon.getInputStream();
		  	      ByteArrayOutputStream baos = new ByteArrayOutputStream();
		  	    final DataSource attachment = new ByteArrayDataSource(is, "application/octet-stream");
         //compose the message  
              MimeMessage message = new MimeMessage(session);
//              MimeMessageHelper helper = new MimeMessageHelper(message, "utf-8");
              MimeMessageHelper helper = new MimeMessageHelper(message, true, CharEncoding.UTF_8);
              helper.setFrom(new InternetAddress(from));
              helper.setTo(toArray);
              helper.setSubject(configurationResponseModel.getSubject());
              helper.setText(configurationResponseModel.getTemplate(),true);
           
             	helper.addAttachment(fileName, attachment);
			  
               // Send message  
               Transport.send(message);  
               System.out.println("Mail sent successfully....");
              }
              
              else {
            	  MimeMessage message = new MimeMessage(session);
//                MimeMessageHelper helper = new MimeMessageHelper(message, "utf-8");
                MimeMessageHelper helper = new MimeMessageHelper(message, true, CharEncoding.UTF_8);
                helper.setFrom(new InternetAddress(from));
                helper.setTo(toArray);
                helper.setSubject(configurationResponseModel.getSubject());
                helper.setText(configurationResponseModel.getTemplate(),true);
             
                 // Send message  
                 Transport.send(message);  
                 System.out.println("Mail sent successfully...."); 
              }
        } catch (Exception e) {
            e.printStackTrace();
        }
    
		
	}

	public static String saveAudio(String audiobase64, String audiofilename,
			String azureconnectionstring) 
					throws URISyntaxException, IOException, DocumentException {
		  System.out.println("start : "+java.time.LocalDateTime.now());
		 String base64String = audiobase64;
		 InputStream is = null;
		  byte[] data = null;
		  BlobContainerClient containerClient = null;
		 String connectStr = azureconnectionstring;
	    	BlobServiceClient blobServiceClient = new BlobServiceClientBuilder().connectionString(connectStr).buildClient();
	        String extension = null;
	        
	         containerClient = blobServiceClient.getBlobContainerClient("videos");
	                
	        System.out.println("start dy : "+java.time.LocalDateTime.now());
	     
	        byte[] decoded = Base64.getDecoder().decode(base64String);
	        String name =Base64.getEncoder().encodeToString(audiofilename.getBytes());
	        System.out.println("end dy : "+java.time.LocalDateTime.now());
	     
	         is = new ByteArrayInputStream(decoded);

	        int length = is.available(); 
	        BlobClient blobClient;
	         blobClient = containerClient.getBlobClient(name+".wav");
	        System.out.println("upload start : "+java.time.LocalDateTime.now());
//	    	blobClient.upload(is, length);	   
	    	blobClient.upload(is, length, true);
	    	System.out.println("upload end : "+java.time.LocalDateTime.now());
	    	String path = blobClient.getBlobUrl(); 
	    	System.out.println("\nUploading to Blob storage as blob:\n\t" + path);			
		return path;
	}
	
	
}
