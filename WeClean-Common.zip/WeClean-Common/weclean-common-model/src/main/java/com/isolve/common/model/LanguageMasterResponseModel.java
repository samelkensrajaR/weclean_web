package com.isolve.common.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class LanguageMasterResponseModel implements Serializable{/**
	 * 
	 */
	private static final long serialVersionUID = 881310299499260907L;
	
	@Id
	private Integer LC_LAN_ID;
	private String LC_LANGUAGE_NAME;
	private String LC_LANGUAGE_DISCRIPTION;
	

}
