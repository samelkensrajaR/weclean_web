package com.isolve.web.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class RosterDetUserResponseModel 
{
	@Id
	private Long roster_id;
	private Long user_id;
	private String rider;
	private String roster;
	private Date start_date;
	private Date end_date;
	private Integer status;
	private Long rider_id;
	private Long roster_typeid;
	private String remarks;
	private String day;
}
