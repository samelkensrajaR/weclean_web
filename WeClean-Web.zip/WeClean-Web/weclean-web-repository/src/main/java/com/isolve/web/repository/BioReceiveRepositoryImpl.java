package com.isolve.web.repository;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.UpdateBioReceiveRequestModel;
import com.isolve.web.model.UpdateBioReceiveUserModel;
import com.isolve.web.utils.Utils;
import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;

@Transactional
@Repository
public class BioReceiveRepositoryImpl implements IBioReceiveRepository
{
	

	Logger log = LoggerFactory.getLogger(BioReceiveRepositoryImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public ResponseModel updateBioReceive(UpdateBioReceiveRequestModel updateBioReceiveRequestModel) throws SQLException {
		ResponseModel responseModel = new ResponseModel();
		Connection connection = jdbcTemplate.getDataSource().getConnection();
		try {
			SQLServerDataTable utt_bioorderid = new SQLServerDataTable();
			utt_bioorderid.addColumnMetadata("lc_or_orderid", java.sql.Types.BIGINT);
			utt_bioorderid.addColumnMetadata("lc_or_crmid", java.sql.Types.VARCHAR);
			for(UpdateBioReceiveUserModel userModel:updateBioReceiveRequestModel.getUttbioorderid())
			{
				utt_bioorderid.addRow(userModel.getOrderid(),userModel.getCrm_id());
			}
			CallableStatement csstmt = connection.prepareCall("{call USP_UPDATE_BIO_RECEIVE_DETAILS(?, ?, ?, ?)}");
			if (csstmt.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
				// The CallableStatement object can unwrap to
				// SQLServerCallableStatement.
				SQLServerCallableStatement cs = csstmt.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
				cs.setResponseBuffering("adaptive");
				cs.setStructured(1,"dbo.UTT_BIO_RECEIVED",utt_bioorderid);
				cs.setLong(2, updateBioReceiveRequestModel.getUserid());
				cs.setString(3, Utils.checkNullandEmpty(updateBioReceiveRequestModel.getLattitude()));
				cs.setString(4, Utils.checkNullandEmpty(updateBioReceiveRequestModel.getLongitude()));
				boolean resultSetReturned = cs.execute();
				if (resultSetReturned) {
					try (ResultSet rs = cs.getResultSet()) {
						rs.next();
						responseModel.setStatusCode(rs.getInt(1));
						responseModel.setMessage(rs.getString(2));
					}
					System.out.println("res"+responseModel);
				}
			}
		} finally {
			connection.close();
		}
		return responseModel;
	}

}

