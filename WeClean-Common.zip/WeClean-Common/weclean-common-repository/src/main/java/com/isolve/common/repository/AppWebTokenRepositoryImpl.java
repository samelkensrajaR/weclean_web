package com.isolve.common.repository;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.isolve.common.model.AppWebTokenRequestModel;
import com.isolve.common.model.AppWebTokenResponseModel;
import com.isolve.common.model.GenerateOTPResponseModel;
import com.isolve.common.model.GenerateOtpRequestModel;
import com.isolve.common.model.ResetPinModel;
import com.isolve.common.model.ResponseModel;
import com.isolve.common.model.SignUpDetailsModel;
import com.isolve.common.model.VerifyOTPModel;
import com.isolve.common.utils.CommonConstants;
import com.isolve.common.utils.MyObject;
import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;

@Transactional
@Repository
public class AppWebTokenRepositoryImpl implements IAppWebTokenRepository {

	@Autowired
	private EntityManager entityManager;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	/**
	 * @author
	 * @Name signUpDetails - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: signUpDetails method using to insert sign up web page.
	 */
	@Override
	public SignUpDetailsModel signUpDetails(SignUpDetailsModel signUpDetailsModel) {
		SignUpDetailsModel detailsModel = new SignUpDetailsModel();

		try {
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_SIGNUP_DETAILS);
			// Declare the parameters in the same order
			query.registerStoredProcedureParameter(CommonConstants.USER_TITLE_ID, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_FIRST_NAME, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_LAST_NAME, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_PHONENO, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_EMAILID, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_DOB, Date.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_DOJ, Date.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_GEN_ID, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_ADDRESS_LINE1, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_ADDRESS_LINE2, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_STATUS, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_PHOTO, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.BRANCH_ID, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.REGION_ID, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_NAME, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_IMEI_NUMBER, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_UDID_NUMBER, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_PHONE_CODE, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_TYPE_ID, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_DESIGNATION_ID, Integer.class,
					ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_ROLEID, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_PASSWORD, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.USER_PIN, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.QUALIFICATION, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.EXP_IN_YEARS, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.PINCODE, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.CITYID, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.STATE_ID, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.SIGNUP_USER_ID, Long.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.LOGINID, Long.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.ROLEIDD, Long.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.EMPLOYEEID, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.User_DOA, Date.class, ParameterMode.IN);

			query.setParameter(CommonConstants.USER_TITLE_ID, signUpDetailsModel.getUser_title_id());
			query.setParameter(CommonConstants.USER_FIRST_NAME, signUpDetailsModel.getUser_first_name());
			query.setParameter(CommonConstants.USER_LAST_NAME, signUpDetailsModel.getUser_last_name());
			query.setParameter(CommonConstants.USER_PHONENO, signUpDetailsModel.getUser_phoneno());
			query.setParameter(CommonConstants.USER_EMAILID, signUpDetailsModel.getUser_emailid());
			query.setParameter(CommonConstants.USER_DOB, signUpDetailsModel.getUser_dob());
			query.setParameter(CommonConstants.USER_DOJ, signUpDetailsModel.getUser_doj());
			query.setParameter(CommonConstants.USER_GEN_ID, signUpDetailsModel.getUser_gen_id());
			query.setParameter(CommonConstants.USER_ADDRESS_LINE1, signUpDetailsModel.getUser_address_line1());
			query.setParameter(CommonConstants.USER_ADDRESS_LINE2, signUpDetailsModel.getUser_address_line2());
			query.setParameter(CommonConstants.USER_STATUS, signUpDetailsModel.getUser_status());
			query.setParameter(CommonConstants.USER_PHOTO, signUpDetailsModel.getUser_photo());
			query.setParameter(CommonConstants.BRANCH_ID, signUpDetailsModel.getBranch_id());
			query.setParameter(CommonConstants.REGION_ID, signUpDetailsModel.getRegion_id());
			query.setParameter(CommonConstants.USER_NAME, signUpDetailsModel.getUser_name());
			query.setParameter(CommonConstants.USER_IMEI_NUMBER, signUpDetailsModel.getUser_imei_number());
			query.setParameter(CommonConstants.USER_UDID_NUMBER, signUpDetailsModel.getUser_udid_number());
			query.setParameter(CommonConstants.USER_PHONE_CODE, signUpDetailsModel.getUser_phone_code());
			query.setParameter(CommonConstants.USER_TYPE_ID, signUpDetailsModel.getUser_type_id());
			query.setParameter(CommonConstants.USER_DESIGNATION_ID, signUpDetailsModel.getUser_designation_id());
			query.setParameter(CommonConstants.USER_ROLEID, signUpDetailsModel.getUser_roleid());
			query.setParameter(CommonConstants.USER_PASSWORD, signUpDetailsModel.getUser_password());
			query.setParameter(CommonConstants.USER_PIN, signUpDetailsModel.getUser_pin());
			query.setParameter(CommonConstants.QUALIFICATION, signUpDetailsModel.getQualification());
			query.setParameter(CommonConstants.EXP_IN_YEARS, signUpDetailsModel.getExp_in_years());
			query.setParameter(CommonConstants.PINCODE, signUpDetailsModel.getPincode());
			query.setParameter(CommonConstants.CITYID, signUpDetailsModel.getCityid());
			query.setParameter(CommonConstants.STATE_ID, signUpDetailsModel.getStateid());
			query.setParameter(CommonConstants.SIGNUP_USER_ID, signUpDetailsModel.getUserid());
			query.setParameter(CommonConstants.LOGINID, signUpDetailsModel.getLoginid());
			query.setParameter(CommonConstants.ROLEIDD, signUpDetailsModel.getRoleid());
			query.setParameter(CommonConstants.EMPLOYEEID, signUpDetailsModel.getEmployeeid());
			query.setParameter(CommonConstants.User_DOA, signUpDetailsModel.getUser_doa());

			Object[] fromStoredProcedure = (Object[]) query.getSingleResult();
			detailsModel.setStatus((Integer) fromStoredProcedure[0]);
			detailsModel.setMessage((String) fromStoredProcedure[1]);
		} finally {
			entityManager.close();
		}
		return detailsModel;
	}

	/**
	 * @author
	 * @Name createAuthenticationToken - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: createAuthenticationToken method using to validate the auth Token.
	 */
	@Override
	public AppWebTokenResponseModel checkUsernameandPassword(AppWebTokenRequestModel appWebTokenRequestModel)
			throws SQLException {
		AppWebTokenResponseModel responseModel = new AppWebTokenResponseModel();
		// try {
		// //"login" this is the name of your procedure
		// StoredProcedureQuery query =
		// entityManager.createStoredProcedureQuery(CommonConstants.USP_TOKEN_GENERATION);
		// //Declare the parameters in the same order
		// query.registerStoredProcedureParameter(CommonConstants.LOGIN_USER,
		// String.class, ParameterMode.IN);
		// query.registerStoredProcedureParameter(CommonConstants.PASSWORD,
		// String.class, ParameterMode.IN);
		// query.setParameter(CommonConstants.LOGIN_USER,
		// appWebTokenRequestModel.getLoginUser());
		// query.setParameter(CommonConstants.PASSWORD,
		// appWebTokenRequestModel.getPassword());
		// Object[] fromStoredProcedure = (Object[]) query.getSingleResult();
		// log.info(CommonConstants.USP_TOKEN_GENERATION +" : "+fromStoredProcedure);
		// responseModel.setStatus(Integer.valueOf((String)fromStoredProcedure[0]));
		// responseModel.setMessage((String)fromStoredProcedure[1]);
		// if (responseModel.getStatus() == 200) {
		// responseModel.setKey((String)fromStoredProcedure[2]);
		// }
		//
		Connection connection = jdbcTemplate.getDataSource().getConnection();
		try {
			CallableStatement csstmt = connection
					.prepareCall("{call " + CommonConstants.USP_TOKEN_GENERATION + "(?, ?)}");
			if (csstmt.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {

				SQLServerCallableStatement cs = csstmt
						.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
				cs.setResponseBuffering("adaptive");
				cs.setString(1, appWebTokenRequestModel.getLoginUser());
				cs.setString(2, appWebTokenRequestModel.getPassword());

				boolean isResultSet = cs.execute();
				while (true) {
					if (isResultSet) {
						try (ResultSet rs = cs.getResultSet()) {
							rs.next();
							responseModel.setStatus(Integer.parseInt(rs.getString(1)));
							responseModel.setMessage(rs.getString(2));
							if (responseModel.getStatus() == 200) {
								responseModel.setKey(rs.getString(3));
							}

							rs.close();
						}
					} else {
						int updateCount = cs.getUpdateCount();
						if (updateCount == -1) {
							break;
						}
					}
					isResultSet = cs.getMoreResults();
				}
			}

		} finally {
			connection.close();
		}

		// } finally {
		// entityManager.close();
		// }
		return responseModel;

	}

	/**
	 * @author
	 * @Name appWebLogin - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: appWebLogin method using to login Web.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel appWebLogin(AppWebTokenRequestModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_WECLEAN_APP_WEB_LOGIN + "(?,?,?,?,?,?,?,?,?,?)}");
				callableStatement.setString(1, reqModel.getLoginUser());
				callableStatement.setString(2, reqModel.getPassword());
				callableStatement.setString(3, reqModel.getLoginType());
				callableStatement.setString(4, reqModel.getLoginMode());
				callableStatement.setString(5, reqModel.getLangId());
				callableStatement.setString(6, reqModel.getWcUsdLatitude());
				callableStatement.setString(7, reqModel.getWcUsdLongitude());
				callableStatement.setString(8, reqModel.getImei());
				callableStatement.setString(9, reqModel.getFirebaseId());
				callableStatement.setString(10, String.valueOf(reqModel.getAndroidIOSWeb()));
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Object obj = null;
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				for (int i = 0; i < l_lstResult.size(); i++) {
					obj = new Object();
					LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
					obj = l_hmColmnData;
				}
			}
			if (obj != null) {
				MyObject object = new MyObject(obj);
				responseModel.setResponseObject(object);
			}
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();

			}
		}
		return responseModel;

	}

	/**
	 * @author
	 * @Name generateOTP - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: generateOTP method using to generate OTP for mobile.
	 */
	@Override
	public GenerateOTPResponseModel generateOTP(GenerateOtpRequestModel otpRequestModel) {
		GenerateOTPResponseModel responseModel = new GenerateOTPResponseModel();

		try {
			// "login" this is the name of your procedure
			StoredProcedureQuery query = entityManager
					.createStoredProcedureQuery(CommonConstants.USP_USER_GENERATE_OTP);
			// Declare the parameters in the same order
			query.registerStoredProcedureParameter(CommonConstants.MOBILE_EMAIL, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.LANG_ID, Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.SMS_VALIDTIMELIMIT, String.class, ParameterMode.IN);

			query.setParameter(CommonConstants.MOBILE_EMAIL, otpRequestModel.getMobile_email());
			query.setParameter(CommonConstants.LANG_ID, otpRequestModel.getLang_id());
			query.setParameter(CommonConstants.SMS_VALIDTIMELIMIT, otpRequestModel.getSms_validtimelimit());

			Object[] fromStoredProcedure = (Object[]) query.getSingleResult();
			responseModel.setStatusCode(String.valueOf((Integer) fromStoredProcedure[0]));
			responseModel.setMessage((String) fromStoredProcedure[1]);
			if (responseModel.getStatusCode().equalsIgnoreCase("200")) {
				responseModel.setOTPNo((String) fromStoredProcedure[2]);
				responseModel.setMobileNumber((String) fromStoredProcedure[3]);
				responseModel.setMINS((String) fromStoredProcedure[4]);
				responseModel.setEmail((String) fromStoredProcedure[5]);
			}
		} finally {
			entityManager.close();
			;
		}

		return responseModel;
	}

	/**
	 * @author
	 * @Name verifyOTP - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: verifyOTP method using to verify generated OTP.
	 */
	@Override
	public ResponseModel verifyOTP(VerifyOTPModel verifyOTPModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			// "login" this is the name of your procedure
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery(CommonConstants.USP_VERIFY_OTP);
			// Declare the parameters in the same order
			query.registerStoredProcedureParameter(CommonConstants.USERID, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.LANG_ID, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.OTP, String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter(CommonConstants.OTP_PURPOSE, String.class, ParameterMode.IN);

			query.setParameter(CommonConstants.USERID, verifyOTPModel.getUser_id());
			query.setParameter(CommonConstants.LANG_ID, verifyOTPModel.getLang_id());
			query.setParameter(CommonConstants.OTP, verifyOTPModel.getOtp());
			query.setParameter(CommonConstants.OTP_PURPOSE, verifyOTPModel.getOtp_purpose());

			Object[] fromStoredProcedure = (Object[]) query.getSingleResult();
			responseModel.setStatusCode((Integer) fromStoredProcedure[0]);
			responseModel.setMessage((String) fromStoredProcedure[1]);
		} finally {
			entityManager.close();
		}

		return responseModel;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseModel resetPin(ResetPinModel resetPinModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List<Object> response = new ArrayList<Object>();
			// "login" this is the name of your procedure
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery("USP_RESET_PIN");
			// Declare the parameters in the same order
			query.registerStoredProcedureParameter("USER_ID", String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter("LANG_ID", String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter("PASSWORD", String.class, ParameterMode.IN);

			query.setParameter("USER_ID", resetPinModel.getUser_id());
			query.setParameter("LANG_ID", resetPinModel.getLang_id());
			query.setParameter("PASSWORD", resetPinModel.getPassword());
			query.execute();
			Object[] fromStoredProcedure = (Object[]) query.getSingleResult();
			responseModel.setStatusCode((Integer) fromStoredProcedure[0]);
			responseModel.setMessage((String) fromStoredProcedure[1]);
		} finally {
			entityManager.close();
		}

		return responseModel;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel logout(AppWebTokenRequestModel reqModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.NVARCHAR));

			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call " + CommonConstants.USP_LOGOUT + "(?,?,?)}");
				if (reqModel.getLoginUser() != null) {
					callableStatement.setLong(1, Long.parseLong(reqModel.getLoginUser()));
				} else {
					callableStatement.setString(1, null);
				}
				callableStatement.setInt(2, Integer.parseInt(reqModel.getLangId()));
				callableStatement.setString(3, reqModel.getFirebaseId());
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			Object obj = null;
			int count = 0;
			for (String key : set) {
				count++;
				if (count == 3) {
					List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
							.get(key);
					for (int i = 0; i < l_lstResult.size(); i++) {
						obj = new Object();
						LinkedCaseInsensitiveMap<String> l_hmColmnData = l_lstResult.get(i);
						obj = l_hmColmnData;
					}
				}
			}
			if (obj != null) {
				MyObject object = new MyObject(obj);
				responseModel.setResponseObject(object);
			}
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();

			}
		}
		return responseModel;
	}

}
