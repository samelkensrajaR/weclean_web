package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConfigurationResponseModel implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8603652774789867650L;
	private String username;
	private String password;
    private String host;
    private String fromaddress;
    private String toaddress;
    private String template;
    private String subject;
    private String port;

}
