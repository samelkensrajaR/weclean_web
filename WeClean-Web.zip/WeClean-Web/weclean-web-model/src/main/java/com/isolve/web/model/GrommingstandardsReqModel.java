package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GrommingstandardsReqModel implements Serializable{/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer flag;
	private String title;
	private String userid;
	private String gsflag;
	private String discription;
	private Integer gsid;
	private Long order;
	private String duration;
	private Integer videoid;
	private String videourl;
	private String videoblob;
	private String imagepath;
	private String image;
	private Integer start;
	private Integer end;
	private String status;
	private String search;
	private String activeflag;


}
