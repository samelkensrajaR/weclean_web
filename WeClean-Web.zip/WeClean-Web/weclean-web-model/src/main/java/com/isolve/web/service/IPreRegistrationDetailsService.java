package com.isolve.web.service;

import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;

public interface IPreRegistrationDetailsService {

	

	ResponseModel getPreRegistrationDetails(RequestModel requestModel);

	ResponseModel submitPreRegistration(RequestModel requestModel);

	ResponseModel preRegistrationProcess(RequestModel requestModel);
}
