package com.isolve.web.repository;

import java.util.List;

import com.isolve.web.model.BioBankReceiveSampleModel;
import com.isolve.web.model.BioBankResponseModel;

public interface IBioBankRepository 
{
	public List<BioBankResponseModel> getReceiveBioBankSample(BioBankReceiveSampleModel bankReceiveModel);	

}
