package com.isolve.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.service.ILabTransferService;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@RestController
@CrossOrigin(value = "*",maxAge = 3600)
public class LabTransferController 
{
	@Autowired
	private ILabTransferService iLabTransferService;


	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GETLABTRANSFER, method = RequestMethod.POST)
	public ResponseEntity<?> getLabTransfer(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iLabTransferService.getLabTransfer(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}


	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.UPDATE_LABTRANSFER_INITIATE, method = RequestMethod.POST)
	public ResponseEntity<?> updateLabTransferInitiative(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iLabTransferService.updateLabTransferInitiative(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GETORDERTYPE, method = RequestMethod.GET)
	public ResponseEntity<?> getSampleType()
	{		
		ResponseModel responseModel = new ResponseModel();
		responseModel = iLabTransferService.getSampleType();
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GETLABMASTER, method = RequestMethod.POST)
	public ResponseEntity<?> getLabMaster(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iLabTransferService.getLabMaster(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GETCOURIERMASTER, method = RequestMethod.POST)
	public ResponseEntity<?> getCourierMaster(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iLabTransferService.getCourierMaster(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@RequestMapping(value = "/"+CommonConstants.GETTRANSFERTYPE, method = RequestMethod.GET)
	public ResponseEntity<?> getTransferType() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iLabTransferService.getTransferType();	
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.UPDATE_LAB_TRAN_RECEIVE, method = RequestMethod.POST)
	public ResponseEntity<?> updateLabTranReceive(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iLabTransferService.updateLabTranReceive(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
}
