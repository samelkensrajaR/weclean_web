package com.isolve.web.service;

import com.isolve.web.model.ResponseModel;

public interface IValidateTokenService {

	ResponseModel validateToken(String jwtToken);

}
