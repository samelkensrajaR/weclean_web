package com.isolve.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.service.IPreRegistrationDetailsService;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@RestController
@CrossOrigin(value = "*",maxAge = 3600)
@RequestMapping(value = "/"+CommonConstants.PRE_REGISTRATION)
public class PreRegistrationDetailsController {
	
	@Autowired
	private IPreRegistrationDetailsService iPreRegistrationProcessService;
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_PRE_REGISTRATION_DETAILS, method = RequestMethod.POST)
	public ResponseEntity<?> getPreRegistrationDetails(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iPreRegistrationProcessService.getPreRegistrationDetails(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.SUBMIT_PRE_REGISTRATION, method = RequestMethod.POST)
	public ResponseEntity<?> submitPreRegistration(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iPreRegistrationProcessService.submitPreRegistration(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.PRE_REGISTRATION_PROCESS, method = RequestMethod.POST)
	public ResponseEntity<?> preRegistrationProcess(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iPreRegistrationProcessService.preRegistrationProcess(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
}


