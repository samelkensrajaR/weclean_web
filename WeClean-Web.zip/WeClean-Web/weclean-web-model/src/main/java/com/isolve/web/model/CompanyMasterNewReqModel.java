package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompanyMasterNewReqModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer flag;
	private String companyname;
	private String companydiscription;
	private Long from;
	private Long to;
	private String emailid;
	private String contactnumber;
	private String alternatenumber;
	private String gst_no;
	private String pan_no;
	private String address1;
	private String address2;
	private String pincode;
	private Long countryid;
	private Long stateid;
	private Long cityid;
	private Long wmid;
	private Long userid;
	private String state;
	private String city;
	private String country;
	
}
