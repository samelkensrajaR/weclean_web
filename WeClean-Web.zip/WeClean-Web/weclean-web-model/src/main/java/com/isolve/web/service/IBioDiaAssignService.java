package com.isolve.web.service;

import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;

public interface IBioDiaAssignService 
{
	public ResponseModel updateBioDiaAssign(RequestModel requestModel);

	ResponseModel getAssignParamedicUpdate(RequestModel requestModel);

	ResponseModel getUserPickupSchedule(RequestModel requestModel);

	ResponseModel getParamedicUserAvailability(RequestModel requestModel);

	ResponseModel cancelParamedic(RequestModel requestModel);

	ResponseModel getCancelReason();

	ResponseModel getParamedicUserAvailabilityDay(RequestModel requestModel);

	public ResponseModel getTrackFullUrl(String shortenURL);
}
