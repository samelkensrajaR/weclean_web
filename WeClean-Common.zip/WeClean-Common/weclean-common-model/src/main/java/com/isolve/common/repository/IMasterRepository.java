package com.isolve.common.repository;

import java.util.List;

import com.isolve.common.model.ApiReportDetailsReqModel;
import com.isolve.common.model.CenterRequestModel;
import com.isolve.common.model.CenterResponseModel;
import com.isolve.common.model.ClientDetailsResponse;
import com.isolve.common.model.DoctorListRequestModel;
import com.isolve.common.model.DoctorListResponseModel;
import com.isolve.common.model.LanguageMasterRequestModel;
import com.isolve.common.model.LanguageMasterResponseModel;
import com.isolve.common.model.ParamedicDetailsResponse;
import com.isolve.common.model.ResponseModel;
import com.isolve.common.model.RoleReqModel;
import com.isolve.common.model.StateMasterReqModel;
import com.isolve.common.model.TaskTypeReqModel;
import com.isolve.common.model.UserTypeReqModel;

public interface IMasterRepository {

	public ResponseModel getStateMaster(StateMasterReqModel stateMasterReqModel);

	public ResponseModel getCityMaster(StateMasterReqModel stateMasterReqModel);

	ResponseModel getAddressType();

	ResponseModel getPickupType();

	ResponseModel getAccountType(TaskTypeReqModel typeReqModel);

	public ResponseModel getTaskType(TaskTypeReqModel typeReqModel);

	public ResponseModel getGenderDetails();

	public ResponseModel getTitleMaster();

	List<LanguageMasterResponseModel> getLanguageMaster(LanguageMasterRequestModel languageMasterResponseModel);

	public ResponseModel getUserType(UserTypeReqModel userTypeReqModel);

	public ResponseModel getRole(RoleReqModel reoleReqmodel);
}
