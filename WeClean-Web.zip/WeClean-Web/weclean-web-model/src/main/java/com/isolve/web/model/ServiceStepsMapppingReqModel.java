package com.isolve.web.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class ServiceStepsMapppingReqModel {
	
			private static final long serialVersionUID = -7921769110064861087L;
		private Integer flag;
		private Integer serviceid;
		private Integer stepsid;
		private String userid;
		private Integer dmflag;
		private Integer ssmid;
		private Integer start;
		private Integer end;
		private String search;
		private Integer roleid;
}
