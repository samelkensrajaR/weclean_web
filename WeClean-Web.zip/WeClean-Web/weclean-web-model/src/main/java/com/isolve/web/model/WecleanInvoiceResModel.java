package com.isolve.web.model;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class WecleanInvoiceResModel implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4676472487061149367L;
     
	
	private String wecleanname;
	private String addresslin1;
	private String addressline2;
	private String primarycontact;
	private String wecleanservice;
	private String website;
	private String applink;
	private String gst;
	private String imagepath;
}
