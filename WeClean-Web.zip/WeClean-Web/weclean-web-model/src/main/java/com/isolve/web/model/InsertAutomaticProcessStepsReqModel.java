package com.isolve.web.model;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsertAutomaticProcessStepsReqModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long userid;
	private Long customerid;
	private Long orderid; 
	private String remarks;
	List<AutomaticProcessModel> details;

}
