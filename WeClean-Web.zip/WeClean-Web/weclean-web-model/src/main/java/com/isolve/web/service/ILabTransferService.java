package com.isolve.web.service;

import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;

public interface ILabTransferService {

	ResponseModel getLabTransfer(RequestModel requestModel);


	ResponseModel updateLabTransferInitiative(RequestModel requestModel);


	ResponseModel getSampleType();


	ResponseModel getLabMaster(RequestModel requestModel);


	ResponseModel getCourierMaster(RequestModel requestModel);


	ResponseModel getTransferType();


	ResponseModel updateLabTranReceive(RequestModel requestModel);

}
