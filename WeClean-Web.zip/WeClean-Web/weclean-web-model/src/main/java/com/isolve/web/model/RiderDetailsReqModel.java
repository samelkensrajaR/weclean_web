package com.isolve.web.model;

import java.io.Serializable;
import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RiderDetailsReqModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -630276602028066773L;
	private Long riderid;
	private String ridercode;
	private Long userid;
	private String firstname;
	private String lastname;
	private String email;
	private String mobileno;
	private String alternatemobile;
	private Boolean status;
	private String address;
	private String floor;
	private String landmark;
	private Integer start;
	private Integer end;
	private String search;
	private Integer flag;
	private Long ridertypeid;
}
