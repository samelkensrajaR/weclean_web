package com.isolve.web.service;

import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;

public interface IBioReceiveService {

	ResponseModel updateBioReceive(RequestModel requestModel);

}
