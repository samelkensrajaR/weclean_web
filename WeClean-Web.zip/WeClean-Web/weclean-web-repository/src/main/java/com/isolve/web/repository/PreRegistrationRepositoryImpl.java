package com.isolve.web.repository;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.isolve.web.model.PlanCode;
import com.isolve.web.model.PreRegistrationDetailsReqModel;
import com.isolve.web.model.PreRegistrationProcessRequestModel;
import com.isolve.web.model.PreRegistrationRequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.utils.MyObject;
import com.isolve.web.utils.Utils;
import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;
import com.microsoft.sqlserver.jdbc.SQLServerException;

@Repository
public class PreRegistrationRepositoryImpl implements IPreRegistrationRepository {

	@Autowired
	EntityManager entityManager;

	Logger log = LoggerFactory.getLogger(PreRegistrationRepositoryImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel getPreRegistrationDetails(PreRegistrationDetailsReqModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
						
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_GET_PRE_REGISTRATION_DETAILS(?,?,?,?)}");
				
				if (requestModel.getFlag() != null) {
					callableStatement.setInt(1, requestModel.getFlag());
				} else {
					callableStatement.setString(1, null);
				}
				if (requestModel.getCrmno() != null) {
					callableStatement.setString(2, requestModel.getCrmno());
				} else {
					callableStatement.setString(2, null);
				}
				if (requestModel.getHospitalid() != null) {
					callableStatement.setLong(3, requestModel.getHospitalid());
				} else {
					callableStatement.setString(3, null);
				}
				if (requestModel.getUserid() != null) {
					callableStatement.setLong(4, requestModel.getUserid());
				} else {
					callableStatement.setString(4, null);
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();		
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getpreregistrationdeatails", l_lstResult);
			}
			
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				//log.debug(e.getMessage());
			}
		}
		return responseModel;
	}


	@Override
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public	ResponseModel submitPreRegistration(PreRegistrationRequestModel reqModel) throws SQLServerException
 {
		ResponseModel responseModel = new ResponseModel();
		try 
		{	
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
            prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.TIMESTAMP));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.STRUCT));
			prmtrsList.add(new SqlParameter(Types.TIMESTAMP));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			prmtrsList.add(new SqlParameter(Types.VARCHAR));
			
			SQLServerDataTable menuUser = new SQLServerDataTable();
			menuUser.addColumnMetadata("PLAN_CODE", java.sql.Types.VARCHAR);

			for (PlanCode d : reqModel.getCode()) {			
				menuUser.addRow(d.getPlancode());
			}
				Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_INSERT_UPDATE_PRE_REGISTRATION(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
				if (callableStatement.isWrapperFor(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class)) {
					SQLServerCallableStatement cs = callableStatement
							.unwrap(com.microsoft.sqlserver.jdbc.SQLServerCallableStatement.class);
					cs.setResponseBuffering("adaptive");				
					cs.setString(1, reqModel.getCrmno());
					cs.setString(2, reqModel.getOrderid());
					cs.setString(3, reqModel.getPatientfirstname());
					cs.setString(4, reqModel.getPatientlastname());
					cs.setString(5, reqModel.getPrimarycontact());
					cs.setString(6, reqModel.getAlternatecontact());
					cs.setString(7, reqModel.getEmailid());
					cs.setString(8, reqModel.getAddressname());
					cs.setString(9, reqModel.getAddressemail());
					cs.setString(10, reqModel.getAddressmobile());
					cs.setString(11, reqModel.getAddressstreet1());
					cs.setString(12, reqModel.getAddressstreet2());
					if (reqModel.getAddresscity() != null) {
						cs.setInt(13, reqModel.getAddresscity());
					} else {
						cs.setString(13, null);
					}
					if (reqModel.getAddressstate() != null) {
						cs.setInt(14, reqModel.getAddressstate());
					} else {
						cs.setString(14, null);
					}
					cs.setString(15, reqModel.getAddresscountry());
					cs.setString(16, reqModel.getAddresspincode());
					if (reqModel.getPatientage() != null) {
						cs.setInt(17, reqModel.getPatientage());
					} else {
						cs.setString(17, null);
					}
					cs.setTimestamp(18, Utils.LocalDateToTimeStamp(reqModel.getDob()));
					cs.setString(19, reqModel.getServicetype());
					cs.setStructured(20, "dbo.UTT_ORDER_PLANCODE", menuUser);
					cs.setTimestamp(21, Utils.LocalDateToTimeStamp(reqModel.getCollectiondatetime()));
					cs.setString(22, reqModel.getHospitalid());
					cs.setString(23, reqModel.getHospitalname());
					if (reqModel.getDoctorid() != null) {
						cs.setLong(24, reqModel.getDoctorid());
					} else {
						cs.setString(24, null);
					}
					cs.setString(25, reqModel.getDoctorcode());
					cs.setString(26, reqModel.getDoctorname());
					if (reqModel.getGenderid() != null) {
						cs.setInt(27, reqModel.getGenderid());
					} else {
						cs.setString(27, null);
					}
					if (reqModel.getTitleid() != null) {
						cs.setInt(28, reqModel.getTitleid());
					} else {
						cs.setString(28, null);
					}
					if (reqModel.getUserid() != null) {
						cs.setLong(29, reqModel.getUserid());
					} else {
						cs.setString(29, null);
					}
					cs.setString(30, reqModel.getRemarks());
					if (reqModel.getReferid() != null) {
						cs.setInt(31, reqModel.getReferid());
					} else {
						cs.setString(31, null);
					}					
					cs.setString(32, reqModel.getLattitude());
					cs.setString(33, reqModel.getLongitude());
					cs.setString(34, reqModel.getAgeyear());
					cs.setString(35, reqModel.getAgemonth());
					cs.setString(36, reqModel.getAgeday());
					
				}
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("Response", l_lstResult);
			}
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		}
		finally {	
		try {
			jdbcTemplate.getDataSource().getConnection().close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
		System.out.println(responseModel);
	return responseModel;
}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseModel preRegistrationProcess(PreRegistrationProcessRequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		try {
			List prmtrsList = new ArrayList();
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.BIGINT));
			prmtrsList.add(new SqlParameter(Types.INTEGER));
			
			
			Map<String, Object> resultData = jdbcTemplate.call(connection -> {
				CallableStatement callableStatement = connection
						.prepareCall("{call USP_INSERT_UPDATE_PRE_REGISTRATION_PROCESS(?,?,?)}");
				callableStatement.setLong(1, requestModel.getOrderid());
				callableStatement.setLong(2, requestModel.getUserid());
				callableStatement.setInt(3, requestModel.getStatus());
				
				return callableStatement;
			}, prmtrsList);
			Set<String> set = new HashSet<>();
			set = resultData.keySet();
			log.info(set.toString());
			// Create properties
			HashMap<String, Object> properties = new HashMap<>();
			for (String key : set) {
				List<LinkedCaseInsensitiveMap<String>> l_lstResult = (List<LinkedCaseInsensitiveMap<String>>) resultData
						.get(key);
				properties.put("getpreregistrationprocess", l_lstResult);
			}
			
			MyObject object = new MyObject(properties);
			responseModel.setResponseObject(object);
			responseModel.setStatusCode(200);
		} finally {
			try {
				jdbcTemplate.getDataSource().getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
				log.debug(e.getMessage());
			}
		}//log.info("responseModel--"+responseModel);
		return responseModel;
	}


}
	






	