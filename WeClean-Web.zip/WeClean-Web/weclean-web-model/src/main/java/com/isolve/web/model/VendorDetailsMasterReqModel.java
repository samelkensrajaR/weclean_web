package com.isolve.web.model;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class VendorDetailsMasterReqModel implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7373608550742005618L;
    private Long vendorid;
    private String vendorcode;
    private String hosiptalname;
    private String contactpersonname;
    private String primarycontact;
    private String alternatecontact;
    private String emailid;
    private Integer addresstype;
    private String hospitaladdress;
    private Integer accounttypeid;
    private Long approvedby;
    private Date approveddate;
    private String orginated;
    private Integer orginatedtypeid;
    private Long quotationid;
    private String quotationimage;
    private String mouid;
    private String mouimage;
    private String status;
    private Date statusdatetime;
    private String remarks;
    private String address;
    private String city;
    private String state;
    private String pincode;
    private Double invoiceamount;
    private Integer approvedstatus;
    private Integer otpverified;
    private Long mgrapprovedby;
    private Date mgrapproveddate;
    private String quotationfname;
    private String moufname;
    private  String customercode;
    private Integer vendorcreatedby;
    private Integer salescompleted;
    private Integer salescompby;
    private Date salescompdate;
    private String latitude;
    private String longitude;
    private Long userid;
    private Integer flag;
    
    
    
}
