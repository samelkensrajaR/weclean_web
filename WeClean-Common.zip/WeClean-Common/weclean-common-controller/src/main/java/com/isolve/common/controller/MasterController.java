package com.isolve.common.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.isolve.common.model.RequestModel;
import com.isolve.common.model.ResponseModel;
import com.isolve.common.service.IMasterService;
import com.isolve.common.utils.CommonConstants;
import com.isolve.common.utils.Utils;

@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
public class MasterController {

	@Autowired
	private IMasterService iMasterService;

	/**
	 * @author
	 * @Name getStateMaster - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getStateMaster method using to get all state lists.
	 */
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/" + CommonConstants.GET_STATE_MASTER, method = RequestMethod.POST)
	public ResponseEntity<?> getStateMaster(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getStateMaster(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name getCityMaster - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getCityMaster method using to get City list based on State.
	 */
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/" + CommonConstants.GET_CITY_MASTER, method = RequestMethod.POST)
	public ResponseEntity<?> getCityMaster(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getCityMaster(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name getAddressType - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getAddressType method using to get Address type master.
	 */
	@RequestMapping(value = "/" + CommonConstants.GET_ADDRESS_TYPE, method = RequestMethod.GET)
	public ResponseEntity<?> getAddressType(HttpServletRequest request, HttpServletResponse response) {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getAddressType();
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name getPickupType - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getPickupType method using to get pickup type master.
	 */
	@RequestMapping(value = "/" + CommonConstants.GET_PICKUP_TYPE, method = RequestMethod.GET)
	public ResponseEntity<?> getPickupType(HttpServletRequest request, HttpServletResponse response) {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getPickupType();
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name getUserType - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getUserType method using to get User Type master.
	 */
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/" + CommonConstants.GET_USERTYPE, method = RequestMethod.POST)
	public ResponseEntity<?> getUserType(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getUserType(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name getAccountType - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getAccountType method using to get account type master.
	 */
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/" + CommonConstants.GET_ACCOUNTTYPE, method = RequestMethod.POST)
	public ResponseEntity<?> getAccountType(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getAccountType(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name getRole - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getRole method using to get all roles list.
	 */
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/" + CommonConstants.GET_ROLE, method = RequestMethod.POST)
	public ResponseEntity<?> getRole(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getRole(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name getTaskType - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getTaskType method using to get task type master.
	 */
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/" + CommonConstants.GET_TASK_TYPE, method = RequestMethod.POST)
	public ResponseEntity<?> getTaskType(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getTaskType(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name decrypt - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: decrypt method using to decrypt given data.
	 */
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/" + CommonConstants.DECRYPT, method = RequestMethod.POST)
	public ResponseEntity<?> decrypt(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.decrypt(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		return ResponseEntity.ok(responseModel);
	}

	/**
	 * @author
	 * @Name encrypt - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: encrypt method using to encrypt given data.
	 */
	@RequestMapping(value = "/" + CommonConstants.ENCRYPT, method = RequestMethod.POST)
	public ResponseEntity<?> encrypt(HttpServletRequest request, HttpServletResponse response,
			@RequestBody String requestModel) {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.encrypt(requestModel);
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name getgenderDetails - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getgenderDetails method using to get gender list master.
	 */
	@RequestMapping(value = "/" + CommonConstants.GET_GENDER, method = RequestMethod.GET)
	public ResponseEntity<?> getgenderDetails() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getGenderDetails();

		String iv = responseModel.getStatus();
		responseModel.setStatus(null);

		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name getTitleMaster - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getTitleMaster method using to get Title MAster.
	 */
	@RequestMapping(value = "/" + CommonConstants.GET_TITLE_MASTER, method = RequestMethod.GET)
	public ResponseEntity<?> getTitleMaster() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iMasterService.getTitleMaster();

		String iv = responseModel.getStatus();
		responseModel.setStatus(null);

		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}

	/**
	 * @author
	 * @Name getLanguageMaster - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getLanguageMaster method using to get all language names.
	 */
	@RequestMapping(value = "/" + CommonConstants.GET_LANGUAGE_MASTER, method = RequestMethod.POST)
	public ResponseEntity<?> getLanguageMaster(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iMasterService.getLanguageMaster(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
}
