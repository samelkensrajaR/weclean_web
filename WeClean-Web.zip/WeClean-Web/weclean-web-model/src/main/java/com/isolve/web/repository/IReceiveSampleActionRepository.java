package com.isolve.web.repository;

import com.isolve.web.model.ReceiveSampleActionRequestModel;
import com.isolve.web.model.ResponseModel;

public interface IReceiveSampleActionRepository {

	ResponseModel getReceiveSampleAction(ReceiveSampleActionRequestModel reqModel);


}
