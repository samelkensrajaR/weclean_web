package com.isolve.common.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GenerateOTPResponseModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8601731714173728126L;
	private String statusCode;
	private String message;
	private String OTPNo;
	private String MobileNumber;
	private String MINS;
	private String Email;


}
