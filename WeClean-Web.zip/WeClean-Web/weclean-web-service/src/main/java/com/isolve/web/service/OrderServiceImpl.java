package com.isolve.web.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;


import com.fasterxml.jackson.databind.ObjectMapper;

import com.isolve.web.model.AutomaticProcessReqModel;
import com.isolve.web.model.BrandMasterNewReqModel;
import com.isolve.web.model.CallHestoryReqModel;
import com.isolve.web.model.CenterMasterReqModel;
import com.isolve.web.model.ChallanMasterReqModel;
import com.isolve.web.model.CollectItemDetailsModel;
import com.isolve.web.model.ColourMasterNewReqModel;
import com.isolve.web.model.CompanyMasterNewReqModel;
import com.isolve.web.model.ComplaintsReqModel;
import com.isolve.web.model.ConfigurationModel;
import com.isolve.web.model.ConfigurationResponseModel;
import com.isolve.web.model.CustomerDetailsReqModel;
import com.isolve.web.model.DamageMasterNewReqModel;
import com.isolve.web.model.DeliveryModeReqModel;
import com.isolve.web.model.DispatchDetailsReqModel;
import com.isolve.web.model.DispatchDetailsRequestModel;
import com.isolve.web.model.DoctorDetailsReqModel;
import com.isolve.web.model.DoctorHospitalMappingReqModel;
import com.isolve.web.model.EmailResponseModel;
import com.isolve.web.model.GrommingstandardsReqModel;
import com.isolve.web.model.HospitalstatecityModel;
import com.isolve.web.model.ImageUploadModel;
import com.isolve.web.model.InsertAutomaticProcessStepsReqModel;
import com.isolve.web.model.InsertComplaintsReqModel;
import com.isolve.web.model.InsertRefundReqModel;
import com.isolve.web.model.InsertSlotNewReqModel;
import com.isolve.web.model.ItemMasterNewReqModel;
import com.isolve.web.model.ItemMasterReqModel;
import com.isolve.web.model.NewOrderResModel;
import com.isolve.web.model.OrderDetailsReqModel;
import com.isolve.web.model.OrderSummaryImageReqModel;
import com.isolve.web.model.OrdersummaryPdf;
import com.isolve.web.model.ParamedicDetailsReqModel;
import com.isolve.web.model.PaymentInvoiceResModel;
import com.isolve.web.model.PaymentStatusReqModel;
import com.isolve.web.model.PickupDetailsByItemsReqModel;
import com.isolve.web.model.PickupDetailsReqModel;
import com.isolve.web.model.PickupRescheduleReqModel;
import com.isolve.web.model.PinCodeMappingModel;
import com.isolve.web.model.PincodeMasterReqModel;
import com.isolve.web.model.ProcessStatusReqModel;
import com.isolve.web.model.ProcessStepsByServiceIdReqModel;
import com.isolve.web.model.QrcodeDetailsReqModel;
import com.isolve.web.model.ReceiveDtailsExportReqModel;
import com.isolve.web.model.ReceiveItemDetailsReqModel;
import com.isolve.web.model.ReceivedItemDetailsReqModel;
import com.isolve.web.model.RequestModel;
import com.isolve.web.model.RescheduleAndCancellationExportReqModel;
import com.isolve.web.model.RescheduleAndCancellationReqModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.model.RiderCancilationReqModel;
import com.isolve.web.model.RiderDetailsReqModel;
import com.isolve.web.model.RiderTimeSlotAvailabilityReqModel;
import com.isolve.web.model.SalesHospitalMappingReqModel;
import com.isolve.web.model.ServiceItemMappingReqModel;
import com.isolve.web.model.ServiceItemMasterNewReqModel;
import com.isolve.web.model.SlotReqModel;
import com.isolve.web.model.SocietyDetailsReqModel;
import com.isolve.web.model.SocietyReqModel;
import com.isolve.web.model.StainMasterNewReqModel;
import com.isolve.web.model.TemplateDetailsReqModel;
import com.isolve.web.model.TestProductMappingReqModel;
import com.isolve.web.model.TrackRiderDetailsReqModel;
import com.isolve.web.model.UpdateSocietyReqModel;
import com.isolve.web.model.UpdateWalletConfigurationReqModel;
import com.isolve.web.model.VendorDetailsMasterReqModel;
import com.isolve.web.model.VendorVisitTimeMappingReqModel;
import com.isolve.web.model.VendorVisitTimeReqModel;
import com.isolve.web.model.VisitTimeReqModel;
import com.isolve.web.model.WalletConfigurationReqModel;
import com.isolve.web.model.WebDashBoardDetails;
import com.isolve.web.model.WebDelierySlotsModel;
import com.isolve.web.repository.IMasterRepository;
import com.isolve.web.repository.IOrderRepository;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;
@Service
public class OrderServiceImpl implements IOrderSevice {

	@Autowired
	public IOrderRepository iOrderRepository;

	@Value("${encryptsecretkey}")
	private String encryptsecretkey;
	
	@Autowired
	private TemplateEngine templateEngine;
	
	@Value("${azureconnectionstring}")
	private String azureconnectionstring;

	private ObjectMapper objectMapper = new ObjectMapper();

	Logger log = LoggerFactory.getLogger(OrderServiceImpl.class);

	

	@Override
	public ResponseModel getTrainingVideosDetails(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			GrommingstandardsReqModel societyDetailsReqModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), GrommingstandardsReqModel.class);
			
			responsemodel = iOrderRepository.getTrainingVideosDetails(societyDetailsReqModel);
		} catch (Exception e) {			
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}		
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}
	
	@Override
	public ResponseModel insertupdateTrainingVideos(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		//log.info("hexIv : "+ requestModel.getExtraVariable());
		try {
			GrommingstandardsReqModel grommingstandardsReqModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey,requestModel.getExtraVariable()), GrommingstandardsReqModel.class);
			//log.info(CommonConstants.INSERT_UPDATE_SOCITY+ grommingstandardsReqModel);
			
			if (grommingstandardsReqModel.getVideoblob() != null) {
				String 	imagePath=Utils.saveVideo (grommingstandardsReqModel.getVideoblob(),String.valueOf("TrainingVideos" + Utils.getCurDateTime()),
					 azureconnectionstring);
				
				grommingstandardsReqModel.setVideourl(imagePath);
				System.out.println("imagePath" + imagePath);
			}
			
			else {
				grommingstandardsReqModel.setImagepath(null);	
			}
			responseModel = iOrderRepository.insertupdateTrainingVideos(grommingstandardsReqModel);
			System.out.println("imageUrl" + grommingstandardsReqModel.getImagepath());
			
		} catch (Exception e) {			
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}	
		
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}
	
	
	@Override
	public ResponseModel getgrommingstandardsdetailsExports(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			GrommingstandardsReqModel societyDetailsReqModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), GrommingstandardsReqModel.class);
			
			responsemodel = iOrderRepository.getgrommingstandardsdetailsExports(societyDetailsReqModel);
		} catch (Exception e) {			
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}		
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}
	
	
	
	@Override
	public ResponseModel getTrainingVideosDetailsExports(RequestModel requestModel) {

		ResponseModel model = new ResponseModel();
		ResponseModel responsemodel = new ResponseModel();
		log.info(CommonConstants.ENCRYPTSECRETKEY+ encryptsecretkey);
		try {
			GrommingstandardsReqModel societyDetailsReqModel = objectMapper.readValue(Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()), GrommingstandardsReqModel.class);
			
			responsemodel = iOrderRepository.getTrainingVideosDetailsExports(societyDetailsReqModel);
		} catch (Exception e) {			
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}		
		try {
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responsemodel), encryptsecretkey,iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;

	}
	
	
}
