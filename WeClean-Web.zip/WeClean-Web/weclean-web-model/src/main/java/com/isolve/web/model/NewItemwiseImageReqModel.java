package com.isolve.web.model;

import java.io.Serializable;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewItemwiseImageReqModel implements Serializable{
	
	private static final long serialVersionUID = -142108461205089462L;
	
	
	private  Long orderid;	
	private Integer serviceid;
	private Integer itemid;
	private String qrcode;
	private String imagepath;
	
	
}
