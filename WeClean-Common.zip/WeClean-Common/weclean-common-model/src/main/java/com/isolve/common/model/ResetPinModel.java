package com.isolve.common.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResetPinModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2878684479334013232L;
	private String 	user_id;
	private String 	lang_id;
	private String 	password;

}
