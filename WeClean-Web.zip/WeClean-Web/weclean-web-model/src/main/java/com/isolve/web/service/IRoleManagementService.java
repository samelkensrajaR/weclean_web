package com.isolve.web.service;

import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;

public interface IRoleManagementService {

	ResponseModel getRoleTargets();

	ResponseModel getRoles();

	ResponseModel saveTargetActionRole(RequestModel requestModel);


	ResponseModel getRoleActionForSpecificId(RequestModel requestModel);

	ResponseModel getUserRolePermission(RequestModel requestModel);

	ResponseModel getroleuseroleservicesteps(RequestModel requestModel);

}
