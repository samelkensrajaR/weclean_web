package com.isolve.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.service.IReportService;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@RestController
@CrossOrigin(value = "*",maxAge = 3600)
@RequestMapping(value = "/"+CommonConstants.REPORT)
public class ReportController {
	
	@Autowired
	private IReportService iReportService;
	
	@RequestMapping(value = "/"+CommonConstants.GET_APP_USAGE_STATUS_REPORT, method = RequestMethod.POST)
		public ResponseEntity<?> getAppUsageStatusReport(HttpServletRequest request, HttpServletResponse response,
				@RequestBody RequestModel requestModel)
		{		
			ResponseModel responseModel = new ResponseModel();
			final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
			if (Utils.isNotNullCheck(hexIV)) {
				requestModel.setExtraVariable(hexIV);
				responseModel = iReportService.getAppUsageStatusReport(requestModel);
			} else {
				responseModel.setStatusCode(response.SC_BAD_REQUEST);
				responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
			}
			String iv = responseModel.getStatus();
			responseModel.setStatus(null);
			return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
		}
@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_CASH_COLLECTION_TRACK_REPORT, method = RequestMethod.POST)
	public ResponseEntity<?> getCashCollectionTrackReport(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
			{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iReportService.getCashCollectionTrackReport(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	


@RequestMapping(value = "/"+CommonConstants. GET_CENTERWISE_SAMPLE_COLLECTION_STATUS_REPORT, method = RequestMethod.POST)
public ResponseEntity<?>  getCenterwiseSampleCollectionStatusReport(HttpServletRequest request, HttpServletResponse response,
		@RequestBody RequestModel requestModel)
{		
	ResponseModel responseModel = new ResponseModel();
	final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
	if (Utils.isNotNullCheck(hexIV)) {
		requestModel.setExtraVariable(hexIV);
		responseModel = iReportService. getCenterwiseSampleCollectionStatusReport(requestModel);
	} else {
		responseModel.setStatusCode(response.SC_BAD_REQUEST);
		responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
	}
	String iv = responseModel.getStatus();
	responseModel.setStatus(null);
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}


@RequestMapping(value = "/"+CommonConstants. GET_PARAMEDIC_TAT_REPORT, method = RequestMethod.POST)
public ResponseEntity<?>  getParamedicTatReport(HttpServletRequest request, HttpServletResponse response,
		@RequestBody RequestModel requestModel)
{		
	ResponseModel responseModel = new ResponseModel();
	final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
	if (Utils.isNotNullCheck(hexIV)) {
		requestModel.setExtraVariable(hexIV);
		responseModel = iReportService. getParamedicTatReport(requestModel);
	} else {
		responseModel.setStatusCode(response.SC_BAD_REQUEST);
		responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
	}
	String iv = responseModel.getStatus();
	responseModel.setStatus(null);
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}

@RequestMapping(value = "/"+CommonConstants. GET_BEATVSVISIT_COMPLIANCE_TRACKER_REPORT, method = RequestMethod.POST)
public ResponseEntity<?>  getBeatvsVisitComplianceTrackerReport(HttpServletRequest request, HttpServletResponse response,
		@RequestBody RequestModel requestModel)
{		
	ResponseModel responseModel = new ResponseModel();
	final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
	if (Utils.isNotNullCheck(hexIV)) {
		requestModel.setExtraVariable(hexIV);
		responseModel = iReportService.getBeatvsVisitComplianceTrackerReport(requestModel);
	} else {
		responseModel.setStatusCode(response.SC_BAD_REQUEST);
		responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
	}
	String iv = responseModel.getStatus();
	responseModel.setStatus(null);
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
@SuppressWarnings("static-access")
@RequestMapping(value = "/"+CommonConstants. VIEW_REPORTS, method = RequestMethod.POST)
public ResponseEntity<?>  viewReports(HttpServletRequest request, HttpServletResponse response,
		@RequestBody RequestModel requestModel)
{		
	ResponseModel responseModel = new ResponseModel();
	final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
	if (Utils.isNotNullCheck(hexIV)) {
		requestModel.setExtraVariable(hexIV);
		responseModel = iReportService.viewReports(requestModel);
	} else {
		responseModel.setStatusCode(response.SC_BAD_REQUEST);
		responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
	}
	String iv = responseModel.getStatus();
	responseModel.setStatus(null);
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}

@RequestMapping(value = "/"+CommonConstants.GET_ORDER_HANDOVER_TYPE, method = RequestMethod.GET)
public ResponseEntity<?> getOrderHandOverType()
{		
	ResponseModel responseModel = new ResponseModel();
	responseModel = iReportService.getOrderHandOverType();
	String iv = responseModel.getStatus();
	responseModel.setStatus(null);
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}

@RequestMapping(value = "/"+CommonConstants.HEALTHY, method = RequestMethod.GET)
public ResponseEntity<?> healthy()
{		
	ResponseModel responseModel = new ResponseModel();
	responseModel = iReportService.getOrderHandOverType();
	String iv = responseModel.getStatus();
	responseModel.setStatus(null);
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}

@RequestMapping(value = "/"+CommonConstants.GET_PENDING_REPORTS, method = RequestMethod.GET)
public ResponseEntity<?> getPendingReports()
{		
	ResponseModel responseModel = new ResponseModel();
	responseModel = iReportService.getPendingReports();
	String iv = responseModel.getStatus();
	responseModel.setStatus(null);
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
@SuppressWarnings("static-access")
@RequestMapping(value = "/"+CommonConstants. GET_REPOSITORY_REPORTS, method = RequestMethod.POST)
public ResponseEntity<?>   getRepositoryReports(HttpServletRequest request, HttpServletResponse response,
		@RequestBody RequestModel requestModel)
{		
	ResponseModel responseModel = new ResponseModel();
	final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
	if (Utils.isNotNullCheck(hexIV)) {
		requestModel.setExtraVariable(hexIV);
		responseModel = iReportService. getRepositoryReports(requestModel);
	} else {
		responseModel.setStatusCode(response.SC_BAD_REQUEST);
		responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
	}
	String iv = responseModel.getStatus();
	responseModel.setStatus(null);
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}


@SuppressWarnings("static-access")
@RequestMapping(value = "/"+CommonConstants.GET_REPORT_MASTER, method = RequestMethod.POST)
public ResponseEntity<?>  getReportMaster(HttpServletRequest request, HttpServletResponse response,
		@RequestBody RequestModel requestModel)
{		
	ResponseModel responseModel = new ResponseModel();
	final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
	if (Utils.isNotNullCheck(hexIV)) {
		requestModel.setExtraVariable(hexIV);
		responseModel = iReportService.getReportMaster(requestModel);
	} else {
		responseModel.setStatusCode(response.SC_BAD_REQUEST);
		responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
	}
	String iv = responseModel.getStatus();
	responseModel.setStatus(null);
	return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
}
}



