# Summary

Date : 2023-08-18 13:21:55

Directory d:\\flyway\\WeClean-Web

Total : 346 files,  47373 codes, 1854 comments, 6074 blanks, all 55301 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Java | 268 | 30,525 | 1,417 | 5,008 | 36,950 |
| Log | 44 | 15,215 | 0 | 974 | 16,189 |
| YAML | 18 | 637 | 68 | 56 | 761 |
| JSON | 1 | 452 | 300 | 1 | 753 |
| XML | 7 | 362 | 41 | 15 | 418 |
| HTML | 1 | 133 | 28 | 10 | 171 |
| Diff | 1 | 18 | 0 | 1 | 19 |
| Markdown | 1 | 16 | 0 | 4 | 20 |
| Java Properties | 5 | 15 | 0 | 5 | 20 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 346 | 47,373 | 1,854 | 6,074 | 55,301 |
| . (Files) | 2 | 194 | 5 | 10 | 209 |
| azure-pipelines | 5 | 292 | 24 | 50 | 366 |
| logs | 1 | 356 | 0 | 30 | 386 |
| manifests | 8 | 216 | 44 | 0 | 260 |
| weclean-web-application | 47 | 14,972 | 3 | 962 | 15,937 |
| weclean-web-application (Files) | 1 | 50 | 0 | 0 | 50 |
| weclean-web-application\\logs | 43 | 14,859 | 0 | 944 | 15,803 |
| weclean-web-application\\logs (Files) | 1 | 101 | 0 | 5 | 106 |
| weclean-web-application\\logs\\archived | 42 | 14,758 | 0 | 939 | 15,697 |
| weclean-web-application\\src | 2 | 60 | 3 | 17 | 80 |
| weclean-web-application\\src\\main | 2 | 60 | 3 | 17 | 80 |
| weclean-web-application\\src\\main\\java | 1 | 23 | 0 | 10 | 33 |
| weclean-web-application\\src\\main\\java\\com | 1 | 23 | 0 | 10 | 33 |
| weclean-web-application\\src\\main\\java\\com\\isolve | 1 | 23 | 0 | 10 | 33 |
| weclean-web-application\\src\\main\\java\\com\\isolve\\web | 1 | 23 | 0 | 10 | 33 |
| weclean-web-application\\src\\main\\resources | 1 | 37 | 3 | 7 | 47 |
| weclean-web-application\\target | 1 | 3 | 0 | 1 | 4 |
| weclean-web-application\\target\\maven-archiver | 1 | 3 | 0 | 1 | 4 |
| weclean-web-controller | 16 | 4,318 | 326 | 408 | 5,052 |
| weclean-web-controller (Files) | 2 | 470 | 316 | 1 | 787 |
| weclean-web-controller\\src | 13 | 3,845 | 10 | 406 | 4,261 |
| weclean-web-controller\\src\\main | 13 | 3,845 | 10 | 406 | 4,261 |
| weclean-web-controller\\src\\main\\java | 13 | 3,845 | 10 | 406 | 4,261 |
| weclean-web-controller\\src\\main\\java\\com | 13 | 3,845 | 10 | 406 | 4,261 |
| weclean-web-controller\\src\\main\\java\\com\\isolve | 13 | 3,845 | 10 | 406 | 4,261 |
| weclean-web-controller\\src\\main\\java\\com\\isolve\\web | 13 | 3,845 | 10 | 406 | 4,261 |
| weclean-web-controller\\src\\main\\java\\com\\isolve\\web\\controller | 13 | 3,845 | 10 | 406 | 4,261 |
| weclean-web-controller\\target | 1 | 3 | 0 | 1 | 4 |
| weclean-web-controller\\target\\maven-archiver | 1 | 3 | 0 | 1 | 4 |
| weclean-web-model | 220 | 5,611 | 832 | 2,194 | 8,637 |
| weclean-web-model (Files) | 1 | 9 | 16 | 0 | 25 |
| weclean-web-model\\src | 218 | 5,599 | 816 | 2,193 | 8,608 |
| weclean-web-model\\src\\main | 218 | 5,599 | 816 | 2,193 | 8,608 |
| weclean-web-model\\src\\main\\java | 218 | 5,599 | 816 | 2,193 | 8,608 |
| weclean-web-model\\src\\main\\java\\com | 218 | 5,599 | 816 | 2,193 | 8,608 |
| weclean-web-model\\src\\main\\java\\com\\isolve | 218 | 5,599 | 816 | 2,193 | 8,608 |
| weclean-web-model\\src\\main\\java\\com\\isolve\\web | 218 | 5,599 | 816 | 2,193 | 8,608 |
| weclean-web-model\\src\\main\\java\\com\\isolve\\web\\config | 2 | 85 | 13 | 23 | 121 |
| weclean-web-model\\src\\main\\java\\com\\isolve\\web\\model | 177 | 3,427 | 413 | 1,108 | 4,948 |
| weclean-web-model\\src\\main\\java\\com\\isolve\\web\\repository | 18 | 515 | 0 | 349 | 864 |
| weclean-web-model\\src\\main\\java\\com\\isolve\\web\\service | 18 | 334 | 0 | 318 | 652 |
| weclean-web-model\\src\\main\\java\\com\\isolve\\web\\utils | 3 | 1,238 | 390 | 395 | 2,023 |
| weclean-web-model\\target | 1 | 3 | 0 | 1 | 4 |
| weclean-web-model\\target\\maven-archiver | 1 | 3 | 0 | 1 | 4 |
| weclean-web-repository | 20 | 14,455 | 556 | 1,607 | 16,618 |
| weclean-web-repository (Files) | 1 | 16 | 0 | 1 | 17 |
| weclean-web-repository\\src | 18 | 14,436 | 556 | 1,605 | 16,597 |
| weclean-web-repository\\src\\main | 18 | 14,436 | 556 | 1,605 | 16,597 |
| weclean-web-repository\\src\\main\\java | 18 | 14,436 | 556 | 1,605 | 16,597 |
| weclean-web-repository\\src\\main\\java\\com | 18 | 14,436 | 556 | 1,605 | 16,597 |
| weclean-web-repository\\src\\main\\java\\com\\isolve | 18 | 14,436 | 556 | 1,605 | 16,597 |
| weclean-web-repository\\src\\main\\java\\com\\isolve\\web | 18 | 14,436 | 556 | 1,605 | 16,597 |
| weclean-web-repository\\src\\main\\java\\com\\isolve\\web\\repository | 18 | 14,436 | 556 | 1,605 | 16,597 |
| weclean-web-repository\\target | 1 | 3 | 0 | 1 | 4 |
| weclean-web-repository\\target\\maven-archiver | 1 | 3 | 0 | 1 | 4 |
| weclean-web-service | 27 | 6,959 | 64 | 813 | 7,836 |
| weclean-web-service (Files) | 1 | 54 | 1 | 1 | 56 |
| weclean-web-service\\src | 25 | 6,902 | 63 | 811 | 7,776 |
| weclean-web-service\\src\\main | 25 | 6,902 | 63 | 811 | 7,776 |
| weclean-web-service\\src\\main\\java | 19 | 6,640 | 35 | 795 | 7,470 |
| weclean-web-service\\src\\main\\java\\com | 19 | 6,640 | 35 | 795 | 7,470 |
| weclean-web-service\\src\\main\\java\\com\\isolve | 19 | 6,640 | 35 | 795 | 7,470 |
| weclean-web-service\\src\\main\\java\\com\\isolve\\web | 19 | 6,640 | 35 | 795 | 7,470 |
| weclean-web-service\\src\\main\\java\\com\\isolve\\web\\service | 19 | 6,640 | 35 | 795 | 7,470 |
| weclean-web-service\\src\\main\\resources | 6 | 262 | 28 | 16 | 306 |
| weclean-web-service\\src\\main\\resources (Files) | 5 | 129 | 0 | 6 | 135 |
| weclean-web-service\\src\\main\\resources\\templates | 1 | 133 | 28 | 10 | 171 |
| weclean-web-service\\target | 1 | 3 | 0 | 1 | 4 |
| weclean-web-service\\target\\maven-archiver | 1 | 3 | 0 | 1 | 4 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)