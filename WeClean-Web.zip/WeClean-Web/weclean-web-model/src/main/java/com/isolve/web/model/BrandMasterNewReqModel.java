package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BrandMasterNewReqModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer flag;
	private String brandname;
	private String brandcode;
	private String userid;
	private Integer bmflag;
	private String discription;
	private Integer bmid;
	private String imagepath;
	private Integer start;
	private Integer end;
	private String search;
	

}
