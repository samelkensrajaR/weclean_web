package com.isolve.web.model;

import java.io.Serializable;
import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DamageMasterNewReqModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer flag;
	private String damagename;
	private String categoryid;
	private String userid;
	private Integer dmflag;
	private String discription;
	private Integer dmid;
	private Integer start;
	private Integer end;
	private String search;
}
