package com.isolve.web.controller;

import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
public class ApplicationController {
		@RequestMapping("/welcome")
	  public String welcome(Map<String, Object> model) {	 
	      return "Welcome WeClean Web..!!";
	      }
	    }
