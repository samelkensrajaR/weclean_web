package com.isolve.web.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class RepeatCollectionResponseModel 
{
	@Id
	private Integer orderid;
	private String crm_id;
	private String kit_box_id;
	private String patient_name;
	private String age;
	private String client_name;
	private String paramedic_name;
	private String pickup_type;
	private Date pickup_time;
	private Date lab_received;
	private String phoneno;
	private String emailid;
	private String billing_address;
	private String shipping_address;
	private String paramedic_mobile;
	private String paramedic_email;
	private Date repeat_pickup_initiated;
	private Date repeat_pickup_completed;
	private String status;
	private String test_name;
	private String lc_or_enrolement_id;
}
