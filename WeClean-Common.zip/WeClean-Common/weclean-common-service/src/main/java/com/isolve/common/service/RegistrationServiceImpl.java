package com.isolve.common.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isolve.common.model.ConfigurationModel;
import com.isolve.common.model.GenerateOTPForgotPassResModel;
import com.isolve.common.model.RegistrationDetailsReqModel;
import com.isolve.common.model.RequestModel;
import com.isolve.common.model.ResponseModel;
import com.isolve.common.model.VerifyRegisterUserOtp;
import com.isolve.common.repository.IRegistrationRepository;
import com.isolve.common.utils.SendEmail;
import com.isolve.common.utils.Utils;
import com.isolve.common.model.LableMasterFinalResponseModel;
import com.isolve.common.model.LableMasterRequestModel;

@Service
public class RegistrationServiceImpl implements IRegistrationService {

	@Autowired
	private IRegistrationRepository iRegistrationRepository;

	private ObjectMapper objectMapper = new ObjectMapper();

	@Value("${encryptsecretkey}")
	private String encryptsecretkey;

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	SendEmail sendEmail;

	/**
	 * @author
	 * @Name registrationDetails - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: registrationDetails method using to insert sign up details for Web
	 */
	@Override
	public ResponseModel registrationDetails(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel model = new ResponseModel();

		try {
			String decrypt = Utils.decrypt(requestModel.getPayload(), encryptsecretkey,
					requestModel.getExtraVariable());
			RegistrationDetailsReqModel reqModel = objectMapper.readValue(decrypt, RegistrationDetailsReqModel.class);

			responseModel = iRegistrationRepository.registrationDetails(reqModel);
			String iv = Utils.randomKey(16);
			model.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(responseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

	/**
	 * @author
	 * @Name registerUserGenerateOtp - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: registerUserGenerateOtp method using to generate OTP for Customer and
	 *       Rider
	 */
	@Override
	public ResponseModel registerUserGenerateOtp(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel configResponse = new ResponseModel();
		GenerateOTPForgotPassResModel otpResponseModel = new GenerateOTPForgotPassResModel();

		try {
			VerifyRegisterUserOtp otpRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					VerifyRegisterUserOtp.class);
			otpResponseModel = iRegistrationRepository.registerUserGenerateOtp(otpRequestModel);
			// String responseJsonString =
			// Utils.sendSMS(msgurl,method,otpResponseModel,msg_type,userid,auth_scheme,password,v,format);
			if (otpResponseModel.getIsNewUser() != null) {
				if (otpResponseModel.getStatusCode().equalsIgnoreCase("200")) {
					if (otpRequestModel.getFlag() == 1) {
						configResponse = iRegistrationRepository.getConfiguration();
					} else {
						configResponse = iRegistrationRepository.getRiderConfiguration();
					}
					ConfigurationModel configurationModel = (ConfigurationModel) configResponse.getResponseObject();
					if (otpRequestModel.getEmail() != null) {
						configurationModel.setLC_CM_PURPOSE(otpResponseModel.getOTPNo());
						Utils.sendMail(configurationModel, otpRequestModel.getEmail());
					}

					if (otpRequestModel.getMobile() != null) {
						// String finalurl = configurationModel.getLC_CM_SMS_API().replaceAll("number",
						// "91"+otpResponseModel.getMobileNumber()).replaceAll("message",
						// otpResponseModel.getOTPNo());
						String finalurl = otpResponseModel.getOTPNo();// .replaceAll("number",
																		// "91"+otpResponseModel.getMobileNumber());
						ResponseEntity<String> responseEntity;
						responseEntity = restTemplate.getForEntity(finalurl, String.class);
						String responseJsonString = responseEntity.getBody();
						if (responseJsonString != null) {
							System.out.println("resr" + otpResponseModel);
						}
					}
					otpResponseModel.setOTPNo(null);
				}
			}
			String iv = Utils.randomKey(16);
			responseModel.setResponseData(
					Utils.encrypt(objectMapper.writeValueAsString(otpResponseModel), encryptsecretkey, iv));

			responseModel.setStatusCode(200);
			responseModel.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			responseModel.setStatusCode(400);
			responseModel.setMessage(e.getMessage());
		}
		return responseModel;
	}

	/**
	 * @author
	 * @Name verifyRegisterUserOtps - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: verifyRegisterUserOtps method using to verify register OTP.
	 */
	@Override
	public ResponseModel verifyRegisterUserOtps(RequestModel requestModel) {
		ResponseModel responseModel = new ResponseModel();
		ResponseModel response = new ResponseModel();

		try {
			VerifyRegisterUserOtp otpRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					VerifyRegisterUserOtp.class);
			response = iRegistrationRepository.verifyRegisterUserOtps(otpRequestModel);
			String iv = Utils.randomKey(16);
			responseModel
					.setResponseData(Utils.encrypt(objectMapper.writeValueAsString(response), encryptsecretkey, iv));
			responseModel.setStatusCode(200);
			responseModel.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			responseModel.setStatusCode(400);
			responseModel.setMessage(e.getMessage());
		}
		return responseModel;
	}

	/**
	 * @author
	 * @Name getLableMaster - method
	 * @param request, response, requestModel
	 * @return response from db side
	 * @exp: getLableMaster method using to get Lable MAster.
	 */
	@Override
	public ResponseModel getLableMaster(RequestModel requestModel) {
		LableMasterFinalResponseModel finalResponseModel = new LableMasterFinalResponseModel();
		ResponseModel model = new ResponseModel();
		try {
			LableMasterRequestModel lableMasterRequestModel = objectMapper.readValue(
					Utils.decrypt(requestModel.getPayload(), encryptsecretkey, requestModel.getExtraVariable()),
					LableMasterRequestModel.class);

			finalResponseModel = iRegistrationRepository.getLableMaster(lableMasterRequestModel);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		try {
			String jsonStr = objectMapper.writeValueAsString(finalResponseModel);
			// log.debug("jsonStr : " + jsonStr);
			String iv = Utils.randomKey(16);
			model.setResponseData(
					Utils.encrypt(objectMapper.writeValueAsString(finalResponseModel), encryptsecretkey, iv));
			model.setStatusCode(200);
			model.setStatus(iv);
		} catch (Exception e) {
			e.printStackTrace();

			model.setStatusCode(400);
			model.setMessage(e.getMessage());
		}
		return model;
	}

}
