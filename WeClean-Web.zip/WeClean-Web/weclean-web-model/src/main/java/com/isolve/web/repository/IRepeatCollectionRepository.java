package com.isolve.web.repository;

import java.util.List;

import com.isolve.web.model.RepeatCollectionRequestModel;
import com.isolve.web.model.RepeatCollectionResponseModel;

public interface IRepeatCollectionRepository 
{
	public List<RepeatCollectionResponseModel> getRepeatCollection(
			RepeatCollectionRequestModel repeatCollectionRequestModel);
}
