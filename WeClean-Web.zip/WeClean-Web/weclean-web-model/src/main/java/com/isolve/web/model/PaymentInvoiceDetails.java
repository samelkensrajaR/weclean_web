package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentInvoiceDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8877207270122497223L;

	private Integer status;
	private String message;
	private String username;
	private String mobileno;
	private String invoicecode;
	private String paymentmode;
	private String pickupdate;
	private String deliverydate;
	private String address;
	private String customer_gst_no;

	private String subtotal;
	private String coupon;
	private String pickupcharges;
	private String scheduled_delivery_charges;
	private String net_total;
	private String cgst;
	private String sgst;
	private String tax;
	private String grand_total;
	private String discount;
	private String quickdelivery;
	private String deliverycharges;
	private String roundoff;
}
