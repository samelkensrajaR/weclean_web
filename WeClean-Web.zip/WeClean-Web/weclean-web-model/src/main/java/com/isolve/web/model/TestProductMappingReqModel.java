package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TestProductMappingReqModel implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7373608550742005618L;
    private Integer testid;
    private String testcode;
    private String testname;
    private Double testmaxprice;
    private Double testminprice;
    private String plancode;
    private String precondition;
    private String planname;
    private String sampletype;
    private Integer productid;
    private Long userid;
    private Integer Flag;
    private String productcode;
    private Long status;
    

}
