package com.isolve.common.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class TechDayStartTimeModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5334443052816447585L;

	private Integer technician_id;
	private Integer lang_id;
	private String 	date;
	private String 	time;
	private String 	tech_latitude;
	private String  tech_longitude;
	
}
