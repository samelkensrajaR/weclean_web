package com.isolve.web.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ServiceItemMappingReqModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer flag;
	private Integer serviceid;
	private Integer itemid;
	private String userid;
	private Integer smm_flag;
	private Long amount;
	private Integer smmid;
	private Integer start;
	private Integer end;
	private String search;
	
	

}
