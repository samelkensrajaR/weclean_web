package com.isolve.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.isolve.web.model.RequestModel;
import com.isolve.web.model.ResponseModel;
import com.isolve.web.service.IRosterParamedicService;
import com.isolve.web.utils.CommonConstants;
import com.isolve.web.utils.Utils;

@RestController
@CrossOrigin(value = "*",maxAge = 3600)
public class RosterParamedicController 
{
	@Autowired
	private IRosterParamedicService iRosterParamedicService;


	@RequestMapping(value = "/"+CommonConstants.GET_ROSTER_AGENT, method = RequestMethod.GET)
	public ResponseEntity<?> getParamedicDetails() {
		ResponseModel responseModel = new ResponseModel();
		responseModel = iRosterParamedicService.getRosterAgent();		
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}


	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GETROSTERDETUSER, method = RequestMethod.POST)
	public ResponseEntity<?> getRosterDetUser(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iRosterParamedicService.getRosterDetUser(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);

	}

	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GETROSTERRIDER, method = RequestMethod.GET)
	public ResponseEntity<?> getRosterRider()
	{		
		ResponseModel responseModel = new ResponseModel();
		responseModel = iRosterParamedicService.getRosterRider();
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}


	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GETROSTERTYPE, method = RequestMethod.GET)
	public ResponseEntity<?> getRosterType()
	{		
		ResponseModel responseModel = new ResponseModel();
		responseModel = iRosterParamedicService.getRosterType();
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}


	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GETROSTERINSERTUPDATE, method = RequestMethod.POST)
	public ResponseEntity<?> getRosterInsertUpdate(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iRosterParamedicService.getRosterInsertUpdate(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.DELETEROSTER, method = RequestMethod.POST)
	public ResponseEntity<?> deleteRoster(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iRosterParamedicService.deleteRoster(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}
	
	
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/"+CommonConstants.GET_ROSTER_DET_USER_WITHDATE, method = RequestMethod.POST)
	public ResponseEntity<?> getRosterDetUserWithDate(HttpServletRequest request, HttpServletResponse response,
			@RequestBody RequestModel requestModel)
	{		
		ResponseModel responseModel = new ResponseModel();
		final String hexIV = request.getHeader(CommonConstants.CLIENT_SECRET);		
		if (Utils.isNotNullCheck(hexIV)) {
			requestModel.setExtraVariable(hexIV);
			responseModel = iRosterParamedicService.getRosterDetUserWithDate(requestModel);
		} else {
			responseModel.setStatusCode(response.SC_BAD_REQUEST);
			responseModel.setMessage(CommonConstants.CLIENT_SECRET_NOT_FOUND);
		}
		String iv = responseModel.getStatus();
		responseModel.setStatus(null);
		return ResponseEntity.ok().header(CommonConstants.CLIENT_SECRET, iv).body(responseModel);
	}


}
