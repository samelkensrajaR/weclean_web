package com.isolve.common.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class CancelReasonResModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7480413253373867727L;
	@Id	
	private String LC_C_ID;
	private String LC_C_REASON;

	
}
